class PokeBattle_Battler
  # Streamlining of Minior
  def pbShieldsUp?
    if isConst?(species,PBSpecies,:MINIOR)
      if isConst?(ability,PBAbilities,:SHIELDSDOWN)
        if self.form==6
          return true
        else
          return false
        end
      else
        return false
      end
    else
      return false      
    end    
  end

  def pbIcicleTributeBypassActive?
    return @battle.icicleTributeBypass==true
  end
  # End of Minior streamlining

#===============================================================================
# Status
#===============================================================================
  def pbCanStatus?(showMessages=true,selfsleep=false,ignorespritz=false)
    return true if pbIcicleTributeBypassActive?
    if !selfsleep && pbOwnSide.effects[PBEffects::Safeguard]>0 && !(@battle.battlers[@battle.lastMoveUser]).hasWorkingAbility(:INFILTRATOR) && !(PBMoveData.new(@battle.lastMoveUsed).function==0x21B && @battle.battlers[@battle.lastMoveUser].hp < (0.5 * @battle.battlers[@battle.lastMoveUser].totalhp).floor)
      @battle.pbDisplay(_INTL("{1}'s team is protected by Safeguard!",pbThis)) if showMessages
      return false
    end
    if ($fefieldeffect == 3) && !isAirborne? # Misty Field only
      @battle.pbDisplay(_INTL("Misty Terrain prevents {1} from being inflicted by status!",pbThis(true))) if showMessages
      return false
    end
    if $fefieldeffect == 32 && hasWorkingItem(:AMULETCOIN) # Dragon's Den
      @battle.pbDisplay(_INTL("Amulet Coin prevents {1} from being inflicted by status on Dragon's Den!",pbThis(true))) if showMessages
      return false
    end
    if $fefieldeffect == 38 && effects[PBEffects::Obstruct] # Dimensional Field
      @battle.pbDisplay(_INTL("Dimensional Field obstructs {1} from being inflicted by status!",pbThis(true))) if showMessages
      return false
    end
    if effects[PBEffects::Spritz] == 1 && !ignorespritz
      @battle.pbDisplay(_INTL("{1}'s spritz prevents it from being inflicted by status!",pbThis)) if showMessages
      return false
    end
    if !selfsleep && hasWorkingAbility(:PURIFYINGSALT)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents status conditions!",pbThis,PBAbilities.getName(self.ability))) if showMessages
      return false
    end
    return true
  end
  
#===============================================================================
# Sleep
#===============================================================================
  def pbCanSleep?(showMessages=true,selfsleep=false,ignorestatus=false)
    tribute_icicle = pbIcicleTributeBypassActive?
    return false if isFainted?
    return false if !tribute_icicle && !pbCanStatus?(showMessages,selfsleep)
    if (!ignorestatus && status==PBStatuses::SLEEP) || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1)
      @battle.pbDisplay(_INTL("{1} is already asleep!",pbThis)) if showMessages
      return false
    end
    if !selfsleep && !ignorestatus && status!=0
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && ((!selfsleep && (status!=0 || damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?))) || pbShieldsUp?)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && hasWorkingAbility(:WORLDOFNIGHTMARES)
      @battle.pbDisplay(_INTL("{1}'s dreams jolted them right back up!",pbThis)) if showMessages
      return false
    end
    if !tribute_icicle && !hasWorkingAbility(:SOUNDPROOF)
      @battle.eachActiveBattlerIndex do |i|
        if @battle.battlers[i].effects[PBEffects::Uproar]>0 || @battle.battlers[i].effects[PBEffects::FeverPitch]==true
          @battle.pbDisplay(_INTL("But the uproar kept {1} awake!",pbThis(true))) if showMessages
          return false
        end
      end 
    end
    if !tribute_icicle && (hasWorkingAbility(:INSOMNIA) ||
       hasWorkingAbility(:SWEETVEIL)) && !self.moldbroken
         abilityname=PBAbilities.getName(self.ability)
         @battle.pbDisplay(_INTL("{1} stayed awake using its {2}!",pbThis,abilityname)) if showMessages
        return false
    end
    sweet_veil_holder = tribute_icicle ? nil : otherSameSideAbilityHolder(:SWEETVEIL)
    if sweet_veil_holder && !(self.moldbroken)
      abilityname=PBAbilities.getName(sweet_veil_holder.ability)
      @battle.pbDisplay(_INTL("{1} stayed awake using its ally's {2}!",pbThis,abilityname)) if showMessages
      return false
    end 
    if !tribute_icicle && $fefieldeffect == 1
      if !isAirborne?
        @battle.pbDisplay(_INTL("The electricity jolted {1} awake!",pbThis)) if showMessages
        return false
      end
    end
    return true
  end

  def pbCanSleepYawn?
    return false if status!=0 || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1)
    return false if !pbCanStatus?()
    if !isConst?(ability,PBAbilities,:SOUNDPROOF)
      @battle.eachActiveBattlerIndex do |i|
        return false if @battle.battlers[i].effects[PBEffects::Uproar]>0
        return false if @battle.battlers[i].effects[PBEffects::FeverPitch]==true
      end
    end
    if ((hasWorkingAbility(:INSOMNIA) || hasWorkingAbility(:SWEETVEIL)) &&
        !self.moldbroken) || pbShieldsUp?
      return false
    end
    sweet_veil_holder = otherSameSideAbilityHolder(:SWEETVEIL)
    if sweet_veil_holder && !(self.moldbroken)
      abilityname=PBAbilities.getName(sweet_veil_holder.ability)
      @battle.pbDisplay(_INTL("{1} stayed awake using its ally's {2}!",pbThis,abilityname))
      return false
    end 
    if $fefieldeffect == 1 || @battle.field.effects[PBEffects::ElectricTerrain]>0
      if !isAirborne?
        @battle.pbDisplay(_INTL("The electricity jolted {1} awake!",pbThis)) #if showMessages
        return false
      end
    end
    return true
  end

  def pbSleep(turns=1) #pk code
    self.status=PBStatuses::SLEEP
    self.statusCount=turns+1 #pk code
    if $fefieldeffect==40
      if opposingAbilityHolder(:SHADOWTAG)
        self.statusCount=4
      end
    end
    pbCancelMoves
    @battle.pbCommonAnimation("Sleep",self,nil)
    pbCheckZenModeOnSleep
  end

  def pbSleepSelf(duration=-1)
    self.status=PBStatuses::SLEEP
    if duration>0
      self.statusCount=duration
    else
      self.statusCount=2 #pk code
    end
    pbCancelMoves
    @battle.pbCommonAnimation("Sleep",self,nil)
    pbCheckZenModeOnSleep
  end

  def pbCheckZenModeOnSleep
    return if !isConst?(species,PBSpecies,:DARMANITAN) || !hasWorkingAbility(:ZENMODE)
    firstTransformation=(form==0 || form==2)
    pbCureStatus(false)
    if firstTransformation
      self.form+=1
      @effects[PBEffects::ZenModeSleep]=true
      pbUpdate(false)
      @battle.scene.pbChangePokemon(self,pokemon)
    end
    @battle.pbDisplay(_INTL("{1}'s Zen Mode roused it!",pbThis))
  end

#===============================================================================
# Poison
#===============================================================================
  def pbCanPoison?(showMessages=true,toxicorb=false)
    tribute_icicle = pbIcicleTributeBypassActive?
    return false if isFainted?
    return false if !tribute_icicle && !pbCanStatus?(showMessages)
    if status==PBStatuses::POISON
      @battle.pbDisplay(_INTL("{1} is already poisoned.",pbThis)) if showMessages
      return false
    end
    if self.status!=0
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && (self.status!=0 || damagestate.substitute && toxicorb==false || (effects[PBEffects::Substitute]>0 && toxicorb==false && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?) || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1) || pbShieldsUp?)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && ((pbHasType?(:POISON) || pbHasType?(:STEEL)) && !(self.corroded)) && !hasWorkingItem(:RINGTARGET)
      @battle.pbDisplay(_INTL("It doesn't affect {1}...",pbThis(true))) if showMessages
      return false
    end   
    if !tribute_icicle && (hasWorkingAbility(:IMMUNITY) ||
       (hasWorkingAbility(:PASTELVEIL) && $fefieldeffect!=45)) && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents poisoning!",pbThis,PBAbilities.getName(self.ability))) if showMessages
        return false
    end
    pastel_veil_holder = tribute_icicle ? nil : otherSameSideAbilityHolder(:PASTELVEIL)
    if pastel_veil_holder && $fefieldeffect!=45 && !(self.moldbroken)
      abilityname=PBAbilities.getName(pastel_veil_holder.ability)
      @battle.pbDisplay(_INTL("{1} stayed healthy using its ally's {2}!",pbThis,abilityname)) if showMessages
      return false
    end
    return true
  end

  def pbCanPoisonSynchronize?(opponent)
    return false if isFainted?
    return false if !pbCanStatus?()     
    if (pbHasType?(:POISON) || pbHasType?(:STEEL)) && !hasWorkingItem(:RINGTARGET)
      @battle.pbDisplay(_INTL("{1}'s {2} had no effect on {3}!",
         opponent.pbThis,PBAbilities.getName(opponent.ability),pbThis(true)))
      return false
    end   
    return false if self.status!=0 || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1)
    return false if pbShieldsUp?
    if hasWorkingAbility(:IMMUNITY) || hasWorkingAbility(:PASTELVEIL)
          @battle.pbDisplay(_INTL("{1}'s {2} prevents {3}'s {4} from working!",
          pbThis,PBAbilities.getName(self.ability),
          opponent.pbThis(true),PBAbilities.getName(opponent.ability)))
      return false
    end
    return true
  end

  def pbCanPoisonSpikes?
    return false if isFainted?
    return false if self.status!=0 || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1)
    return false if pbHasType?(:POISON) || pbHasType?(:STEEL)
    return false if hasWorkingAbility(:IMMUNITY)
    return false if hasWorkingAbility(:PASTELVEIL)
    return false if pbShieldsUp?
    return false if pbOwnSide.effects[PBEffects::Safeguard]>0 && !(@battle.battlers[@battle.lastMoveUser]).hasWorkingAbility(:INFILTRATOR)    
    return false if ($fefieldeffect == 3 || @battle.field.effects[PBEffects::MistyTerrain]>0)
    return true
  end

  def pbPoison(attacker,toxic=false)
    self.status=PBStatuses::POISON
    if toxic
      self.statusCount=1
      self.effects[PBEffects::Toxic]=0
    else
      self.statusCount=0
    end
    if self.index!=attacker.index
      @battle.synchronize[0]=self.index
      @battle.synchronize[1]=attacker.index
      @battle.synchronize[2]=PBStatuses::POISON
    end
    @battle.pbCommonAnimation("Poison",self,nil)
  end

#===============================================================================
# Burn
#===============================================================================
  def pbCanBurn?(showMessages=true)
    tribute_icicle = pbIcicleTributeBypassActive?
    return false if isFainted?
    return false if !tribute_icicle && !pbCanStatus?(showMessages)
#### KUROTSUNE - 028 - START  #### JERICHO - 002 - START    
    if !tribute_icicle && hasWorkingAbility(:WATERBUBBLE) && !moldbroken
      @battle.pbDisplay(_INTL("{1} is protected by its Water Bubble!",pbThis)) if showMessages
      return false
    end        
#### KUROTSUNE - 028 - END  #### JERICHO - 002 - END
    if !tribute_icicle && hasWorkingItem(:THERMOSUIT)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents burns!",pbThis,PBItems.getName(self.item))) if showMessages
      return false
    end
    if self.status==PBStatuses::BURN
      @battle.pbDisplay(_INTL("{1} already has a burn.",pbThis)) if showMessages
      return false
    end
    if self.status!=0
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && (self.status!=0 || damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?) || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1) || pbShieldsUp?)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && pbHasType?(:FIRE) && !hasWorkingItem(:RINGTARGET)
       @battle.pbDisplay(_INTL("It doesn't affect {1}...",pbThis(true))) if showMessages
       return false
    end
    if !tribute_icicle && hasWorkingAbility(:HEATPROOF) && !self.moldbroken
      @battle.pbDisplay(_INTL("{1}'s {2} prevents burns!",pbThis,PBAbilities.getName(self.ability))) if showMessages
      return false
    end
    return true
  end

  def pbCanBurnFromFireMove?(move,showMessages=true) # Use for status moves only
    return false if isFainted?
    return false if !pbCanStatus?(showMessages)
#### KUROTSUNE - 028 - START  #### JERICHO - 002 - START    
    if hasWorkingAbility(:WATERBUBBLE) && !moldbroken
      @battle.pbDisplay(_INTL("{1} is protected by its Water Bubble!",pbThis)) if showMessages
      return false
    end       
#### KUROTSUNE - 028 - END  #### JERICHO - 002 - END  
    if hasWorkingItem(:THERMOSUIT)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents burns!",pbThis,PBItems.getName(self.item))) if showMessages
      return false
    end
    if self.status==PBStatuses::BURN
      @battle.pbDisplay(_INTL("{1} already has a burn.",pbThis)) if showMessages
      return false
    end     
    if self.status!=0 || damagestate.substitute || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1) || pbShieldsUp?
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if hasWorkingAbility(:FLASHFIRE) && !(self.moldbroken) && isConst?(move.type,PBTypes,:FIRE) && $fefieldeffect!=39
      if !@effects[PBEffects::FlashFire]
        @effects[PBEffects::FlashFire]=true
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Fire power!",pbThis,PBAbilities.getName(self.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!",pbThis,PBAbilities.getName(self.ability),move.name))
      end
      return false
    end
    if pbHasType?(:FIRE) && !hasWorkingItem(:RINGTARGET)
      @battle.pbDisplay(_INTL("It doesn't affect {1}...",pbThis(true))) if showMessages
      return false
    end
    if hasWorkingAbility(:HEATPROOF) && !self.moldbroken
      @battle.pbDisplay(_INTL("{1}'s {2} prevents burns!",pbThis,PBAbilities.getName(self.ability))) if showMessages
      return false
    end
    return true
  end

  def pbCanBurnSynchronize?(opponent)
    return false if isFainted?
    return false if self.status!=0 || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1)
    return false if pbShieldsUp?
    return false if !pbCanStatus?()
#### KUROTSUNE - 028 - START  #### JERICHO - 002 - START    
    if hasWorkingAbility(:WATERBUBBLE) && !moldbroken
      @battle.pbDisplay(_INTL("{1} is protected by its Water Bubble!",pbThis)) if showMessages
      return false
    end       
#### KUROTSUNE - 028 - END  #### JERICHO - 002 - END  
    if pbHasType?(:FIRE) && !hasWorkingItem(:RINGTARGET)
       @battle.pbDisplay(_INTL("{1}'s {2} had no effect on {3}!",
          opponent.pbThis,PBAbilities.getName(opponent.ability),pbThis(true)))
       return false
    end   
    if hasWorkingAbility(:HEATPROOF)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents {3}'s {4} from working!",
      pbThis,PBAbilities.getName(self.ability),
      opponent.pbThis(true),PBAbilities.getName(opponent.ability)))
      return false
    end
    return true
  end

  def pbBurn(attacker)
    self.status=PBStatuses::BURN
    self.statusCount=0
    if self.index!=attacker.index
      @battle.synchronize[0]=self.index
      @battle.synchronize[1]=attacker.index
      @battle.synchronize[2]=PBStatuses::BURN
    end
    @battle.pbCommonAnimation("Burn",self,nil)
  end

#===============================================================================
# Paralyze
#===============================================================================
  def pbCanParalyze?(showMessages=true)
    tribute_icicle = pbIcicleTributeBypassActive?
    return false if isFainted?
    return false if !tribute_icicle && !pbCanStatus?(showMessages)            
    if !tribute_icicle && pbHasType?(:ELECTRIC)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if status==PBStatuses::PARALYSIS
      @battle.pbDisplay(_INTL("{1} is already paralyzed!",pbThis)) if showMessages
      return false
    end
    if self.status!=0
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && (self.status!=0 || damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?) || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1) || pbShieldsUp?)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && hasWorkingAbility(:IMMUNITY) && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents paralysis!",pbThis,PBAbilities.getName(self.ability))) if showMessages
        return false
    end
    return true
  end

  def pbCanParalyzeSynchronize?(opponent)
    return false if self.status!=0 || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1)
    return false if pbShieldsUp?
    return false if !pbCanStatus?()                   
    if pbHasType?(:ELECTRIC)
      return false
    end
    if hasWorkingAbility(:IMMUNITY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents {3}'s {4} from working!",
      pbThis,PBAbilities.getName(self.ability),
      opponent.pbThis(true),PBAbilities.getName(opponent.ability)))
      return false
    end
    return true
  end

  def pbParalyze(attacker)
    self.status=PBStatuses::PARALYSIS
    self.statusCount=0
    if self.index!=attacker.index
      @battle.synchronize[0]=self.index
      @battle.synchronize[1]=attacker.index
      @battle.synchronize[2]=PBStatuses::PARALYSIS
    end
    @battle.pbCommonAnimation("Paralysis",self,nil)
  end

#===============================================================================
# Crushing
#===============================================================================
def pbCanCrush?(showMessages=true)
  return false if isFainted?
  if hasWorkingItem(:PRESSURESUIT)
    @battle.pbDisplay(_INTL("{1}'s suit prevented crushing!",pbThis)) if showMessages
    return false
  end
  if status==PBStatuses::CRUSHED
    @battle.pbDisplay(_INTL("{1} is already crushed!",pbThis)) if showMessages
    return false
  end
  if self.status!=0 || damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?) || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1) || pbShieldsUp?
    @battle.pbDisplay(_INTL("But it failed!")) if showMessages
    return false
  end
  if hasWorkingAbility(:ABYSSAL) && !(self.moldbroken)
    @battle.pbDisplay(_INTL("{1}'s {2} prevents crushing!",pbThis,PBAbilities.getName(self.ability))) if showMessages
    return false
  end
  if pbOwnSide.effects[PBEffects::Safeguard]>0 && !(@battle.battlers[@battle.lastMoveUser]).hasWorkingAbility(:INFILTRATOR) && !(PBMoveData.new(@battle.lastMoveUsed).function==0x21B && @battle.battlers[@battle.lastMoveUser].hp < (0.5 * @battle.battlers[@battle.lastMoveUser].totalhp).floor)
    @battle.pbDisplay(_INTL("{1}'s team is protected by Safeguard!",pbThis)) if showMessages
    return false
  end
  if ($fefieldeffect == 3 || ($fefieldeffect != 40 && @battle.field.effects[PBEffects::MistyTerrain]>0)) && !isAirborne?
    @battle.pbDisplay(_INTL("Misty Terrain prevents {1} from being inflicted by status!",pbThis)) if showMessages
    return false
  end
  if $fefieldeffect == 32 && hasWorkingItem(:AMULETCOIN) # Dragon's Den
    @battle.pbDisplay(_INTL("Amulet Coin prevents {1} from being inflicted by status on Dragon's Den!",pbThis)) if showMessages
    return false
  end
  if $fefieldeffect == 38 && effects[PBEffects::Obstruct]==true # Dimensional Field
    @battle.pbDisplay(_INTL("Dimensional Field obstructs {1} from being inflicted by status!",pbThis)) if showMessages
    return false
  end
  return true
end

def pbCanCrushSynchronize?(opponent)
  return false            
end

def pbCrush(attacker)
  self.status=PBStatuses::CRUSHED
  self.statusCount=0
  if self.index!=attacker.index
    @battle.synchronize[0]=self.index
    @battle.synchronize[1]=attacker.index
    @battle.synchronize[2]=PBStatuses::CRUSHED
  end
end


#===============================================================================
# Freeze
#===============================================================================
  def pbCanFreeze?(showMessages=true)
    tribute_icicle = pbIcicleTributeBypassActive?
    return false if isFainted?
    return false if !tribute_icicle && !pbCanStatus?(showMessages)                   
    if self.status!=0
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if !tribute_icicle && ((@battle.pbWeather==PBWeather::SUNNYDAY && !hasWorkingItem(:UTILITYUMBRELLA)) || self.status!=0 || (isConst?(ability,PBAbilities,:COMATOSE) && $fefieldeffect!=1) ||
      ($fefieldeffect == 33 && $fecounter>0) ||
       hasWorkingItem(:THERMOSUIT) ||
       (pbOwnSide.effects[PBEffects::Safeguard]>0 && !(@battle.battlers[@battle.lastMoveUser]).hasWorkingAbility(:INFILTRATOR) && !(PBMoveData.new(@battle.lastMoveUsed).function==0x21B && @battle.battlers[@battle.lastMoveUser].hp < (0.5 * @battle.battlers[@battle.lastMoveUser].totalhp).floor)) ||
       damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?) || $fefieldeffect == 7 ||
      (pbHasType?(:ICE) && !hasWorkingItem(:RINGTARGET)) && !(self.moldbroken) || pbShieldsUp?)
        return false
    end
    return true
  end

  def pbFreeze
    self.status=PBStatuses::FROZEN
    self.statusCount=0
    @battle.pbCommonAnimation("Frozen",self,nil)
  end

#===============================================================================
# Generalised status displays
#===============================================================================
  def pbContinueStatus(showAnim=true)
    case self.status
      when PBStatuses::SLEEP
        @battle.pbCommonAnimation("Sleep",self,nil)
        @battle.pbDisplay(_INTL("{1} is fast asleep.",pbThis))
      when PBStatuses::POISON
        @battle.pbCommonAnimation("Poison",self,nil)
        @battle.pbDisplay(_INTL("{1} is hurt by poison!",pbThis))
      when PBStatuses::BURN
        @battle.pbCommonAnimation("Burn",self,nil)
        @battle.pbDisplay(_INTL("{1} is hurt by its burn!",pbThis))
      when PBStatuses::PARALYSIS
        @battle.pbCommonAnimation("Paralysis",self,nil)
        @battle.pbDisplay(_INTL("{1} is hurt by its paralysis!",pbThis)) #pk code
      when PBStatuses::FROZEN
        @battle.pbCommonAnimation("Frozen",self,nil)
        @battle.pbDisplay(_INTL("{1} is hurt by the cold!",pbThis)) #pk code
    end
  end

  def pbCureStatus(showMessages=true)
    oldstatus=self.status
    if self.status==PBStatuses::SLEEP
    end
    self.status=0
    self.statusCount=0
    if oldstatus==PBStatuses::SLEEP && self.hasWorkingAbility(:EARLYBIRD)
      @effects[PBEffects::EarlyBirdBoost]=2
    end
    if showMessages
      case oldstatus
        when PBStatuses::SLEEP
          @battle.pbDisplay(_INTL("{1} woke up!",pbThis))
        when PBStatuses::POISON
        when PBStatuses::BURN
        when PBStatuses::PARALYSIS
        when PBStatuses::FROZEN
          @battle.pbDisplay(_INTL("{1} was defrosted!",pbThis))
      end
    end
  end

#===============================================================================
# Confuse
#===============================================================================
  def pbCanConfuse?(showMessages=true)
    tribute_icicle = pbIcicleTributeBypassActive?
    return false if isFainted?
    return false if !tribute_icicle && !pbCanStatus?(showMessages,false,true)
    if effects[PBEffects::Confusion]>0
      @battle.pbDisplay(_INTL("{1} is already confused!",pbThis)) if showMessages
      return false
    end
    if !tribute_icicle && (damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?))
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    # Oblivious prevents confusion
    if !tribute_icicle && hasWorkingAbility(:OBLIVIOUS) && !(self.moldbroken)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents confusion!",pbThis,
         PBAbilities.getName(self.ability))) if showMessages
      return false
    end
    if !tribute_icicle && $fefieldeffect == 20 && pbHasType?(:FIGHTING)
      @battle.pbDisplay(_INTL("{1} broke through the confusion!",pbThis)) if showMessages
      return false
    end
    return true
  end

  def pbCanConfuseSelf?(showMessages=true)
    return false if isFainted?
    return false if !pbCanStatus?(showMessages,true,true)
    if effects[PBEffects::Confusion]>0
      @battle.pbDisplay(_INTL("{1} is already confused!",pbThis)) if showMessages
      return false
    end
    if $fefieldeffect == 20 && pbHasType?(:FIGHTING)
      @battle.pbDisplay(_INTL("{1} broke through the confusion!",pbThis)) if showMessages
      return false
    end
    return true
  end

  def pbConfuseSelf
    if @effects[PBEffects::Confusion]==0
      @effects[PBEffects::Confusion]=3 #pk code
      @battle.pbCommonAnimation("Confusion",self,nil)
      @battle.pbDisplay(_INTL("{1} became confused!",pbThis))
    end
  end

  def pbContinueConfusion
    @battle.pbCommonAnimation("Confusion",self,nil)
    @battle.pbDisplayBrief(_INTL("{1} is confused!",pbThis))
  end

  def pbCureConfusion(showMessages=true)
    @effects[PBEffects::Confusion]=0
    @battle.pbDisplay(_INTL("{1} snapped out of confusion!",pbThis)) if showMessages
  end

#===============================================================================
# Attraction
#===============================================================================
  def pbCanAttract?(attacker,showMessages=true)
    return false if isFainted?
    return false if !attacker
    if @effects[PBEffects::Attract]>=0
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if hasWorkingAbility(:OBLIVIOUS) && !(self.moldbroken) 
      @battle.pbDisplay(_INTL("{1}'s {2} prevents enchantment!",pbThis, #pk code
         PBAbilities.getName(self.ability))) if showMessages
      return false
    end
    return true
  end

  def pbAnnounceAttract(seducer)
    @battle.pbCommonAnimation("Attract",self,nil)
    @battle.pbDisplayBrief(_INTL("{1} is enchanted by {2}!",
       pbThis,seducer.pbThis(true)))
  end

  def pbApplyTimedAttract(attacker,reflected=false)
    @effects[PBEffects::Attract]=attacker.index
    @effects[PBEffects::AttractTurns]=3
    @battle.pbCommonAnimation("Attract",self,nil)
    if reflected
      @battle.pbDisplay(_INTL("{1}'s {2} enchanted {3}!",attacker.pbThis, #pk code
        PBItems.getName(attacker.item),pbThis(true)))
      return
    end
    @battle.pbDisplay(_INTL("{1} became enchanted!",pbThis))
    if hasWorkingItem(:DESTINYKNOT) && attacker.pbCanAttract?(self,false) &&
       !@battle.pbCheckSideAbility(:AROMAVEIL,attacker)
      attacker.pbApplyTimedAttract(self,true)
    end
  end

  def pbCureAttract
    @effects[PBEffects::Attract]=-1
    @effects[PBEffects::AttractTurns]=0
  end

  def pbContinueAttract
    @battle.pbDisplay(_INTL("{1} is enchanted!",pbThis)) #pk code
  end

#===============================================================================
# Blind
#===============================================================================
  def pbCanBlind?(showMessages=true)
    return false if isFainted?
    if effects[PBEffects::Blinded]>0
      @battle.pbDisplay(_INTL("{1} is already blinded!",pbThis)) if showMessages
      return false
    end
    if damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?)
      @battle.pbDisplay(_INTL("But it failed!")) if showMessages
      return false
    end
    if (hasWorkingAbility(:ILLUMINATE) || hasWorkingAbility(:DAZZLING)) && !(self.moldbroken) 
      @battle.pbDisplay(_INTL("{1}'s {2} prevents blinding!",pbThis,PBAbilities.getName(self.ability))) if showMessages
      return false
    end
    return true
  end

#===============================================================================
# Increase stat stages
#===============================================================================
  def pbStatChangeMoveId
    return nil if !@battle || @battle.lastMoveUser < 0
    user=@battle.battlers[@battle.lastMoveUser]
    return nil if !user
    move_id=@battle.lastMoveUsed
    return nil if !move_id || move_id<=0
    begin
      PBMoveData.new(move_id)
    rescue
      return nil
    end
    return move_id
  end

  def pbStatChangeSourceKey(move_id=nil)
    if @battle && @battle.respond_to?(:statChangeSource) && @battle.statChangeSource
      return @battle.statChangeSource
    end
    move_id = nil if move_id && !move_id.is_a?(Integer)
    move_id ||= pbStatChangeMoveId
    return nil if !move_id
    return [:move,move_id]
  end

  def pbDisplayStatCapMessages
    return if @effects[PBEffects::StatCapPendingMessages].empty?

    messages = @effects[PBEffects::StatCapPendingMessages]

    # Group by direction and magnitude
    pos_by_mag = {1 => [], 2 => [], 3 => []}
    neg_by_mag = {1 => [], 2 => [], 3 => []}

    messages.each do |msg|
      mag = msg[:increment] >= 3 ? 3 : msg[:increment]
      stat_name = case msg[:stat]
        when PBStats::ATTACK then "Attack"
        when PBStats::DEFENSE then "Defense"
        when PBStats::SPEED then "Speed"
        when PBStats::SPATK then "Special Attack"
        when PBStats::SPDEF then "Special Defense"
        when PBStats::EVASION then "evasiveness"
        when PBStats::ACCURACY then "accuracy"
      end

      if msg[:direction] == :positive
        pos_by_mag[mag] << stat_name
      else
        neg_by_mag[mag] << stat_name
      end
    end

    # Build the message parts
    parts = []

    # Positive caps
    [3, 2, 1].each do |mag|
      next if pos_by_mag[mag].empty?
      stat_list = pos_by_mag[mag].length == 1 ? pos_by_mag[mag][0] :
                  pos_by_mag[mag][0..-2].join(", ") + ", and " + pos_by_mag[mag][-1]
      adverb = mag == 3 ? "drastically" : (mag == 2 ? "sharply" : nil)
      cap_word = pos_by_mag[mag].length == 1 ? "cap" : "caps"
      if adverb
        parts << "positive #{stat_list} stat #{cap_word} #{adverb} increased"
      else
        parts << "positive #{stat_list} stat #{cap_word} increased"
      end
    end

    # Negative caps
    [3, 2, 1].each do |mag|
      next if neg_by_mag[mag].empty?
      stat_list = neg_by_mag[mag].length == 1 ? neg_by_mag[mag][0] :
                  neg_by_mag[mag][0..-2].join(", ") + ", and " + neg_by_mag[mag][-1]
      adverb = mag == 3 ? "drastically" : (mag == 2 ? "sharply" : nil)
      cap_word = neg_by_mag[mag].length == 1 ? "cap" : "caps"
      if adverb
        parts << "negative #{stat_list} stat #{cap_word} #{adverb} increased"
      else
        parts << "negative #{stat_list} stat #{cap_word} increased"
      end
    end

    # Combine and display
    if parts.length == 1
      @battle.pbDisplay(_INTL("{1}'s {2}!",pbThis,parts[0]))
    elsif parts.length == 2
      @battle.pbDisplay(_INTL("{1}'s {2} and its {3}!",pbThis,parts[0],parts[1]))
    else
      # Join all but last with commas, then add "and" before last
      @battle.pbDisplay(_INTL("{1}'s {2}!",pbThis,parts[0..-2].join(", ") + ", and its " + parts[-1]))
    end

    # Clear pending messages
    @effects[PBEffects::StatCapPendingMessages].clear
  end

  def pbTooHigh?(stat)
    cap = @effects[PBEffects::StatCapPositive][stat] || 0
    # Check if there's a pending stat source that would raise the cap
    stat_source = pbStatChangeSourceKey
    if stat_source
      contributors = @effects[PBEffects::StatCapContributors][stat_source]
      if !contributors || !contributors.has_key?(stat)
        # This source hasn't contributed yet, so it would raise the cap
        # Calculate what the new cap would be (assuming +1 increment by default)
        increment = 1
        if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
          increment = 2
        end
        cap = [cap + increment, 3].min
      end
    end
    if @effects[PBEffects::MultiTurnAttack] == PBMoves::BINDINGWORD # Stats suppressed by binding word
      return @effects[PBEffects::StatChangeHolder][stat]>=cap
    else
      return @stages[stat]>=cap
    end
  end

  def pbCanIncreaseStatStage?(stat,showMessages=false)
    return false if isFainted?
    tribute_icicle = pbIcicleTributeBypassActive?
    cn=@battle.pbCheckGlobalAbility(:CLOUDNINE)
    if cn && !tribute_icicle
      abilityname=PBAbilities.getName(cn.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat boosts!",cn.pbThis,abilityname)) if showMessages
      return false
    end
    if pbTooHigh?(stat)
      if showMessages
        @battle.pbDisplay(_INTL("{1}'s Attack won't go any higher!",pbThis)) if stat==PBStats::ATTACK
        @battle.pbDisplay(_INTL("{1}'s Defense won't go any higher!",pbThis)) if stat==PBStats::DEFENSE
        @battle.pbDisplay(_INTL("{1}'s Speed won't go any higher!",pbThis)) if stat==PBStats::SPEED
        @battle.pbDisplay(_INTL("{1}'s Special Attack won't go any higher!",pbThis)) if stat==PBStats::SPATK
        @battle.pbDisplay(_INTL("{1}'s Special Defense won't go any higher!",pbThis)) if stat==PBStats::SPDEF
        @battle.pbDisplay(_INTL("{1}'s evasiveness won't go any higher!",pbThis)) if stat==PBStats::EVASION
        @battle.pbDisplay(_INTL("{1}'s accuracy won't go any higher!",pbThis)) if stat==PBStats::ACCURACY
      end
      return false
    end
    return true
  end

  def pbIncreaseStatBasic(stat,increment,triggerBigPecks=true)
    stat_source=pbStatChangeSourceKey
    cn=@battle.pbCheckGlobalAbility(:CLOUDNINE)
    return false if cn

    # Cap increment at +3
    increment = [increment, 3].min

    # Check if this source has contributed to the cap yet
    if stat_source
      contributors = @effects[PBEffects::StatCapContributors][stat_source]
      if !contributors || !contributors.has_key?(stat)
        # First time this effect is trying to raise this stat
        # Increase the positive cap (max +3)
        # Account for Simple ability when setting cap
        cap_increment = increment
        if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
          cap_increment *= 2
        end
        current_cap = @effects[PBEffects::StatCapPositive][stat] || 0
        new_cap = [current_cap + cap_increment, 3].min
        @effects[PBEffects::StatCapPositive][stat] = new_cap

        # Add to pending cap messages
        @effects[PBEffects::StatCapPendingMessages] << {
          direction: :positive,
          stat: stat,
          increment: cap_increment
        }

        # Mark this effect as having contributed
        @effects[PBEffects::StatCapContributors][stat_source] ||= {}
        @effects[PBEffects::StatCapContributors][stat_source][stat] = cap_increment
      end
    end

    # Apply Simple ability
    if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
      increment*=2
    end

    # Cap final increment at +3
    increment = [increment, 3].min

    # Now attempt to change the stat within caps (max +3)
    cap = [@effects[PBEffects::StatCapPositive][stat] || 0, 3].min
    oldStage=@stages[stat]
    if @effects[PBEffects::MultiTurnAttack] == PBMoves::BINDINGWORD # Stats suppressed by binding word
      @effects[PBEffects::StatChangeHolder][stat]+=increment
      @effects[PBEffects::StatChangeHolder][stat]=cap if @effects[PBEffects::StatChangeHolder][stat]>cap
    else
      @stages[stat]+=increment
      @stages[stat]=cap if @stages[stat]>cap
    end
    @battle.pbRecordMirrorHerbBoost(self,stat,@stages[stat]-oldStage) if @stages[stat]>oldStage
    if triggerBigPecks && @stages[stat]>oldStage
      opposingLivingBattlers.each do |foe|
        next if !foe.hasWorkingAbility(:BIGPECKS)
        oldDefense=foe.stages[PBStats::DEFENSE]
        @battle.pbWithStatChangeSource([:ability,foe.ability]) do
          foe.pbIncreaseStatBasic(PBStats::DEFENSE,1,false)
        end
        if foe.stages[PBStats::DEFENSE]>oldDefense
          @battle.pbCommonAnimation("StatUp",foe,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!",foe.pbThis,PBAbilities.getName(foe.ability)))
        end
      end
    end
    return true
  end

  #pk code
  unless method_defined?(:azure_move_compat_pbIncreaseStatBasic)
    alias azure_move_compat_pbIncreaseStatBasic pbIncreaseStatBasic
    def pbIncreaseStatBasic(stat,increment,triggerBigPecks=true)
      beforestage=@stages[stat]
      holder=@effects[PBEffects::StatChangeHolder]
      beforestored=holder ? holder[stat] : nil
      ret=azure_move_compat_pbIncreaseStatBasic(stat,increment,triggerBigPecks)
      holder=@effects[PBEffects::StatChangeHolder]
      if @stages[stat]>beforestage ||
         (holder && !beforestored.nil? && holder[stat]>beforestored)
        @azureStatsRaisedThisRound=true
      end
      return ret
    end
  end

# UPDATE 11/29/2013
# Contrary
# calls reduce stat from here if we have contrary
# Added an extra parameter to determine if this was called from reduce stat
# changed from: def pbIncreaseStat(stat,increment,showMessages,moveid=nil,attacker=nil,upanim=true)
  def pbIncreaseStat(stat,increment,showMessages1,moveid=nil,attacker=nil,upanim=true, cont_call=false, showMessages2=true)
    if increment>0 && pbTributeMoveMatches?(attacker,:ZAPTRIBUTE,moveid) && attacker.moves[0].basedamage>0
      increment += 1
    end
    stat_source=pbStatChangeSourceKey(moveid)
    # here we call reduce instead
    if hasWorkingAbility(:CONTRARY) && !cont_call && !(self.moldbroken)
      ret=pbReduceStat(stat,increment,showMessages1,moveid,attacker,upanim,false,true,showMessages2)
      if !ret
        return pbReduceStat(stat,increment,showMessages1,moveid,attacker,upanim,true,true,showMessages2)
      else
        return ret
      end
    end
    # end of update
    arrStatTexts=[]
    if stat==PBStats::ATTACK
      arrStatTexts=[_INTL("{1}'s Attack rose!",pbThis),
         _INTL("{1}'s Attack rose sharply!",pbThis),
         _INTL("{1}'s Attack rose drastically!",pbThis),
         _INTL("{1}'s Attack went way up!",pbThis)]
    elsif stat==PBStats::DEFENSE
      arrStatTexts=[_INTL("{1}'s Defense rose!",pbThis),
         _INTL("{1}'s Defense rose sharply!",pbThis),
         _INTL("{1}'s Defense rose drastically!",pbThis),
         _INTL("{1}'s Defense went way up!",pbThis)]
    elsif stat==PBStats::SPEED
      arrStatTexts=[_INTL("{1}'s Speed rose!",pbThis),
         _INTL("{1}'s Speed rose sharply!",pbThis),
         _INTL("{1}'s Speed rose drastically!",pbThis),
         _INTL("{1}'s Speed went way up!",pbThis)]
    elsif stat==PBStats::SPATK
      arrStatTexts=[_INTL("{1}'s Special Attack rose!",pbThis),
         _INTL("{1}'s Special Attack rose sharply!",pbThis),
         _INTL("{1}'s Special Attack rose drastically!",pbThis),
         _INTL("{1}'s Special Attack went way up!",pbThis)]
    elsif stat==PBStats::SPDEF
      arrStatTexts=[_INTL("{1}'s Special Defense rose!",pbThis),
         _INTL("{1}'s Special Defense rose sharply!",pbThis),
         _INTL("{1}'s Special Defense rose drastically!",pbThis),
         _INTL("{1}'s Special Defense went way up!",pbThis)]
    elsif stat==PBStats::EVASION
      arrStatTexts=[_INTL("{1}'s evasiveness rose!",pbThis),
         _INTL("{1}'s evasiveness rose sharply!",pbThis),
         _INTL("{1}'s evasiveness rose drastically!",pbThis),
         _INTL("{1}'s evasiveness went way up!",pbThis)]
    elsif stat==PBStats::ACCURACY
      arrStatTexts=[_INTL("{1}'s accuracy rose!",pbThis),
         _INTL("{1}'s accuracy rose sharply!",pbThis),
         _INTL("{1}'s accuracy rose drastically!",pbThis),
         _INTL("{1}'s accuracy went way up!",pbThis)]
    else
      return false
    end
    if pbCanIncreaseStatStage?(stat,showMessages1)
      pbIncreaseStatBasic(stat,increment)
      @battle.pbCommonAnimation("StatUp",self,nil) if upanim
      # For message display: if Simple is active, show the doubled increment
      # (The actual stat change with Simple was already handled in pbIncreaseStatBasic)
      message_increment = increment
      if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
        message_increment *= 2
      end
      if message_increment>3
        @battle.pbDisplay(arrStatTexts[3]) if showMessages2
      elsif message_increment==3
        @battle.pbDisplay(arrStatTexts[2]) if showMessages2
      elsif message_increment==2
        @battle.pbDisplay(arrStatTexts[1]) if showMessages2
      else
        @battle.pbDisplay(arrStatTexts[0]) if showMessages2
      end
      return true
    end
    return false
  end

#===============================================================================
# Decrease stat stages
#===============================================================================
  def pbTooLow?(stat)
    cap = @effects[PBEffects::StatCapNegative][stat] || 0
    # Check if there's a pending stat source that would raise the cap
    stat_source = pbStatChangeSourceKey
    if stat_source
      contributors = @effects[PBEffects::StatCapContributors][stat_source]
      if !contributors || !contributors.has_key?(stat)
        # This source hasn't contributed yet, so it would raise the cap
        # Calculate what the new cap would be (assuming -1 increment by default)
        increment = 1
        if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
          increment = 2
        end
        cap = [cap + increment, 6].min
      end
    end
    if @effects[PBEffects::MultiTurnAttack] == PBMoves::BINDINGWORD # Stats suppressed by binding word
      return @effects[PBEffects::StatChangeHolder][stat]<=-cap
    else
      return @stages[stat]<=-cap
    end
  end

  # Tickle (04A) and Memento (0E2) can't use this, but replicate it instead.
  # (Reason is they lower more than 1 stat independently, and therefore could
  # show certain messages twice which is undesirable.)
  def pbCanReduceStatStage?(stat,showMessages=false,selfreduce=false)
    return false if isFainted?
    if !selfreduce && hasWorkingItem(:CLEARAMULET)
      @battle.pbDisplay(_INTL("{1}'s Clear Amulet prevents stat loss!",pbThis)) if showMessages
      return false
    end
    tribute_icicle = pbIcicleTributeBypassActive?
    if !selfreduce && !tribute_icicle
      if damagestate.substitute || (effects[PBEffects::Substitute]>0 && !PBMoveData.new(@battle.lastMoveUsed).isSoundBased?)
        @battle.pbDisplay(_INTL("But it failed!")) if showMessages
        return false
      end
      if pbOwnSide.effects[PBEffects::Mist]>0 && !(@battle.battlers[@battle.lastMoveUser]).hasWorkingAbility(:INFILTRATOR) && !(PBMoveData.new(@battle.lastMoveUsed).function==0x21B && @battle.battlers[@battle.lastMoveUser].hp < (0.5 * @battle.battlers[@battle.lastMoveUser].totalhp).floor)
        @battle.pbDisplay(_INTL("{1} is protected by Mist!",pbThis)) if showMessages
        return false
      end
      if ((hasWorkingAbility(:CLEARBODY) || hasWorkingAbility(:WHITESMOKE) || hasWorkingAbility(:TEMPORALSHIFT)) && !(self.moldbroken)) || hasWorkingAbility(:FULLMETALBODY)
        abilityname=PBAbilities.getName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if stat==PBStats::ATTACK && hasWorkingAbility(:HYPERCUTTER) && !(self.moldbroken)
        abilityname=PBAbilities.getName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Attack loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if stat==PBStats::SPATK && hasWorkingAbility(:EXECUTION) && !(self.moldbroken)
        abilityname=PBAbilities.getName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Special Attack loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if stat==PBStats::DEFENSE && hasWorkingAbility(:BIGPECKS) && !(self.moldbroken)
        abilityname=PBAbilities.getName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!",pbThis,abilityname)) if showMessages
        return false
      end
      if stat==PBStats::ACCURACY && !(self.moldbroken) && hasWorkingAbility(:KEENEYE)
        abilityname=PBAbilities.getName(self.ability)
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Accuracy loss!",pbThis,abilityname)) if showMessages
        return false
      end
      #
    #
    end
    if pbTooLow?(stat)
      if showMessages
        @battle.pbDisplay(_INTL("{1}'s Attack won't go any lower!",pbThis)) if stat==PBStats::ATTACK
        @battle.pbDisplay(_INTL("{1}'s Defense won't go any lower!",pbThis)) if stat==PBStats::DEFENSE
        @battle.pbDisplay(_INTL("{1}'s Speed won't go any lower!",pbThis)) if stat==PBStats::SPEED
        @battle.pbDisplay(_INTL("{1}'s Special Attack won't go any lower!",pbThis)) if stat==PBStats::SPATK
        @battle.pbDisplay(_INTL("{1}'s Special Defense won't go any lower!",pbThis)) if stat==PBStats::SPDEF
        @battle.pbDisplay(_INTL("{1}'s evasiveness won't go any lower!",pbThis)) if stat==PBStats::EVASION
        @battle.pbDisplay(_INTL("{1}'s accuracy won't go any lower!",pbThis)) if stat==PBStats::ACCURACY
      end
      return false
    end
    return true
  end

  def pbReduceStatBasic(stat,increment)
    stat_source=pbStatChangeSourceKey

    # Check if this source has contributed to the cap yet
    if stat_source
      contributors = @effects[PBEffects::StatCapContributors][stat_source]
      if !contributors || !contributors.has_key?(stat)
        # First time this effect is trying to lower this stat
        # Increase the negative cap
        # Account for Simple ability when setting cap
        cap_increment = increment
        if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
          cap_increment *= 2
        end
        current_cap = @effects[PBEffects::StatCapNegative][stat] || 0
        new_cap = [current_cap + cap_increment, 6].min
        @effects[PBEffects::StatCapNegative][stat] = new_cap

        # Add to pending cap messages
        @effects[PBEffects::StatCapPendingMessages] << {
          direction: :negative,
          stat: stat,
          increment: cap_increment
        }

        # Mark this effect as having contributed
        @effects[PBEffects::StatCapContributors][stat_source] ||= {}
        @effects[PBEffects::StatCapContributors][stat_source][stat] = -cap_increment
      end
    end

    # Apply Simple ability
    if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
      increment*=2
    end

    # Now attempt to change the stat within caps
    cap = @effects[PBEffects::StatCapNegative][stat] || 0
    if @effects[PBEffects::MultiTurnAttack] == PBMoves::BINDINGWORD # Stats suppressed by binding word
      @effects[PBEffects::StatChangeHolder][stat]-=increment
      @effects[PBEffects::StatChangeHolder][stat]=-cap if @effects[PBEffects::StatChangeHolder][stat]<-cap
    else
      @stages[stat]-=increment
      @stages[stat]=-cap if @stages[stat]<-cap
    end
    self.statLowered = true
    return true
  end

# UPDATE 11/29/2013
# Contrary
# Call increase stat if we have contrary
# Added another parameter to determine if we called from within increase
# changed from: def pbReduceStat(stat,increment,showMessages,moveid=nil,attacker=nil,downanim=true,selfreduce=false)
  def pbReduceStat(stat,increment,showMessages1=true,moveid=nil,attacker=nil,downanim=true,selfreduce=false, cont_call=false, showMessages2=true, mirrored=false)
    if @tributeDracoSelfDrops && selfreduce && attacker==self && !cont_call && moveid==@tributeDracoSelfDrops[0]
      @tributeDracoSelfDrops[1][stat]+=increment
    end
    if !selfreduce && attacker!=self && hasWorkingItem(:CLEARAMULET)
      @battle.pbDisplay(_INTL("{1}'s Clear Amulet prevents stat loss!",pbThis)) if showMessages1
      return false
    end
    if increment>0 && pbTributeMoveMatches?(attacker,:DREADTRIBUTE,moveid)
      increment += 1
    end
    stat_source=pbStatChangeSourceKey(moveid)
    # no, we don't want to say reduce 5 times - Thunder Raid
    if moveid == 207
      showMessages2 = false
    end
    # here we play uno reverse if we have Mirror Armor
    if hasWorkingAbility(:MIRRORARMOR) && !selfreduce && !mirrored && !(moveid==660)
      if !attacker.nil? 
        if attacker.hp!=0 
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return attacker.pbReduceStat(stat,increment,showMessages1,moveid=nil,self,downanim=true,selfreduce=false, cont_call=false, showMessages2=true, true)
        end
      else
        mirrorTarget = pbPreferredOpposingTarget(self.pbOppositeOpposing)
        if mirrorTarget && mirrorTarget.hp!=0
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return mirrorTarget.pbReduceStat(stat,increment,showMessages1,moveid=nil,self,downanim=true,selfreduce=false, cont_call=false, showMessages2=true, true)
        end
      end
      @battle.pbDisplay(_INTL("{1}'s Mirror Armor blocked the stat drop!", pbThis))
    end
    # here we call increase if we have contrary
    return pbIncreaseStat(stat,increment,showMessages1,moveid,attacker,downanim,true,showMessages2) if hasWorkingAbility(:CONTRARY) && !cont_call && !(self.moldbroken)
    # end of update
    arrStatTexts=[]
    if stat==PBStats::ATTACK
      arrStatTexts=[_INTL("{1}'s Attack fell!",pbThis),
         _INTL("{1}'s Attack harshly fell!",pbThis)] 
    elsif stat==PBStats::DEFENSE
      arrStatTexts=[_INTL("{1}'s Defense fell!",pbThis),
         _INTL("{1}'s Defense harshly fell!",pbThis)]
    #### JERICHO - 018 - START         
    elsif stat==PBStats::SPEED 
      arrStatTexts=[_INTL("{1}'s Speed fell!",pbThis),
         _INTL("{1}'s Speed harshly fell!",pbThis)]  
    #### JERICHO - 018 - END            
    elsif stat==PBStats::SPATK
      arrStatTexts=[_INTL("{1}'s Special Attack fell!",pbThis),
         _INTL("{1}'s Special Attack harshly fell!",pbThis)]
    elsif stat==PBStats::SPDEF
      arrStatTexts=[_INTL("{1}'s Special Defense fell!",pbThis),
         _INTL("{1}'s Special Defense harshly fell!",pbThis)]
    elsif stat==PBStats::EVASION
      arrStatTexts=[_INTL("{1}'s evasiveness fell!",pbThis),
         _INTL("{1}'s evasiveness harshly fell!",pbThis)]
    elsif stat==PBStats::ACCURACY
      arrStatTexts=[_INTL("{1}'s accuracy fell!",pbThis),
         _INTL("{1}'s accuracy harshly fell!",pbThis)]
    else
      return false
    end
    if pbCanReduceStatStage?(stat,showMessages1,selfreduce)
      pbReduceStatBasic(stat,increment)
      if moveid!=207
        @battle.pbCommonAnimation("StatDown",self,nil) if downanim
      end
      # For message display: if Simple is active, show the doubled increment
      # (The actual stat change with Simple was already handled in pbReduceStatBasic)
      message_increment = increment
      if !(self.moldbroken) && (hasWorkingAbility(:SIMPLE))
        message_increment *= 2
      end
      if message_increment>=2
        @battle.pbDisplay(arrStatTexts[1]) if showMessages2
      else
        @battle.pbDisplay(arrStatTexts[0]) if showMessages2
      end
      # end update
      # UPDATE 11/30/2013
      # Defiant
      if !selfreduce && (hasWorkingAbility(:DEFIANT) || @battle.SilvallyCheck(self, "fighting"))
        pbIncreaseStat(PBStats::ATTACK,2,false,nil,nil,true,false,false)
        @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Attack!", pbThis))
        if $fefieldeffect == 44  
          pbIncreaseStat(PBStats::DEFENSE,2,false,nil,nil,true,false,false)  
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Defense!", pbThis))  
        end
      end      
      if !selfreduce && hasWorkingAbility(:COMPETITIVE)      
        pbIncreaseStat(PBStats::SPATK,2,false,nil,nil,true,false,false)
        @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Special Attack!", pbThis))
        if $fefieldeffect == 44  
          pbIncreaseStat(PBStats::SPDEF,2,false,nil,nil,true,false,false)  
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Special Defense!", pbThis))  
        end
      end
      
      # end of update
      return true
    end
    return false
  end

  def pbReduceAttackStatStageIntimidate(opponent)
    return false if isFainted?
    return false if effects[PBEffects::Substitute]>0
    if hasWorkingAbility(:CLEARBODY) || hasWorkingAbility(:WHITESMOKE) ||
       hasWorkingAbility(:HYPERCUTTER) || hasWorkingAbility(:FULLMETALBODY) ||
       hasWorkingAbility(:TEMPORALSHIFT) || hasWorkingAbility(:INNERFOCUS) ||
       hasWorkingAbility(:OBLIVIOUS) || hasWorkingAbility(:EXECUTION)
       hasWorkingAbility(:SCRAPPY)
      abilityname=PBAbilities.getName(self.ability)
      oppabilityname=PBAbilities.getName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!",
         pbThis,abilityname,opponent.pbThis(true),oppabilityname))
      return false
    end
    if pbOwnSide.effects[PBEffects::Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",pbThis))
      return false
    end
    if pbCanReduceStatStage?(PBStats::ATTACK,false)
      pbReduceStat(PBStats::ATTACK,1,false,nil,nil,true,false,false,false)
      oppabilityname=PBAbilities.getName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Attack!",opponent.pbThis,
         oppabilityname,pbThis(true))) if !hasWorkingAbility(:CONTRARY)          
      if hasWorkingAbility(:CONTRARY)           
        @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Attack!",opponent.pbThis,
            oppabilityname,pbThis(true)))  
      end   
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED,false)
        pbIncreaseStat(PBStats::SPEED,pbHeldItemDose,false,nil,nil,true,false,false)
        @battle.pbDisplay(_INTL("{1}'s Adrenaline orb boosts its Speed!",pbThis(true))) 
        pbUseConsumableHeldItem
      end
      if hasWorkingAbility(:RATTLED)
        if pbCanIncreaseStatStage?(PBStats::SPEED)
          pbIncreaseStatBasic(PBStats::SPEED,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!",
            self.pbThis,PBAbilities.getName(self.ability)))
        end
      end
      if hasWorkingItem(:WHITEHERB)
        reducedstats=false
        for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,PBStats::SPATK,PBStats::SPDEF,PBStats::EVASION,PBStats::ACCURACY]
          if self.stages[i]<0
            self.stages[i]=0; reducedstats=true
          end
          if self.effects[PBEffects::StatChangeHolder] && self.effects[PBEffects::StatChangeHolder][i] < 0
            self.effects[PBEffects::StatChangeHolder][i] = 0 ; reducedstats=true
          end
        end
        if reducedstats
          itemname=(self.item==0) ? "" : PBItems.getName(self.item)
          @battle.pbDisplay(_INTL("{1}'s {2} restored its status!",pbThis,itemname))
          pbUseConsumableHeldItem(repeat: true)
        end
      end
      return true
    end
    return false
  end
  
  def pbReduceIlluminate(opponent)
    return false if isFainted?
    return false if effects[PBEffects::Substitute]>0
    if hasWorkingAbility(:CLEARBODY) || hasWorkingAbility(:WHITESMOKE) ||
       hasWorkingAbility(:FULLMETALBODY) || hasWorkingAbility(:TEMPORALSHIFT)
      abilityname=PBAbilities.getName(self.ability)
      oppabilityname=PBAbilities.getName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!",
         pbThis,abilityname,opponent.pbThis(true),oppabilityname))
      return false
    end
    if pbOwnSide.effects[PBEffects::Mist]>0 
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",pbThis))
      return false
    end
    if pbCanReduceStatStage?(PBStats::ACCURACY,false)
      pbReduceStat(PBStats::ACCURACY,1,false,nil,nil,true,false,false,false)
      oppabilityname=PBAbilities.getName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Accuracy!",opponent.pbThis,
         oppabilityname,pbThis(true)))
      return true
    end
    return false
  end

  def pbGetStatName(stat)
    return ["HP","Attack", "Defense", "Sp. Attack", "Sp. Defense", "Speed", "Accuracy", "Evasion"][stat]
  end
  
end
