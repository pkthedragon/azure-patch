#===============================================================================
# ** Game_Variables
#-------------------------------------------------------------------------------
#  This class handles variables. It's a wrapper for the built-in class "Array."
#  Refer to "$game_variables" for the instance of this class.
#===============================================================================

class Game_Variables
  #-----------------------------------------------------------------------------
  # * Object Initialization
  #-----------------------------------------------------------------------------
  def initialize
    @data = []
  end
  #-----------------------------------------------------------------------------
  # * Get Variable
  #     variable_id : variable ID
  #-----------------------------------------------------------------------------
  def [](variable_id)
    variable_id = Variables[variable_id] if variable_id.is_a?(Symbol)
    if variable_id <= 5000 and @data[variable_id] != nil
      return @data[variable_id]
    else
      return 0
    end
  end
  #-----------------------------------------------------------------------------
  # * Set Variable
  #     variable_id : variable ID
  #     value       : the variable's value
  #-----------------------------------------------------------------------------
  def []=(variable_id, value)
    variable_id = Variables[variable_id] if variable_id.is_a?(Symbol)
    if variable_id <= 5000
      old_value = @data[variable_id] || 0
      @data[variable_id] = value
      if variable_id == 695 && value.to_i > old_value.to_i && defined?(pbApplyMysticGimmighoulProgress)
        pbApplyMysticGimmighoulProgress(value)
      end
    end
  end
end

#===============================================================================
# * Hashes for Variable names, in ascending order
#===============================================================================

Variables = {
    Difficulty_Mode:    200,
}
