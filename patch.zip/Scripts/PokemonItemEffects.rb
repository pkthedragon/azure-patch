#===============================================================================
# This script implements items included by default in Pokemon Essentials.
#===============================================================================

#===============================================================================
# UseFromBag handlers
# Return values: 0 = not used
#                1 = used, item not consumed
#                2 = close the Bag to use, item not consumed
#                3 = used, item consumed
#                4 = close the Bag to use, item consumed
#===============================================================================

def pbRepel(item,steps)
  if $PokemonGlobal.repel>0
    Kernel.pbMessage(_INTL("But a repellent's effect still lingers from earlier."))
    return 0
  else
    Kernel.pbMessage(_INTL("{1} used the {2}.",$Trainer.name,PBItems.getName(item)))
    $PokemonGlobal.repel=steps
    return 3
  end
end

ItemHandlers::UseFromBag.add(:REPEL,proc{|item|  pbRepel(item,100)  })

ItemHandlers::UseFromBag.add(:SUPERREPEL,proc{|item|  pbRepel(item,200)  })

ItemHandlers::UseFromBag.add(:MAXREPEL,proc{|item|  pbRepel(item,250)  })

Events.onStepTaken+=proc {
   if $game_player.terrain_tag!=PBTerrain::Ice   # Shouldn't count down if on ice
     if $PokemonGlobal.repel>0
       $PokemonGlobal.repel-=1
       if $PokemonGlobal.repel<=0
#### SARDINES - v17 - START
         if $PokemonBag.pbHasItem?(:REPEL) ||
           $PokemonBag.pbHasItem?(:SUPERREPEL) ||
           $PokemonBag.pbHasItem?(:MAXREPEL)
           if Kernel.pbConfirmMessage(_INTL("The repellent's effects wore off!\r\nWould you like to use another one?"))
             ret=pbChooseItemFromList(_INTL("Which repellent do you want to use?"),1,
            :REPEL,:SUPERREPEL,:MAXREPEL)
             pbUseItem($PokemonBag,ret) if ret>0
           end
         else
           Kernel.pbMessage(_INTL("The repellent's effect wore off!"))
         end
#### SARDINES - v17 - END
       end
     end
   end
}

#ItemHandlers::UseFromBag.add(:BLACKFLUTE,proc{|item|
#   Kernel.pbMessage(_INTL("{1} used the {2}.",$Trainer.name,PBItems.getName(item)))
#   Kernel.pbMessage(_INTL("Wild Pokémon will be repelled."))
#   $PokemonMap.blackFluteUsed=true
#   $PokemonMap.whiteFluteUsed=false
#   next 1
#})

#ItemHandlers::UseFromBag.add(:WHITEFLUTE,proc{|item|
#   Kernel.pbMessage(_INTL("{1} used the {2}.",$Trainer.name,PBItems.getName(item)))
#   Kernel.pbMessage(_INTL("Wild Pokémon will be lured."))
#   $PokemonMap.blackFluteUsed=false
#   $PokemonMap.whiteFluteUsed=true
#   next 1
#})

ItemHandlers::UseFromBag.add(:HONEY,proc{|item|  next 4  })

ItemHandlers::UseFromBag.add(:ESCAPEROPE,proc{|item|
   if $game_player.pbHasDependentEvents?
     Kernel.pbMessage(_INTL("It can't be used when you have someone with you."))
     next 0
   end
   if ($PokemonGlobal.escapePoint rescue false) && $PokemonGlobal.escapePoint.length>0
     next 4 # End screen and consume item
   else
     Kernel.pbMessage(_INTL("Can't use that here."))
     next 0
   end
})

ItemHandlers::UseFromBag.add(:SACREDASH,proc{|item|
   if $Trainer.pokemonCount==0
     Kernel.pbMessage(_INTL("There is no Pokémon."))
     next 0
   end
   revived = 0
   pbFadeOutIn(99999){
      scene=PokemonScreen_Scene.new
      screen=PokemonScreen.new(scene,$Trainer.party)
      screen.pbStartScene(_INTL("Using item..."),false)
      for i in $Trainer.party
       if i.hp<=0 && !i.isEgg?
         revived+=1
         i.heal
         screen.pbDisplay(_INTL("{1}'s HP was restored.",i.name))
       end
     end
     if revived==0
       screen.pbDisplay(_INTL("It won't have any effect."))
     end
     screen.pbEndScene
   }
   next (revived==0) ? 0 : 3
})

# ItemHandlers::UseFromBag.add(:INTERCEPTORWISH,proc{|item|
#    if $game_switches[1408]==false
#       $game_switches[1408]=true
#     next 1
#    else
#       $game_switches[1408]=false
#     next 0
#    end
# })

ItemHandlers::UseFromBag.add(:BICYCLE,proc{|item|
   next pbBikeCheck ? 2 : 0
})

ItemHandlers::UseFromBag.copy(:BICYCLE,:MACHBIKE,:ACROBIKE)

ItemHandlers::UseFromBag.add(:OLDROD,proc{|item|
   terrain=Kernel.pbFacingTerrainTag
   notCliff=$game_map.passable?($game_player.x,$game_player.y,$game_player.direction)
   isSwimming = $PokemonGlobal.respond_to?(:swimming) && $PokemonGlobal.swimming
   # Can fish when: facing water from shore (not surfing/swimming) OR when surfing (but not swimming)
   if ((pbIsWaterTag?(terrain) || pbIsGrimeTag?(terrain)) && !$PokemonGlobal.surfing && !isSwimming && notCliff) ||
      (pbIsWaterTag?(terrain) && $PokemonGlobal.surfing && !isSwimming)
 next 2
   else
     Kernel.pbMessage(_INTL("Can't use that here."))
     next 0
   end
})
ItemHandlers::UseFromBag.copy(:OLDROD,:GOODROD,:SUPERROD)

ItemHandlers::UseFromBag.add(:ITEMFINDER,proc{|item| next 2 })

ItemHandlers::UseFromBag.copy(:ITEMFINDER,:DOWSINGMCHN)

ItemHandlers::UseFromBag.add(:TOWNMAP,proc{|item|
   pbShowMap(-1,false)
   next 1 # Continue
})


ItemHandlers::UseFromBag.add(:GATHERCUBE,proc{|item|
   Kernel.pbMessage(_INTL("Zygarde Cells Found: {1}, Zygarde Cores Found: {2}, Red Essence: {3}",$game_variables[361],$game_variables[362],$game_variables[705]))
   next 1 # Continue
})

ItemHandlers::UseFromBag.add(:COINCASE,proc{|item|
   Kernel.pbMessage(_INTL("Coins: {1}",pbCommaNumber($PokemonGlobal.coins)))
   next 1 # Continue
})

ItemHandlers::UseFromBag.add(:ITEMBELTCONTROLLER,proc{|item|
   pbManageItemBelt
   next 1 # Continue
})

ItemHandlers::UseFromBag.add(:ACHIEVEMENTCARD,proc{|item|
   Kernel.pbMessage(_INTL("AP: {1}",pbCommaNumber($game_variables[526])))
   next 1 # Continue
})

ItemHandlers::UseFromBag.add(:EXPALL,proc{|item|
   $PokemonBag.pbChangeItem(:EXPALL,:EXPALLOFF)
   Kernel.pbMessage(_INTL("The Exp Share All was turned off."))
   next 1
})

ItemHandlers::UseFromBag.add(:EXPALLOFF,proc{|item|
   $PokemonBag.pbChangeItem(:EXPALLOFF,:EXPALL)
   Kernel.pbMessage(_INTL("The Exp Share All was turned on."))
   next 1
})

ItemHandlers::UseFromBag.add(:NULLTRIBUTE, proc { |item|
  current_sym = item.is_a?(Symbol) ? item : (getConstantName(PBItems, item) rescue nil)
  current_sym = current_sym.to_sym if current_sym.is_a?(String)
  current_sym ||= :NULLTRIBUTE
  names, items = pbBuildUnlockedTributeLists(current_sym)
  current_index = items.index(current_sym) || 0
  cmd = Kernel.pbMessage(
    _INTL("Change the Tribute's attunement?"),
    names,
    -1,
    nil,
    current_index
  )
  if cmd < 0 || cmd >= items.length
    Kernel.pbMessage(_INTL("You decided not to change the Tribute."))
    next 0
  end
  new_sym = items[cmd]
  new_id  = getID(PBItems, new_sym)
  old_id  = getID(PBItems, current_sym)
  if new_id == old_id
    Kernel.pbMessage(_INTL("The Tribute's attunement remains the same."))
    next 1
  end
  $PokemonBag.pbChangeItem(old_id, new_id)
  Kernel.pbMessage(_INTL("The Tribute's attunement shifted.", PBItems.getName(new_id)))

  next 1
})

ItemHandlers::UseFromBag.copy(
  :NULLTRIBUTE,
  :MEADOWTRIBUTE,
  :SPLASHTRIBUTE,
  :FLAMETRIBUTE,
  :BLANKTRIBUTE,
  :FISTTRIBUTE,
  :MINDTRIBUTE,
  :ZAPTRIBUTE,
  :ICICLETRIBUTE,
  :DREADTRIBUTE,
  :SPOOKYTRIBUTE
)

ItemHandlers::UseFromBag.add(:GOLDENWINGS,proc{|item|
  next 0 if !pbCheckHiddenMoveSwitch(SWITCHFORFLY,true)
  next 0 if !$PokemonBag.pbHasItem?(:HM02)
  if inPast?
    Kernel.pbMessage(_INTL("You are unable to travel in the past!"))
    next 0
  end
  if $game_player.pbHasDependentEvents?
    Kernel.pbMessage(_INTL("It can't be used when you have someone with you."))
    next 0
  end
  if $game_switches[999]
    Kernel.pbMessage(_INTL("It can't be used while riding a Pokemon."))
    next 0
  end
  if !pbGetMetadata($game_map.map_id,MetadataOutdoor)
    Kernel.pbMessage(_INTL("Can't use that here."))
    next 0
  end
  if $game_switches[1235]
    Kernel.pbMessage(_INTL("Golden items cannot be used at this time."))
    next 0
  end  

  scene=PokemonRegionMapScene.new(-1,false)
  screen=PokemonRegionMap.new(scene)
  ret=screen.pbStartFlyScreen
  if ret
    Kernel.pbMessage(_INTL("{1} used Golden Wings!", $Trainer.name))
    pbFadeOutIn(99999){
      $strengthUsed = false
      $game_temp.player_new_map_id    = ret[0] #$PokemonTemp.flydata[0]
      $game_temp.player_new_x         = ret[1] #$PokemonTemp.flydata[1]
      $game_temp.player_new_y         = ret[2] #$PokemonTemp.flydata[2]
      $game_temp.player_new_direction = 2
      Kernel.pbCancelVehicles
      $PokemonTemp.flydata = nil
      $scene.transfer_player
      $game_map.autoplay
      $game_map.refresh
      $game_variables[298] = 0
    }
    pbEraseEscapePoint
    next 1
  end
  next 0
})

#===============================================================================
# UseOnPokemon handlers
#===============================================================================

ItemHandlers::UseOnPokemon.add(:FIRESTONE,proc{|item,pokemon,scene|
   if item != (PBItems::LINKHEART)
     newspecies=pbCheckEvolution(pokemon,item)
   else
     newspecies=pbTradeCheckEvolution(pokemon,item)
   end
   if (pokemon.isShadow? rescue false)
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   end
   if newspecies<=0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pbFadeOutInWithMusic(99999){
        evo=PokemonEvolutionScene.new
        evo.pbStartScreen(pokemon,newspecies)
        evo.pbEvolution(false)
        evo.pbEndScreen
        Achievements.incrementProgress("STONE_EVOLVE_POKEMON",1)
        scene.pbRefreshAnnotations(proc{|p| pbCheckEvolution(p,item)>0 })
        scene.pbRefresh
     }
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:FIRESTONE, :MALICIOUSARMOR,
   :THUNDERSTONE,:WATERSTONE,:LEAFSTONE,:MOONSTONE, :SUNSTONE,:GALARICAWREATH,:GALARICACUFF,
   :DUSKSTONE,:DAWNSTONE,:SHINYSTONE,:LINKHEART, :APOPHYLLPAN,:BLACKAUGURITE, :AUSPICIOUSARMOR,
   :ICESTONE, :SWEETAPPLE, :TARTAPPLE, :CHIPPEDPOT, :CRACKEDPOT, :XENWASTE, :MASTERPIECETEACUP,
   :NIGHTMAREFUEL, :SYRUPYAPPLE, :PEATBLOCK, :METALALLOY, :UNREMARKABLETEACUP)
   
ItemHandlers::UseOnPokemon.add(:POTION,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,20,scene)
})

ItemHandlers::UseOnPokemon.add(:SUPERPOTION,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,60,scene)
})

ItemHandlers::UseOnPokemon.add(:CHINESEFOOD,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,40,scene)
})

ItemHandlers::UseOnPokemon.add(:HYPERPOTION,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,120,scene)
})

ItemHandlers::UseOnPokemon.add(:ULTRAPOTION,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,200,scene)
})

ItemHandlers::UseOnPokemon.add(:MAXPOTION,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,pokemon.totalhp-pokemon.hp,scene)
})

ItemHandlers::UseOnPokemon.add(:BERRYJUICE,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,20,scene)
})

ItemHandlers::UseOnPokemon.add(:RAGECANDYBAR,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,20,scene)
})

ItemHandlers::UseOnPokemon.add(:SWEETHEART,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,20,scene)
})

ItemHandlers::UseOnPokemon.add(:FRESHWATER,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,30,scene)
})

ItemHandlers::UseOnPokemon.add(:SODAPOP,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,50,scene)
})

ItemHandlers::UseOnPokemon.add(:LEMONADE,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,70,scene)
})

ItemHandlers::UseOnPokemon.add(:STRAWCAKE,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,150,scene)
})

ItemHandlers::UseOnPokemon.add(:VANILLAIC,proc{|item,pokemon,scene|
  if pokemon.hp<=0 || pokemon.isEgg?
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  elsif pokemon.hp==pokemon.totalhp
    scene.pbDisplay(_INTL("It didn't heal but {1} seems happier.",pokemon.name))
    pokemon.changeHappiness("candy")
    next true
  else
    hpgain=pbItemRestoreHP(pokemon,30)
    scene.pbRefresh
    scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.",pokemon.name,hpgain))
    pokemon.changeHappiness("candy")
    next true
  end
  
#   if pbHPItem(pokemon,30,scene)
#     pokemon.changeHappiness("candy")
#     next true
#   end
#   next false
})

ItemHandlers::UseOnPokemon.add(:CHOCOLATEIC,proc{|item,pokemon,scene|
  if pokemon.hp<=0 || pokemon.isEgg?
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  elsif pokemon.hp==pokemon.totalhp
    scene.pbDisplay(_INTL("It didn't heal but {1} seems happier.",pokemon.name))
    pokemon.changeHappiness("candy")
    next true
  else
    hpgain=pbItemRestoreHP(pokemon,70)
    scene.pbRefresh
    scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.",pokemon.name,hpgain))
    pokemon.changeHappiness("candy")
    next true
  end
  
#   if pbHPItem(pokemon,70,scene)
#     pokemon.changeHappiness("candy")
#     next true
#   end
#   next false
})

ItemHandlers::UseOnPokemon.add(:STRAWBIC,proc{|item,pokemon,scene|
  if pokemon.hp<=0 || pokemon.isEgg?
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  elsif pokemon.hp==pokemon.totalhp
    scene.pbDisplay(_INTL("It didn't heal but {1} seems happier.",pokemon.name))
    pokemon.changeHappiness("candy")
    next true
  else
    hpgain=pbItemRestoreHP(pokemon,90)
    scene.pbRefresh
    scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.",pokemon.name,hpgain))
    pokemon.changeHappiness("candy")
    next true
  end

#   if pbHPItem(pokemon,90,scene)
#     pokemon.changeHappiness("candy")
#     next true
#   end
#   next false

})

ItemHandlers::UseOnPokemon.add(:BLUEMIC,proc{|item,pokemon,scene|
  if pokemon.hp<=0 || pokemon.isEgg?
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  elsif pokemon.hp==pokemon.totalhp
    scene.pbDisplay(_INTL("It didn't heal but {1} seems happier.",pokemon.name))
    pokemon.changeHappiness("bluecandy")
    next true
  else
    hpgain=pbItemRestoreHP(pokemon,200)
    scene.pbRefresh
    scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.",pokemon.name,hpgain))
    pokemon.changeHappiness("bluecandy")
    next true
  end
#   if pbHPItem(pokemon,200,scene)
#     pokemon.changeHappiness("bluecandy")
#     next true
#   end
#   next false
})

ItemHandlers::UseOnPokemon.add(:MOOMOOMILK,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,100,scene)
})

ItemHandlers::UseOnPokemon.add(:ORANBERRY,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,10,scene)
})

ItemHandlers::UseOnPokemon.add(:SITRUSBERRY,proc{|item,pokemon,scene|
   next pbHPItem(pokemon,(pokemon.totalhp/4).floor,scene)
})

ItemHandlers::UseOnPokemon.add(:LEVIABERRY,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::CRUSHED
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was uncrushed.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:LEVIABERRY,:DECOMPRESSOR)

ItemHandlers::UseOnPokemon.add(:COCONBERRY,proc{|item,pokemon,scene|
   scene.pbDisplay(_INTL("It won't have any effect."))
   next false
})

ItemHandlers::UseOnPokemon.add(:AWAKENING,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::SLEEP
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} woke up.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:AWAKENING,:CHESTOBERRY,:BLUEFLUTE,:POKEFLUTE)

ItemHandlers::UseOnPokemon.add(:ANTIDOTE,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::POISON
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of its poisoning.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:ANTIDOTE,:PECHABERRY)

ItemHandlers::UseOnPokemon.add(:BURNHEAL,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::BURN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s burn was healed.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:BURNHEAL,:RAWSTBERRY)

ItemHandlers::UseOnPokemon.add(:PARLYZHEAL,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::PARALYSIS
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of paralysis.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:PARLYZHEAL,:CHERIBERRY)

ItemHandlers::UseOnPokemon.add(:ICEHEAL,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::FROZEN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was thawed out.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:ICEHEAL,:ASPEARBERRY)

ItemHandlers::UseOnPokemon.add(:FULLHEAL,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} became healthy.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.copy(:FULLHEAL,
   :LAVACOOKIE,:OLDGATEAU,:CASTELIACONE,:BIGMALASADA,:LUMBERRY,:RAZZTART)

ItemHandlers::UseOnPokemon.add(:FULLRESTORE,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || (pokemon.status==0 && pokemon.hp==pokemon.totalhp)
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     hpgain=pbItemRestoreHP(pokemon,pokemon.totalhp-pokemon.hp)
     pokemon.status=0
     pokemon.statusCount=0
     scene.pbRefresh
     if hpgain>0
       scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.",pokemon.name,hpgain))
     else
       scene.pbDisplay(_INTL("{1} became healthy.",pokemon.name))
     end
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:REVIVE,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=(pokemon.totalhp/2).floor
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:FUNNELCAKE,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=(pokemon.totalhp/2).floor
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:REVIVE,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=1+(pokemon.totalhp/2).floor
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:PEPPERMINT,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::POISON
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of its poisoning.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:CHEWINGGUM,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::PARALYSIS
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of its paralysis.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:REDHOTS,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::FROZEN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} thawed out.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:SALTWATERTAFFY,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::BURN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s burn was healed.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:POPROCKS,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::SLEEP
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} woke up.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:COTTONCANDY,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=1+(pokemon.totalhp/2).floor
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:POKESNAX,proc{|item,pokemon,scene|
   if pokemon.happiness==255
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.changeHappiness("level up")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} ate the Pokesnax happily!",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:MAXREVIVE,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=pokemon.totalhp
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:HERBALTEA,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=pokemon.totalhp
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:ENERGYPOWDER,proc{|item,pokemon,scene|
   if pbHPItem(pokemon,50,scene)
     pokemon.changeHappiness("powder")
     next true
   end
   next false
})

ItemHandlers::UseOnPokemon.add(:ENERGYROOT,proc{|item,pokemon,scene|
   if pbHPItem(pokemon,200,scene)
     pokemon.changeHappiness("Energy Root")
     next true
   end
   next false
})

ItemHandlers::UseOnPokemon.add(:HEALPOWDER,proc{|item,pokemon,scene|
   if pokemon.hp<=0 || pokemon.status==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     pokemon.changeHappiness("powder")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} became healthy.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:REVIVALHERB,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=pokemon.totalhp
     pokemon.changeHappiness("Revival Herb")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})


ItemHandlers::BattleUseOnPokemon.add(:PEPPERMINT,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::POISON
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of its poisoning.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:CHEWINGGUM,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::PARALYSIS
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of its paralysis.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:REDHOTS,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::FROZEN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} thawed out.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:SALTWATERTAFFY,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::BURN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s burn was healed.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:POPROCKS,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::SLEEP
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} woke up.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:COTTONCANDY,proc{|item,pokemon,battler,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=(pokemon.totalhp/2)
     for i in 0...$Trainer.party.length
       if $Trainer.party[i]==pokemon
         battler.pbInitialize(pokemon,i,false) if battler
         break
       end
     end
     pokemon.changeHappiness("candy")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})
ItemHandlers::UseOnPokemon.add(:ETHER,proc{|item,pokemon,scene|
   move=scene.pbChooseMove(pokemon,_INTL("Restore which move?"))
   if move>=0
     if pbRestorePP(pokemon,move,10)==0
       scene.pbDisplay(_INTL("It won't have any effect."))
       next false
     else
      scene.pbDisplay(_INTL("PP was restored."))
      next true
    end
  end
  next false
})

ItemHandlers::UseOnPokemon.copy(:ETHER,:LEPPABERRY)

ItemHandlers::UseOnPokemon.add(:MAXETHER,proc{|item,pokemon,scene|
   move=scene.pbChooseMove(pokemon,_INTL("Restore which move?"))
   if move>=0
     if pbRestorePP(pokemon,move,pokemon.moves[move].totalpp-pokemon.moves[move].pp)==0
       scene.pbDisplay(_INTL("It won't have any effect."))
       next false
     else
       scene.pbDisplay(_INTL("PP was restored."))
       next true
     end
   end
   next false
})

ItemHandlers::UseOnPokemon.add(:ELIXIR,proc{|item,pokemon,scene|
   pprestored=0
   for i in 0...pokemon.moves.length
     pprestored+=pbRestorePP(pokemon,i,10)
   end
   if pprestored==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("PP was restored."))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:ROSETEA,proc{|item,pokemon,scene|
   pprestored=0
   for i in 0...pokemon.moves.length
     pprestored+=pbRestorePP(pokemon,i,10)
   end
   if pprestored==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("PP was restored."))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:MAXELIXIR,proc{|item,pokemon,scene|
   pprestored=0
   for i in 0...pokemon.moves.length
     pprestored+=pbRestorePP(pokemon,i,pokemon.moves[i].totalpp-pokemon.moves[i].pp)
   end
   if pprestored==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("PP was restored."))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:HOPOBERRY,proc{|item,pokemon,scene|
   pprestored=0
   for i in 0...pokemon.moves.length
     pprestored+=pbRestorePP(pokemon,i,2)
   end
   if pprestored==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("PP was restored a little."))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:PPUP,proc{|item,pokemon,scene|
   move=scene.pbChooseMove(pokemon,_INTL("Boost PP of which move?"))
   if move>=0
     if pokemon.moves[move].totalpp==0 || pokemon.moves[move].ppup>=3
       scene.pbDisplay(_INTL("It won't have any effect."))
       next false
     else
       pokemon.moves[move].ppup+=1
       movename=PBMoves.getName(pokemon.moves[move].id)
       scene.pbDisplay(_INTL("{1}'s PP increased.",movename))
       next true
     end
   end
})

ItemHandlers::UseOnPokemon.add(:PPMAX,proc{|item,pokemon,scene|
   move=scene.pbChooseMove(pokemon,_INTL("Boost PP of which move?"))
   if move>=0
     if pokemon.moves[move].totalpp==0 || pokemon.moves[move].ppup>=3
       scene.pbDisplay(_INTL("It won't have any effect."))
       next false
     else
       pokemon.moves[move].ppup=3
       movename=PBMoves.getName(pokemon.moves[move].id)
       scene.pbDisplay(_INTL("{1}'s PP increased.",movename))
       next true
     end
   end
})

ItemHandlers::UseOnPokemon.add(:HPUP,proc{|item,pokemon,scene|
   if pbRaiseIV(pokemon,0)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP IV increased.",pokemon.name))
     pokemon.changeHappiness("vitamin")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:PROTEIN,proc{|item,pokemon,scene|
   if pbRaiseIV(pokemon,1)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Attack IV increased.",pokemon.name))
     pokemon.changeHappiness("vitamin")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:IRON,proc{|item,pokemon,scene|
   if pbRaiseIV(pokemon,2)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Defense IV increased.",pokemon.name))
     pokemon.changeHappiness("vitamin")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:CALCIUM,proc{|item,pokemon,scene|
   if pbRaiseIV(pokemon,4)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Special Attack IV increased.",pokemon.name))
     pokemon.changeHappiness("vitamin")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:ZINC,proc{|item,pokemon,scene|
   if pbRaiseIV(pokemon,5)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Special Defense IV increased.",pokemon.name))
     pokemon.changeHappiness("vitamin")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:CARBOS,proc{|item,pokemon,scene|
   if pbRaiseIV(pokemon,3)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Speed IV increased.",pokemon.name))
     pokemon.changeHappiness("vitamin")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:HEALTHWING,proc{|item,pokemon,scene|
   if pbLowerIV(pokemon,0)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP IV decreased.",pokemon.name))
     pokemon.changeHappiness("wing")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:MUSCLEWING,proc{|item,pokemon,scene|
   if pbLowerIV(pokemon,1)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Attack IV decreased.",pokemon.name))
     pokemon.changeHappiness("wing")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:RESISTWING,proc{|item,pokemon,scene|
   if pbLowerIV(pokemon,2)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Defense IV decreased.",pokemon.name))
     pokemon.changeHappiness("wing")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:GENIUSWING,proc{|item,pokemon,scene|
   if pbLowerIV(pokemon,4)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Special Attack IV decreased.",pokemon.name))
     pokemon.changeHappiness("wing")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:CLEVERWING,proc{|item,pokemon,scene|
   if pbLowerIV(pokemon,5)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Special Defense IV decreased.",pokemon.name))
     pokemon.changeHappiness("wing")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:SWIFTWING,proc{|item,pokemon,scene|
   if pbLowerIV(pokemon,3)==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("{1}'s Speed IV decreased.",pokemon.name))
     pokemon.changeHappiness("wing")
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:PRISONBOTTLE,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:HOOPA) && pokemon.form==0 &&
      pokemon.hp>=0
     pokemon.form=1
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
     next true
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

##################################################################################
# Z Crystals                                                                     #
##################################################################################
ItemHandlers::UseOnPokemon.add(:BUGINIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==6
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:BUGINIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:BUGINIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:DARKINIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==17
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:DARKINIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:DARKINIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:DRAGONIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==16
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:DRAGONIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:DRAGONIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:ELECTRIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==13
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:ELECTRIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:ELECTRIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:FAIRIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==18
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:FAIRIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:FAIRIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:FIGHTINIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==1
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:FIGHTINIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:FIGHTINIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:FIRIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==10
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:FIRIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:FIRIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:FLYINIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==2
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:FLYINIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:FLYINIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:GHOSTIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==7
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:GHOSTIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:GHOSTIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:INTERCEPTZ,proc{|item,pokemon,scene|
   canuse=true   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:INTERCEPTZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:INTERCEPTZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:GRASSIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==12
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:GRASSIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:GRASSIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:GROUNDIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==4
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:GROUNDIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:GROUNDIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:ICIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==15
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:ICIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:ICIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:NORMALIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==0
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:NORMALIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:NORMALIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:POISONIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==3
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:POISONIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:POISONIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:PSYCHIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==14
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:PSYCHIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:PSYCHIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:ROCKIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==5
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:ROCKIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:ROCKIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:STEELIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==8
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:STEELIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:STEELIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:WATERIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.type==11
       canuse=true
     end
   end
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:WATERIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:WATERIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:ALORAICHIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:THUNDERBOLT)
       canuse=true
     end
   end
   if pokemon.species!=26 || pokemon.form!=1
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:ALORAICHIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:ALORAICHIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:DECIDIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:SPIRITSHACKLE)
       canuse=true
     end
   end
   if pokemon.species!=724
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:DECIDIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:DECIDIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:INCINIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:DARKESTLARIAT)
       canuse=true
     end
   end
   if pokemon.species!=727
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:INCINIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:INCINIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:PRIMARIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:SPARKLINGARIA)
       canuse=true
     end
   end
   if pokemon.species!=730
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:PRIMARIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:PRIMARIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:EEVIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:LASTRESORT)
       canuse=true
     end
   end
   if pokemon.species!=133
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:EEVIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:EEVIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:PIKANIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:VOLTTACKLE)
       canuse=true
     end
   end
   if pokemon.species!=25
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:PIKANIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:PIKANIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:SNORLIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:GIGAIMPACT)
       canuse=true
     end
   end
   if pokemon.species!=143
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:SNORLIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:SNORLIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:MEWNIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:PSYCHIC)
       canuse=true
     end
   end
   if pokemon.species!=151
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:MEWNIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:MEWNIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:TAPUNIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:NATURESMADNESS)
       canuse=true
     end
   end
   if !(pokemon.species==785 || pokemon.species==786 || pokemon.species==787 || pokemon.species==788)
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:TAPUNIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:TAPUNIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:MARSHADIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:SPECTRALTHIEF)
       canuse=true
     end
   end
   if pokemon.species!=802
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:MARSHADIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:MARSHADIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:KOMMONIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:CLANGINGSCALES)
       canuse=true
     end
   end
   if pokemon.species!=784
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:KOMMONIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:KOMMONIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})


ItemHandlers::UseOnPokemon.add(:LYCANIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:STONEEDGE)
       canuse=true
     end
   end
   if pokemon.species!=745
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:LYCANIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:LYCANIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:MIMIKIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:PLAYROUGH)
       canuse=true
     end
   end
   if pokemon.species!=778
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:MIMIKIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:MIMIKIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:SOLGANIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:SUNSTEELSTRIKE)
       canuse=true
     end
   end
   if !(pokemon.species==791 || (pokemon.species==800 && pokemon.form==1))
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:SOLGANIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:SOLGANIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:LUNALIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:MOONGEISTBEAM)
       canuse=true
     end
   end
   if !(pokemon.species==792 || (pokemon.species==800 && pokemon.form==2))
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:LUNALIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:LUNALIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})

ItemHandlers::UseOnPokemon.add(:ULTRANECROZIUMZ,proc{|item,pokemon,scene|
   canuse=false   
   for move in pokemon.moves
     if move.id==getID(PBMoves,:PHOTONGEYSER)
       canuse=true
     end
   end
   if pokemon.species!=800 || pokemon.form==0
     canuse=false
   end   
   if canuse
     scene.pbDisplay(_INTL("The {1} will be given to {2} so that it can use its Z-Power!",PBItems.getName(item),pokemon.name))
     if pokemon.item!=0
      itemname=PBItems.getName(pokemon.item)
      scene.pbDisplay(_INTL("{1} is already holding one {2}.\1",pokemon.name,itemname))
      if scene.pbConfirm(_INTL("Would you like to switch the two items?"))   
        if !$PokemonBag.pbStoreItem(pokemon.item)
          scene.pbDisplay(_INTL("The Bag is full. The Pokémon's item could not be removed."))
        else
          pokemon.setItem(:ULTRANECROZIUMZ2)
          scene.pbDisplay(_INTL("The {1} was taken and replaced with the {2}.",itemname,PBItems.getName(item)))
          next true
        end
      end
    else
      pokemon.setItem(:ULTRANECROZIUMZ2)
      scene.pbDisplay(_INTL("{1} was given the {2} to hold.",pokemon.name,PBItems.getName(item)))
      next true      
    end
  else       
    scene.pbDisplay(_INTL("It had no effect."))
    next false
  end
})
##################################################################################
# End of Z Crystals                                                                     #
##################################################################################
 
def pbChangeLevel(pokemon,newlevel,scene)
  newlevel=1 if newlevel<1
  newlevel=PBExperience::MAXLEVEL if newlevel>PBExperience::MAXLEVEL
  if pokemon.level>newlevel
    attackdiff=pokemon.attack
    defensediff=pokemon.defense
    speeddiff=pokemon.speed
    spatkdiff=pokemon.spatk
    spdefdiff=pokemon.spdef
    totalhpdiff=pokemon.totalhp        
    #pkedit
    evpool=80+pokemon.level*8
    evpool=(evpool.div(4))*4 
    evsum=pokemon.ev[0]+pokemon.ev[1]+pokemon.ev[2]+pokemon.ev[4]+pokemon.ev[5]+pokemon.ev[3]
    if evsum==evpool
      count=0
      for i in 0..5
        if pokemon.ev[i]>0 && count<=8
          pokemon.ev[i]-=4
          pokemon.calcStats
          count+=4
        end        
      end
    end
    if evsum==(evpool-4)
      count=0
      for i in 0..5
        if pokemon.ev[i]>4 && count<=4
          pokemon.ev[i]-=4
          pokemon.calcStats
          count+=4
        end        
      end
    end    
    pokemon.level=newlevel
    pokemon.poklevel = newlevel 
    pokemon.calcStats
    scene.pbRefresh
    Kernel.pbMessage(_INTL("{1} was downgraded to Level {2}!",pokemon.name,pokemon.level))
    attackdiff=pokemon.attack-attackdiff
    defensediff=pokemon.defense-defensediff
    speeddiff=pokemon.speed-speeddiff
    spatkdiff=pokemon.spatk-spatkdiff
    spdefdiff=pokemon.spdef-spdefdiff
    totalhpdiff=pokemon.totalhp-totalhpdiff
    pbTopRightWindow(_INTL("Max. HP<r>{1}\r\nAttack<r>{2}\r\nDefense<r>{3}\r\nSp. Atk<r>{4}\r\nSp. Def<r>{5}\r\nSpeed<r>{6}",
       totalhpdiff,attackdiff,defensediff,spatkdiff,spdefdiff,speeddiff))
    pbTopRightWindow(_INTL("Max. HP<r>{1}\r\nAttack<r>{2}\r\nDefense<r>{3}\r\nSp. Atk<r>{4}\r\nSp. Def<r>{5}\r\nSpeed<r>{6}",
       pokemon.totalhp,pokemon.attack,pokemon.defense,pokemon.spatk,pokemon.spdef,pokemon.speed))
  elsif pokemon.level==newlevel
    Kernel.pbMessage(_INTL("{1}'s level remained unchanged.",pokemon.name))
  else
    attackdiff=pokemon.attack
    defensediff=pokemon.defense
    speeddiff=pokemon.speed
    spatkdiff=pokemon.spatk
    spdefdiff=pokemon.spdef
    totalhpdiff=pokemon.totalhp
    oldlevel=pokemon.level
    pokemon.level=newlevel
    pokemon.poklevel = newlevel 
    pokemon.changeHappiness("level up")
    pokemon.calcStats
    scene.pbRefresh
    Kernel.pbMessage(_INTL("{1} was elevated to Level {2}!",pokemon.name,pokemon.level))
    attackdiff=pokemon.attack-attackdiff
    defensediff=pokemon.defense-defensediff
    speeddiff=pokemon.speed-speeddiff
    spatkdiff=pokemon.spatk-spatkdiff
    spdefdiff=pokemon.spdef-spdefdiff
    totalhpdiff=pokemon.totalhp-totalhpdiff
    pbTopRightWindow(_INTL("Max. HP<r>+{1}\r\nAttack<r>+{2}\r\nDefense<r>+{3}\r\nSp. Atk<r>+{4}\r\nSp. Def<r>+{5}\r\nSpeed<r>+{6}",
       totalhpdiff,attackdiff,defensediff,spatkdiff,spdefdiff,speeddiff))
    pbTopRightWindow(_INTL("Max. HP<r>{1}\r\nAttack<r>{2}\r\nDefense<r>{3}\r\nSp. Atk<r>{4}\r\nSp. Def<r>{5}\r\nSpeed<r>{6}",
       pokemon.totalhp,pokemon.attack,pokemon.defense,pokemon.spatk,pokemon.spdef,pokemon.speed))
    movelist=pokemon.getMoveList
    for i in movelist
      if i[0]==pokemon.level          # Learned a new move
        pbLearnMove(pokemon,i[1],true)
      end
    end
    newspecies=pbCheckEvolution(pokemon)
    if newspecies>0
      pbFadeOutInWithMusic(99999){
         evo=PokemonEvolutionScene.new
         evo.pbStartScreen(pokemon,newspecies)
         evo.pbEvolution
         evo.pbEndScreen
      }
    end
  end
end

def IncreaseExp(pokemon, exp, scene)
  newexp=PBExperience.pbAddExperience(pokemon.exp,exp,pokemon.growthrate)
  exp=newexp-pokemon.exp
  oldlevel=pokemon.level

  if exp>0
    scene.pbDisplay(_INTL("{1} gained {2} Exp. Points!",pokemon.name,exp))
    newlevel=PBExperience.pbGetLevelFromExperience(newexp,pokemon.growthrate)
    tempexp=0
    curlevel=pokemon.level
    if newlevel<curlevel
      debuginfo="#{pokemon.name}: #{pokemon.level}/#{newlevel} | #{pokemon.exp}/#{newexp} | gain: #{exp}"
      raise RuntimeError.new(_INTL("The new level ({1}) is less than the Pokémon's\r\ncurrent level ({2}), which shouldn't happen.\r\n[Debug: {3}]",
                             newlevel,curlevel,debuginfo))
      return
    end
    loop do
      # EXP Bar increment
      startexp=PBExperience.pbGetStartExperience(curlevel,pokemon.growthrate)
      endexp=PBExperience.pbGetStartExperience(curlevel+1,pokemon.growthrate)
      tempexp2=(endexp<newexp) ? endexp : newexp
      pokemon.exp=tempexp2
      tempexp1=tempexp2
      curlevel+=1
      if curlevel>newlevel
        pokemon.calcStats 
        break
      end
      attackdiff=pokemon.attack
      defensediff=pokemon.defense
      speeddiff=pokemon.speed
      spatkdiff=pokemon.spatk
      spdefdiff=pokemon.spdef
      totalhpdiff=pokemon.totalhp
      pokemon.poklevel = newlevel 
      pokemon.changeHappiness("level up")
      pokemon.calcStats
      attackdiff=pokemon.attack-attackdiff
      defensediff=pokemon.defense-defensediff
      speeddiff=pokemon.speed-speeddiff
      spatkdiff=pokemon.spatk-spatkdiff
      spdefdiff=pokemon.spdef-spdefdiff
      totalhpdiff=pokemon.totalhp-totalhpdiff
      scene.pbDisplay(_INTL("{1} grew to Level {2}!",pokemon.name,curlevel))
      pbTopRightWindow(_INTL("Max. HP<r>+{1}\r\nAttack<r>+{2}\r\nDefense<r>+{3}\r\nSp. Atk<r>+{4}\r\nSp. Def<r>+{5}\r\nSpeed<r>+{6}",
                       totalhpdiff,attackdiff,defensediff,spatkdiff,spdefdiff,speeddiff))
      pbTopRightWindow(_INTL("Max. HP<r>{1}\r\nAttack<r>{2}\r\nDefense<r>{3}\r\nSp. Atk<r>{4}\r\nSp. Def<r>{5}\r\nSpeed<r>{6}",
                       pokemon.totalhp,pokemon.attack,pokemon.defense,pokemon.spatk,pokemon.spdef,pokemon.speed))
      # Finding all moves learned at this level
      movelist=pokemon.getMoveList
      for i in movelist
        if i[0]==pokemon.level || i[0]==curlevel          # Learned a new move
          pbLearnMove(pokemon,i[1],true)
        end
      end
    end
    if pokemon.level>oldlevel
      newspecies=pbCheckEvolution(pokemon)
      if newspecies>0
        pbFadeOutInWithMusic(99999){
          evo=PokemonEvolutionScene.new
          evo.pbStartScreen(pokemon,newspecies)
          evo.pbEvolution
          evo.pbEndScreen
        }
      end
    end
  end
end


ItemHandlers::UseOnPokemon.add(:RARECANDY,proc{|item,pokemon,scene|
   newspecies=pbCheckEvolution(pokemon)

   if (pokemon.level>=PBExperience::MAXLEVEL && newspecies==0) || (pokemon.isShadow? rescue false)
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   elsif pokemon.level>=PBExperience::MAXLEVEL && newspecies>0
      pbFadeOutInWithMusic(99999){
         evo=PokemonEvolutionScene.new
         evo.pbStartScreen(pokemon,newspecies)
         evo.pbEvolution
         evo.pbEndScreen
      }
   else
     pbChangeLevel(pokemon,pokemon.level+1,scene)
     scene.pbHardRefresh
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:REVERSECANDY,proc{|item,pokemon,scene|
   if pokemon.level==1 || (pokemon.isShadow? rescue false)
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pbChangeLevel(pokemon,pokemon.level-1,scene)
     pokemon.changeHappiness("badcandy")
     scene.pbHardRefresh
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:PHANTOMCANDYS,proc{|item,pokemon,scene|
  if pokemon.level>=PBExperience::MAXLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    exp = 800
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(pokemon, exp)
    if result == -1
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    IncreaseExp(pokemon, exp, scene)
    
    scene.pbHardRefresh
    next true
  end
})
ItemHandlers::UseOnPokemon.add(:PHANTOMCANDYM,proc{|item,pokemon,scene|
  if pokemon.level>=PBExperience::MAXLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    exp = 3000
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(pokemon, exp)
    if result == -1
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    IncreaseExp(pokemon, exp, scene)
    
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:EXPCANDYXS,proc{|item,pokemon,scene|
  if pokemon.level>=PBExperience::MAXLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    exp = 100
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(pokemon, exp)
    if result == -1
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    IncreaseExp(pokemon, exp, scene)
    
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:EXPCANDYS,proc{|item,pokemon,scene|
  if pokemon.level>=PBExperience::MAXLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    exp = 800
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(pokemon, exp)
    if result == -1
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    IncreaseExp(pokemon, exp, scene)
    
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:EXPCANDYM,proc{|item,pokemon,scene|
  if pokemon.level>=PBExperience::MAXLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    exp = 3000
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(pokemon, exp)
    if result == -1
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    IncreaseExp(pokemon, exp, scene)
    
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:EXPCANDYL,proc{|item,pokemon,scene|
  if pokemon.level>=PBExperience::MAXLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    exp = 10000
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(pokemon, exp)
    if result == -1
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    IncreaseExp(pokemon, exp, scene)
    
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:EXPCANDYXL,proc{|item,pokemon,scene|
  if pokemon.level>=PBExperience::MAXLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    exp = 30000
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(pokemon, exp)
    if result == -1
      scene.pbDisplay(_INTL("It won't have any effect."))
      next false
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    IncreaseExp(pokemon, exp, scene)
    
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:ADAMANTMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::ADAMANT || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:ADAMANT)
    scene.pbDisplay(_INTL("{1} becomes Adamant!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:LONELYMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::LONELY || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:LONELY)
    scene.pbDisplay(_INTL("{1} feels Lonely!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:NAUGHTYMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::NAUGHTY || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:NAUGHTY)
    scene.pbDisplay(_INTL("{1} becomes Naughty!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:BRAVEMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::BRAVE || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:BRAVE)
    scene.pbDisplay(_INTL("{1} becomes Brave!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:BOLDMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::BOLD || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:BOLD)
    scene.pbDisplay(_INTL("{1} becomes Bold!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:IMPISHMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::IMPISH || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:IMPISH)
    scene.pbDisplay(_INTL("{1} becomes Impish!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:LAXMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::LAX || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:LAX)
    scene.pbDisplay(_INTL("{1} becomes Lax!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:RELAXEDMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::RELAXED || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:RELAXED)
    scene.pbDisplay(_INTL("{1} feels Relaxed!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:MODESTMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::MODEST || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:MODEST)
    scene.pbDisplay(_INTL("{1} becomes Modest!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:MILDMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::MILD || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:MILD)
    scene.pbDisplay(_INTL("{1} becomes Mild!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:RASHMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::RASH || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:RASH)
    scene.pbDisplay(_INTL("{1} becomes Rash!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:QUIETMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::QUIET || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:QUIET)
    scene.pbDisplay(_INTL("{1} becomes Quiet!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:CALMMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::CALM || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:CALM)
    scene.pbDisplay(_INTL("{1} feels Calm!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:GENTLEMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::GENTLE || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:GENTLE)
    scene.pbDisplay(_INTL("{1} becomes Gentle!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:CAREFULMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::CAREFUL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:CAREFUL)
    scene.pbDisplay(_INTL("{1} becomes Careful!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:SASSYMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::SASSY || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:SASSY)
    scene.pbDisplay(_INTL("{1} becomes Sassy!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:TIMIDMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::TIMID || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:TIMID)
    scene.pbDisplay(_INTL("{1} becomes Timid!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:HASTYMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::HASTY || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:HASTY)
    scene.pbDisplay(_INTL("{1} becomes Hasty!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:JOLLYMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::JOLLY || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:JOLLY)
    scene.pbDisplay(_INTL("{1} feels Jolly!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:NAIVEMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::NAIVE || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:NAIVE)
    scene.pbDisplay(_INTL("{1} becomes Naive!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})

ItemHandlers::UseOnPokemon.add(:SERIOUSMINT,proc{|item,pokemon,scene|
  if pokemon.nature==PBNatures::SERIOUS || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  else
    pokemon.setNature(:SERIOUS)
    scene.pbDisplay(_INTL("{1} becomes Serious!",pokemon.name))
    scene.pbHardRefresh
    next true
  end
})


ItemHandlers::UseOnPokemon.add(:ABILITYCAPSULE,proc{|item,pokemon,scene|
  tempabil   = pokemon.abilityIndex
  abilid     = pokemon.ability
  abillist   = pokemon.getAbilityList
  
  if abillist[0].length == 1 || pokemon.species == 718
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false
  end
  commands=[]
  for i in 0...abillist[0].length
    commands.push((abillist[1][i]<2 ? "" : "(H) ")+PBAbilities.getName(abillist[0][i]))
  end
  height=3
  msg=[_INTL("Which ability would you like to change to?")][height]
  cmd=Kernel.pbShowCommands(msg,commands,tempabil)
  # Break
  if cmd==-1
    break
  # Set ability override
  elsif cmd>=0 && cmd<abillist[0].length
    pokemon.setAbility(abillist[1][cmd])
  # Remove override
  elsif cmd==abillist[0].length
    pokemon.abilityflag=nil
  end
# #### KUROTSUNE - 030 - START  
#   if abillist[0][0]     == abillist[0][1] && 
#     (tempabil           == 0              || 
#      tempabil           == 1)             && 
#      abillist[0].length == 3
#     pokemon.setAbility(2)

#   elsif abillist[0].length == 2
#     case tempabil
#       when 0
#         pokemon.setAbility(1)
#       when 1
#         pokemon.setAbility(0)
#       when 2
#         pokemon.setAbility(0)
#         newabilid     = pokemon.ability
#         if newabilid == abilid
#           pokemon.setAbility(1)
#         end
#     end

#   elsif abillist[0].length == 3
#     case tempabil
#       when 0
#         pokemon.setAbility(1)
#       when 1
#         pokemon.setAbility(2)
#       when 2
#         pokemon.setAbility(0)
#     end
#   end
#### KUROTSUNE - 030 - END
  scene.pbDisplay(_INTL("{1}'s ability was shuffled to {2}!",pokemon.name,PBAbilities.getName(pokemon.ability)))
  next true
})

def pbRaiseHappinessAndLowerEV(pokemon,scene,ev,messages)
  if pokemon.happiness==255 && pokemon.ev[ev]==0
    scene.pbDisplay(_INTL("It won't have any effect."))
    return false
  elsif pokemon.happiness==255
    pokemon.ev[ev]-=10
    pokemon.ev[ev]=0 if pokemon.ev[ev]<0
    pokemon.calcStats
    scene.pbRefresh
    scene.pbDisplay(messages[0])
    return true
  elsif pokemon.ev[ev]==0
    pokemon.changeHappiness("EV berry")
    scene.pbRefresh
    scene.pbDisplay(messages[1])
    return true
  else
    pokemon.changeHappiness("EV berry")
    pokemon.ev[ev]-=10
    pokemon.ev[ev]=0 if pokemon.ev[ev]<0
    pokemon.calcStats
    scene.pbRefresh
    scene.pbDisplay(messages[2])
    return true
  end
end

def pbResetEVStat(pokemon,scene,ev,messages)
  if pokemon.ev[ev]==0
    scene.pbDisplay(_INTL("It won't have any effect."))
    return false
  else
    pokemon.ev[ev]=0
    pokemon.calcStats
    scene.pbRefresh
    scene.pbDisplay(messages[0])
    return true
  end
end

ItemHandlers::UseOnPokemon.add(:POMEGBERRY,proc{|item,pokemon,scene|
   next pbRaiseHappinessAndLowerEV(pokemon,scene,0,[
      _INTL("{1} adores you!\nThe base HP fell!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base HP can't fall!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base HP fell!",pokemon.name)
   ])
})

ItemHandlers::UseOnPokemon.add(:KELPSYBERRY,proc{|item,pokemon,scene|
   next pbRaiseHappinessAndLowerEV(pokemon,scene,1,[
      _INTL("{1} adores you!\nThe base Attack fell!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Attack can't fall!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Attack fell!",pokemon.name)
   ])
})

ItemHandlers::UseOnPokemon.add(:QUALOTBERRY,proc{|item,pokemon,scene|
   next pbRaiseHappinessAndLowerEV(pokemon,scene,2,[
      _INTL("{1} adores you!\nThe base Defense fell!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Defense can't fall!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Defense fell!",pokemon.name)
   ])
})

ItemHandlers::UseOnPokemon.add(:HONDEWBERRY,proc{|item,pokemon,scene|
   next pbRaiseHappinessAndLowerEV(pokemon,scene,4,[
      _INTL("{1} adores you!\nThe base Special Attack fell!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Special Attack can't fall!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Special Attack fell!",pokemon.name)
   ])
})

ItemHandlers::UseOnPokemon.add(:GREPABERRY,proc{|item,pokemon,scene|
   next pbRaiseHappinessAndLowerEV(pokemon,scene,5,[
      _INTL("{1} adores you!\nThe base Special Defense fell!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Special Defense can't fall!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Special Defense fell!",pokemon.name)
   ])
})

ItemHandlers::UseOnPokemon.add(:TAMATOBERRY,proc{|item,pokemon,scene|
   next pbRaiseHappinessAndLowerEV(pokemon,scene,3,[
      _INTL("{1} adores you!\nThe base Speed fell!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Speed can't fall!",pokemon.name),
      _INTL("{1} turned friendly.\nThe base Speed fell!",pokemon.name)
   ])
})

ItemHandlers::UseOnPokemon.add(:HPRESETBAG,proc{|item,pokemon,scene|
   next pbResetEVStat(pokemon,scene,0,[
      _INTL("{1} forgot it's HP training!\nIt's base HP was reset!",pokemon.name),
   ])
})

ItemHandlers::UseOnPokemon.add(:ATKRESETBAG,proc{|item,pokemon,scene|
   next pbResetEVStat(pokemon,scene,1,[
      _INTL("{1} forgot it's Attack training!\nIt's base Attack was reset!",pokemon.name),
   ])
})

ItemHandlers::UseOnPokemon.add(:DEFRESETBAG,proc{|item,pokemon,scene|
   next pbResetEVStat(pokemon,scene,2,[
      _INTL("{1} forgot it's Defense training!\nIt's base Defense was reset!",pokemon.name),
   ])
})

ItemHandlers::UseOnPokemon.add(:SPARESETBAG,proc{|item,pokemon,scene|
   next pbResetEVStat(pokemon,scene,4,[
      _INTL("{1} forgot it's Sp. Attack training!\nIt's base Sp. Attack was reset!",pokemon.name),
   ])
})

ItemHandlers::UseOnPokemon.add(:SPDRESETBAG,proc{|item,pokemon,scene|
   next pbResetEVStat(pokemon,scene,5,[
      _INTL("{1} forgot it's Sp. Defense training!\nIt's base Sp. Defense was reset!",pokemon.name),
   ])
})

ItemHandlers::UseOnPokemon.add(:SPERESETBAG,proc{|item,pokemon,scene|
   next pbResetEVStat(pokemon,scene,3,[
      _INTL("{1} forgot it's Speed training!\nIt's base Speed was reset!",pokemon.name),
   ])
})



ItemHandlers::UseOnPokemon.add(:GRACIDEA,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:SHAYMIN) && pokemon.form==0 &&
      pokemon.hp>=0 && pokemon.status!=PBStatuses::FROZEN &&
      !PBDayNight.isNight?(pbGetTimeNow)
     pokemon.form=1
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
     next true
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:REVEALGLASS,proc{|item,pokemon,scene|
   if (isConst?(pokemon.species,PBSpecies,:TORNADUS) ||
      isConst?(pokemon.species,PBSpecies,:THUNDURUS) ||
      isConst?(pokemon.species,PBSpecies,:LANDORUS)) && pokemon.hp>=0
     pokemon.form=(pokemon.form==0) ? 1 : 0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
     next true
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:DNASPLICERS,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:KYUREM) && pokemon.hp>=0
     if pokemon.fused!=nil
       if $Trainer.party.length>=6
         scene.pbDisplay(_INTL("Your party is full! You can't unfuse {1}.",pokemon.name))
         next false
       else
         $Trainer.party[$Trainer.party.length]=pokemon.fused
         pokemon.fused=nil
         pokemon.form=0
         scene.pbHardRefresh
         scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
         next true
       end
     else
       chosen=scene.pbChoosePokemon(_INTL("Fuse with which Pokémon?"))
       if chosen>=0
         poke2=$Trainer.party[chosen]
         if (isConst?(poke2.species,PBSpecies,:RESHIRAM) ||
            isConst?(poke2.species,PBSpecies,:ZEKROM)) && poke2.hp>=0
           pokemon.form=1 if isConst?(poke2.species,PBSpecies,:RESHIRAM)
           pokemon.form=2 if isConst?(poke2.species,PBSpecies,:ZEKROM)
           pokemon.fused=poke2
           pbRemovePokemonAt(chosen)
           scene.pbHardRefresh
           scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
           next true
         elsif pokemon==poke2
           scene.pbDisplay(_INTL("{1} can't be fused with itself!",pokemon.name))
         else
           scene.pbDisplay(_INTL("{1} can't be fused with {2}.",poke2.name,pokemon.name))
         end
       else
         next false
       end
     end
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})


ItemHandlers::UseOnPokemon.add(:PHASEDIAL,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:SOLROCK) && pokemon.hp>=0
     if pokemon.fused!=nil
       if $Trainer.party.length>=6
         scene.pbDisplay(_INTL("Your party is full! You can't unfuse {1}.",pokemon.name))
         next false
       else
         $Trainer.party[$Trainer.party.length]=pokemon.fused
         pokemon.fused=nil
         pokemon.form=0
         scene.pbHardRefresh
         scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
         next true
       end
     else
       chosen=scene.pbChoosePokemon(_INTL("Fuse with which Pokémon?"))
       if chosen>=0
         poke2=$Trainer.party[chosen]
         if (isConst?(poke2.species,PBSpecies,:LUNATONE) ||
            isConst?(poke2.species,PBSpecies,:LUNATONE)) && poke2.hp>=0
           pokemon.form=1 if isConst?(poke2.species,PBSpecies,:LUNATONE)
           pokemon.form=2 if isConst?(poke2.species,PBSpecies,:SOLROCK)
           pokemon.fused=poke2
           pbRemovePokemonAt(chosen)
           scene.pbHardRefresh
           scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
           next true
         elsif pokemon==poke2
           scene.pbDisplay(_INTL("{1} can't be fused with itself!",pokemon.name))
         else
           scene.pbDisplay(_INTL("{1} can't be fused with {2}.",poke2.name,pokemon.name))
         end
       else
         next false
       end
     end
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:NSOLARIZER,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:NECROZMA) && pokemon.hp>=0
     if pokemon.fused!=nil
       if $Trainer.party.length>=6
         scene.pbDisplay(_INTL("Your party is full! You can't unfuse {1}.",pokemon.name))
         next false
       else
         $Trainer.party[$Trainer.party.length]=pokemon.fused
         pokemon.fused=nil
         pokemon.form=0
         scene.pbHardRefresh
         scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
         next true
       end
     else
       chosen=scene.pbChoosePokemon(_INTL("Fuse with which Pokémon?"))
       if chosen>=0
         poke2=$Trainer.party[chosen]
         if isConst?(poke2.species,PBSpecies,:SOLGALEO) && poke2.hp>=0
           pokemon.form=1
           pokemon.fused=poke2
           pbRemovePokemonAt(chosen)
           scene.pbHardRefresh
           scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
           next true
         elsif pokemon==poke2
           scene.pbDisplay(_INTL("{1} can't be fused with itself!",pokemon.name))
         elsif isConst?(poke2.species,PBSpecies,:LUNALA)
           scene.pbDisplay(_INTL("This item can't fuse {1} with {2}.",poke2.name,pokemon.name))
         else
           scene.pbDisplay(_INTL("{1} can't be fused with {2}.",poke2.name,pokemon.name))
         end
       else
         next false
       end
     end
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:NLUNARIZER,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:NECROZMA) && pokemon.hp>=0
     if pokemon.fused!=nil
       if $Trainer.party.length>=6
         scene.pbDisplay(_INTL("Your party is full! You can't unfuse {1}.",pokemon.name))
         next false
       else
         $Trainer.party[$Trainer.party.length]=pokemon.fused
         pokemon.fused=nil
         pokemon.form=0
         scene.pbHardRefresh
         scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
         next true
       end
     else
       chosen=scene.pbChoosePokemon(_INTL("Fuse with which Pokémon?"))
       if chosen>=0
         poke2=$Trainer.party[chosen]
         if isConst?(poke2.species,PBSpecies,:LUNALA) && poke2.hp>=0
           pokemon.form=2
           pokemon.fused=poke2
           pbRemovePokemonAt(chosen)
           scene.pbHardRefresh
           scene.pbDisplay(_INTL("{1} changed Forme!",pokemon.name))
           next true
         elsif pokemon==poke2
           scene.pbDisplay(_INTL("{1} can't be fused with itself!",pokemon.name))
          elsif isConst?(poke2.species,PBSpecies,:SOLGALEO)
           scene.pbDisplay(_INTL("This item can't fuse {1} with {2}.",poke2.name,pokemon.name))
         else
           scene.pbDisplay(_INTL("{1} can't be fused with {2}.",poke2.name,pokemon.name))
         end
       else
         next false
       end
     end
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:REDNECTAR,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:ORICORIO) && pokemon.form!=0 &&
      pokemon.hp>=0 
     pokemon.form=0
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} transformed!",pokemon.name))
     next true
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:YELLOWNECTAR,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:ORICORIO) && pokemon.form!=1 &&
      pokemon.hp>=0 
     pokemon.form=1
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} transformed!",pokemon.name))
     next true
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:PINKNECTAR,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:ORICORIO) && pokemon.form!=2 &&
      pokemon.hp>=0 
     pokemon.form=2
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} transformed!",pokemon.name))
     next true
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})

ItemHandlers::UseOnPokemon.add(:PURPLENECTAR,proc{|item,pokemon,scene|
   if isConst?(pokemon.species,PBSpecies,:ORICORIO) && pokemon.form!=3 &&
      pokemon.hp>=0 
     pokemon.form=3
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} transformed!",pokemon.name))
     next true
   else
     scene.pbDisplay(_INTL("It had no effect."))
     next false
   end
})
#===============================================================================
# UseInField handlers
#===============================================================================

ItemHandlers::UseInField.add(:HONEY,proc{|item|  
   Kernel.pbMessage(_INTL("{1} used the {2}!",$Trainer.name,PBItems.getName(item)))
   pbSweetScent
})

ItemHandlers::UseInField.add(:ESCAPEROPE,lambda{|item|
   escape=($PokemonGlobal.escapePoint rescue nil)
   if !escape || escape==[]
     Kernel.pbMessage(_INTL("Can't use that here."))
     next
   end
   if $game_player.pbHasDependentEvents?
     Kernel.pbMessage(_INTL("It can't be used when you have someone with you."))
     next
   end
   Kernel.pbMessage(_INTL("{1} used the Escape Rope.",$Trainer.name))
   pbFadeOutIn(99999){
      Kernel.pbCancelVehicles
      $game_temp.player_new_map_id=escape[0]
      $game_temp.player_new_x=escape[1]
      $game_temp.player_new_y=escape[2]
      $game_temp.player_new_direction=escape[3]
      $scene.transfer_player
      $game_map.autoplay
      $game_map.refresh
      if pbIsWaterTag?(Kernel.pbFacingTerrainTag) && !$PokemonGlobal.surfing
        $PokemonEncounters.clearStepCount
        $PokemonGlobal.surfing=true
        $game_switches[999]=true
        $game_map.refresh
        Kernel.pbUpdateVehicle
      end
      $game_variables[999] = 0
      $game_variables[298] = 0
      $game_variables[708] = 0
   }
   
   return true #if @surfstart
      
   pbEraseEscapePoint

})

ItemHandlers::UseInField.add(:BICYCLE,proc{|item|
   if pbBikeCheck
     if $PokemonGlobal.bicycle
       Kernel.pbDismountBike
     else
       Kernel.pbMountBike 
     end
   end
})

ItemHandlers::UseInField.add(:ITEMBELTCONTROLLER,proc{|item|
   pbManageItemBelt
   next 1
})

ItemHandlers::UseInField.copy(:BICYCLE,:MACHBIKE,:ACROBIKE)

ItemHandlers::UseInField.add(:OLDROD,proc{|item|
   terrain=Kernel.pbFacingTerrainTag
   notCliff=$game_map.passable?($game_player.x,$game_player.y,$game_player.direction)
 if (!pbIsWaterTag?(terrain) && !pbIsGrimeTag?(terrain)) || 
     (!notCliff && !$PokemonGlobal.surfing)
     Kernel.pbMessage(_INTL("Can't use that here.")) 
     next
   end
   encounter=$PokemonEncounters.hasEncounter?(EncounterTypes::OldRod)
   if pbFishing(encounter,1)
     pbEncounter(EncounterTypes::OldRod)
   end
})

ItemHandlers::UseInField.add(:GOODROD,proc{|item|
   terrain=Kernel.pbFacingTerrainTag
   notCliff=$game_map.passable?($game_player.x,$game_player.y,$game_player.direction)
 if (!pbIsWaterTag?(terrain) && !pbIsGrimeTag?(terrain)) || 
     (!notCliff && !$PokemonGlobal.surfing)
     Kernel.pbMessage(_INTL("Can't use that here.")) 
     next
   end
   encounter=$PokemonEncounters.hasEncounter?(EncounterTypes::GoodRod)
   if pbFishing(encounter,2)
     pbEncounter(EncounterTypes::GoodRod)
   end
})

ItemHandlers::UseInField.add(:SUPERROD,proc{|item|
   terrain=Kernel.pbFacingTerrainTag
   notCliff=$game_map.passable?($game_player.x,$game_player.y,$game_player.direction)
 if (!pbIsWaterTag?(terrain) && !pbIsGrimeTag?(terrain)) || 
     (!notCliff && !$PokemonGlobal.surfing)
     Kernel.pbMessage(_INTL("Can't use that here.")) 
     next
   end
   encounter=$PokemonEncounters.hasEncounter?(EncounterTypes::SuperRod)
   if pbFishing(encounter,3)
     pbEncounter(EncounterTypes::SuperRod)
   end
})

ItemHandlers::UseInField.add(:ITEMFINDER,proc{|item|
   event=pbClosestHiddenItem
   if !event
     Kernel.pbMessage(_INTL("... ... ... ...Nope!\r\nThere's no response."))
   else
     offsetX=event.x-$game_player.x
     offsetY=event.y-$game_player.y
     if offsetX==0 && offsetY==0
       for i in 0...32
         Graphics.update
         Input.update
         $game_player.turn_right_90 if (i&7)==0
         pbUpdateSceneMap
       end
       Kernel.pbMessage(_INTL("The {1}'s indicating something right underfoot!\1",PBItems.getName(item)))
     else
       direction=$game_player.direction
       if offsetX.abs>offsetY.abs
         direction=(offsetX<0) ? 4 : 6         
       else
         direction=(offsetY<0) ? 8 : 2
       end
       for i in 0...8
         Graphics.update
         Input.update
         if i==0
           $game_player.turn_down if direction==2
           $game_player.turn_left if direction==4
           $game_player.turn_right if direction==6
           $game_player.turn_up if direction==8
         end
         pbUpdateSceneMap
       end
       Kernel.pbMessage(_INTL("Huh?\nThe {1}'s responding!\1",PBItems.getName(item)))
       Kernel.pbMessage(_INTL("There's an item buried around here!"))
     end
   end
})

ItemHandlers::UseInField.copy(:ITEMFINDER,:DOWSINGMCHN)

ItemHandlers::UseInField.add(:TOWNMAP,proc{|item|
   pbShowMap(-1,false)
})

# Temporal Sage: key item that preserves herbs/powders after battle
ItemHandlers::UseInField.add(:TEMPORALSAGE,proc{|item|
   Kernel.pbMessage(_INTL("Your herbs and powders will be preserved after battles."))
   $PokemonGlobal.temporalSage=true if $PokemonGlobal
   next 1
})

ItemHandlers::UseInField.add(:COINCASE,proc{|item|
   Kernel.pbMessage(_INTL("Coins: {1}",$PokemonGlobal.coins))
   next 1 # Continue
})

ItemHandlers::UseInField.add(:ACHIEVEMENTCARD,proc{|item|
   Kernel.pbMessage(_INTL("AP: {1}",pbCommaNumber($game_variables[526])))
   next 1 # Continue
})

ItemHandlers::UseInField.add(:GATHERCUBE,proc{|item|
   Kernel.pbMessage(_INTL("Zygarde Cells Found: {1}, Zygarde Cores Found: {2}, Red Essence: {3}",$game_variables[361],$game_variables[362],$game_variables[705]))
   next 1 # Continue
})

ItemHandlers::UseInField.add(:EXPALL,proc{|item|
   $PokemonBag.pbChangeItem(:EXPALL,:EXPALLOFF)
   Kernel.pbMessage(_INTL("The Exp Share All was turned off."))
   next 1 # Continue
})

ItemHandlers::UseInField.add(:EXPALLOFF,proc{|item|
   $PokemonBag.pbChangeItem(:EXPALLOFF,:EXPALL)
   Kernel.pbMessage(_INTL("The Exp Share All was turned on."))
   next 1 # Continue
})

ItemHandlers::UseInField.add(:GOLDENWINGS,proc{|item|
  next 0 if !pbCheckHiddenMoveSwitch(SWITCHFORFLY,true)
  next 0 if !$PokemonBag.pbHasItem?(:HM02)
  if inPast?
    Kernel.pbMessage(_INTL("You are unable to travel in the past!"))
    next 0
  end
  if $game_player.pbHasDependentEvents?
    Kernel.pbMessage(_INTL("It can't be used when you have someone with you."))
    next 0
  end
  if $game_switches[999]
    Kernel.pbMessage(_INTL("It can't be used while riding a Pokemon."))
    next 0
  end
  if !pbGetMetadata($game_map.map_id,MetadataOutdoor)
    Kernel.pbMessage(_INTL("Can't use that here."))
    next 0
  end
  if $game_switches[1235]
    Kernel.pbMessage(_INTL("Golden items cannot be used at this time."))
    next 0
  end  

  scene=PokemonRegionMapScene.new(-1,false)
  screen=PokemonRegionMap.new(scene)
  ret=screen.pbStartFlyScreen
  if ret
    Kernel.pbMessage(_INTL("{1} used Golden Wings!", $Trainer.name))
    pbFadeOutIn(99999){
      $strengthUsed = false
      $game_temp.player_new_map_id    = ret[0] #$PokemonTemp.flydata[0]
      $game_temp.player_new_x         = ret[1] #$PokemonTemp.flydata[1]
      $game_temp.player_new_y         = ret[2] #$PokemonTemp.flydata[2]
      $game_temp.player_new_direction = 2
      Kernel.pbCancelVehicles
      $PokemonTemp.flydata = nil
      $scene.transfer_player
      $game_map.autoplay
      $game_map.refresh
      $game_variables[298] = 0
    }
    pbEraseEscapePoint
    next 1
  end
  next 0
})
#===============================================================================
# BattleUseOnPokemon handlers
#===============================================================================

ItemHandlers::BattleUseOnPokemon.add(:POTION,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,20,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:SUPERPOTION,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,60,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:CHINESEFOOD,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,40,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:HYPERPOTION,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,120,scene)
})
 
ItemHandlers::BattleUseOnPokemon.add(:ULTRAPOTION,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,200,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:MAXPOTION,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,pokemon.totalhp-pokemon.hp,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:BERRYJUICE,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,20,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:RAGECANDYBAR,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,20,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:SWEETHEART,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,20,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:FRESHWATER,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,30,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:SODAPOP,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,50,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:VANILLAIC,proc{|item,pokemon,battler,scene|
   if pbBattleHPItem(pokemon,battler,30,scene)
     pokemon.changeHappiness("candy")
     next true
   end
   next false
})

ItemHandlers::BattleUseOnPokemon.add(:CHOCOLATEIC,proc{|item,pokemon,battler,scene|
   if pbBattleHPItem(pokemon,battler,70,scene)
     pokemon.changeHappiness("candy")
     next true
   end
   next false
})

ItemHandlers::BattleUseOnPokemon.add(:STRAWBIC,proc{|item,pokemon,battler,scene|
  if pbBattleHPItem(pokemon,battler,90,scene)
     pokemon.changeHappiness("candy")
     next true
   end
   next false
})
 
ItemHandlers::BattleUseOnPokemon.add(:BLUEMIC,proc{|item,pokemon,battler,scene|
   if pbBattleHPItem(pokemon,battler,200,scene)
     pokemon.changeHappiness("bluecandy")
     next true
   end
   next false
})

ItemHandlers::BattleUseOnPokemon.add(:LEMONADE,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,70,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:MOOMOOMILK,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,100,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:STRAWCAKE,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,150,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:ORANBERRY,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,10,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:SITRUSBERRY,proc{|item,pokemon,battler,scene|
   next pbBattleHPItem(pokemon,battler,(pokemon.totalhp/4).floor,scene)
})

ItemHandlers::BattleUseOnPokemon.add(:HOPOBERRY,proc{|item,pokemon,battler,scene|
   pprestored=0
   for i in 0...pokemon.moves.length
     pprestored+=pbBattleRestorePP(pokemon,battler,i,2)
   end
   if pprestored==0
     scene.pbDisplay(_INTL("But it had no effect!"))
     next false
   end
   scene.pbDisplay(_INTL("PP was restored a little."))
   next true
})

ItemHandlers::BattleUseOnPokemon.add(:LEVIABERRY,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::CRUSHED
     scene.pbDisplay(_INTL("But it had no effect!"))
     next false
   end
   pokemon.status=0
   pokemon.statusCount=0
   battler.status=0 if battler
   scene.pbRefresh
   scene.pbDisplay(_INTL("{1} was uncrushed.",pokemon.name))
   next true
})

ItemHandlers::BattleUseOnPokemon.add(:COCONBERRY,proc{|item,pokemon,battler,scene|
   itemname=PBItems.getName(item)
   if !battler || battler.isFainted?
     scene.pbDisplay(_INTL("But it had no effect!"))
     next false
   end
   shieldhp=(battler.totalhp/3).floor
   if battler.pbApplyTempShield(shieldhp,_INTL("{1} shielded itself with the {2}!",battler.pbThis,itemname))
     next true
   end
   scene.pbDisplay(_INTL("But it had no effect!"))
   next false
})

ItemHandlers::BattleUseOnPokemon.add(:AWAKENING,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::SLEEP
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} woke up.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.copy(:AWAKENING,:CHESTOBERRY,:BLUEFLUTE,:POKEFLUTE)

ItemHandlers::BattleUseOnPokemon.add(:ANTIDOTE,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::POISON
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of its poisoning.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.copy(:ANTIDOTE,:PECHABERRY)

ItemHandlers::BattleUseOnPokemon.add(:BURNHEAL,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::BURN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     battler.status=0 if battler
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s burn was healed.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.copy(:BURNHEAL,:RAWSTBERRY)

ItemHandlers::BattleUseOnPokemon.add(:PARLYZHEAL,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::PARALYSIS
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     battler.status=0 if battler
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was cured of paralysis.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.copy(:PARLYZHEAL,:CHERIBERRY)

ItemHandlers::BattleUseOnPokemon.add(:ICEHEAL,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || pokemon.status!=PBStatuses::FROZEN
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     battler.status=0 if battler
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} was thawed out.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.copy(:ICEHEAL,:ASPEARBERRY)

ItemHandlers::BattleUseOnPokemon.add(:FULLHEAL,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || (pokemon.status==0 && (!battler || battler.effects[PBEffects::Confusion]==0))
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     battler.effects[PBEffects::Confusion]=0 if battler
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} became healthy.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.copy(:FULLHEAL,
   :LAVACOOKIE,:OLDGATEAU,:CASTELIACONE,:BIGMALASADA,:LUMBERRY,:RAZZTART)

ItemHandlers::BattleUseOnPokemon.add(:FULLRESTORE,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || (pokemon.status==0 && pokemon.hp==pokemon.totalhp &&
      (!battler || battler.effects[PBEffects::Confusion]==0))
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     hpgain=pbItemRestoreHP(pokemon,pokemon.totalhp-pokemon.hp)
     battler.hp=pokemon.hp if battler
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     battler.effects[PBEffects::Confusion]=0 if battler
     scene.pbRefresh
     if hpgain>0
       scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.",pokemon.name,hpgain))
     else
       scene.pbDisplay(_INTL("{1} became healthy.",pokemon.name))
     end
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:REVIVE,proc{|item,pokemon,battler,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=1+(pokemon.totalhp/2).floor
     for i in 0...$Trainer.party.length
       if $Trainer.party[i]==pokemon
         battler.pbInitialize(pokemon,i,false) if battler
         break
       end
     end
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})


ItemHandlers::BattleUseOnPokemon.add(:FUNNELCAKE,proc{|item,pokemon,battler,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=1+(pokemon.totalhp/2).floor
     for i in 0...$Trainer.party.length
       if $Trainer.party[i]==pokemon
         battler.pbInitialize(pokemon,i,false) if battler
         break
       end
     end
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:MAXREVIVE,proc{|item,pokemon,battler,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=pokemon.totalhp
     for i in 0...$Trainer.party.length
       if $Trainer.party[i]==pokemon
         battler.pbInitialize(pokemon,i,false) if battler
         break
       end
     end
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})


ItemHandlers::BattleUseOnPokemon.add(:HERBALTEA,proc{|item,pokemon,battler,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=pokemon.totalhp
     for i in 0...$Trainer.party.length
       if $Trainer.party[i]==pokemon
         battler.pbInitialize(pokemon,i,false) if battler
         break
       end
     end
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:GOURMETTREAT,proc{|item,pokemon,scene|
   if pokemon.happiness==255
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.changeHappiness("level up")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} ate the Gourmet Treat happily!",pokemon.name))
     next true
   end
})

ItemHandlers::UseOnPokemon.add(:MAXREVIVE,proc{|item,pokemon,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=pokemon.totalhp
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})
ItemHandlers::BattleUseOnPokemon.add(:ENERGYPOWDER,proc{|item,pokemon,battler,scene|
   if pbBattleHPItem(pokemon,battler,50,scene)
     pokemon.changeHappiness("powder")
     next true
   end
   next false
})

ItemHandlers::BattleUseOnPokemon.add(:ENERGYROOT,proc{|item,pokemon,battler,scene|
   if pbBattleHPItem(pokemon,battler,200,scene)
     pokemon.changeHappiness("Energy Root")
     next true
   end
   next false
})

ItemHandlers::BattleUseOnPokemon.add(:HEALPOWDER,proc{|item,pokemon,battler,scene|
   if pokemon.hp<=0 || (pokemon.status==0 && (!battler || battler.effects[PBEffects::Confusion]==0))
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.statusCount=0
     battler.status=0 if battler
     battler.effects[PBEffects::Confusion]=0 if battler
     pokemon.changeHappiness("powder")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1} became healthy.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:REVIVALHERB,proc{|item,pokemon,battler,scene|
   if pokemon.hp>0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     pokemon.status=0
     pokemon.hp=pokemon.totalhp
     for i in 0...$Trainer.party.length
       if $Trainer.party[i]==pokemon
         battler.pbInitialize(pokemon,i,false) if battler
         break
       end
     end
     pokemon.changeHappiness("Revival Herb")
     scene.pbRefresh
     scene.pbDisplay(_INTL("{1}'s HP was restored.",pokemon.name))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:ETHER,proc{|item,pokemon,battler,scene|
#   move=scene.pbChooseMove(pokemon,_INTL("Restore which move?"))
#   if move>=0
#     if pbBattleRestorePP(pokemon,battler,move,10)==0
#       scene.pbDisplay(_INTL("It won't have any effect."))
#       next false
#     else
       scene.pbDisplay(_INTL("PP was restored."))
       next true
#     end
#   end
#   next false
})

ItemHandlers::BattleUseOnPokemon.copy(:ETHER,:LEPPABERRY)

ItemHandlers::BattleUseOnPokemon.add(:MAXETHER,proc{|item,pokemon,battler,scene|
#   move=scene.pbChooseMove(pokemon,_INTL("Restore which move?"))
#   if move>=0
#     if pbBattleRestorePP(pokemon,battler,move,pokemon.moves[move].totalpp-pokemon.moves[move].pp)==0
#       scene.pbDisplay(_INTL("It won't have any effect."))
#       next false
#     else
       scene.pbDisplay(_INTL("PP was restored."))
       next true
#     end
#   end
#   next false
})
ItemHandlers::BattleUseOnPokemon.add(:ELIXIR,proc{|item,pokemon,battler,scene|
   pprestored=0
   for i in 0...pokemon.moves.length
     pprestored+=pbBattleRestorePP(pokemon,battler,i,10)
   end
   if pprestored==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("PP was restored."))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:MAXELIXIR,proc{|item,pokemon,battler,scene|
   pprestored=0
   for i in 0...pokemon.moves.length
     pprestored+=pbBattleRestorePP(pokemon,battler,i,pokemon.moves[i].totalpp-pokemon.moves[i].pp)
   end
   if pprestored==0
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   else
     scene.pbDisplay(_INTL("PP was restored."))
     next true
   end
})

ItemHandlers::BattleUseOnPokemon.add(:REDFLUTE,proc{|item,pokemon,battler,scene|
   if battler && battler.effects[PBEffects::Attract]>=0
     battler.effects[PBEffects::Attract]=-1
     scene.pbDisplay(_INTL("{1} got over its infatuation.",pokemon.name))
     next true # :consumed:
   else
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   end
})

ItemHandlers::BattleUseOnPokemon.add(:YELLOWFLUTE,proc{|item,pokemon,battler,scene|
   if battler && battler.effects[PBEffects::Confusion]>0
     battler.effects[PBEffects::Confusion]=0
     scene.pbDisplay(_INTL("{1} snapped out of confusion.",pokemon.name))
     next true # :consumed:
   else
     scene.pbDisplay(_INTL("It won't have any effect."))
     next false
   end
})

ItemHandlers::BattleUseOnPokemon.copy(:YELLOWFLUTE,:PERSIMBERRY)

#===============================================================================
# BattleUseOnBattler handlers
#===============================================================================

ItemHandlers::BattleUseOnBattler.add(:DECOMPRESSOR,proc{|item,battler,scene|
   if !battler || battler.isFainted? || battler.status!=PBStatuses::CRUSHED
     scene.pbDisplay(_INTL("But it had no effect!"))
     next false
   end
   battler.status=0
   battler.statusCount=0
   battler.pokemon.status=0 if battler.pokemon
   scene.pbRefresh
   scene.pbDisplay(_INTL("{1} was uncrushed by the {2}!",battler.pbThis,PBItems.getName(item)))
   next true
})

ItemHandlers::BattleUseOnBattler.add(:SNARE,proc{|item,battler,scene|
   if !battler || battler.isFainted?
     scene.pbDisplay(_INTL("But it had no effect!"))
     next false
   end
   opponents=[]
   opponents << battler.pbOpposing1 if battler.pbOpposing1 && !battler.pbOpposing1.isFainted?
   opponents << battler.pbOpposing2 if battler.pbOpposing2 && !battler.pbOpposing2.isFainted?
   opponents.compact!
   opponents.uniq!
   applied=false
   for foe in opponents
     next if foe.effects[PBEffects::MeanLook]>=0 || foe.effects[PBEffects::Substitute]>0
     foe.effects[PBEffects::MeanLook]=battler.index
     battler.battle.pbDisplay(_INTL("{1} can't escape now!",foe.pbThis))
     applied=true
   end
   if !applied
     scene.pbDisplay(_INTL("But it had no effect!"))
     next false
   end
   next true
})

ItemHandlers::BattleUseOnBattler.add(:MAGNETWAND,proc{|item,battler,scene|
   if !battler || battler.isFainted?
     scene.pbDisplay(_INTL("But it had no effect!"))
     next false
   end
   if battler.pbOwnSide.effects[PBEffects::Gravity]>0 ||
      battler.pbOpposingSide.effects[PBEffects::Gravity]>0
     scene.pbDisplay(_INTL("But it failed!"))
     next false
   end
   if battler.effects[PBEffects::Ingrain] ||
      battler.effects[PBEffects::SmackDown] ||
      battler.effects[PBEffects::MagnetRise]>0
     scene.pbDisplay(_INTL("But it failed!"))
     next false
   end
   battler.effects[PBEffects::MagnetRise]=5
   if $fefieldeffect == 1 || $fefieldeffect == 17 || $fefieldeffect == 18
     battler.effects[PBEffects::MagnetRise]=8
   end
   scene.pbRefresh
   battler.battle.pbDisplay(_INTL("{1} levitated with electromagnetism!",battler.pbThis))
   next true
})

ItemHandlers::BattleUseOnBattler.add(:XATTACK,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ATTACK,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XATTACK2,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ATTACK,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XATTACK3,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ATTACK,3,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XATTACK6,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ATTACK,6,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XDEFEND,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::DEFENSE,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XDEFEND2,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::DEFENSE,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XDEFEND3,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::DEFENSE,3,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XDEFEND6,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::DEFENSE,6,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPECIAL,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPATK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPATK,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPECIAL2,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPATK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPATK,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPECIAL3,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPATK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPATK,3,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPECIAL6,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPATK,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPATK,6,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPDEF,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPDEF,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPDEF2,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPDEF,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPDEF3,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPDEF,3,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPDEF6,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPDEF,6,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPEED,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPEED,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPEED,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPEED2,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPEED,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPEED,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPEED3,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPEED,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPEED,3,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XSPEED6,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::SPEED,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::SPEED,6,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XACCURACY,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ACCURACY,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ACCURACY,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XACCURACY2,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ACCURACY,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ACCURACY,2,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XACCURACY3,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ACCURACY,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ACCURACY,3,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:XACCURACY6,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbCanIncreaseStatStage?(PBStats::ACCURACY,false)
     battler.battle.statChangeSource=[:item,item]
     battler.pbIncreaseStat(PBStats::ACCURACY,6,true)
     battler.battle.statChangeSource=nil
     return true
   else
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false  
   end
})

ItemHandlers::BattleUseOnBattler.add(:DIREHIT,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.effects[PBEffects::FocusEnergy]>=1
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false
   else
     battler.effects[PBEffects::FocusEnergy]=1
     scene.pbDisplay(_INTL("{1} is getting pumped!",battler.pbThis))
     return true
   end
})

ItemHandlers::BattleUseOnBattler.add(:DIREHIT2,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.effects[PBEffects::FocusEnergy]>=2
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false
   else
     battler.effects[PBEffects::FocusEnergy]=2
     scene.pbDisplay(_INTL("{1} is getting pumped!",battler.pbThis))
     return true
   end
})

ItemHandlers::BattleUseOnBattler.add(:DIREHIT3,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.effects[PBEffects::FocusEnergy]>=3
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false
   else
     battler.effects[PBEffects::FocusEnergy]=3
     scene.pbDisplay(_INTL("{1} is getting pumped!",battler.pbThis))
     return true
   end
})

ItemHandlers::BattleUseOnBattler.add(:GUARDSPEC,lambda{|item,battler,scene|
   playername=battler.battle.pbPlayer.name
   itemname=PBItems.getName(item)
   scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
   if battler.pbOwnSide.effects[PBEffects::Mist]>0
     scene.pbDisplay(_INTL("But it had no effect!"))
     return false
   else
     battler.pbOwnSide.effects[PBEffects::Mist]=5
     if !battler.pbIsOpposing?(battler.index) #Item not implemented for enemies. Messages may be incorrect for them if it is.
       scene.pbDisplay(_INTL("Your team became shrouded in mist!"))
     else
       scene.pbDisplay(_INTL("The foe's team became shrouded in mist!"))
     end
     return true
   end
})

ItemHandlers::BattleUseOnBattler.add(:POKEDOLL,lambda{|item,battler,scene|
   battle=battler.battle
   if battle.opponent || (battler.pbOpposing1.isbossmon || battler.pbOpposing2.isbossmon)
     scene.pbDisplay(_INTL("Can't use that here."))
     return false
   else
     playername=battle.pbPlayer.name
     itemname=PBItems.getName(item)
     scene.pbDisplay(_INTL("{1} used the {2}.",playername,itemname))
     return true
   end
})

ItemHandlers::BattleUseOnBattler.copy(:POKEDOLL,:FLUFFYTAIL,:POKETOY)

ItemHandlers::BattleUseOnBattler.addIf(lambda{|item|
                pbIsPokeBall?(item)},lambda{|item,battler,scene|  # Any Poké Ball
   battle=battler.battle
   if !battler.pbOpposing1.isFainted? && !battler.pbOpposing2.isFainted?
     if !pbIsSnagBall?(item)
       scene.pbDisplay(_INTL("It's no good!  It's impossible to aim when there are two Pokémon!"))
       return false
     end
   end
   if battle.pbPlayer.party.length>=6 && $PokemonStorage.full?
     scene.pbDisplay(_INTL("There is no room left in the PC!"))
     return false
   end
   return true
})

#===============================================================================
# UseInBattle handlers
#===============================================================================

ItemHandlers::UseInBattle.add(:POKEDOLL,proc{|item,battler,battle|
   battle.decision=3
   battle.pbDisplayPaused(_INTL("Got away safely!"))
})

ItemHandlers::UseInBattle.copy(:POKEDOLL,:FLUFFYTAIL,:POKETOY)

ItemHandlers::UseInBattle.addIf(proc{|item|
   pbIsPokeBall?(item)},proc{|item,battler,battle|  # Any Poké Ball
      PBDebug.log("[UseInBattle handler called for pokeball #{item}, battler.index=#{battler.index}]")
      battle.pbThrowPokeBall(battler.index,item)
})
