# Results of battle:
#    0 - Undecided or aborted
#    1 - Player won
#    2 - Player lost
#    3 - Player or wild PokÃ©mon ran from battle, or player forfeited the match
#    4 - Wild PokÃ©mon was caught
#    5 - Draw
################################################################################
# Battle Peer.
################################################################################
class PokeBattle_NullBattlePeer
  def pbStorePokemon(player,pokemon)
    if player.party.length<6
      player.party[player.party.length]=pokemon
      return -1
    else
      return -1
    end
  end

  def pbOnEnteringBattle(battle,pokemon)
  end

  def pbGetStorageCreator()
    return nil
  end

  def pbCurrentBox()
    return -1
  end

  def pbBoxName(box)
    return ""
  end
end



class PokeBattle_BattlePeer
  def self.create
    return PokeBattle_NullBattlePeer.new()
  end
end



################################################################################
# Success State.
################################################################################
class PokeBattle_SuccessState
  attr_accessor :typemod
  attr_accessor :useState # 0 - not used, 1 - failed, 2 - succeeded
  attr_accessor :protected
  attr_accessor :skill # Used in Battle Arena

  def initialize
    clear
  end

  def clear
    @typemod=4
    @useState=0
    @protected=false
    @skill=0
  end

  def updateSkill
    if @useState==1 && !@protected
      @skill-=2
    elsif @useState==2
      if @typemod>4
        @skill+=2 # "Super effective"
      elsif @typemod>=1 && @typemod<4
        @skill-=1 # "Not very effective"
      elsif @typemod==0
        @skill-=2 # Ineffective
      else
        @skill+=1
      end
    end
    @typemod=4
    @useState=0
    @protected=false
  end
end



################################################################################
# Catching and storing PokÃ©mon.
################################################################################
module PokeBattle_BattleCommon
  def pbStorePokemon(pokemon)
    if !(pokemon.isShadow? rescue false)
      if pbDisplayConfirm(_INTL("Would you like to give a nickname to {1}?",pokemon.name))
        species=PBSpecies.getName(pokemon.species)
        nickname=@scene.pbNameEntry(_INTL("{1}'s nickname?",species),pokemon)
        pokemon.name=nickname if nickname!=""
      end
    end
    oldcurbox=@peer.pbCurrentBox()
    storedbox=@peer.pbStorePokemon(self.pbPlayer,pokemon)
    creator=@peer.pbGetStorageCreator()
    return if storedbox<0
    curboxname=@peer.pbBoxName(oldcurbox)
    boxname=@peer.pbBoxName(storedbox)
    if storedbox!=oldcurbox
      if creator
        pbDisplayPaused(_INTL("Box \"{1}\" on {2}'s PC was full.",curboxname,creator))
      else
        pbDisplayPaused(_INTL("Box \"{1}\" on someone's PC was full.",curboxname))
      end
      pbDisplayPaused(_INTL("{1} was transferred to box \"{2}\".",pokemon.name,boxname))
    else
      if creator
        pbDisplayPaused(_INTL("{1} was transferred to {2}'s PC.",pokemon.name,creator))
      else
        pbDisplayPaused(_INTL("{1} was transferred to someone's PC.",pokemon.name))
      end
      pbDisplayPaused(_INTL("It was stored in box \"{1}\".",boxname))
    end
  end

  def pbBallFetch(pokeball)
    if !pbInSafari?
      eachActiveBattlerIndex do |i|
        if self.battlers[i].ability==PBAbilities::BALLFETCH && !self.abilitynulled && self.battlers[i].item==0
          if $fefieldeffect == 28
            self.battlers[i].effects[PBEffects::BallFetch]=getID(PBItems,:SNOWBALL)
          else
            self.battlers[i].effects[PBEffects::BallFetch]=pokeball
          end
        end
      end
    end
  end

  def pbThrowPokeBall(idxPokemon,ball,rareness=nil,showplayer=false)
    PBDebug.log("[pbThrowPokeBall called with idxPokemon=#{idxPokemon}, ball=#{ball}]")
    itemname=PBItems.getName(ball)
    battler=nil
    if pbIsOpposing?(idxPokemon)
      battler=self.battlers[idxPokemon]
    else
      battler=self.battlers[idxPokemon].pbOppositeOpposing
    end
    battler=battler.firstLivingAlly if battler && battler.isFainted?
    pbDisplayBrief(_INTL("{1} threw one {2}!",self.pbPlayer.name,itemname))
    $game_variables[536] += 1
    if !battler
      pbDisplay(_INTL("But there was no target..."))
      pbBallFetch(ball)
      return
    end
    aboveLimit=battler.hp > (battler.totalhp * 0.25)
    no_catch = ($game_switches[290] || $game_switches[:No_Catch])
    if @opponent && ((!pbIsSnagBall?(ball) || !battler.isShadow?) || ((pbIsSnagBall?(ball) || battler.isShadow?) && $game_switches[1235]==true))
      @scene.pbThrowAndDeflect(ball,1)
      if !(no_catch || battler.isbossmon || battler.issossmon)
        pbDisplay(_INTL("The Trainer blocked the Ball!\nDon't be a thief!"))
      else
        pbDisplay(_INTL("The Pokémon knocked the ball away!"))
      end
      pbBallFetch(ball)
    elsif @raidbattle && (@shieldCount>0 || aboveLimit)
      pbDisplay(_INTL("The Pokémon knocked the ball away!"))
      pbBallFetch(ball)
    else
      if $game_switches[1998]==true
        pbDisplay(_INTL("The Ball didn't work!"))
        return
      end
      if no_catch || battler.issossmon || (battler.isbossmon && (!battler.capturable || battler.shieldCount > 0))
        pbDisplay(_INTL("The Pokémon knocked the ball away!"))
        pbBallFetch(ball)
        return
      end
      pokemon=battler.pokemon
      species=pokemon.species
      if $DEBUG && Input.press?(Input::CTRL)
        shakes=4
      else
        if !rareness
          rareness = $pkmn_dex[species][6]
        end
        formrarity = MultipleForms.call("catchrate",pokemon)
        if formrarity!=nil
          rareness = formrarity
        end
        # Check if Pokemon can be caught based on new rules
        trapped = (battler.effects[PBEffects::MeanLook]>=0 ||
                   battler.effects[PBEffects::MultiTurn]>0)
        hasStatus = (battler.status!=0)
        conditionMet = BallHandlers.isUnconditional?(ball,self,battler)

        # Pokemon can only be caught if trapped, has status, or ball condition met
        canCatch = (trapped || hasStatus || conditionMet)

        a=battler.totalhp
        b=battler.hp
        guaranteed=pbGuaranteedCatch?(ball,battler)
        rareness=BallHandlers.modifyCatchRate(ball,rareness,self,battler)
        x=(((a*3-b*2)*rareness)/(a*3)).floor
        #Critical Capture chances based on caught species'
        c=0
        if $Trainer
          if $Trainer.pokedexOwned>600
            c=(x*2.5/6).floor
          elsif $Trainer.pokedexOwned>450
            c=(x*2/6).floor
          elsif $Trainer.pokedexOwned>300
            c=(x*1.5/6).floor
          elsif $Trainer.pokedexOwned>150
            c=(x*1/6).floor
          elsif $Trainer.pokedexOwned>30
            c=(x*0.5/6).floor
          end
        end
        if $PokemonBag.pbHasItem?(:CATCHINGCHARM)
          c=(c*2.0).floor # 2.0 is a placeholder value, adjust later
        end
        shakes=0; critical=false; critsuccess=false
        if guaranteed
          shakes=4
        elsif !canCatch
          # Pokemon cannot be caught - not trapped, no status, condition not met
          shakes=0
        else
          if x>255
            shakes=4
          else
            x=1 if x<1
            y = (65536/((255.0/x)**0.1875) ).floor
            if pbRandom(256)<c
              critical=true
              if pbRandom(65536)<y
                critsuccess=true
                shakes=4
              end
            else
              shakes+=1 if pbRandom(65536)<y
              shakes+=1 if pbRandom(65536)<y
              shakes+=1 if pbRandom(65536)<y
              shakes+=1 if pbRandom(65536)<y
            end
          end
        end
      end
      @scene.pbThrow(ball,(critical) ? 1 : shakes,critical,critsuccess,battler.index,showplayer)

      case shakes
      when 0
        pbDisplay(_INTL("Oh no! The Pokémon broke free!"))
        BallHandlers.onFailCatch(ball,self,pokemon)
        pbBallFetch(ball)
      when 1
        pbDisplay(_INTL("Aww... It appeared to be caught!"))
        BallHandlers.onFailCatch(ball,self,pokemon)
        pbBallFetch(ball)
      when 2
        pbDisplay(_INTL("Aargh! Almost had it!"))
        BallHandlers.onFailCatch(ball,self,pokemon)
        pbBallFetch(ball)
      when 3
        pbDisplay(_INTL("Shoot! It was so close, too!"))
        BallHandlers.onFailCatch(ball,self,pokemon)
        pbBallFetch(ball)
      when 4
        pbDisplayBrief(_INTL("Gotcha! {1} was caught!",pokemon.name))
#        @scene.pbThrowSuccess
        if pbIsSnagBall?(ball) && @opponent
          pbRemoveFromParty(battler.index,battler.pokemonIndex)
          battler.pbReset
          battler.participants=[]
        elsif !@opponent && !singleBattle?
          #pk code
          party_index=@party2.index { |pkmn| pkmn.equal?(pokemon) }
          pbRemoveFromParty(battler.index,party_index) if party_index
          battler.pbReset
          battler.participants=[]
          @decision=4 if !battler.firstLivingAlly
        else
          @decision=4
        end
        if pbIsSnagBall?(ball)
          pokemon.ot=self.pbPlayer.name
          pokemon.trainerID=self.pbPlayer.id
        end
        BallHandlers.onCatch(ball,self,pokemon)
        pokemon.ballused=pbGetBallType(ball)
        pokemon.pbRecordFirstMoves
        self.pbPlayer.setSeen(species)
        pbSeenForm(pokemon) if self.pbPlayer.equal?($Trainer)
        if !self.pbPlayer.owned[species]
          self.pbPlayer.setOwned(species)
          if $Trainer.pokedex
            pbDisplayPaused(_INTL("{1}'s data was added to the Pokédex.",pokemon.name))
            @scene.pbShowPokedex(pokemon)
          end
        end
        @scene.pbHideCaptureBall
        if pbIsSnagBall?(ball) && @opponent
          pokemon.pbUpdateShadowMoves rescue nil
          @snaggedpokemon.push(pokemon)
        else
          pbStorePokemon(pokemon)
        end
      end
    end
  end
end

def pbIsTrappedForCatch?(battler)
  return false if !battler
  return true if battler.effects[PBEffects::MeanLook]>=0
  return true if battler.effects[PBEffects::MultiTurn]>0
  return true if battler.effects[PBEffects::Ingrain]
  return false
end

def pbGuaranteedCatch?(ball,battler)
  return false if !battler
  return true if BallHandlers.isUnconditional?(ball,self,battler)
  return false if @opponent # Don't auto-capture in trainer battles
  return true if battler.status!=0
  return true if pbIsTrappedForCatch?(battler)
  return false
end



################################################################################
# Main battle class.
################################################################################
class PokeBattle_Battle
  attr_reader(:scene)             # Scene object for this battle
  attr_accessor(:decision)        # Decision: 0=undecided; 1=win; 2=loss; 3=escaped; 4=caught
  attr_accessor(:internalbattle)  # Internal battle flag
  attr_accessor(:doublebattle)    # Double battle flag
  attr_reader(:sideSizes)         # Active battler counts for player/foe sides
  attr_accessor(:cantescape)      # True if player can't escape
  attr_accessor(:shiftStyle)      # Shift/Set "battle style" option
  attr_accessor(:battlescene)     # "Battle scene" option
  attr_accessor(:debug)           # Debug flag
  attr_reader(:player)            # Player trainer
  attr_reader(:opponent)          # Opponent trainer
  attr_reader(:party1)            # Player's PokÃ©mon party
  attr_reader(:party2)            # Foe's PokÃ©mon party
  attr_reader(:partyorder)        # Order of PokÃ©mon in the player's party
  attr_accessor(:fullparty1)      # True if player's party's max size is 6 instead of 3
  attr_accessor(:fullparty2)      # True if opponent's party's max size is 6 instead of 3
  attr_reader(:battlers)          # Currently active PokÃ©mon
  attr_accessor(:items)           # Items held by opponents
  attr_reader(:sides)             # Effects common to each side of a battle
  attr_reader(:field)             # Effects common to the whole of a battle
  attr_accessor(:environment)     # Battle surroundings
  attr_reader(:weather)         # Current weather, custom methods should use pbWeather instead
  attr_reader(:weatherduration) # Duration of current weather, or -1 if indefinite
  attr_accessor(:weatherbackup)    # The original weather of the area, if it exists.  #### DemICE - persistentweather
  attr_accessor(:weatherbackupanim)# Easy loading for original weather's animation.  #### DemICE - persistentweather
  attr_reader(:switching)         # True if during the switching phase of the round
  attr_reader(:faintswitch)       # True if switching after a faint during endphase
  attr_reader(:struggle)          # The Struggle move
  attr_accessor(:choices)         # Choices made by each PokÃ©mon this round
  attr_reader(:successStates)     # Success states
  attr_accessor(:lastMoveUsed)    # Last move used
  attr_accessor(:lastMoveUser)    # Last move user
  attr_accessor(:synchronize)     # Synchronize state
  attr_accessor(:megaEvolution)   # Battle index of each trainer's PokÃ©mon to Mega Evolve
  attr_accessor(:amuletcoin)      # Whether Amulet Coin's effect applies
  attr_accessor(:extramoney)      # Money gained in battle by using Pay Day
  attr_accessor(:endspeech)       # Speech by opponent when player wins
  attr_accessor(:endspeech2)      # Speech by opponent when player wins
  attr_accessor(:endspeechwin)    # Speech by opponent when opponent wins
  attr_accessor(:endspeechwin2)   # Speech by opponent when opponent wins
  attr_accessor(:trickroom)
#### KUROTSUNE - 015 - START
  attr_accessor(:switchedOut)
#### KUROTSUNE - 015 - END
  attr_accessor(:previousMove)    # Move used directly previously
  attr_accessor(:rules)
  attr_reader(:turncount)
  attr_accessor :controlPlayer
#### SARDINES - Eruption - START
  attr_accessor(:eruption)        # Eruption variable for Volcano Top field
#### SARDINES - Eruption - END
#### SARDINES - Dragon's Den - START
  attr_accessor(:basefield)
#### SARDINES - Dragon's Den - END
  attr_accessor(:maybestatusing)
  attr_accessor(:statustarget)
  attr_accessor(:raidbattle)      # stores fight is raid den battle or not
  attr_accessor(:ultramegadeath)  # ussd for Ultra Mega Death
  attr_accessor(:bossfight)       # Stores fight is boss battle or not
  attr_accessor(:shieldSetup)
  attr_accessor(:shieldCount)
  attr_accessor(:sosbattle)       # Stores fight is an sos battle or not
  attr_accessor(:lastFaintedEnemyAbility) # Last fainted enemy ability for Power of Alchemy
  attr_accessor(:lastFaintedAllyAbility)  # Last fainted ally ability for Receiver
  attr_accessor(:statChangeSource)
  attr_accessor(:icicleTributeBypass)

  include PokeBattle_BattleCommon

  MAXPARTYSIZE = 6

  class BattleAbortedException < Exception; end

  def pbAbort
    raise BattleAbortedException.new("Battle aborted")
  end

  def pbDebugUpdate
  end

  def pbRandom(x)
    return rand(x)
  end

  def pbAIRandom(x)
    return rand(x)
  end

  def pbWithStatChangeSource(source)
    previous_source=@statChangeSource
    @statChangeSource=source
    yield
  ensure
    @statChangeSource=previous_source
  end

  def pbWithIcicleTributeMove(user,move)
    previous_bypass=@icicleTributeBypass
    @icicleTributeBypass=move.tribute_status?(user,:ICICLETRIBUTE)
    yield
  ensure
    @icicleTributeBypass=previous_bypass
  end

  def pbRecordMirrorHerbBoost(source,stat,amount)
    return if amount<=0 || @statChangeSource==[:item,PBItems::MIRRORHERB]
    source.opposingLivingBattlers.each do |holder|
      next unless holder.hasWorkingItem(:MIRRORHERB)
      @mirrorHerbBoosts||={}
      boosts=@mirrorHerbBoosts[[holder,holder.pokemon]]||={}
      boosts[stat]=boosts.fetch(stat,0)+amount
    end
  end

  def pbResolveMirrorHerbs
    return if !@mirrorHerbBoosts
    pending=@mirrorHerbBoosts
    @mirrorHerbBoosts=nil
    pending.each do |(holder,pokemon),boosts|
      next unless holder.pokemon==pokemon && holder.hasWorkingItem(:MIRRORHERB)
      consumed=pbWithStatChangeSource([:item,PBItems::MIRRORHERB]) do
        boosts.map do |stat,amount|
          holder.pbIncreaseStat(stat,amount*holder.pbHeldItemDose,false)
        end.any?
      end
      holder.pbUseConsumableHeldItem if consumed
    end
  end

  def isOnline?
    return false
  end
################################################################################
# Initialise battle class.
################################################################################
  def initialize(scene,p1,p2,player,opponent)
    if p1.length==0
      raise ArgumentError.new(_INTL("Party 1 has no Pokémon."))
      return
    end
    if p2.length==0
      raise ArgumentError.new(_INTL("Party 2 has no Pokémon."))
      return
    end
    if p2.length>2 && !opponent
      raise ArgumentError.new(_INTL("Wild battles with more than two Pokémon are not allowed."))
      return
    end
    @scene           = scene
    @decision        = 0
    @internalbattle  = true
    @doublebattle    = false
    @sideSizes       = [1,1]
    @sizeRuleExplicit = false
    @cantescape      = false
    @shiftStyle      = true
    @battlescene     = true
    @debug           = false
    @debugupdate     = 0
	@shieldCount = $game_variables[704]
	@shieldSetup = -1
    if opponent && player.is_a?(Array) && player.length==0
      player = player[0]
    end
    if opponent && opponent.is_a?(Array) && opponent.length==0
      opponent = opponent[0]
    end
    @player          = player                # PokeBattle_Trainer object
    @opponent        = opponent              # PokeBattle_Trainer object
    @party1          = p1
    @party2          = p2
    @partyorder      = []
    # Extend partyorder for partner battles with control enabled
    maxparty = ($game_switches[2030] && player.is_a?(Array)) ? 12 : 6
    for i in 0...maxparty; @partyorder.push(i); end
    @fullparty1      = false
    @fullparty2      = false
    @battlers        = []
    @items           = nil
    @sides           = [PokeBattle_ActiveSide.new,   # Player's side
                        PokeBattle_ActiveSide.new]   # Foe's side
    @field           = PokeBattle_ActiveField.new    # Whole field (gravity/rooms)
    @environment     = PBEnvironment::None   # e.g. Tall grass, cave, still water
    @weather         = 0
    @weatherduration = 0
    @weatherbackup    = 0      #### DemICE - persistentweather
    @weatherbackupanim = nil  #### DemICE  - persistentweather
    @switching       = false
    @faintswitch     = false
    @choices         = [ [0,0,nil,-1],[0,0,nil,-1],[0,0,nil,-1],[0,0,nil,-1] ]
    @successStates   = []
    for i in 0...4
      @successStates.push(PokeBattle_SuccessState.new)
    end
    @lastMoveUsed    = -1
    @lastMoveUser    = -1
    @lastFaintedEnemyAbility = [nil, nil] # [player side, opponent side]
    @lastFaintedAllyAbility = [nil, nil]  # [player side, opponent side]
    @partnerswitch   = []
    @synchronize     = [-1,-1,0]
    @megaEvolution   = []
    if @player.is_a?(Array)
      @megaEvolution[0]=[-1]*@player.length
    else
      @megaEvolution[0]=[-1]
    end
    if @opponent.is_a?(Array)
      @megaEvolution[1]=[-1]*@opponent.length
    else
      @megaEvolution[1]=[-1]
    end
    @zMove           = []
    if @player.is_a?(Array)
      @zMove[0]=[-1]*@player.length
    else
      @zMove[0]=[-1]
    end
    if @opponent.is_a?(Array)
      @zMove[1]=[-1]*@opponent.length
    else
      @zMove[1]=[-1]
    end
    @amuletcoin      = false
#### KUROTSUNE - 015 - START
    @switchedOut     = []
#### KUROTSUNE - 015 - END
    @extramoney      = 0
    @endspeech       = ""
    @endspeech2      = ""
    @endspeechwin    = ""
    @endspeechwin2   = ""
    @rules           = {}
    @turncount       = 0
    @peer            = PokeBattle_BattlePeer.create()
    @trickroom       = 0
    @priority        = []
    @usepriority     = false
    @snaggedpokemon  = []
    @runCommand      = 0
    if hasConst?(PBMoves,:STRUGGLE)
      @struggle = PokeBattle_Move.pbFromPBMove(self,PBMove.new(getConst(PBMoves,:STRUGGLE)),nil)
    else
      @struggle = PokeBattle_Struggle.new(self,nil,nil)
    end
    @struggle.pp     = -1
    for i in 0...4
      battlers[i] = PokeBattle_Battler.new(self,i)
    end
    for i in @party1
      next if !i
      i.itemRecycle = 0
      i.itemInitial = i.item
      i.harvestBerry = 0
      i.harvestUsed = false
    end
    for i in @party2
      next if !i
      i.itemRecycle = 0
      i.itemInitial = i.item
      i.harvestBerry = 0
      i.harvestUsed = false
    end
#### SARDINES - Eruption - START
    @eruption        = false
#### SARDINES - Eruption - END
    @basefield       = 0
    @sosbattle       = 2
    @maybestatusing  = false
    @statustarget    = nil
    @raidbattle      = $game_switches[1499]
    $game_variables[530] = 0
    $game_variables[536] = 0
    $game_variables[541] = 0
    @ultramegadeath  = 0
  end


  def pbMakeFakeBattler(pokemon,batonpass=false,currentmon=nil,effectnegate=true)
    if @index.nil? || !currentmon.nil?
       @index=currentmon.index
    end
    wonderroom= @field.effects[PBEffects::WonderRoom]!=0
    battler = PokeBattle_Battler.new(self,@index)
    battler.pbInitPokemon(pokemon,@index,wonderroom)
    battler.pbInitEffects(batonpass,false,effectnegate)
    return battler
  end
################################################################################
# Info about battle.
################################################################################
  def pbIsWild?
    return !@opponent? true : false
  end

  def pbDoubleBattleAllowed?
    return true
  end

  def doublebattle=(value)
    @doublebattle = value ? true : false
    return if @sizeRuleExplicit
    @sideSizes = @doublebattle ? [2,2] : [1,1]
  end

  def pbEnsureBattlerSlots(slot_count)
    slot_count = [slot_count.to_i, 4].max
    while @choices.length < slot_count
      @choices.push([0,0,nil,-1])
    end
    while @successStates.length < slot_count
      @successStates.push(PokeBattle_SuccessState.new)
    end
    while @battlers.length < slot_count
      @battlers[@battlers.length] = PokeBattle_Battler.new(self, @battlers.length)
    end
  end

  def setBattleMode(mode, explicit = true)
    normalized = pbNormalizeBattleSizeRule(mode)
    normalized = (@doublebattle) ? "double" : "single" if !normalized
    @sizeRuleExplicit = explicit
    @sideSizes = [
       pbBattleSideSizeFromRule(normalized, false),
       pbBattleSideSizeFromRule(normalized, true)
    ]
    @doublebattle = (@sideSizes[0] > 1 || @sideSizes[1] > 1)
    @rules["size"] = normalized if @rules
    pbEnsureBattlerSlots(@sideSizes.max * 2)
    return normalized
  end

  def pbSideSize(index)
    return @sideSizes[pbIsOpposing?(index) ? 1 : 0]
  end

  def singleBattle?
    return @sideSizes[0] <= 1 && @sideSizes[1] <= 1
  end

  def maxBattlerIndex
    return [@battlers.length - 1, (@sideSizes.max * 2) - 1, 3].max
  end

  def pbSidePosition(index)
    return index / 2
  end

  def tripleBattle?
    return @sideSizes[0] >= 3 || @sideSizes[1] >= 3
  end

  def pbBattlerIndex(side, position)
    return (position * 2) + side
  end

  def pbEncodeShiftSelection(battlerIndex)
    return -(1000 + battlerIndex + 1)
  end

  def pbShiftSelection?(selection)
    return selection.is_a?(Numeric) && selection <= -1001
  end

  def pbDecodeShiftSelection(selection)
    return nil if !pbShiftSelection?(selection)
    return (-selection) - 1001
  end

  def pbFirstEmptySameSideBattlerIndex(index)
    side = pbIsOpposing?(index) ? 1 : 0
    for position in 0...@sideSizes[side]
      battler_index = pbBattlerIndex(side, position)
      battler = @battlers[battler_index]
      return battler_index if !battler || battler.isFainted? || battler.hp<=0
    end
    return nil
  end

  def eachSameSideBattler(index)
    return if !block_given?
    side = pbIsOpposing?(index) ? 1 : 0
    for position in 0...@sideSizes[side]
      battler = @battlers[pbBattlerIndex(side, position)]
      yield battler if battler
    end
  end

  def eachOtherSideBattler(index)
    return if !block_given?
    side = pbIsOpposing?(index) ? 0 : 1
    for position in 0...@sideSizes[side]
      battler = @battlers[pbBattlerIndex(side, position)]
      yield battler if battler
    end
  end

  def allSameSideBattlers(index)
    ret = []
    eachSameSideBattler(index) { |battler| ret.push(battler) }
    return ret
  end

  def allOtherSideBattlers(index)
    ret = []
    eachOtherSideBattler(index) { |battler| ret.push(battler) }
    return ret
  end

  def eachActiveBattlerIndex
    return if !block_given?
    for i in 0...@battlers.length
      next if pbSidePosition(i) >= pbSideSize(i)
      yield i
    end
  end

  def activeBattlerIndices
    ret = []
    eachActiveBattlerIndex { |i| ret.push(i) }
    return ret
  end

  def nearBattlers?(index1, index2)
    pos1 = pbSidePosition(index1)
    pos2 = pbSidePosition(index2)
    if pbIsOpposing?(index1) != pbIsOpposing?(index2)
      return (pos1 - pos2).abs <= 1
    end
    return (pos1 - pos2).abs == 1
  end

  def pbTripleLaneDistance(index1, index2)
    return (pbSidePosition(index1) - pbSidePosition(index2)).abs
  end

  def pbMoveIgnoresTripleLanes?(move, attacker, target = nil)
    return false if !tripleBattle? || !move || !attacker
    return true if move.tribute_has?(attacker,:EARTHTRIBUTE)
    return true if move.id==PBMoves::SANDATTACK
    resolved_type = move.type
    if move.respond_to?(:pbType)
      begin
        resolved_type = move.pbType(move.type, attacker, target)
      rescue
        resolved_type = move.type
      end
    end
    return true if isConst?(resolved_type, PBTypes, :FLYING)
    return true if isConst?(resolved_type, PBTypes, :GHOST)
    return true if PBStuff::AURAPULSEMOVE.include?(move.id)
    return true if PBStuff::CANNONMOVE.include?(move.id)
    return true if move.isBeamMove?
    return true if PBStuff::WINDMOVE.include?(move.id)
    return true if PBStuff::SCALINGMOVE.include?(move.id)
    return false
  end

  def pbMoveCanTargetInTriple?(attacker, target, move)
    return true if !tripleBattle? || !attacker || !target || !move
    return true if attacker.index == target.index
    return true if pbMoveIgnoresTripleLanes?(move, attacker, target)
    return pbTripleLaneDistance(attacker.index, target.index) <= 1
  end

  def pbTripleLaneDamageMultiplier(attacker, target, move)
    return 1.0 if !tripleBattle? || !attacker || !target || !move
    return 1.0 if move.basedamage <= 0
    spread_move = false
    if attacker.respond_to?(:pbTarget)
      chosen_target = attacker.pbTarget(move)
      spread_move = (chosen_target == PBTargets::AllOpposing || chosen_target == PBTargets::AllNonUsers)
    end
    return 0.5 if spread_move
    case pbTripleLaneDistance(attacker.index, target.index)
    when 0 then return 1.0
    when 1 then return 0.5
    else        return 0.75
    end
  end

  def pbActiveSameSideBattlerForPartyIndex(idxPokemon, pkmnidxTo)
    ret = nil
    eachSameSideBattler(idxPokemon) do |battler|
      next if !battler || battler.isFainted?
      if battler.pokemonIndex == pkmnidxTo
        ret = battler
        break
      end
    end
    return ret
  end

  #pk code
  def pbShiftTargeted?(index, except_index=nil)
    return @choices.each_with_index.any? do |choice, i|
      i!=except_index && choice[0]==2 && choice[2]==:shift && choice[3]==index
    end
  end

  def pbCanShift?(idxPokemon, targetBattlerIndex, showMessages, move_swap: false)
    return false if move_swap ? singleBattle? : !tripleBattle?
    return false if targetBattlerIndex.nil? || targetBattlerIndex < 0 || targetBattlerIndex >= @battlers.length
    targetBattler = @battlers[targetBattlerIndex]
    return false if !targetBattler || targetBattler.isFainted?
    if idxPokemon == targetBattlerIndex
      pbDisplayPaused(_INTL("{1} is already in battle!", @battlers[idxPokemon].name)) if showMessages
      return false
    end
    if pbIsOpposing?(idxPokemon) != pbIsOpposing?(targetBattlerIndex)
      pbDisplayPaused(_INTL("You can only shift with an allied Pokémon.")) if showMessages
      return false
    end
    if pbGetOwnerIndex(idxPokemon) != pbGetOwnerIndex(targetBattlerIndex)
      pbDisplayPaused(_INTL("Those Pokémon can't swap lanes.")) if showMessages
      return false
    end
    if targetBattler.effects[PBEffects::Commander] || @battlers[idxPokemon].effects[PBEffects::Commander]
      pbDisplayPaused(_INTL("A Pokémon inside Dondozo can't shift lanes.")) if showMessages
      return false
    end
    return true if move_swap
    return false if !pbCanSwitch?(idxPokemon, -1, showMessages)
    #pk code
    if pbShiftTargeted?(idxPokemon)
      pbDisplayPaused(_INTL("{1} is already repositioning this round!", @battlers[idxPokemon].pbThis)) if showMessages
      return false
    end
    if @choices[targetBattlerIndex][0]==2 || pbShiftTargeted?(targetBattlerIndex,idxPokemon)
      pbDisplayPaused(_INTL("{1} is already repositioning this round!", targetBattler.pbThis)) if showMessages
      return false
    end
    return true
  end

  def pbCheckSideAbility(a,pkmn) #checks to see if your side has a pokemon with a certain ability.
    for i in 0..maxBattlerIndex # in order from own first, opposing first, own second, opposing second
      if @battlers[i].hasWorkingAbility(a)
        if !pkmn || !pkmn.respond_to?(:index)
          return @battlers[i]
        end
        sameSide = false
        eachSameSideBattler(pkmn.index) do |battler|
          if battler==@battlers[i]
            sameSide = true
            break
          end
        end
        if sameSide
          return @battlers[i]
        end
      end
    end
    return nil
  end

  def weather=(weather)
    azureInvalidateJetstreamWeather
    @weather=weather
  end

  def weatherduration=(duration)
    azureInvalidateJetstreamWeather
    @weatherduration=duration
  end

  def pbWeather
    for i in 0..maxBattlerIndex
      if @battlers[i].hasWorkingAbility(:CLOUDNINE) ||
         @battlers[i].hasWorkingAbility(:AIRLOCK) ||
         $fefieldeffect == 22
        return 0
      end
    end
    return @weather
  end

  def pbClearTeraformWeatherAndTerrain(battler)
    effects=@field.effects
    overlays=[PBEffects::ElectricTerrain,PBEffects::GrassyTerrain,PBEffects::MistyTerrain,PBEffects::PsychicTerrain]
    temporary=effects[PBEffects::Terrain]>0 || effects[PBEffects::Splintered]>0
    changed=temporary || @weather>0 || overlays.any? { |effect| effects[effect]>0 }
    return false if !changed
    @weather=@weatherduration=@weatherbackup=0
    @weatherbackupanim=nil
    effects[PBEffects::HarshSunlight]=false
    effects[PBEffects::HeavyRain]=false
    overlays.each { |effect| effects[effect]=0 }
    if temporary
      effects[PBEffects::Terrain]=0
      effects[PBEffects::Splintered]=0
      $fefieldeffect=$febackup
      pbChangeBGSprite
    end
    pbDisplay(_INTL("{1}'s {2} eliminated the weather and terrain!",battler.pbThis,PBAbilities.getName(battler.ability)))
    return true
  end

  def pbCanChangeFieldSeedStat?(battler,stat,increase=true)
    pbWithStatChangeSource([:item,battler.item]) do
      increase ? !battler.pbTooHigh?(stat) : !battler.pbTooLow?(stat)
    end
  end

  def pbChangeFieldSeedStat(battler,stat,increment)
    dose=battler.pbHeldItemDose
    pbWithStatChangeSource([:item,battler.item]) do
      if increment>0
        battler.pbIncreaseStatBasic(stat,increment*dose)
      else
        battler.pbReduceStatBasic(stat,-increment*dose)
      end
    end
  end

  def seedCheck
    for battler in @battlers
      next if !battler.itemWorks? || battler.item<=0
      dose=battler.pbHeldItemDose
      if isConst?(battler.item, PBItems, :ELEMENTALSEED)
        case $fefieldeffect
        when 1 #Electric Terrain
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::Charge]=true
          pbAnimation(81,battler,nil) # Charge Animation
          pbDisplay(_INTL("{1} began charging power!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 2 #Grassy Terrain
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::Ingrain]=true
          pbAnimation(216,battler,nil) # Ingrain Animation
          pbDisplay(_INTL("{1} planted its roots!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 3 #Misty Terrain
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Special Defense!",
              battler.pbThis))
          end
          battler.pbRecoverHP(battler.totalhp,true)
          battler.status=0
          battler.statusCount=0
          pbDisplayPaused(_INTL("The healing wish came true for {1}!",battler.pbThis(true)))
          battler.pbUseConsumableHeldItem
        when 7 #Burning Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Special Attack, Attack, and Speed!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MultiTurn]=4*dose
          battler.effects[PBEffects::MultiTurnAttack]=147
          battler.effects[PBEffects::MultiTurnUser]=battler.index
          pbAnimation(147,battler,nil) # Fire Spin Animation
          pbDisplayPaused(_INTL("{1} was trapped in the vortex!",battler.pbThis(true)))
          battler.pbUseConsumableHeldItem
        when 11 #Corrosive Mist Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Attack and Special Attack!",
              battler.pbThis))
          end
          if battler.pbCanPoison?(true)
            battler.pbPoison(battler,true)
            pbDisplayPaused(_INTL("{1} was badly poisoned!",battler.pbThis(true)))
          end
          battler.pbUseConsumableHeldItem
        when 13 #Icy Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,2)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed sharply boosted its Speed!",
              battler.pbThis))
            battler.pbUseConsumableHeldItem
          end
        when 21 #Water Surface
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Special Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::AquaRing]=true
          pbAnimation(555,battler,nil) # Aqua Ring animation
          pbDisplay(_INTL("{1} surrounded itself with a veil of water!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 22 #Underwater
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Speed!",
              battler.pbThis))
          end
          if !(isConst?(battler.ability,PBAbilities,:MULTITYPE) ||
             isConst?(battler.ability,PBAbilities,:RKSSYSTEM))
            battler.type1=getConst(PBTypes,:WATER)
            battler.type2=getConst(PBTypes,:WATER)
            typename=PBTypes.getName(getConst(PBTypes,:WATER))
            pbAnimation(557,battler,nil) # Soak animation
            pbDisplay(_INTL("{1} transformed into the {2} type!",battler.pbThis,typename))
          end
          battler.pbUseConsumableHeldItem
        when 26 #Murkwater Surface
          battler.effects[PBEffects::AquaRing]=true
          pbAnimation(555,battler,nil) # Aqua Ring animation
          pbDisplay(_INTL("{1} surrounded itself with a veil of water!",battler.pbThis))
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Speed!",
              battler.pbThis))
          end
          if battler.pbCanPoison?(true)
            battler.pbPoison(battler,true)
            pbDisplayPaused(_INTL("{1} was badly poisoned!",battler.pbThis(true)))
          end
          battler.pbUseConsumableHeldItem
        when 32 #Dragon's Den
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Special Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::FlashFire]=true
          #pbAnimation(555,battler,nil) # Aqua Ring animation
          pbDisplay(_INTL("{1} raised its Fire power!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 39 #Frozen Dimensional Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,2)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its Speed!",
              battler.pbThis))
          end
          if !battler.effects[PBEffects::Torment] && !battler.hasWorkingAbility(:OBLIVIOUS)
            battler.effects[PBEffects::Torment]=true
            pbDisplay(_INTL("{1} was subjected to torment!",
              battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 43 #Sky Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF,false)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,-1)
            pbCommonAnimation("StatDown",battler,nil)
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE,false)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,-1)
            pbCommonAnimation("StatDown",battler,nil)
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Elemental Seed lowered its Defense and Special Defense!",
              battler.pbThis))
          end
          battler.pbOwnSide.effects[PBEffects::Tailwind]=8*dose
          pbAnimation(173,battler,nil) # Tailwind Animation
          pbDisplay(_INTL("The tailwind blew from behind {1}'s team!",battler.pbThis))
          # if @weather!=PBWeather::STRONGWINDS
          #   @weather=PBWeather::STRONGWINDS
          #   @weatherduration=-1
          # end
          battler.pbUseConsumableHeldItem
        when 45 #Infernal Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Elemental Seed boosted its offenses!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MeanLook]=battler.index
          pbAnimation(379,battler,nil) # Mean Look Animation
          pbDisplayPaused(_INTL("{1} was trapped in the field!",battler.pbThis(true)))
          battler.pbUseConsumableHeldItem
        end
      elsif isConst?(battler.item, PBItems, :MAGICALSEED)
        case $fefieldeffect
        when 4 #Dark Crystal Cavern
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Special Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MagicCoat]=true
          pbAnimation(484,battler,nil) # Magic Coat Animation
          pbDisplay(_INTL("{1} shrouded itself with Magic Coat!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 9 #Rainbow Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Special Attack!",
              battler.pbThis))
          end
          battler.pbRecoverHP(battler.totalhp,true)
          battler.status=0
          battler.statusCount=0
          pbDisplayPaused(_INTL("The healing wish came true for {1}!",battler.pbThis(true)))
          battler.pbUseConsumableHeldItem
        when 25 #Crystal Cavern
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Special Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MagicCoat]=true
          pbAnimation(484,battler,nil) # Magic Coat Animation
          pbDisplay(_INTL("{1} shrouded itself with Magic Coat!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 29 #Holy Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Special Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MagicCoat]=true
          pbAnimation(484,battler,nil) # Magic Coat Animation
          pbDisplay(_INTL("{1} shrouded itself with Magic Coat!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 31 #Fairy Tale Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::KingsShield]=true
          pbAnimation(584,battler,nil) # King's Shield Animation
          pbDisplay(_INTL("{1} shielded itself against damage!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 34 #Starlight Arena
          next if isConst?(battler.ability,PBAbilities,:WORLDOFNIGHTMARES)
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Special Attack!",
              battler.pbThis))
          end
          battler.pbRecoverHP(battler.totalhp,true)
          battler.status=0
          battler.statusCount=0
          pbDisplayPaused(_INTL("{1} became cloaked in mystical moonlight!!",battler.pbThis(true)))
          battler.pbUseConsumableHeldItem
        when 35 #New World
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Magical Seed boosted all of its stats!",
              battler.pbThis))
          end
          battler.effects[PBEffects::HyperBeam]=1*dose
          pbDisplay(_INTL("{1} must recharge!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 36 #Inverse Field
          if !battler.pbHasType?(:NORMAL)
            newtype=getConst(PBTypes,:NORMAL) || 0
            battler.type1=newtype
            battler.type2=newtype
            typename=PBTypes.getName(newtype)
            pbDisplay(_INTL("{1} transformed into the {2} type!",
              battler.pbThis,typename))
          end
          if !isConst?(battler.ability,PBAbilities,:NORMALIZE)
            battler.ability=getConst(PBAbilities,:NORMALIZE) || 0
            pbDisplay(_INTL("{1}'s Magical Seed Normalized it!",
              battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 37 #Psychic Terrain
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Special Attack and Special Defense!",
              battler.pbThis))
          end
          if battler.pbCanConfuse?(false)
            battler.effects[PBEffects::Confusion]=3*dose
            pbCommonAnimation("Confusion",battler,nil)
            pbDisplay(_INTL("{1} became confused!",battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 38 #Dimensional Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Defense!",
              battler.pbThis))
          end
          if @trickroom == 0
            @trickroom=5*dose
            pbAnimation(499,battler,nil) # Trick Room Animation
            pbDisplay(_INTL("{1} twisted the dimensions!",battler.pbThis))
          else
            @trickroom=0
            pbAnimation(499,battler,nil) # Trick Room Animation
            pbDisplay(_INTL("The twisted dimensions returned to normal!",battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 40 #Haunted Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Defense and Special Defense!",
              battler.pbThis))
          end
          if battler.pbCanBurn?(true)
            battler.pbBurn(battler)
            pbDisplayPaused(_INTL("{1} was burned!",battler.pbThis(true)))
          end
          battler.pbUseConsumableHeldItem
        when 42 #Bewitched Woods
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Magical Seed boosted its Special Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::Ingrain]=true
          pbAnimation(216,battler,nil) # Ingrain Animation
          pbDisplay(_INTL("{1} planted its roots!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        end
      elsif isConst?(battler.item, PBItems, :SYNTHETICSEED)
        case $fefieldeffect
        when 5 #Chess Board
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Special Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MagicCoat]=true
          pbAnimation(484,battler,nil) # Magic Coat Animation
          pbDisplay(_INTL("{1} shrouded itself with Magic Coat!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 6 #Big Top
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::HelpingHand]=true
          # pbAnimation(372,battler,nil) # Helping Hand Animation
          pbDisplay(_INTL("{1} accepts the crowd's help!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 17 #Factory
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Special Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::LaserFocus]=2*dose
          pbAnimation(658,battler,nil) # Laser Focus Animation
          pbDisplay(_INTL("{1} is focused!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 18 #Short-Circuit
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Special Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MagnetRise]=8*dose
          pbAnimation(82,battler,nil) # Magnet Rise Animation
          pbDisplay(_INTL("{1} levitated with electromagnetism!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 24 #Glitch
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Defense and Special Defense!",
              battler.pbThis))
          end
          if !(isConst?(battler.ability,PBAbilities,:MULTITYPE) ||
             isConst?(battler.ability,PBAbilities,:RKSSYSTEM))
            battler.type1=getConst(PBTypes,:QMARKS)
            battler.type2=getConst(PBTypes,:QMARKS)
            typename=PBTypes.getName(getConst(PBTypes,:QMARKS))
           #No anim? pbAnimation(557,battler,nil) # Soak animation
            pbDisplay(_INTL("{1}.TYPE = GETCONST(PBTYPES,:QMARKS)",battler.pbThis.upcase,typename))
          end
          battler.pbUseConsumableHeldItem
        when 30 #Mirror Arena
          if pbCanChangeFieldSeedStat?(battler,PBStats::EVASION)
            pbChangeFieldSeedStat(battler,PBStats::EVASION,2)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Synthetic Seed sharply boosted its Evasion!",
              battler.pbThis))
            battler.pbUseConsumableHeldItem
          end
        when 33 #Flower Garden
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Special Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::Ingrain]=true
          pbAnimation(216,battler,nil) # Ingrain Animation
          pbDisplay(_INTL("{1} planted its roots!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 41 #Corrupted Cave
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,2)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Defense!",
              battler.pbThis))
          end
          if battler.pbCanPoison?(true)
            battler.pbPoison(battler,true)
            pbDisplayPaused(_INTL("{1} was poisoned!",battler.pbThis(true)))
          end
          battler.pbUseConsumableHeldItem
        when 44 #Colosseum Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,2)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            pbDisplay(_INTL("{1}'s Synthetic Seed boosted its Attack!",
              battler.pbThis))
          end
          if battler.effects[PBEffects::Taunt]==0
            pbAnimation(49,battler,nil) # Taunt Animation
            battler.effects[PBEffects::Taunt]=4*dose
            pbDisplayPaused(_INTL("{1} feels taunted!",battler.pbThis(true)))
          end
          battler.pbUseConsumableHeldItem
        when 47 # Library Field
          if battler.effects[PBEffects::FocusEnergy] < 3
            battler.effects[PBEffects::FocusEnergy]=3*dose
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Synthetic Seed sharpened its focus!",battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        end
      elsif isConst?(battler.item, PBItems, :TELLURICSEED)
        case $fefieldeffect
        when 8 #Swamp Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Defense and Special Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::Ingrain]=true
          pbAnimation(216,battler,nil) # Ingrain Animation
          pbDisplay(_INTL("{1} planted its roots!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 10 #Corrosive Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::BanefulBunker]=true
          pbAnimation(693,battler,nil) # Baneful Bunker Animation
          pbDisplay(_INTL("{1} shielded itself against damage!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 12 #Desert Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Special Defense, Defense, and Speed!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MultiTurn]=4*dose
          battler.effects[PBEffects::MultiTurnAttack]=232
          battler.effects[PBEffects::MultiTurnUser]=battler.index
          pbAnimation(232,battler,nil) # Sand Tomb Animation
          pbDisplayPaused(_INTL("{1} was trapped by Sand Tomb!",battler.pbThis(true)))
          battler.pbUseConsumableHeldItem
        when 14 #Rocky Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
            pbChangeFieldSeedStat(battler,PBStats::SPDEF,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Defense and Special Defense!",
              battler.pbThis))
          end
          if !battler.hasWorkingAbility(:MAGICGUARD)
            atype=getConst(PBTypes,:ROCK) || 0
            eff=PBTypes.getCombinedEffectiveness(atype,battler.type1,battler.type2)
            if eff>0
              eff = eff*2
              @scene.pbDamageAnimation(battler,0)
              battler.pbReduceHP([(battler.totalhp*eff*dose/32).floor,1].max)
              pbDisplay(_INTL("{1} was hurt by stealth rocks!",battler.pbThis))
              battler.pbFaint if battler.isFainted?
            end
          end
          battler.pbUseConsumableHeldItem
        when 15 #Forest Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Attack!",
              battler.pbThis))
          end
          battler.effects[PBEffects::SpikyShield]=true
          pbAnimation(603,battler,nil) # Spiky Shield Animation
          pbDisplay(_INTL("{1} shielded itself against damage!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 16 #Superheated Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Defense!",
              battler.pbThis))
          end
          battler.effects[PBEffects::ShellTrap]=true
          pbCommonAnimation("ShellTrap",battler,nil) # Shell Trap Animation
          pbDisplay(_INTL("{1} primed a trap!",battler.pbThis))
          battler.pbUseConsumableHeldItem
        when 19 #Wasteland
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Attack and Special Attack!",
              battler.pbThis))
          end
          rnd=pbRandom(4)
          case rnd
          when 0
            if battler.pbCanBurn?(false)
              battler.pbBurn(battler)
              pbDisplay(_INTL("{1} was burned!",battler.pbThis))
            end
          when 1
            if battler.pbCanFreeze?(false)
              battler.pbFreeze
              pbDisplay(_INTL("{1} was frozen solid!",battler.pbThis))
            end
          when 2
            if battler.pbCanParalyze?(false)
              battler.pbParalyze(battler)
              pbDisplay(_INTL("{1} is paralyzed! It may be unable to move!",battler.pbThis))
            end
          when 3
            if battler.pbCanPoison?(false)
              battler.pbPoison(battler)
              pbDisplay(_INTL("{1} was poisoned!",battler.pbThis))
            end
          end
          battler.pbUseConsumableHeldItem
        when 20 #Ashen Beach
          if !(battler.effects[PBEffects::FocusEnergy]>=2)
            battler.effects[PBEffects::FocusEnergy]=3*dose
            pbAnimation(364,battler,nil) # Focus Energy Animation
            pbDisplay(_INTL("{1}'s Telluric Seed is getting it pumped!",
              battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 23 #Cave Field
          if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
            pbChangeFieldSeedStat(battler,PBStats::DEFENSE,2) # Sharply boost Defense
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed sharply boosted its Defense!",
              battler.pbThis))
          end
          # Apply crushing status to the holder
          if battler.pbCanCrush?(false)
            battler.pbCrush(battler)
            pbDisplay(_INTL("{1} was crushed!",battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 27 #Mountain
          if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
            pbChangeFieldSeedStat(battler,PBStats::ATTACK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Attack!",
              battler.pbThis))
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::ACCURACY,false)
            pbChangeFieldSeedStat(battler,PBStats::ACCURACY,-1)
            pbCommonAnimation("StatDown",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed lowered its Accuracy!",
              battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 28 #Snowy Mountain
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
            pbChangeFieldSeedStat(battler,PBStats::SPATK,1)
            pbCommonAnimation("StatUp",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Special Attack!",
              battler.pbThis))
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::ACCURACY,false)
            pbChangeFieldSeedStat(battler,PBStats::ACCURACY,-1)
            pbCommonAnimation("StatDown",battler,nil)
            pbDisplay(_INTL("{1}'s Telluric Seed lowered its Accuracy!",
              battler.pbThis))
          end
          battler.pbUseConsumableHeldItem
        when 46 #Beach Field
          boost=false
          if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
            pbChangeFieldSeedStat(battler,PBStats::SPEED,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if pbCanChangeFieldSeedStat?(battler,PBStats::ACCURACY)
            pbChangeFieldSeedStat(battler,PBStats::ACCURACY,1)
            pbCommonAnimation("StatUp",battler,nil) if !boost
            boost=true
          end
          if boost
            pbDisplay(_INTL("{1}'s Telluric Seed boosted its Speed and Accuracy!",
              battler.pbThis))
          end
          battler.effects[PBEffects::MultiTurn]=4*dose
          battler.effects[PBEffects::MultiTurnAttack]=232
          battler.effects[PBEffects::MultiTurnUser]=battler.index
          pbAnimation(232,battler,nil) # Sand Tomb Animation
          pbDisplayPaused(_INTL("{1} was trapped by Sand Tomb!",battler.pbThis(true)))
          battler.pbUseConsumableHeldItem
        end
      elsif isConst?(battler.item, PBItems, :RIFTSEED)
        next if $fefieldeffect!=38 && $fefieldeffect!=39
        if $fefieldeffect==38 || $fefieldeffect==39 #Dimensional/Frozen Dim Field
          increment = 1
          increment = 2 if $fefieldeffect == 38
          aBoost = battler.attack
          dBoost = battler.defense
          saBoost = battler.spatk
          sdBoost = battler.spdef
          spdBoost = battler.speed
          boostStat = [aBoost,dBoost,saBoost,sdBoost,spdBoost].max
          case boostStat
          when aBoost
            if pbCanChangeFieldSeedStat?(battler,PBStats::ATTACK)
              pbCommonAnimation("StatUp",battler,nil)
              pbChangeFieldSeedStat(battler,PBStats::ATTACK,increment)
              pbDisplay(_INTL("{1}'s Rift Seed boosted its Attack!",battler.pbThis))
            end
          when dBoost
            if pbCanChangeFieldSeedStat?(battler,PBStats::DEFENSE)
              pbCommonAnimation("StatUp",battler,nil)
              pbChangeFieldSeedStat(battler,PBStats::DEFENSE,increment)
              pbDisplay(_INTL("{1}'s Rift Seed boosted its Defense!",battler.pbThis))
            end
          when saBoost
            if pbCanChangeFieldSeedStat?(battler,PBStats::SPATK)
              pbCommonAnimation("StatUp",battler,nil)
              pbChangeFieldSeedStat(battler,PBStats::SPATK,increment)
              pbDisplay(_INTL("{1}'s Rift Seed boosted its Special Attack!",battler.pbThis))
            end
          when sdBoost
            if pbCanChangeFieldSeedStat?(battler,PBStats::SPDEF)
              pbCommonAnimation("StatUp",battler,nil)
              pbChangeFieldSeedStat(battler,PBStats::SPDEF,increment)
              pbDisplay(_INTL("{1}'s Rift Seed boosted its Special Defense!",battler.pbThis))
            end
          when spdBoost
            if pbCanChangeFieldSeedStat?(battler,PBStats::SPEED)
              pbCommonAnimation("StatUp",battler,nil)
              pbChangeFieldSeedStat(battler,PBStats::SPEED,increment)
              pbDisplay(_INTL("{1}'s Rift Seed boosted its Speed!",battler.pbThis))
            end
          end
        end
        battler.pbUseConsumableHeldItem
      end
    end
  end

################################################################################
# Get battler info.
################################################################################
  def pbIsOpposing?(index)
    return (index%2)==1
  end

  def pbGetOwnerIndexFromBattlerIndex(battlerIndex)
    owners = pbIsOpposing?(battlerIndex) ? @opponent : @player
    return 0 if !owners || !owners.is_a?(Array) || owners.length <= 1
    sideSize = pbSideSize(battlerIndex)
    sidePosition = pbSidePosition(battlerIndex)
    if owners.length == 2
      return 0 if sideSize <= 1
      return sidePosition if sideSize == 2
      return (sidePosition >= sideSize - 1) ? 1 : 0
    end
    return [sidePosition, owners.length - 1].min
  end

  def pbOwnedByPlayer?(index)
    return false if pbIsOpposing?(index)
    # If switch 2030 is ON, player controls partner Pokemon
    return false if @player.is_a?(Array) && pbGetOwnerIndexFromBattlerIndex(index) > 0 && !$game_switches[2030]
    return true
  end

  def pbIsDoubleBattler?(index)
    return pbSidePosition(index)>0
  end

  def pbThisEx(battlerindex,pokemonindex)
    party=pbParty(battlerindex)
    if pbIsOpposing?(battlerindex)
      if @opponent || party[pokemonindex].sosmon
        return _INTL("The foe {1}",party[pokemonindex].name)
      elsif party[pokemonindex].isbossmon
        return _INTL("{1}",party[pokemonindex].name)
      else
        return _INTL("The wild {1}",party[pokemonindex].name)
      end
    else
      return _INTL("{1}",party[pokemonindex].name)
    end
  end

# Checks whether an item can be removed from a PokÃ©mon.
  def pbIsUnlosableItem(pkmn,item)
    return true if pbIsMail?(item)
    return true if pbIsZCrystal?(item)
    if defined?(pbTributeItemIDs) && pbTributeItemIDs.include?(item)
      return true
    end
    return false if pkmn.effects[PBEffects::Transform]
    return true if pkmn.pokemon && AzureMegaForms.stone_for_species?(pkmn.pokemon.species,item)
    if isConst?(pkmn.ability,PBAbilities,:MULTITYPE) &&
       (isConst?(item,PBItems,:FISTPLATE) ||
        isConst?(item,PBItems,:SKYPLATE) ||
        isConst?(item,PBItems,:TOXICPLATE) ||
        isConst?(item,PBItems,:EARTHPLATE) ||
        isConst?(item,PBItems,:STONEPLATE) ||
        isConst?(item,PBItems,:INSECTPLATE) ||
        isConst?(item,PBItems,:SPOOKYPLATE) ||
        isConst?(item,PBItems,:IRONPLATE) ||
        isConst?(item,PBItems,:FLAMEPLATE) ||
        isConst?(item,PBItems,:SPLASHPLATE) ||
        isConst?(item,PBItems,:MEADOWPLATE) ||
        isConst?(item,PBItems,:ZAPPLATE) ||
        isConst?(item,PBItems,:MINDPLATE) ||
        isConst?(item,PBItems,:ICICLEPLATE) ||
        isConst?(item,PBItems,:DRACOPLATE) ||
        isConst?(item,PBItems,:PIXIEPLATE) ||
        isConst?(item,PBItems,:DREADPLATE))
      return true
    end
    if isConst?(pkmn.ability,PBAbilities,:RKSSYSTEM) &&
       (isConst?(item,PBItems,:FIGHTINGMEMORY) ||
        isConst?(item,PBItems,:FLYINGMEMORY) ||
        isConst?(item,PBItems,:POISONMEMORY) ||
        isConst?(item,PBItems,:GROUNDMEMORY) ||
        isConst?(item,PBItems,:ROCKMEMORY) ||
        isConst?(item,PBItems,:BUGMEMORY) ||
        isConst?(item,PBItems,:GHOSTMEMORY) ||
        isConst?(item,PBItems,:STEELMEMORY) ||
        isConst?(item,PBItems,:FIREMEMORY) ||
        isConst?(item,PBItems,:WATERMEMORY) ||
        isConst?(item,PBItems,:GRASSMEMORY) ||
        isConst?(item,PBItems,:ELECTRICMEMORY) ||
        isConst?(item,PBItems,:PSYCHICMEMORY) ||
        isConst?(item,PBItems,:ICEMEMORY) ||
        isConst?(item,PBItems,:DRAGONMEMORY) ||
        isConst?(item,PBItems,:FAIRYMEMORY) ||
        isConst?(item,PBItems,:DARKMEMORY))
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GIRATINA) &&
       isConst?(item,PBItems,:GRISEOUSORB)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GENESECT) &&
       (isConst?(item,PBItems,:SHOCKDRIVE) ||
        isConst?(item,PBItems,:BURNDRIVE) ||
        isConst?(item,PBItems,:CHILLDRIVE) ||
        isConst?(item,PBItems,:DOUSEDRIVE))
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:VENUSAUR) &&
       isConst?(item,PBItems,:VENUSAURITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:CHARIZARD) &&
       (isConst?(item,PBItems,:CHARIZARDITEX) ||
        isConst?(item,PBItems,:CHARIZARDITEY))
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:BLASTOISE) &&
       isConst?(item,PBItems,:BLASTOISINITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:ABOMBASNOW) &&
       isConst?(item,PBItems,:ABOMASITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:ABSOL) &&
       isConst?(item,PBItems,:ABSOLITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:AERODACTYL) &&
       isConst?(item,PBItems,:AERODACTYLITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:AGGRON) &&
       isConst?(item,PBItems,:AGGRONITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:ALAKAZAM) &&
       isConst?(item,PBItems,:ALAKAZITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:AMPHAROS) &&
       isConst?(item,PBItems,:AMPHAROSITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:BANETTE) &&
       isConst?(item,PBItems,:BANETTITITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:BLAZIKEN) &&
       isConst?(item,PBItems,:BLAZIKENITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GARCHOMP) &&
       isConst?(item,PBItems,:GARCHOMPITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GARDEVOIR) &&
       isConst?(item,PBItems,:GARDEVOIRITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GENGAR) &&
       isConst?(item,PBItems,:GENGARITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GYARADOS) &&
       isConst?(item,PBItems,:GYARADOSITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:HERACROSS) &&
       isConst?(item,PBItems,:HERACROSSITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:HOUNDOOM) &&
       isConst?(item,PBItems,:HOUNDOOMINITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:KANGASKHAN) &&
       isConst?(item,PBItems,:KANGASKHANITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:LUCARIO) &&
       isConst?(item,PBItems,:LUCARIONITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:MANECTRIC) &&
       isConst?(item,PBItems,:MANECTITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:MAWILE) &&
       isConst?(item,PBItems,:MAWILITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:MEDICHAM) &&
       isConst?(item,PBItems,:MEDICHAMITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:MEWTWO) &&
       (isConst?(item,PBItems,:MEWTWONITEX) ||
        isConst?(item,PBItems,:MEWTWONITEY))
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:PINSIR) &&
       isConst?(item,PBItems,:PINSIRITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:SCIZOR) &&
       isConst?(item,PBItems,:SCIZORITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:TYRANITAR) &&
       isConst?(item,PBItems,:TYRANITARITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:BEEDRILL) &&
       isConst?(item,PBItems,:BEEDRILLITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:PIDGEOT) &&
       isConst?(item,PBItems,:PIDGEOTITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:SLOWBRO) &&
       isConst?(item,PBItems,:SLOWBRONITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:STEELIX) &&
       isConst?(item,PBItems,:STEELIXITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:SCEPTILE) &&
       isConst?(item,PBItems,:SCEPTILITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:SWAMPERT) &&
       isConst?(item,PBItems,:SWAMPERTITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:SHARPEDO) &&
       isConst?(item,PBItems,:SHARPEDONITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:SABLEYE) &&
       isConst?(item,PBItems,:SABLENITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:CAMERUPT) &&
       isConst?(item,PBItems,:CAMERUPTITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:ALTARIA) &&
       isConst?(item,PBItems,:ALTARIANITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GLALIE) &&
       isConst?(item,PBItems,:GLALITITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:SALAMENCE) &&
       isConst?(item,PBItems,:SALAMENCITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:METAGROSS) &&
       isConst?(item,PBItems,:METAGROSSITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:LOPUNNY) &&
       isConst?(item,PBItems,:LOPUNNITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GALLADE) &&
       isConst?(item,PBItems,:GALLADITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:AUDINO) &&
       isConst?(item,PBItems,:AUDINITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:DIANCIE) &&
       isConst?(item,PBItems,:DIANCITE)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:GROUDON) &&
       isConst?(item,PBItems,:REDORB)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:KYOGRE) &&
       isConst?(item,PBItems,:BLUEORB)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:ZACIAN) &&
       isConst?(item,PBItems,:RUSTEDSWORD)
      return true
    end
    if isConst?(pkmn.species,PBSpecies,:ZAMAZENTA) &&
       isConst?(item,PBItems,:RUSTEDSHIELD)
      return true
    end
    if isConst?(item,PBItems,:DEMONSTONE)
      return true
    end
    if pkmn.hasCrest?
      return true
    end
    return false
  end


  def pbCheckGlobalAbility(a)
    ability_id=getConst(PBAbilities,a)
    for i in 0..maxBattlerIndex # in order from own first, opposing first, own second, opposing second
      if PBAbilityData.canonical_id(@battlers[i].ability)==ability_id
        return @battlers[i] if @battlers[i].hasWorkingAbility(a)
      end
    end
    return nil
  end

  def pbNeutralizingGasStarted
    pbDisplay(_INTL("Neutralizing Gas fills the area! Abilities are suppressed!"))
  end

  def pbNeutralizingGasEnded(entering=nil)
    return if pbCheckGlobalAbility(:NEUTRALIZINGGAS)
    if @switching
      @neutralizingGasEnded=true
      return
    end
    pbDisplayBrief(_INTL("The effects of the Neutralizing Gas wore off!"))
    active=activeBattlerIndices.map { |index| @battlers[index] }
    active.reject! { |battler| battler.isFainted? || (entering && entering.include?(battler.index)) }
    active.sort_by! { |battler| [-battler.pbSpeed,battler.index] }
    active.each do |battler|
      break if pbCheckGlobalAbility(:NEUTRALIZINGGAS)
      next if battler.isFainted?
      battler.pbAbilitiesOnSwitchIn(true,false,true) if battler.abilityWorks?
      battler.pbAbilityCureCheck
      battler.pbCheckForm
    end
  end

  def SilvallyCheck(mon, type)
    if !isConst?(mon.species,PBSpecies,:SILVALLY)
      return false
    end
    if mon.is_a? PokeBattle_Battler
      if pbOwnedByPlayer?(mon.index) && !$PokemonBag.pbHasItem?(:SILVCREST)
        return false
      end
      if type == PBTypes::FIRE && mon.hasWorkingItem(:FIREMEMORY)
        return true
      elsif type == PBTypes::WATER && mon.hasWorkingItem(:WATERMEMORY)
        return true
      elsif type == PBTypes::GRASS && mon.hasWorkingItem(:GRASSMEMORY)
        return true
      elsif type == PBTypes::ELECTRIC && mon.hasWorkingItem(:ELECTRICMEMORY)
        return true
      elsif type == PBTypes::ICE && mon.hasWorkingItem(:ICEMEMORY)
        return true
      elsif type == PBTypes::DRAGON && mon.hasWorkingItem(:DRAGONMEMORY)
        return true
      elsif type == PBTypes::PSYCHIC && mon.hasWorkingItem(:PSYCHICMEMORY)
        return true
      elsif type == PBTypes::DARK && mon.hasWorkingItem(:DARKMEMORY)
        return true
      elsif type == PBTypes::POISON && mon.hasWorkingItem(:POISONMEMORY)
        return true
      elsif type == PBTypes::GHOST && mon.hasWorkingItem(:GHOSTMEMORY)
        return true
      elsif type == PBTypes::FIGHTING && mon.hasWorkingItem(:FIGHTINGMEMORY)
        return true
      elsif type == PBTypes::BUG && mon.hasWorkingItem(:BUGMEMORY)
        return true
      elsif type == PBTypes::FAIRY && mon.hasWorkingItem(:FAIRYMEMORY)
        return true
      elsif type == PBTypes::GROUND && mon.hasWorkingItem(:GROUNDMEMORY)
        return true
      elsif type == PBTypes::ROCK && mon.hasWorkingItem(:ROCKMEMORY)
        return true
      elsif type == PBTypes::STEEL && mon.hasWorkingItem(:STEELMEMORY)
        return true
      end
      # In case no memory
      if type == PBTypes::NORMAL &&
       !(mon.hasWorkingItem(:FIREMEMORY) || mon.hasWorkingItem(:WATERMEMORY) ||
       mon.hasWorkingItem(:GRASSMEMORY) || mon.hasWorkingItem(:ELECTRICMEMORY) ||
       mon.hasWorkingItem(:ICEMEMORY) || mon.hasWorkingItem(:DRAGONMEMORY) ||
       mon.hasWorkingItem(:PSYCHICMEMORY) || mon.hasWorkingItem(:DARKMEMORY) ||
       mon.hasWorkingItem(:POISONMEMORY) || mon.hasWorkingItem(:GHOSTMEMORY) ||
       mon.hasWorkingItem(:FIGHTINGMEMORY) || mon.hasWorkingItem(:BUGMEMORY) ||
       mon.hasWorkingItem(:FAIRYMEMORY) || mon.hasWorkingItem(:GROUNDMEMORY) ||
       mon.hasWorkingItem(:ROCKMEMORY) || mon.hasWorkingItem(:STEELMEMORY))
        return true
      end
    elsif mon.is_a? PokeBattle_Pokemon
      if @party1.include?(mon) && !$PokemonBag.pbHasItem?(:SILVCREST)
        return false
      end
      if type == PBTypes::FIRE && mon.item == PBItems::FIREMEMORY
        return true
      elsif type == PBTypes::WATER && mon.item == PBItems::WATERMEMORY
        return true
      elsif type == PBTypes::GRASS && mon.item == PBItems::GRASSMEMORY
        return true
      elsif type == PBTypes::ELECTRIC && mon.item == PBItems::ELECTRICMEMORY
        return true
      elsif type == PBTypes::ICE && mon.item == PBItems::ICEMEMORY
        return true
      elsif type == PBTypes::DRAGON && mon.item == PBItems::DRAGONMEMORY
        return true
      elsif type == PBTypes::PSYCHIC && mon.item == PBItems::PSYCHICMEMORY
        return true
      elsif type == PBTypes::DARK && mon.item == PBItems::DARKMEMORY
        return true
      elsif type == PBTypes::POISON && mon.item == PBItems::POISONMEMORY
        return true
      elsif type == PBTypes::GHOST && mon.item == PBItems::GHOSTMEMORY
        return true
      elsif type == PBTypes::FIGHTING && mon.item == PBItems::POISONMEMORY
        return true
      elsif type == PBTypes::BUG && mon.item == PBItems::BUGMEMORY
        return true
      elsif type == PBTypes::FAIRY && mon.item == PBItems::FAIRYMEMORY
        return true
      elsif type == PBTypes::GROUND && mon.item == PBItems::GROUNDMEMORY
        return true
      elsif type == PBTypes::ROCK && mon.item == PBItems::ROCKMEMORY
        return true
      elsif type == PBTypes::STEEL && mon.item == PBItems::STEELMEMORY
        return true
      end
      # In case no memory
      if type == PBTypes::NORMAL &&
       !(mon.hasWorkingItem(:FIREMEMORY) || mon.hasWorkingItem(:WATERMEMORY) ||
       mon.hasWorkingItem(:GRASSMEMORY) || mon.hasWorkingItem(:ELECTRICMEMORY) ||
       mon.hasWorkingItem(:ICEMEMORY) || mon.hasWorkingItem(:DRAGONMEMORY) ||
       mon.hasWorkingItem(:PSYCHICMEMORY) || mon.hasWorkingItem(:DARKMEMORY) ||
       mon.hasWorkingItem(:POISONMEMORY) || mon.hasWorkingItem(:GHOSTMEMORY) ||
       mon.hasWorkingItem(:FIGHTINGMEMORY) || mon.hasWorkingItem(:BUGMEMORY) ||
       mon.hasWorkingItem(:FAIRYMEMORY) || mon.hasWorkingItem(:GROUNDMEMORY) ||
       mon.hasWorkingItem(:ROCKMEMORY) || mon.hasWorkingItem(:STEELMEMORY))
        return true
      end
    end

    return false
  end

################################################################################
# Player-related info.
################################################################################
  def pbPlayer
    if @player.is_a?(Array)
      return @player[0]
    else
      return @player
    end
  end

  def pbGetOwnerItems(battlerIndex)
    return [] if !@items
    if pbIsOpposing?(battlerIndex)
      if @opponent.is_a?(Array)
        ownerIndex = pbGetOwnerIndexFromBattlerIndex(battlerIndex)
        return @items[ownerIndex] || @items[0] || []
      else
        return @items
      end
    else
      return []
    end
  end

  def pbSetSeen(pokemon)
    if pokemon && @internalbattle
      self.pbPlayer.setSeen(pokemon.species)
      pbSeenForm(pokemon)
    end
  end

   def pbGetMegaRingName(battlerIndex)
    if pbBelongsToPlayer?(battlerIndex)
      ringsA=[:MEGARING,:MEGABRACELET,:MEGACUFF,:MEGACHARM]
      ringsB=[566]                                          # 566 = Mega Ring.
      for i in ringsA
        next if !hasConst?(PBItems,i)
        for k in ringsB
          return PBItems.getName(k) if $PokemonBag.pbQuantity(k)>0
        end
      end
    end
    # Add your own Mega objects for particular trainer types here
#    if isConst?(pbGetOwner(battlerIndex).trainertype,PBTrainers,:BUGCATCHER)
#      return _INTL("Mega Net")
#    end
    return _INTL("Mega Ring")
  end

  def pbHasMegaRing(battlerIndex)
    return true if !pbBelongsToPlayer?(battlerIndex)
    rings=[:MEGARING,:MEGABRACELET,:MEGACUFF,:MEGACHARM]
    for i in rings
      next if !hasConst?(PBItems,i)
      return true if $PokemonBag.pbQuantity(i)>0
    end
    return false
  end

  def pbHasZRing(battlerIndex)
    return true if !pbBelongsToPlayer?(battlerIndex)
    rings=[:MEGARING,:MEGABRACELET,:MEGACUFF,:MEGACHARM]
    for i in rings
      next if !hasConst?(PBItems,i)
      return true if $PokemonBag.pbQuantity(i)>0
    end
    return false
  end

################################################################################
# Get party info, manipulate parties.
################################################################################
  def pbPokemonCount(party)
    count=0
    for i in party
      next if !i
      count+=1 if i.hp>0 && !i.isEgg?
    end
    return count
  end

  def pbAllFainted?(party)
    pbPokemonCount(party)==0
  end

  # Check if a specific trainer's Pokemon are all fainted in partner battles
  def pbTrainerAllFainted?(battlerIndex)
    return pbAllFainted?(pbParty(battlerIndex)) if !@player.is_a?(Array)

    party = pbParty(battlerIndex)
    secondParty = pbSecondPartyBegin(battlerIndex)
    ownerIndex = pbGetOwnerIndexFromBattlerIndex(battlerIndex)
    start = (ownerIndex == 0) ? 0 : secondParty
    finish = (ownerIndex == 0) ? secondParty : party.length

    for i in start...finish
      next if !party[i]
      return false if party[i].hp > 0 && !party[i].isEgg?
    end
    return true
  end

  def pbMaxLevelFromIndex(index)
    party=pbParty(index)
    owner=(pbIsOpposing?(index)) ? @opponent : @player
    maxlevel=0
    if owner.is_a?(Array)
      split=pbSecondPartyBegin(index)
      ownerIndex = pbGetOwnerIndexFromBattlerIndex(index)
      start = (ownerIndex == 0) ? 0 : split
      finish = (ownerIndex == 0) ? split : party.length
      for i in start...finish
        next if !party[i]
        maxlevel=party[i].level if maxlevel<party[i].level
      end
    else
      for i in party
        next if !i
        maxlevel=i.level if maxlevel<i.level
      end
    end
    return maxlevel
  end

  def pbMaxLevel(party)
    lv=0
    for i in party
      next if !i
      lv=i.level if lv<i.level
    end
    return lv
  end

  def pbParty(index)
    return pbIsOpposing?(index) ? party2 : party1
  end

  def pbSecondPartyBegin(battlerIndex)
    if pbIsOpposing?(battlerIndex)
      return @fullparty2 ? 6 : 3
    else
      return @fullparty1 ? 6 : 3
    end
  end

  def pbFindNextUnfainted(party,start,finish=-1)
    finish=party.length if finish<0
    for i in start...finish
      next if !party[i]
      return i if party[i].hp>0 && !party[i].isEgg?
    end
    return -1
  end

  def pbActiveBattlerIndicesForSide(opposing)
    side = opposing ? 1 : 0
    ret = []
    for position in 0...@sideSizes[side]
      ret.push(pbBattlerIndex(side,position))
    end
    return ret
  end

  def pbCommandPhaseBattlers
    return pbActiveBattlerIndicesForSide(false) + pbActiveBattlerIndicesForSide(true)
  end

  def pbOwnerActiveBattlerIndices(opposing,ownerIndex)
    ret = []
    pbActiveBattlerIndicesForSide(opposing).each do |battlerIndex|
      ret.push(battlerIndex) if pbGetOwnerIndexFromBattlerIndex(battlerIndex)==ownerIndex
    end
    return ret
  end

  def pbOwnedPartyRangeForSideOwner(opposing,ownerIndex)
    party = opposing ? @party2 : @party1
    secondParty = [pbSecondPartyBegin(opposing ? 1 : 0),party.length].min
    owners = opposing ? @opponent : @player
    return 0,party.length if !owners || !owners.is_a?(Array) || owners.length<=1
    return (ownerIndex==0) ? [0,secondParty] : [secondParty,party.length]
  end

  def pbSetBlankBattler(index)
    @battlers[index].pbInitBlank
    @battlers[index].fainted = true
    @choices[index] = [0,0,nil,-1] if @choices[index]
  end

  def pbPrepareTrainerSideSendOuts(opposing)
    sideIndices = pbActiveBattlerIndicesForSide(opposing)
    party = opposing ? @party2 : @party1
    owners = opposing ? @opponent : @player
    sendouts = []
    sideIndices.each { |battlerIndex| pbSetBlankBattler(battlerIndex) }
    if owners && owners.is_a?(Array)
      owners.each_with_index do |owner,ownerIndex|
        ownerSent = 0
        ownerIndices = pbOwnerActiveBattlerIndices(opposing,ownerIndex)
        next if ownerIndices.length==0
        startIdx,endIdx = pbOwnedPartyRangeForSideOwner(opposing,ownerIndex)
        nextSearch = startIdx
        ownerIndices.each do |battlerIndex|
          sendout = pbFindNextUnfainted(party,nextSearch,endIdx)
          next if sendout<0
          @battlers[battlerIndex].pbInitialize(party[sendout],sendout,false)
          sendouts.push([battlerIndex,sendout,owner])
          nextSearch = sendout+1
          ownerSent += 1
        end
        ownerName = (owner && owner.respond_to?(:fullname)) ? owner.fullname : _INTL("Trainer")
        raise _INTL("{1} has no unfainted Pokémon",ownerName) if ownerSent==0
      end
    else
      nextSearch = 0
      sideIndices.each do |battlerIndex|
        sendout = pbFindNextUnfainted(party,nextSearch)
        next if sendout<0
        @battlers[battlerIndex].pbInitialize(party[sendout],sendout,false)
        sendouts.push([battlerIndex,sendout,owners])
        nextSearch = sendout+1
      end
      if sendouts.length==0
        raise _INTL(opposing ? "Trainer has no unfainted Pokémon" : "Player has no unfainted Pokémon")
      end
    end
    return sendouts
  end

  def pbFindPlayerBattler(pkmnIndex)
    battler=nil
    eachActiveBattlerIndex do |k|
      if !pbIsOpposing?(k) && @battlers[k].pokemonIndex==pkmnIndex
        battler=@battlers[k]
        break
      end
    end
    return battler
  end

  def pbIsOwner?(battlerIndex,partyIndex)
    secondParty=pbSecondPartyBegin(battlerIndex)
    if !pbIsOpposing?(battlerIndex)
      return true if !@player || !@player.is_a?(Array)
      ownerIndex = pbGetOwnerIndexFromBattlerIndex(battlerIndex)
      if $game_switches[2030] && ownerIndex > 0
        return partyIndex>=secondParty
      end
      return (ownerIndex==0) ? partyIndex<secondParty : partyIndex>=secondParty
    else
      return true if !@opponent || !@opponent.is_a?(Array)
      return (pbGetOwnerIndexFromBattlerIndex(battlerIndex)==0) ? partyIndex<secondParty : partyIndex>=secondParty
    end
  end

  def pbGetOwner(battlerIndex)
    if pbIsOpposing?(battlerIndex)
      if @opponent.is_a?(Array)
        return @opponent[pbGetOwnerIndexFromBattlerIndex(battlerIndex)] || @opponent[0]
      else
        return @opponent
      end
    else
      if @player.is_a?(Array)
        return @player[pbGetOwnerIndexFromBattlerIndex(battlerIndex)] || @player[0]
      else
        return @player
      end
    end
  end

  def pbGetOwnerPartner(battlerIndex)
    if pbIsOpposing?(battlerIndex)
      if @opponent.is_a?(Array)
        ownerIndex = pbGetOwnerIndexFromBattlerIndex(battlerIndex)
        partnerIndex = (ownerIndex == 0) ? 1 : 0
        return @opponent[partnerIndex] || @opponent[ownerIndex]
      else
        return @opponent
      end
    else
      if @player.is_a?(Array)
        ownerIndex = pbGetOwnerIndexFromBattlerIndex(battlerIndex)
        partnerIndex = (ownerIndex == 0) ? 1 : 0
        return @player[partnerIndex] || @player[ownerIndex]
      else
        return @player
      end
    end
  end

  def pbGetOwnerIndex(battlerIndex)
    return pbGetOwnerIndexFromBattlerIndex(battlerIndex)
  end

  def pbBelongsToPlayer?(battlerIndex)
    return false if pbIsOpposing?(battlerIndex)
    return pbGetOwnerIndexFromBattlerIndex(battlerIndex)==0
  end

  def pbPartyGetOwner(battlerIndex,partyIndex)
    secondParty=pbSecondPartyBegin(battlerIndex)
    if !pbIsOpposing?(battlerIndex)
      return @player if !@player || !@player.is_a?(Array)
      return (partyIndex<secondParty) ? @player[0] : @player[1]
    else
      return @opponent if !@opponent || !@opponent.is_a?(Array)
      return (partyIndex<secondParty) ? @opponent[0] : @opponent[1]
    end
  end

  def pbAddToPlayerParty(pokemon)
    party=pbParty(0)
    for i in 0...party.length
      party[i]=pokemon if pbIsOwner?(0,i) && !party[i]
    end
  end

  def pbRemoveFromParty(battlerIndex,partyIndex)
    party=pbParty(battlerIndex)
    side=(pbIsOpposing?(battlerIndex)) ? @opponent : @player
    party[partyIndex]=nil
    if !side || !side.is_a?(Array) # Wild or single opponent
      #pk code
      party.compact!
      eachSameSideBattler(battlerIndex) do |battler|
        next if !battler.pokemon
        new_index=party.index { |pkmn| pkmn.equal?(battler.pokemon) }
        battler.pokemonIndex=new_index if new_index
      end
    else
      if battlerIndex<pbSecondPartyBegin(battlerIndex)-1
        for i in battlerIndex...pbSecondPartyBegin(battlerIndex)
          if i>=pbSecondPartyBegin(battlerIndex)-1
            party[i]=nil
          else
            party[i]=party[i+1]
          end
        end
      else
        for i in battlerIndex...party.length
          if i>=party.length-1
            party[i]=nil
          else
            party[i]=party[i+1]
          end
        end
      end
    end
  end

################################################################################
# Check whether actions can be taken.
################################################################################
  def pbCanShowCommands?(idxPokemon)
    thispkmn=@battlers[idxPokemon]
    return false if thispkmn.isFainted?
    return false if thispkmn.effects[PBEffects::Commander]
    return false if thispkmn.effects[PBEffects::TwoTurnAttack]>0
    return false if thispkmn.effects[PBEffects::HyperBeam]>0
    return false if thispkmn.effects[PBEffects::Rollout]>0
    return false if thispkmn.effects[PBEffects::Outrage]>0
    return false if thispkmn.effects[PBEffects::Rage]==true && $fefieldeffect == 24
    return false if thispkmn.effects[PBEffects::Uproar]>0
#### KUROTSUNE - 022 - START
    #return false if thispkmn.effects[PBEffects::SkyDrop]
#### KUROTSUNE - 022 - END
    return true
  end

  def zMove
    return @zMove
  end

################################################################################
# Attacking.
################################################################################
  def pbCanShowFightMenu?(idxPokemon)
    thispkmn=@battlers[idxPokemon]
    if !pbCanShowCommands?(idxPokemon)
      return false
    end
    # No moves that can be chosen
    if !pbCanChooseMove?(idxPokemon,0,false) &&
       !pbCanChooseMove?(idxPokemon,1,false) &&
       !pbCanChooseMove?(idxPokemon,2,false) &&
       !pbCanChooseMove?(idxPokemon,3,false)
      if pbCanDracoTribute?(idxPokemon)
        battler=@battlers[idxPokemon]
        enabled_here=!battler.tributeDracoActive && battler.pbEnableTributeDraco
        begin
          return true if pbCanChooseMove?(idxPokemon,0,false)
        ensure
          battler.pbDisableTributeDraco if enabled_here
        end
      end
      return false
    end
    # Encore
    return false if thispkmn.effects[PBEffects::Encore]>0
    return true
  end

  def pbCanChooseMove?(idxPokemon,idxMove,showMessages,sleeptalk=false)
    thispkmn=@battlers[idxPokemon]
    thismove=thispkmn.moves[idxMove]
    if !thismove||thismove.id==0
      return false
    end
    # Imprison checks both opposing battler slots below. These references must
    # be established for every ordinary move-availability query, including AI
    # scoring, or the check raises before any move can be selected.
    opp1=thispkmn.pbOpposing1
    opp2=thispkmn.pbOpposing2
    tribute_icicle_status = defined?(pbTributeMoveMatches?) &&
      pbTributeMoveMatches?(thispkmn,:ICICLETRIBUTE,thismove.id) && thismove.basedamage<=0
    pixie_tribute_attack = thismove.respond_to?(:pixie_tribute_power) &&
      thismove.pixie_tribute_power(thispkmn)>0
    if thismove.pp<=0 && thismove.totalpp>0 && !sleeptalk
      if showMessages
        pbDisplayPaused(_INTL("There's no PP left for this move!"))
      end
      return false
    end
    # Forewarn - blocks disabled move
    if thispkmn.effects[PBEffects::ForewarnDisable] > 0 &&
       thismove.id == thispkmn.effects[PBEffects::ForewarnDisableMove]
      if showMessages
        pbDisplayPaused(_INTL("{1} is disabled by Forewarn!",thismove.name))
      end
      return false
    end
    if thispkmn.effects[PBEffects::ChoiceBand]>=0 &&
      (thispkmn.hasWorkingItem(:CHOICEBAND) ||
      thispkmn.hasWorkingItem(:CHOICESPECS) ||
      thispkmn.hasWorkingItem(:CHOICESCARF) ||
      thispkmn.hasWorkingAbility(:GORILLATACTICS))
      hasmove=false
      for i in 0...4
        if thispkmn.moves[i].id==thispkmn.effects[PBEffects::ChoiceBand]
          hasmove=true
          break
        end
      end
      if hasmove && thismove.id!=thispkmn.effects[PBEffects::ChoiceBand]
        if showMessages
          pbDisplayPaused(_INTL("{1} allows the use of only {2}!",
             PBItems.getName(thispkmn.item),
             PBMoves.getName(thispkmn.effects[PBEffects::ChoiceBand])))
        end
        return false
      end
    end
#### KUROTSUNE - 018 - START
    if thispkmn.hasWorkingItem(:ASSAULTVEST) &&
       !(thismove.pbIsPhysical?(thismove.type) || thismove.pbIsSpecial?(thismove.type) || pixie_tribute_attack)
        if showMessages
          pbDisplayPaused(_INTL("{1} doesn't allow use of non-attacking moves!",
             PBItems.getName(thispkmn.item)))
        end
        return false
    end
#### KUROTSUNE - 018 - END

    if thispkmn.hasWorkingAbility(:ANGERPOINT) && thismove.basedamage==0 && !pixie_tribute_attack
      if showMessages
        pbDisplayPaused(_INTL("{1}'s Anger Point doesn't allow use of status moves!",
            thispkmn.pbThis))
      end
      return false
    end

    if !tribute_icicle_status && opp1.effects[PBEffects::Imprison]
      if thismove.id==opp1.moves[0].id ||
         thismove.id==opp1.moves[1].id ||
         thismove.id==opp1.moves[2].id ||
         thismove.id==opp1.moves[3].id
        if showMessages
          pbDisplayPaused(_INTL("{1} can't use the sealed {2}!",thispkmn.pbThis,thismove.name))
        end
       #PBDebug.log("[CanChoose][#{opp1.pbThis} has: #{opp1.moves[0].name}, #{opp1.moves[1].name},#{opp1.moves[2].name},#{opp1.moves[3].name}]") if $INTERNAL
        return false
      end
    end
    if !tribute_icicle_status && opp2.effects[PBEffects::Imprison]
      if thismove.id==opp2.moves[0].id ||
         thismove.id==opp2.moves[1].id ||
         thismove.id==opp2.moves[2].id ||
         thismove.id==opp2.moves[3].id
        if showMessages
          pbDisplayPaused(_INTL("{1} can't use the sealed {2}!",thispkmn.pbThis,thismove.name))
        end
        #PBDebug.log("[CanChoose][#{opp2.pbThis} has: #{opp2.moves[0].name}, #{opp2.moves[1].name},#{opp2.moves[2].name},#{opp2.moves[3].name}]") if $INTERNAL
        return false
      end
    end
    if !tribute_icicle_status &&
       thispkmn.effects[PBEffects::Taunt]>0 && thismove.basedamage==0 && !pixie_tribute_attack
      if showMessages
        pbDisplayPaused(_INTL("{1} can't use {2} after the Taunt!",thispkmn.pbThis,thismove.name))
      end
      return false
    end
    if !tribute_icicle_status && thispkmn.effects[PBEffects::Torment]
      if thismove.id==thispkmn.lastMoveUsed
        if showMessages
          pbDisplayPaused(_INTL("{1} can't use the same move in a row due to the torment!",thispkmn.pbThis))
        end
        return false
      end
    end
    if thismove.id==thispkmn.effects[PBEffects::DisableMove] && !sleeptalk
      if showMessages
        pbDisplayPaused(_INTL("{1}'s {2} is disabled!",thispkmn.pbThis,thismove.name))
      end
      return false
    end
    if thispkmn.effects[PBEffects::Encore]>0 && idxMove!=thispkmn.effects[PBEffects::EncoreIndex]
      return false
    end
    return true
  end

  def pbAutoChooseMove(idxPokemon,showMessages=true)
    thispkmn=@battlers[idxPokemon]
    if thispkmn.isFainted?
      @choices[idxPokemon][0]=0
      @choices[idxPokemon][1]=0
      @choices[idxPokemon][2]=nil
      return
    end
    if thispkmn.effects[PBEffects::Encore]>0 &&
       pbCanChooseMove?(idxPokemon,thispkmn.effects[PBEffects::EncoreIndex],false)
      PBDebug.log("[Auto choosing Encore move...]") if $INTERNAL
	  enc_idx = thispkmn.effects[PBEffects::EncoreIndex]
	  enc_move = thispkmn.moves[enc_idx]
	  if enc_move.nil?
		@choices[idxPokemon][0]=1
		@choices[idxPokemon][1]=-1
		@choices[idxPokemon][2]=@struggle
		@choices[idxPokemon][3]=-1
	  else
		@choices[idxPokemon][0]=1
		@choices[idxPokemon][1]=enc_idx
		@choices[idxPokemon][2]=enc_move
		@choices[idxPokemon][3]=-1
	  end
      if enc_move && enc_move.id==PBMoves::MINIMIZE && pbOwnedByPlayer?(idxPokemon) && !@controlPlayer
        target=@scene.pbChooseTarget(idxPokemon)
        pbRegisterTarget(idxPokemon,target) if target>=0
      elsif !singleBattle?
        thismove=enc_move
        target=thispkmn.pbTarget(thismove)
        if target==PBTargets::SingleNonUser #&& ($fefieldeffect != 33 ||
          #$fecounter != 4 || (thismove.id != 192 || thismove.id != 214 ||
#         thismove.id != 218 || thismove.id != 219 || thismove.id != 220 ||
 #        thismove.id != 445 || thismove.id != 596 || thismove.id != 600))
  #        print("this message is bad")
          target=@scene.pbChooseTarget(idxPokemon)
          pbRegisterTarget(idxPokemon,target) if target>=0
        elsif target==PBTargets::UserOrPartner
          target=@scene.pbChooseTarget(idxPokemon)
          pbRegisterTarget(idxPokemon,target) if target>=0 && (target&1)==(idxPokemon&1)
        end
      end
    else
      if !pbIsOpposing?(idxPokemon)
        pbDisplayPaused(_INTL("{1} has no moves left!",thispkmn.name)) if showMessages
      end
      @choices[idxPokemon][0]=1           # "Use move"
      @choices[idxPokemon][1]=-1          # Index of move to be used
      @choices[idxPokemon][2]=@struggle   # Use Struggle
      @choices[idxPokemon][3]=-1          # No target chosen yet
    end
  end

  def pbRegisterMove(idxPokemon,idxMove,showMessages=true)
	thispkmn=@battlers[idxPokemon]
	thismove=thispkmn.moves[idxMove]

	# --- FIX: never allow nil here ---
	return false if thismove.nil?

	# safe now
	thispkmn.selectedMove = thismove.id

	return false if !pbCanChooseMove?(idxPokemon,idxMove,showMessages)

	@choices[idxPokemon][0]=1         # "Use move"
	@choices[idxPokemon][1]=idxMove   # Index of move to be used
	@choices[idxPokemon][2]=thismove  # PokeBattle_Move object of the move
	@choices[idxPokemon][3]=-1        # No target chosen yet
	return true
  end

  def pbCanDracoTribute?(index)
    battler=@battlers[index]
    return false if !battler || battler.isFainted?
    return false if !battler.moves || !battler.moves[0] || battler.moves[0].id==0
    inscribed=battler.pbPrepareTributeDraco
    return false if !inscribed
    return inscribed.totalpp==0 || inscribed.pp>0
  end

  def pbRegisterDracoTribute(index,setup=false)
    battler=@battlers[index]
    if setup
      return nil if !pbCanDracoTribute?(index)
      backup=battler.moves.clone
      return backup if battler.pbEnableTributeDraco
      return nil
    end
    battler.pbDisableTributeDraco
    return battler.moves.clone
  end

  def pbTriggerTributeChain(user,move)
    user.sameSideLivingBattlers(false).each do |ally|
      choice=@choices[ally.index]
      next if ally.hasMovedThisRound? || choice[0]!=1 || choice[2]&.id!=move.id
      return true if pbProcessQueuedAttackTurn(ally)
    end
    return false
  end



  def pbChoseMove?(i,move)
    return false if @battlers[i].isFainted?
    if @choices[i][0]==1 && @choices[i][1]>=0
      choice=@choices[i][1]
      move_id=PBMove.current_id(getID(PBMoves,move))
      return false if !move_id || move_id==0
      return @battlers[i].moves[choice].id==move_id
    end
    return false
  end

  def pbChoseMoveFunctionCode?(i,code)
    return false if @battlers[i].isFainted?
    if @choices[i][0]==1 && @choices[i][1]>=0
      choice=@choices[i][1]
      return @battlers[i].moves[choice].function==code
    end
    return false
  end

  def pbRegisterTarget(idxPokemon,idxTarget)
    @choices[idxPokemon][3]=idxTarget   # Set target of move
    return true
  end

  def pbIntensifyGravity(turns)
    @field.effects[PBEffects::Gravity]=turns
    eachActiveBattlerIndex do |index|
      battler=@battlers[index]
      effects=battler.effects
      airborne_move=effects[PBEffects::TwoTurnAttack]>0 &&
        [0xC9,0xCC,0xCE].include?(PBMoveData.new(effects[PBEffects::TwoTurnAttack]).function)
      if airborne_move || effects[PBEffects::SkyDrop]
        effects[PBEffects::TwoTurnAttack]=0 if airborne_move
        effects[PBEffects::SkyDrop]=false
        effects[PBEffects::SkyDroppee]=nil
        @scene.pbUnVanishSprite(battler) if battler.vanished
      end
      effects[PBEffects::MagnetRise]=0
      effects[PBEffects::Telekinesis]=0
    end
  end

  def pbMovePriority(user,move,target=nil,first_turn=(user.turncount==1))
    priority=move.zmove ? 0 : move.priority
    return priority if priority==-99 && move.tribute_has?(user,:IRONTRIBUTE)
    pixie_attack=move.respond_to?(:pixie_tribute_power) && move.pixie_tribute_power(user)>0
    status_move=move.basedamage==0 && !pixie_attack
    priority+=1 if status_move && user.hasWorkingAbility(:PRANKSTER)
    if (user.hasWorkingAbility(:GALEWINGS) || SilvallyCheck(user,PBTypes::FLYING)) && move.type==PBTypes::FLYING &&
       (user.hp==user.totalhp || ([16,27,28].include?($fefieldeffect) && @weather==PBWeather::STRONGWINDS) || $fefieldeffect==43)
      priority+=1
    end
    priority+=3 if user.hasWorkingAbility(:TRIAGE) && PBStuff::HEALFUNCTIONS.include?(move.function) && !pixie_attack
    priority+=1 if user.hasWorkingAbility(:QUICKDRAW) && first_turn
    priority+=1 if first_turn && move.basedamage>0 && user.species==PBSpecies::FERALIGATR && user.hasWorkingItem(:FERACREST)
    priority+=1 if $fefieldeffect==38 && move.function==0x11E
    if status_move && user.hasWorkingAbility(:LIMINAL) && user.effects[PBEffects::LiminalStatusPriority]
      priority+=1
    end
    priority=0 if priority>0 && pbCheckGlobalAbility(:HALCYON)
    if priority>=0 && move.isContactMove? && !user.hasWorkingAbility(:LONGREACH)
      targets=case user.pbTarget(move)
      when PBTargets::AllOpposing, PBTargets::DragonDarts, PBTargets::ThunderRaid
        user.opposingLivingBattlers
      when PBTargets::AllNonUsers
        user.opposingLivingBattlers + user.sameSideLivingBattlers(false)
      when PBTargets::SingleNonUser, PBTargets::SingleOpposing, PBTargets::OppositeOpposing, PBTargets::RandomOpposing
        [target && !target.isFainted? ? target : user.pbPreferredOpposingTarget(nil,move)]
      when PBTargets::Partner
        [target || user.firstLivingAlly]
      when PBTargets::UserOrPartner
        [target]
      else
        []
      end
      if targets.any? { |battler| battler && battler!=user &&
          pbMoveCanTargetInTriple?(user,battler,move) && battler.hasWorkingAbility(:DEEPFREEZE) }
        priority=-1
      end
    end
    return priority
  end

# UPDATE 11/23/2013
  # implementing STALL
  def pbPriority(ignorequickclaw = false,megacalc = false,move_order_keys: nil)
    return @priority if @usepriority && !megacalc
    @priority.clear
    priorityarray = []
    # -Move priority take precedence(stored as priorityarray[i][0])
    # -Then Items  (stored as priorityarray[i][1])
    # -Then speed (stored as priorityarray[i][2]) (trick room is applied by just making speed negative.)
    # -The last element is just the battler index (which is otherwise lost when sorting)
    active_indices = activeBattlerIndices.find_all { |i| !@battlers[i].isFainted? }
    active_indices.each do |i|
      priorityarray.push([0,0,0,i]) #initializes the array and stores the battler index
      # Move priority
      pri=0
	  if @choices[i][0]==1 # Is a move
	    if @choices[i][2].nil?
		  PBDebug.log("PRIORITY CHOICE NIL: i=#{i} choice=#{@choices[i].inspect}") if $INTERNAL
		  next
		end
        target_index=@choices[i][3]
        target=target_index if target_index.is_a?(PokeBattle_Battler)
        target=@battlers[target_index] if target_index.is_a?(Integer) && target_index>=0
        pri=pbMovePriority(@battlers[i],@choices[i][2],target)
      end
      pri=-Float::INFINITY if @choices[i][0]==1 && @battlers[i].hasWorkingAbility(:STALL)
      priorityarray[-1][0]=pri
      # Held item priority breaks ties within the same move priority.
      priorityarray[-1][1] = 1 if @battlers[i].custap || (@battlers[i].itemWorks? && @battlers[i].item == PBItems::QUICKCLAW && (pbRandom(100)<20))
      priorityarray[-1][1] = -2 if (@battlers[i].itemWorks? && (@battlers[i].item == PBItems::LAGGINGTAIL || @battlers[i].item == PBItems::FULLINCENSE))
      if @choices[i][0]==1 && @battlers[i].effects[PBEffects::AbsoluteZeroTurn]==@turncount
        priorityarray[-1][1]=-3
      end
      move_order_keys[@battlers[i]]=priorityarray[-1].first(2) if move_order_keys
      #speed priority
      priorityarray[-1][2]    = @battlers[i].pbSpeed if @trickroom==0
      priorityarray[-1][2]    = -@battlers[i].pbSpeed if @trickroom>0
    end
    priorityarray.sort!
    #Speed ties. Only works correctly if two pokemon speed tie
    speedtie_limit = [priorityarray.length-1,0].max
    for i in 0...speedtie_limit
      for j in (i+1)...priorityarray.length
        if priorityarray[i][0]==priorityarray[j][0] && priorityarray[i][1]==priorityarray[j][1] && priorityarray[i][2]==priorityarray[j][2]
          if pbRandom(2)==1
            priorityarray[i],priorityarray[j] = priorityarray[j],priorityarray[i]
          end
        end
      end
    end
    priorityarray.reverse!
    for i in 0...priorityarray.length
      @priority[i] = @battlers[priorityarray[i][3]]
    end
    @usepriority=true
    return @priority
  end

##### KUROTSUNE - 011 - START
 # Makes target pokemon move last
  def pbMoveLast(target)
    #pk code
    if @attackTurnOrder
      return false if !pbPendingAttack?(target)
      @attackTurnOrder[:next].delete(target)
      @attackTurnOrder[:last].delete(target)
      @attackTurnOrder[:last].push(target)
      pbRefreshAttackTurnOrder
      return true
    end
    priorityTarget = pbGetPriority(target)
    priority = @priority
    return false if priorityTarget<0 || priorityTarget>=priority.length-1
    battler = priority.delete_at(priorityTarget)
    priority.push(battler)
    @priority = priority
    return true
  end


  # Makes the second pokemon move after the first.
  def pbMoveAfter(first, second)
    #pk code
    if @attackTurnOrder
      return false if first==second || !pbPendingAttack?(second)
      @attackTurnOrder[:last].delete(second)
      @attackTurnOrder[:next].delete(second)
      @attackTurnOrder[:next].unshift(second)
      pbRefreshAttackTurnOrder
      return true
    end
    priorityFirst = pbGetPriority(first)
    priority = @priority
    prioritySecond = pbGetPriority(second)
    return false if priorityFirst<0 || prioritySecond<0
    return false if prioritySecond==priorityFirst+1
    battler = priority.delete_at(prioritySecond)
    priorityFirst = priority.index(first)
    priority.insert(priorityFirst+1,battler)
    @priority = priority
    return true
  end
##### KUROTSUNE - 011 - END

  def pbGetPriority(mon)
    for i in 0...@priority.length
      if @priority[i] == mon
        return i
      end
    end
    return -1
  end


   def pbClearChoices(index)
    choices[index][0] = -1
    choices[index][1] = -1
    choices[index][2] = -1
    choices[index][3] = -1
  end
################################################################################
# Switching PokÃ©mon.
################################################################################
  def pbCanSwitchLax?(idxPokemon,pkmnidxTo,showMessages)
    if @battlers[idxPokemon].effects[PBEffects::Commandee]
      pbDisplayPaused(_INTL("{1} can't be switched out!",@battlers[idxPokemon].pbThis)) if showMessages
      return false
    end
    if pkmnidxTo>=0
      party=pbParty(idxPokemon)
      return false if pkmnidxTo>=party.length
      return false if !party[pkmnidxTo]
      if party[pkmnidxTo].isEgg?
        pbDisplayPaused(_INTL("An Egg can't battle!")) if showMessages
        return false
      end
      if !pbIsOwner?(idxPokemon,pkmnidxTo)
        owner=pbPartyGetOwner(idxPokemon,pkmnidxTo)
        pbDisplayPaused(_INTL("You can't switch {1}'s Pokémon with one of yours!",owner.name)) if showMessages
        return false
      end
      if party[pkmnidxTo].hp<=0
        pbDisplayPaused(_INTL("{1} has no energy left to battle!",party[pkmnidxTo].name)) if showMessages
        return false
      end
      if @battlers[idxPokemon].pokemonIndex==pkmnidxTo
        pbDisplayPaused(_INTL("{1} is already in battle!",party[pkmnidxTo].name)) if showMessages
        return false
      end
      eachSameSideBattler(idxPokemon) do |battler|
        next if battler.index==idxPokemon
        if battler.pokemonIndex==pkmnidxTo
          pbDisplayPaused(_INTL("{1} is already in battle!",party[pkmnidxTo].name)) if showMessages
          return false
        end
      end
    end
    return true
  end

  def pbCanSwitch?(idxPokemon,pkmnidxTo,showMessages)
    thispkmn=@battlers[idxPokemon]
    return false if !pbCanSwitchLax?(idxPokemon,pkmnidxTo,showMessages)
    #pk code
    if pkmnidxTo>=0
      if pbShiftTargeted?(idxPokemon)
        pbDisplayPaused(_INTL("{1} is already repositioning this round!",thispkmn.pbThis)) if showMessages
        return false
      end
      eachSameSideBattler(idxPokemon) do |battler|
        next if battler.index==idxPokemon
        choice=@choices[battler.index]
        next if choice[0]!=2 || choice[2]==:shift || choice[1]!=pkmnidxTo
        pbDisplayPaused(_INTL("{1} has already been selected.",pbParty(idxPokemon)[pkmnidxTo].name)) if showMessages
        return false
      end
    end
    # UPDATE 11/16/2013
    # Ghost type can now escape from anything
    shadowTagFoe = false
    eachOtherSideBattler(idxPokemon) do |battler|
      next if battler.isFainted?
      if battler.hasWorkingAbility(:SHADOWTAG)
        shadowTagFoe = true
        break
      end
    end
    if thispkmn.pbHasType?(:GHOST) && ($fefieldeffect!=38 || !shadowTagFoe)
      return true
    end
    if thispkmn.hasWorkingAbility(:RUNAWAY)
      return true
    end
    return true if thispkmn.hasWorkingItem(:SHEDSHELL)
    # Colosseum Field
    if $fefieldeffect == 44
      pbDisplayPaused(_INTL("{1} can't be switched out while on Colosseum Field!",thispkmn.pbThis)) if showMessages
      return false
    end
    # Embargo
    if $fefieldeffect==38 && thispkmn.effects[PBEffects::Embargo]>0
      pbDisplayPaused(_INTL("{1} can't be switched out due to Embargo!",thispkmn.pbThis)) if showMessages
      return false
    end
    # Multi-Turn Attacks/Mean Look
    if thispkmn.effects[PBEffects::MultiTurn]>0 || thispkmn.pbRiteOfSpringSource ||
       thispkmn.effects[PBEffects::MeanLook]>=0 ||
       (thispkmn.hasWorkingAbility(:MUMMY) && $fefieldeffect==40) ||
       field.effects[PBEffects::FairyLock]==1
      pbDisplayPaused(_INTL("{1} can't be switched out!",thispkmn.pbThis)) if showMessages
      return false
    end
    # Ingrain
    if thispkmn.effects[PBEffects::Ingrain]
      pbDisplayPaused(_INTL("{1} can't be switched out!",thispkmn.pbThis)) if showMessages
      return false
    end
    # Jaw Lock
    if thispkmn.effects[PBEffects::JawLock]
      pbDisplayPaused(_INTL("{1} can't be switched out!",thispkmn.pbThis)) if showMessages
      return false
    end
    opp=nil
    eachOtherSideBattler(idxPokemon) do |battler|
      next if battler.isFainted?
      if !opp && thispkmn.pbHasType?(:STEEL) && battler.hasWorkingAbility(:MAGNETPULL)
        opp=battler
        next
      end
      if !opp && !thispkmn.isAirborne? && battler.hasWorkingAbility(:ARENATRAP)
        opp=battler
        next
      end
      if !opp && !thispkmn.hasWorkingAbility(:SHADOWTAG) && battler.hasWorkingAbility(:SHADOWTAG)
        opp=battler
      end
    end
    if opp
      abilityname=PBAbilities.getName(opp.ability)
      pbDisplayPaused(_INTL("{1}'s {2} prevents switching!",opp.pbThis,abilityname)) if showMessages
      # UPDATE 11/16
      # now displays the proper fleeing message iff you are attempting to flee
      # Note: not very elegant, but it should work.
      pbDisplayPaused(_INTL("{1} prevents escaping with {2}!", opp.pbThis, abilityname)) if !showMessages && pkmnidxTo == -1
      return false
    end
    if (thispkmn.effects[PBEffects::MudBath] || 0) > 0
      @scene.pbDisplay(_INTL("{1} is stuck in the mud and can't be switched out!",thispkmn.pbThis))
      return false
    end
    return true
  end

  def pbRegisterSwitch(idxPokemon,idxOther)
    return false if !pbCanSwitch?(idxPokemon,idxOther,false)
    @choices[idxPokemon][0]=2          # "Switch PokÃ©mon"
    @choices[idxPokemon][1]=idxOther   # Index of other PokÃ©mon to switch with
    @choices[idxPokemon][2]=nil
    side=(pbIsOpposing?(idxPokemon)) ? 1 : 0
    owner=pbGetOwnerIndex(idxPokemon)
    if @megaEvolution[side][owner]==idxPokemon
      @megaEvolution[side][owner]=-1
    end
    if @zMove[side][owner]==idxPokemon
      @zMove[side][owner]=-1
    end
    return true
  end

  def pbRegisterShift(idxPokemon,targetBattlerIndex)
    return false if !pbCanShift?(idxPokemon,targetBattlerIndex,false)
    targetBattler=@battlers[targetBattlerIndex]
    @choices[idxPokemon][0]=2
    @choices[idxPokemon][1]=targetBattler.pokemonIndex
    @choices[idxPokemon][2]=:shift
    @choices[idxPokemon][3]=targetBattlerIndex
    side=(pbIsOpposing?(idxPokemon)) ? 1 : 0
    owner=pbGetOwnerIndex(idxPokemon)
    if @megaEvolution[side][owner]==idxPokemon
      @megaEvolution[side][owner]=-1
    end
    if @zMove[side][owner]==idxPokemon
      @zMove[side][owner]=-1
    end
    return true
  end

  def pbCanChooseNonActive?(index)
    party=pbParty(index)
    for i in 0..party.length-1
      return true if pbCanSwitchLax?(index,i,false)
    end
    return false
  end

 def pbJudgeSwitch(favorDraws=false)
    if !favorDraws
      return if @decision>0
      pbJudge()
      return if @decision>0
    else
      return if @decision==5
      pbJudge()
      return if @decision>0
    end
  end

  def pbSwitch(favorDraws=false)
    if !favorDraws
      return if @decision>0
      pbJudge()
      return if @decision>0
    else
      return if @decision==5
      pbJudge()
      return if @decision>0
    end
    firstbattlerhp=@battlers[0].hp
    switched=[]
    activeBattlerIndices.each do |index|
      next if @sosbattle == 3 && index == 2
      next if @battlers[index] && !@battlers[index].isFainted?
      next if !pbCanChooseNonActive?(index)
      if !pbOwnedByPlayer?(index)
        if !pbIsOpposing?(index) || (@opponent && pbIsOpposing?(index))
          newenemy=pbSwitchInBetween(index,false,false)
          if newenemy >= 0
#### JERICHO - 001 - START
              if !pbIsOpposing?(index)
                if isConst?(@party1[newenemy].ability,PBAbilities,:ILLUSION) #ILLUSION
                  party3=@party1.find_all {|item| item && !item.egg? && item.hp>0 }
                  if party3[@party1.length-1] != @party1[newenemy]
                    illusionpoke = party3[party3.length-1]
                  end
                end #ILLUSION
                newname = illusionpoke != nil ? illusionpoke.name : @party1[newenemy].name #ILLUSION
              else
                if isConst?(@party2[newenemy].ability,PBAbilities,:ILLUSION) #ILLUSION
                  party3=@party2.find_all {|item| item && !item.egg? && item.hp>0 }
                  if party3[@party2.length-1] != @party2[newenemy]
                    illusionpoke = party3[party3.length-1]
                  end
                end #ILLUSION
                newname = illusionpoke != nil ? illusionpoke.name : PBSpecies.getName(@party2[newenemy].species) #ILLUSION
              end
#### JERICHO - 001 - END
            opponent=pbGetOwner(index)
            if singleBattle? && firstbattlerhp>0 && @shiftStyle && @opponent &&
                @internalbattle && pbCanChooseNonActive?(0) && pbIsOpposing?(index) &&
                @battlers[0].effects[PBEffects::Outrage]==0
#### JERICHO - 001 - START
                pbDisplayPaused(_INTL("{1} is about to send in {2}.",opponent.fullname,newname)) #ILLUSION
#### JERICHO - 001 - END
              if pbDisplayConfirm(_INTL("Will {1} change Pokémon?",self.pbPlayer.name))
                newpoke=pbSwitchPlayer(0,true,true)
                if newpoke>=0
                  pbDisplayBrief(_INTL("{1}, that's enough!  Come back!",@battlers[0].name))
                  switched.push(0) if pbRecallAndReplace(0,newpoke)
                end
              end
            end
            switched.push(index) if pbRecallAndReplace(index,newenemy)
          end
        end
      elsif @opponent || isBossBattle?
        newpoke=pbSwitchInBetween(index,true,false)
        if newpoke >= 0
          switched.push(index) if pbRecallAndReplace(index,newpoke)
        end
      else
        switch=false
        if !pbDisplayConfirm(_INTL("Use next Pokémon?"))
          switch=(pbRun(index,true)<=0)
        else
          switch=true
        end
        if switch
          newpoke=pbSwitchInBetween(index,true,false)
          if newpoke >= 0
            switched.push(index) if pbRecallAndReplace(index,newpoke)
          end
        end
      end
    end
    # The stored turn order may have been built with these lanes empty.
    entrants=switched.map { |index| @battlers[index] }
    entrants.sort_by { |battler| [-battler.pbSpeed,battler.index] }.each do |battler|
      battler.pbAbilitiesOnSwitchIn(true)
    end
  end

  def pbSendOut(index,pokemon)
    pbSetSeen(pokemon)
    @peer.pbOnEnteringBattle(self,pokemon)

    if isConst?(@battlers[index].species,PBSpecies,:MAGCARGO) &&
       isConst?(@battlers[index].item,PBItems,:MAGCREST)
      temp = @battlers[index].defense
      @battlers[index].defense = @battlers[index].speed
      @battlers[index].speed = temp
      @battlers[index].spatk *= 1.1
    end
    if isConst?(@battlers[index].species,PBSpecies,:RELICANTH) &&
       isConst?(@battlers[index].item,PBItems,:RELICREST)
      @battlers[index].attack *= 1.2
      @battlers[index].spdef *= 1.3
    end
    if isConst?(@battlers[index].species,PBSpecies,:ORICORIO) &&
       isConst?(@battlers[index].item,PBItems,:ORICREST)
      @battlers[index].spatk *= 1.25
      @battlers[index].speed *= 1.25
    end
    if isConst?(@battlers[index].species,PBSpecies,:SEVIPER) &&
       isConst?(@battlers[index].item,PBItems,:SEVCREST)
      @battlers[index].speed *= 1.5
    end
    if isConst?(@battlers[index].species,PBSpecies,:COFAGRIGUS) &&
       isConst?(@battlers[index].item,PBItems,:COFCREST)
      @battlers[index].spatk *= 1.25
      @battlers[index].spdef *= 1.25
    end
    if isConst?(@battlers[index].species,PBSpecies,:SKUNKCREST) &&
      isConst?(@battlers[index].item,PBItems,:SKUNCREST)
     @battlers[index].atk *= 1.2
     @battlers[index].spatk *= 1.2
   end
    if isConst?(@battlers[index].species,PBSpecies,:DUSKNOIR) &&
       isConst?(@battlers[index].item,PBItems,:DUSKCREST)
      @battlers[index].attack *= 1.2
    end
#    if isConst?(@battlers[index].species,PBSpecies,:CLAYDOL) &&
#       isConst?(@battlers[index].item,PBItems,:CLAYCREST)
#      @battlers[index].spatk = @battlers[index].defense
#    end
#    if isConst?(@battlers[index].species,PBSpecies,:DEDENNE) &&
#       isConst?(@battlers[index].item,PBItems,:DEDECREST)
#      @battlers[index].attack = @battlers[index].speed
#    end
#    if isConst?(@battlers[index].species,PBSpecies,:TYPHLOSION) &&
#       isConst?(@battlers[index].item,PBItems,:TYPHCREST)
#      @battlers[index].attack = @battlers[index].spatk
#    end
    if isConst?(@battlers[index].species,PBSpecies,:ARIADOS) &&
       isConst?(@battlers[index].item,PBItems,:ARIACREST)
      @battlers[index].speed *= 1.5
    end
    if isConst?(@battlers[index].ability,PBAbilities,:ILLUSORYSHROUD)
      temp = @battlers[index].defense
      @battlers[index].defense = @battlers[index].spdef
      @battlers[index].spdef = temp
    end
    if isConst?(@battlers[index].species,PBSpecies,:INFERNAPE) &&
       isConst?(@battlers[index].item,PBItems,:INFCREST)
      temp1 = @battlers[index].attack
      @battlers[index].attack = @battlers[index].defense
      @battlers[index].defense = temp1

      temp2 = @battlers[index].spatk
      @battlers[index].spatk = @battlers[index].spdef
      @battlers[index].spdef = temp2
    end
    if isConst?(@battlers[index].species,PBSpecies,:DELCATTY) &&
       isConst?(@battlers[index].item,PBItems,:DELCREST)
      party = pbParty(index)
      boost = false
      for mon in party
        if !mon || mon==@battlers[index] || mon.hp <= 0
          next
        end
        @battlers[index].attack += (0.1 * mon.attack)
        @battlers[index].defense += (0.1 * mon.defense)
        @battlers[index].speed += (0.1 * mon.speed)
        @battlers[index].spatk += (0.1 * mon.spatk)
        @battlers[index].spdef += (0.1 * mon.spdef)
        boost = true
      end
      if boost
        pbDisplay(_INTL("{1} gained strength from The Power of Friendship!",battlers[index].pbThis))
      end
    end
    if pbIsOpposing?(index)
      #  in-battle text
      @scene.pbTrainerSendOut(index,pokemon,@battlers[index])
      if isConst?(@battlers[index].species,PBSpecies,:PHIONE) &&
        isConst?(@battlers[index].item,PBItems,:PHIONECREST)
       @battlers[index].defense *= 1.5
       @battlers[index].spdef *= 1.5
       battlers[index].effects[PBEffects::AquaRing]=true
       pbAnimation(555,battlers[index],nil) # Aqua Ring animation
       pbDisplay(_INTL("{1} surrounded itself with a veil of water!",battlers[index].pbThis))
     end
     if isConst?(@battlers[index].species,PBSpecies,:PROBOPASS) &&
      isConst?(@battlers[index].item,PBItems,:PROBOCREST)
        @battlers[index].effects[PBEffects::MagnetRise]=8
        pbDisplay(_INTL("{1} levitated with the power of its crest!",@battlers[index].pbThis))
    end
     if isConst?(@battlers[index].species,PBSpecies,:THIEVUL) &&
      isConst?(@battlers[index].item,PBItems,:THIEVCREST)
        opposing=@battlers[index].pbOppositeOpposing
        if opposing.pbCanReduceStatStage?(PBStats::SPATK)
          opposing.pbReduceStat(PBStats::SPATK,1,true)
        end
        if @battlers[index].pbCanIncreaseStatStage?(PBStats::SPATK)
          @battlers[index].pbIncreaseStat(PBStats::SPATK,1,true)
        end
     end
      # Last Pokemon script; credits to venom12 and HelioAU
      if !@opponent.is_a?(Array)
        trainertext = @opponent
        if isConst?(trainertext.trainertype,PBTrainers,:POKEGANG6)
          if pokemon.name=="Cofagrigus"
            @battlers[1].pbIncreaseStatBasic(PBStats::ATTACK,1)
            @battlers[1].pbIncreaseStatBasic(PBStats::DEFENSE,2)
            @battlers[1].pbIncreaseStatBasic(PBStats::SPDEF,2)
            pbCommonAnimation("StatUp",battlers[1],nil)
            pbDisplayPaused(_INTL("Cofagrigus' Attack, Defense and Sp. Def. rose!"))
          end
        end
        if pbPokemonCount(@party2) <= pbSideSize(1)
        # Define any trainers that you want to activate this script below
        # For each defined trainer, add the BELOW section for them
          if isConst?(trainertext.trainertype,PBTrainers,:POKEMONTRAINER_Kara)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("You're about to lose so bad!"))
              @scene.pbHideOpponent
            elsif $game_variables[226] == 2
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("Dammit, no way am I about to lose to you!"))
              @scene.pbHideOpponent
            elsif $game_variables[226] == 3
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("This is starting to piss me off."))
              @scene.pbHideOpponent
            elsif $game_variables[226] == 4
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("What am I doing wrong?"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:POKEMONTRAINER_Percy)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("I have to say, two battles in and I still don't enjoy it."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LUX)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("Now this is something else."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:HANDMAIDEN)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("You may be talented, sure. But that means nothing."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:HANDMAIDEN)
            if $game_variables[226] == 1
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("Not again! I will not let this happen again!"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:CONDUIT)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("How wonderful, being able to see my closest friend grow so much!"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:ELDERCULTIST_Perrin)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Elder Cultist",100,105)
              pbDisplayPaused(_INTL("What the hell is this?!"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:ELDERCULTIST_Echo)
            if $game_variables[226] == 1
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Elder Cultist",100,105)
              pbDisplayPaused(_INTL("Maybe we can turn this one around?"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:ELDERCULTIST_Doran)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Elder Cultist",100,105)
              pbDisplayPaused(_INTL("Yeah, you lost any chance of me showin' you any mercy."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:ELDERCULTIST_Hadien)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Elder Cultist",100,105)
              pbDisplayPaused(_INTL("Now this brings a smile to my face."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:MINERVA)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Music - Don't Lose Hope!",100,100)
              pbDisplayPaused(_INTL("Oh, I might have just met my match."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:AGRUS)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Music - Don't Lose Hope!",100,100)
              pbDisplayPaused(_INTL("I ain't accepting a loss just yet!"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:HYACINTH)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Music - Don't Lose Hope!",100,100)
              pbDisplayPaused(_INTL("The end is within your grasp!"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Four)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("Hold your applause! It's not over yet!"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Five)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("The tides are dyin' down. Who's gonna be the one afloat?"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Six)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("It's not too late for you to join us among the clouds."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Seven)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Elder Cultist",100,90)
              pbDisplayPaused(_INTL("Night falls. Is this the end?"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Eight)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("How troublesome. I should've killed you when I had the chance."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Nine)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("You've grown so much, old friend."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:RESERVELEADER_1)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("What's happening to me?"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Ten)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("Hah! I didn't think for a second that us old folk could shine a light to you kids."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:RESERVELEADER_2)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("The future is changing. Can you feel it? How exciting, yet how harrowing it feels."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:RESERVELEADER_3)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("Only one of us will be leaving here alive, and I don't intend to die just yet."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_ElevenA)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("Tch. The sun is nearly setting."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_ElevenB)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("Can you feel the moon's chill? This battle is nearing its end."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:LEADER_Twelve)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbBGMPlay("Battle! Gym Leader",100,105)
              pbDisplayPaused(_INTL("I do love a twist ending!"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:MYRON2)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("This can't be happening, this can't be-"))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:CLOUDQUEEN)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("I've grown bored of this meaningless conflict."))
              @scene.pbHideOpponent
            end
          elsif isConst?(trainertext.trainertype,PBTrainers,:ALCHEMIST)
            if $game_variables[226] == 0
              @scene.pbShowOpponent(0)
              pbDisplayPaused(_INTL("Damn, I said no hard feelings, didn't I?"))
              @scene.pbHideOpponent
            end
          end
        end
        # For each defined trainer, add the ABOVE section for them
      end
    else
      @scene.pbSendOut(index,pokemon)
      if isConst?(@battlers[index].species,PBSpecies,:PHIONE) &&
        isConst?(@battlers[index].item,PBItems,:PHIONECREST)
       @battlers[index].defense *= 1.5
       @battlers[index].spdef *= 1.5
       battlers[index].effects[PBEffects::AquaRing]=true
       pbAnimation(555,battlers[index],nil) # Aqua Ring animation
       pbDisplay(_INTL("{1} surrounded itself with a veil of water!",battlers[index].pbThis))
     end
    if isConst?(@battlers[index].species,PBSpecies,:PROBOPASS) &&
      isConst?(@battlers[index].item,PBItems,:PROBOCREST)
        @battlers[index].effects[PBEffects::MagnetRise]=8
        pbDisplay(_INTL("{1} levitated with the power of its crest!",@battlers[index].pbThis))
    end
     if isConst?(@battlers[index].species,PBSpecies,:THIEVUL) &&
      isConst?(@battlers[index].item,PBItems,:THIEVCREST)
        opposing=@battlers[index].pbOppositeOpposing
        if opposing.pbCanReduceStatStage?(PBStats::SPATK)
          opposing.pbReduceStat(PBStats::SPATK,1,true)
        end
        if @battlers[index].pbCanIncreaseStatStage?(PBStats::SPATK)
          @battlers[index].pbIncreaseStat(PBStats::SPATK,1,true)
        end
     end
    end

    # Bruce's Normal trainer boss uses its sheet entry typing on each sendout.
    if @opponent && pbIsOpposing?(index) && $game_variables[:Difficulty_Mode]==0 &&
       pokemon.bossId==:TOXICROAKBOSS_NORMAL
      boss=$bosscache[pokemon.bossId]
      pbShieldEffects(@battlers[index],boss.onEntryEffects,true) if boss && boss.onEntryEffects
    end
    @scene.pbResetMoveIndex(index)
  end

  def pbReplace(index,newpoke,batonpass=false)
    @switchedOut[index]=true
    party=pbParty(index)
    old_gas=@battlers[index].hasWorkingAbility(:NEUTRALIZINGGAS)
    if pbOwnedByPlayer?(index)
      # Reorder the party for this battle
      bpo=-1; bpn=-1
      partysize = [@partyorder.length, party.length].max
      for i in 0...partysize
        bpo=i if @partyorder[i]==@battlers[index].pokemonIndex
        bpn=i if @partyorder[i]==newpoke
      end
      if bpo >= 0 && bpn >= 0
        poke1=@partyorder[bpo]
        @partyorder[bpo]=@partyorder[bpn]
        @partyorder[bpn]=poke1
      end
      @battlers[index].pbInitialize(party[newpoke],newpoke,batonpass)
      pbSendOut(index,party[newpoke])
    else
      @battlers[index].pbInitialize(party[newpoke],newpoke,batonpass)
      pbSetSeen(party[newpoke])
      if pbIsOpposing?(index)
        pbSendOut(index,party[newpoke])
      else
        pbSendOut(index,party[newpoke])
      end
    end
    pbNeutralizingGasEnded([index]) if old_gas
  end

  def pbRecallAndReplace(index,newpoke,batonpass=false)
    # Infatuated Pokemon take 1/6 HP damage when switching out
    if @battlers[index].effects[PBEffects::Attract]>=0 && !@battlers[index].isFainted?
      pbDisplay(_INTL("{1} is hurt by leaving its love behind!",@battlers[index].pbThis))
      @battlers[index].pbReduceHP((@battlers[index].totalhp/6).floor)
      if @battlers[index].isFainted?
        @battlers[index].pbFaint
        # Don't return - we still need to send out the replacement Pokemon
      end
    end
    if @battlers[index].effects[PBEffects::Illusion]
      @battlers[index].effects[PBEffects::Illusion] = nil
    end
    if @battlers[index].unburdened
      @battlers[index].unburdened=false
      @battlers[index].speed/=2
    end
    pbClearChoices(index)
    @battlers[index].pbResetForm
    if !@battlers[index].isFainted?
      @scene.pbRecall(index)
    end
    pbMessagesOnReplace(index,newpoke)
    pbReplace(index,newpoke,batonpass)
    if  @field.effects[PBEffects::WonderRoom] > 0
      if !(@battlers[index].isFainted?)
        if @battlers[index].wonderroom==false
          @battlers[index].pbSwapDefenses
        end
      end
    end
    @scene.partyBetweenKO2(!pbOwnedByPlayer?(index)) unless pbSideSize(index)>1
    return pbOnActiveOne(@battlers[index])
  end

  def pbMessagesOnReplace(index,newpoke)
    party=pbParty(index)
    if pbOwnedByPlayer?(index)
#     if !party[newpoke]
#       p [index,newpoke,party[newpoke],pbAllFainted?(party)]
#       PBDebug.log([index,newpoke,party[newpoke],"pbMOR"].inspect)
#       for i in 0...party.length
#         PBDebug.log([i,party[i].hp].inspect)
#       end
#       raise BattleAbortedException.new
#     end
#### JERICHO - 001 - start
      if isConst?(party[newpoke].ability,PBAbilities,:ILLUSION) #ILLUSION
        party2=party.find_all {|item| item && !item.egg? && item.hp>0 }
        if party2[party.length-1] != party[newpoke]
          illusionpoke = party[party.length-1]
        end
      end #ILLUSION
      newname = illusionpoke != nil ? illusionpoke.name : party[newpoke].name
      opposing=@battlers[index].pbOppositeOpposing
      if opposing.hp<=0 || opposing.hp==opposing.totalhp
        pbDisplayBrief(_INTL("Go! {1}!",newname))
      elsif opposing.hp>=(opposing.totalhp/2)
        pbDisplayBrief(_INTL("Do it! {1}!",newname))
      elsif opposing.hp>=(opposing.totalhp/4)
        pbDisplayBrief(_INTL("Go for it, {1}!",newname))
      else
        pbDisplayBrief(_INTL("Your foe's weak!\nGet 'em, {1}!",newname))
      end
#### JERICHO - 001 - END
    else
#     if !party[newpoke]
#       p [index,newpoke,party[newpoke],pbAllFainted?(party)]
#       PBDebug.log([index,newpoke,party[newpoke],"pbMOR"].inspect)
#       for i in 0...party.length
#         PBDebug.log([i,party[i].hp].inspect)
#       end
#       raise BattleAbortedException.new
#     end
#### JERICHO - 001 - START
      if isConst?(party[newpoke].ability,PBAbilities,:ILLUSION) #ILLUSION
        party2=party.find_all {|item| item && !item.egg? && item.hp>0 }
        if party2[party.length-1] != party[newpoke]
          illusionpoke = party[party.length-1]
        end
      end #ILLUSION
      if pbIsOpposing?(index)
        newname = illusionpoke != nil ? illusionpoke.name : PBSpecies.getName(party[newpoke].species) #ILLUSION
      else
        newname = illusionpoke != nil ? illusionpoke.name : party[newpoke].name #ILLUSION
      end
      owner=pbGetOwner(index)
      pbDisplayBrief(_INTL("{1} sent\r\nout {2}!",owner.fullname,newname)) #ILLUSION
#### JERICHO - 001 - END
    end
  end

  def pbSwitchInBetween(index,lax,cancancel)
    if !pbOwnedByPlayer?(index)
      return @scene.pbChooseNewEnemy(index,pbParty(index))
    else
      return pbSwitchPlayer(index,lax,cancancel)
    end
  end

  def pbSwitchPlayer(index,lax,cancancel)
    if @debug
      return @scene.pbChooseNewEnemy(index,pbParty(index))
    else
      return @scene.pbSwitch(index,lax,cancancel)
    end
  end

  def pbDefaultChooseNewEnemy(index,party)
    return -1 if party.nil?

    startIdx = 0
    endIdx = party.length

    # Adjust range for partner control
    if $game_switches[2030] && @player.is_a?(Array) && !pbIsOpposing?(index)
      ownerIndex = pbGetOwnerIndexFromBattlerIndex(index)
      startIdx,endIdx = pbOwnedPartyRangeForSideOwner(false,ownerIndex)
    end

    for i in startIdx...endIdx
      next if !party[i]
      next if party[i].isEgg?
      next if party[i].hp<=0
      next if !pbCanSwitch?(index,i,false)
      return i
    end
    return -1
  end

  # These effects reference an established battler. Move selections and pending
  # Reverb targets instead refer to lanes, so a shift leaves them in place.
  SHIFTED_BATTLER_EFFECTS = [
    PBEffects::Attract,
    PBEffects::FutureSightUser, PBEffects::LeechSeed, PBEffects::LockOnPos,
    PBEffects::MeanLook, PBEffects::MultiTurnUser,
    PBEffects::PerishSongUser, PBEffects::Crushing, PBEffects::JawLockUser,
    PBEffects::AftershockUser, PBEffects::SyrupBombUser
  ].freeze

  def pbShiftBattlers(index1,index2,move_swap: false)
    return false if !pbCanShift?(index1,index2,false,move_swap: move_swap)
    side=(pbIsOpposing?(index1)) ? 1 : 0
    owner=pbGetOwnerIndex(index1)
    if @megaEvolution[side][owner]==index1
      @megaEvolution[side][owner]=index2
    elsif @megaEvolution[side][owner]==index2
      @megaEvolution[side][owner]=index1
    end
    if @zMove[side][owner]==index1
      @zMove[side][owner]=index2
    elsif @zMove[side][owner]==index2
      @zMove[side][owner]=index1
    end
    @battlers[index1],@battlers[index2]=@battlers[index2],@battlers[index1]
    @choices[index1],@choices[index2]=@choices[index2],@choices[index1]
    @successStates[index1],@successStates[index2]=@successStates[index2],@successStates[index1]
    @switchedOut[index1],@switchedOut[index2]=@switchedOut[index2],@switchedOut[index1]
    @battlers[index1].instance_variable_set(:@index,index1)
    @battlers[index2].instance_variable_set(:@index,index2)
    shifted_indices={index1=>index2,index2=>index1}
    eachActiveBattlerIndex do |index|
      battler=@battlers[index]
      effects=battler.effects
      SHIFTED_BATTLER_EFFECTS.each do |effect|
        value=effects[effect]
        effects[effect]=shifted_indices.fetch(value,value)
      end
      forebode=effects[PBEffects::Forebode]
      forebode[1]=shifted_indices.fetch(forebode[1],forebode[1]) if forebode
      battler.lastAttacker=shifted_indices.fetch(battler.lastAttacker,battler.lastAttacker)
    end
    @lastMoveUser=shifted_indices.fetch(@lastMoveUser,@lastMoveUser)
    @synchronize[0]=shifted_indices.fetch(@synchronize[0],@synchronize[0])
    @synchronize[1]=shifted_indices.fetch(@synchronize[1],@synchronize[1])
    seed_target=@field.effects[PBEffects::PyroPreTarget]
    @field.effects[PBEffects::PyroPreTarget]=shifted_indices.fetch(seed_target,seed_target)
    @scene.pbShiftBattlers(index1,index2) if @scene && @scene.respond_to?(:pbShiftBattlers)
    return true
  end

################################################################################
# Using an item.
################################################################################
# Uses an item on a PokÃ©mon in the player's party.
  def pbUseItemOnPokemon(item,pkmnIndex,userPkmn,scene,move_index=nil)
    pokemon=pkmnIndex && pkmnIndex>=0 ? @party1[pkmnIndex] : nil
    battler=nil
    name=pbGetOwner(userPkmn.index).fullname
    name=pbGetOwner(userPkmn.index).name if pbBelongsToPlayer?(userPkmn.index)
    pbDisplayBrief(_INTL("{1} used the\r\n{2}.",name,PBItems.getName(item)))
    PBDebug.log("[Player used #{PBItems.getName(item)}]")
    ret=false
    if !pokemon || pokemon.isEgg?
      pbDisplay(_INTL("But it had no effect!"))
    else
      eachActiveBattlerIndex do |i|
        if !pbIsOpposing?(i) && @battlers[i].pokemonIndex==pkmnIndex
          battler=@battlers[i]
        end
      end
      blocked=battler && (battler.effects[PBEffects::Embargo]>0 ||
                          battler.effects[PBEffects::MultiTurnAttack]==PBMoves::BINDINGWORD)
      if !blocked
        ret=ItemHandlers.triggerBattleUseOnPokemon(item,pokemon,battler,scene,move_index)
      end
    end
    if !ret && pbBelongsToPlayer?(userPkmn.index) && [1,2].include?($ItemData[item][ITEMBATTLEUSE])
      if $PokemonBag.pbCanStore?(item)
        $PokemonBag.pbStoreItem(item)
      else
        raise _INTL("Couldn't return unused item to Bag somehow.")
      end
    end
    if ret
      $game_variables[536] += 1
    end
    return ret
  end

# Uses an item on an active PokÃ©mon.
  def pbUseItemOnBattler(item,index,userPkmn,scene)
    PBDebug.log("[Player used #{PBItems.getName(item)}]")
    target=index && index>=0 ? @battlers[index] : nil
    ret=false
    if target && !target.isFainted? && target.effects[PBEffects::Embargo]<=0 &&
       target.effects[PBEffects::MultiTurnAttack]!=PBMoves::BINDINGWORD
      ret=ItemHandlers.triggerBattleUseOnBattler(item,target,scene)
    end
    if !ret && pbBelongsToPlayer?(userPkmn.index) && [1,2].include?($ItemData[item][ITEMBATTLEUSE])
      if $PokemonBag.pbCanStore?(item)
        $PokemonBag.pbStoreItem(item)
      else
        raise _INTL("Couldn't return unused item to Bag somehow.")
      end
    end
    if ret
      $game_variables[536] += 1
    end
    return ret
  end

  def pbRegisterItem(idxPokemon,idxItem,idxTarget=nil,move_index=nil)
    PBDebug.log("[pbRegisterItem called with idxPokemon=#{idxPokemon}, idxItem=#{idxItem}, idxTarget=#{idxTarget}]")
    # Block using items on partner's Pokemon when partner control is enabled
    if $game_switches[2030] && @player.is_a?(Array) && idxTarget &&
       [1,3].include?($ItemData[idxItem][ITEMBATTLEUSE])
      secondPartyStart = pbSecondPartyBegin(idxPokemon)
      if idxTarget >= secondPartyStart
        pbDisplay(_INTL("You can't use items on your partner's Pokémon!"))
        return false
      end
    end
    if ItemHandlers.hasUseInBattle(idxItem)
      PBDebug.log("[Item has UseInBattle handler]")
      if idxPokemon==0
        if ItemHandlers.triggerBattleUseOnBattler(idxItem,@battlers[idxPokemon],@scene)
          PBDebug.log("[BattleUseOnBattler returned true, calling UseInBattle]")
          ItemHandlers.triggerUseInBattle(idxItem,@battlers[idxPokemon],self)
          if pbSideSize(0)>1
            @choices[idxPokemon+2][0]=3         # "Use an item"
            @choices[idxPokemon+2][1]=idxItem   # ID of item to be used
            @choices[idxPokemon+2][2]=idxTarget # Index of PokÃ©mon to use item on
          end
        else
          PBDebug.log("[BattleUseOnBattler returned false]")
          return false
        end
      else
        PBDebug.log("[idxPokemon != 0, cannot use item]")
        if ItemHandlers.triggerBattleUseOnBattler(idxItem,@battlers[idxPokemon],@scene)
          pbDisplay(_INTL("It's impossible to aim without being focused!"))
        end
        return false
      end
    else
      PBDebug.log("[Item does NOT have UseInBattle handler]")
    end
    PBDebug.log("[Registering choice for Pokemon #{idxPokemon}]")
    @choices[idxPokemon]=[3,idxItem,idxTarget,-1,move_index]
    side=(pbIsOpposing?(idxPokemon)) ? 1 : 0
    owner=pbGetOwnerIndex(idxPokemon)
    if @megaEvolution[side][owner]==idxPokemon
      @megaEvolution[side][owner]=-1
    end
    if @zMove[side][owner]==idxPokemon
      @zMove[side][owner]=-1
    end
    return true
  end

  def pbEnemyUseItem(item,battler)
    return 0 if !@internalbattle
    items=pbGetOwnerItems(battler.index)
    return if !items
    opponent=pbGetOwner(battler.index)
    for i in 0...items.length
      if items[i]==item
        items.delete_at(i)
        break
      end
    end
    itemname=PBItems.getName(item)
    pbDisplayBrief(_INTL("{1} used the\r\n{2}!",opponent.fullname,itemname))
    if isConst?(item,PBItems,:POTION)
      battler.pbRecoverHP(20,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:SUPERPOTION)
      battler.pbRecoverHP(60,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:HYPERPOTION)
      battler.pbRecoverHP(120,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:ULTRAPOTION)
      battler.pbRecoverHP(200,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:MOOMOOMILK)
      battler.pbRecoverHP(100,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:CHOCOLATEIC)
      battler.pbRecoverHP(70,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:STRAWBIC)
      battler.pbRecoverHP(90,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:STRAWCAKE)
      battler.pbRecoverHP(150,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:BLUEMIC)
      battler.pbRecoverHP(200,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:MAXPOTION)
      battler.pbRecoverHP(battler.totalhp-battler.hp,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:FRESHWATER)
      battler.pbRecoverHP(30,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:SODAPOP)
      battler.pbRecoverHP(50,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:LEMONADE)
      battler.pbRecoverHP(70,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:ENERGYPOWDER)
      battler.pbRecoverHP(50,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:ENERGYROOT)
      battler.pbRecoverHP(200,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:ORANBERRY)
      battler.pbRecoverHP(10,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:SITRUSBERRY)
      battler.pbRecoverHP(battler.totalhp/4,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:BERRYJUICE)
      battler.pbRecoverHP(20,true)
      pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
    elsif isConst?(item,PBItems,:FULLRESTORE)
      fullhp=(battler.hp==battler.totalhp)
      battler.pbRecoverHP(battler.totalhp-battler.hp,true)
      unless battler.effects[PBEffects::Spritz] == 1
        battler.status=0; battler.statusCount=0
      else
        pbDisplay(_INTL("{1}'s spritz prevented status cure!",battler.pbThis))
      end
      battler.effects[PBEffects::Confusion]=0
      if fullhp
        pbDisplay(_INTL("{1} became healthy!",battler.pbThis))
      else
        pbDisplay(_INTL("{1}'s HP was restored.",battler.pbThis))
      end
    elsif isConst?(item,PBItems,:FULLHEAL)
      unless battler.effects[PBEffects::Spritz] == 1
        battler.status=0; battler.statusCount=0
      else
        pbDisplay(_INTL("{1}'s spritz prevented status cure!",battler.pbThis))
      end
      battler.effects[PBEffects::Confusion]=0
      pbDisplay(_INTL("{1} became healthy!",battler.pbThis))
    elsif isConst?(item,PBItems,:XATTACK)
      if battler.pbCanIncreaseStatStage?(PBStats::ATTACK)
        battler.pbIncreaseStat(PBStats::ATTACK,2,true)
      end
    elsif isConst?(item,PBItems,:XDEFEND)
      if battler.pbCanIncreaseStatStage?(PBStats::DEFENSE)
        battler.pbIncreaseStat(PBStats::DEFENSE,2,true)
      end
    elsif isConst?(item,PBItems,:XSPEED)
      if battler.pbCanIncreaseStatStage?(PBStats::SPEED)
        battler.pbIncreaseStat(PBStats::SPEED,2,true)
      end
    elsif isConst?(item,PBItems,:XSPECIAL)
      if battler.pbCanIncreaseStatStage?(PBStats::SPATK)
        battler.pbIncreaseStat(PBStats::SPATK,2,true)
      end
    elsif isConst?(item,PBItems,:XSPDEF)
      if battler.pbCanIncreaseStatStage?(PBStats::SPDEF)
        battler.pbIncreaseStat(PBStats::SPDEF,2,true)
      end
    elsif isConst?(item,PBItems,:XACCURACY)
      if battler.pbCanIncreaseStatStage?(PBStats::ACCURACY)
        battler.pbIncreaseStat(PBStats::ACCURACY,2,true)
      end
    elsif isConst?(item,PBItems,:REVIVE)
#      battler.hp=(battler.totalhp/2).floor
      pbDisplay(_INTL("{1} revived a fainted Pokémon!",opponent.fullname))
    elsif isConst?(item,PBItems,:MAXREVIVE) || isConst?(item,PBItems,:REVIVALHERB)
#      battler.hp=battler.totalhp
      pbDisplay(_INTL("{1} revived a fainted Pokémon!",opponent.fullname))
    elsif isConst?(item,PBItems,:SACREDASH)
#      party=pbParty(1)
#      for j in 0...party.length
#        party[j].hp=party[j].totalhp if party[j].isFainted?
#      end
      pbDisplay(_INTL("{1} revived all fainted Pokémon!",opponent.fullname))
    end
  end

################################################################################
# Fleeing from battle.
################################################################################
  def pbCanRun?(idxPokemon)
    return false if @opponent
    if @battlers.any?{|battler| battler.isbossmon}
      return true if @battlers.any?{|battler| battler.canrun}
    end
    thispkmn=@battlers[idxPokemon]
    return true if thispkmn.hasWorkingItem(:SMOKEBALL)
    return true if thispkmn.hasWorkingAbility(:RUNAWAY)
    return pbCanSwitch?(idxPokemon,-1,false)
  end

  def pbRun(idxPokemon,duringBattle=false)
    thispkmn=@battlers[idxPokemon]
    if pbIsOpposing?(idxPokemon)
      return 0 if @opponent
      @choices[i][0]=5 # run
      @choices[i][1]=0
      @choices[i][2]=nil
      return -1
    end
    if @opponent
      if $DEBUG && Input.press?(Input::CTRL)
        if pbDisplayConfirm(_INTL("Treat this battle as a win?"))
          @decision=1
          return 1
        elsif pbDisplayConfirm(_INTL("Treat this battle as a loss?"))
          @decision=2
          return 1
        end
      elsif @internalbattle
        if pbDisplayConfirm(_INTL("Would you like to forfeit the battle?"))
          pbDisplay(_INTL("{1} forfeited the match!",self.pbPlayer.name))
          @forfeited=true #pk code
          @decision=2
          return 1
        end
      elsif pbDisplayConfirm(_INTL("Would you like to forfeit the match and quit now?"))
        pbSEPlay("Battle flee")
        pbDisplay(_INTL("{1} forfeited the match!",self.pbPlayer.name))
        @decision=3
        return 1
      end
      return 0
    elsif $game_switches[1998]
      pbDisplayPaused(_INTL("No!  There's no running from this battle!"))
      return 0
    end
    if $DEBUG && Input.press?(Input::CTRL)
      pbSEPlay("Battle flee")
      pbDisplayPaused(_INTL("Got away safely!"))
      @decision=3
      return 1
    end
    if @cantescape
      if isBossBattle?
        pbDisplayPaused(_INTL("No! There's no running from this battle!"))
      else
        pbDisplayPaused(_INTL("Can't escape!"))
      end
      return 0
    end
  if !$game_switches[1379] # Anti-running away switch.
    if thispkmn.pbHasType?(:GHOST)
      pbSEPlay("Battle flee")
      pbDisplayPaused(_INTL("Got away safely!"))
      @decision=3
      return 1
    end
    if thispkmn.hasWorkingItem(:SMOKEBALL)
      pbSEPlay("Battle flee")
      if duringBattle
        pbDisplayPaused(_INTL("Got away safely!"))
      else
        pbDisplayPaused(_INTL("{1} fled using its {2}!",thispkmn.pbThis,PBItems.getName(thispkmn.item)))
      end
      @decision=3
      return 1
    end
    if thispkmn.hasWorkingAbility(:RUNAWAY)
      pbSEPlay("Battle flee")
      if duringBattle
        pbDisplayPaused(_INTL("Got away safely!"))
      else
        pbDisplayPaused(_INTL("{1} fled using Run Away!",thispkmn.pbThis))
      end
      @decision=3
      return 1
    end
  end
    if !duringBattle && !pbCanSwitch?(idxPokemon,-1,false) # TODO: Use real messages
      pbDisplayPaused(_INTL("Can't escape!"))
      return 0
    end
    # Note: not pbSpeed, because using unmodified Speed
    speedPlayer=thispkmn.speed
    opposing=thispkmn.pbOppositeOpposing
    if !opposing || opposing.isFainted?
      opposing=thispkmn.opposingLivingBattlers.first
    end
    if opposing
      speedEnemy=opposing.speed
      if speedPlayer>speedEnemy
        rate=256
      else
        speedEnemy=1 if speedEnemy<=0
        rate=speedPlayer*128/speedEnemy
        rate+=@runCommand*30
        rate&=0xFF
      end
    else
      rate=256
    end
    ret=1
    if pbAIRandom(256)<rate && !$game_switches[1379] # Anti-running away switch.
      pbSEPlay("Battle flee")
      pbDisplayPaused(_INTL("Got away safely!"))
      @decision=3
    else
      pbDisplayPaused(_INTL("Can't escape!"))
      ret=-1
    end
    if !duringBattle
      @runCommand+=1
    end
    return ret
  end

################################################################################
# Mega Evolve battler.
################################################################################
  def pbCanMegaEvolve?(index)
    return false if $game_switches[NO_MEGA_EVOLUTION]
    return false if !@battlers[index] || @battlers[index].isFainted?
    if !(@battlers[index].isMega?)
      @battlers[index].hasmegad=false
    end
    return false if @battlers[index].hasmegad
    return false if (@battlers[index].isMega? && @battlers[index].hasmegad)
    return false if !@battlers[index].hasMega?
    return false if !pbHasMegaRing(index)
    if !@battlers[index].premega
     side=(pbIsOpposing?(index)) ? 1 : 0
     owner=pbGetOwnerIndex(index)
     return false if @megaEvolution[side][owner]!=-1
    end
    return true
  end

  def pbRegisterMegaEvolution(index)
    side=(pbIsOpposing?(index)) ? 1 : 0
    owner=pbGetOwnerIndex(index)
    @megaEvolution[side][owner]=index
  end

  def pbCanMegaEvolveAI?(i,index)
    return false if $game_switches[NO_MEGA_EVOLUTION]
    return false if !i.hasMegaForm?
    #return false if i.hasmegad
    return false if !pbHasMegaRing(index)
    side=1
    owner=pbGetOwnerIndex(index)
    if !i.premega
      return false if @megaEvolution[side][owner]!=-1
    end
    return true
  end

  #def pbCanMegaEvolveAI?(i,index)
  #  return false if !i.hasMega?
  #  side=1
  #  owner=pbGetOwnerIndex(index)
  #  return false if @megaEvolution[side][owner]!=-1
  #  return true
  #end

  def pbMegaEvolve(index)
    return if !@battlers[index] || !@battlers[index].pokemon
    return if @battlers[index].isFainted? || $game_switches[NO_MEGA_EVOLUTION]
    return if !(@battlers[index].hasMega? rescue false)
    return if (@battlers[index].hasmegad)
    return if (@battlers[index].isMega?)
    ownername=pbGetOwner(index).fullname
    ownername=pbGetOwner(index).name if pbBelongsToPlayer?(index)
    if $game_switches[987] && @battlers[index].item==531
      pbDisplay(_INTL("{1}'s {2} is reacting with its soul!",
       @battlers[index].pbThis,
       PBItems.getName(@battlers[index].item),
       ownername))
#### KUROTSUNE - 005 - START
    elsif isConst?(@battlers[index].species, PBSpecies, :RAYQUAZA)
      pbDisplay(_INTL("{1}'s fervent wish has reached {2}!",ownername,@battlers[index].pbThis))
#### KUROTSUNE - 005 - END
    elsif ($Trainer.numbadges>=12 && $game_variables[:Difficulty_Mode] == 2) && !pbBelongsToPlayer?(index) # Intense Mode only. Allows for enemy megas to hold an item and still Mega Evolve.
      pbDisplay(_INTL("{1} is reacting to {2}'s {3}!",@battlers[index].pbThis,ownername,pbGetMegaRingName(index)))
    else
      pbDisplay(_INTL("{1}'s {2} is reacting to {3}'s {4}!",@battlers[index].pbThis,PBItems.getName(@battlers[index].item),ownername,pbGetMegaRingName(index)))
    end
    if $game_switches[987] && @battlers[index].item==531
      pbCommonAnimation("PulseEvolution",@battlers[index],nil)
    else
      pbCommonAnimation("MegaEvolution",@battlers[index],nil)
    end
    wonderroom= @field.effects[PBEffects::WonderRoom]!=0
    @battlers[index].pokemon.makeMega
    @battlers[index].form=@battlers[index].pokemon.form
    @battlers[index].pbUpdate(true,wonderroom)
    @scene.pbChangePokemon(@battlers[index],@battlers[index].pokemon)
    meganame=@battlers[index].pokemon.megaName
    if !meganame || meganame==""
      meganame=_INTL("Mega {1}",PBSpecies.getName(@battlers[index].pokemon.species))
    end
    if $game_switches[987] && @battlers[index].item==531
      pbDisplay(_INTL("{1} was corrupted into {2}!",@battlers[index].pbThis,meganame))
    else
      pbDisplay(_INTL("{1} Mega Evolved into {2}!",@battlers[index].pbThis,meganame))
    end
    side=(pbIsOpposing?(index)) ? 1 : 0
    owner=pbGetOwnerIndex(index)
    @megaEvolution[side][owner]=-2
#### KUROTSUNE - 006 - START
    @battlers[index].pbAbilitiesOnSwitchIn(true,true)
    @battlers[index].hasmegad=true
    #@battlers[index].wonderroom=false
#### KUROTSUNE - 006 - END
    if !pbBelongsToPlayer?(index) && @bossfight &&
     isBossPokemonInRiftForm?(@battlers[index]) &&
     !(@shieldCount>=0 || @shieldSetup>=0)
      @battlers[index].isBoss = true
      @shieldSetup = 1
      @shieldCount = $game_variables[704]
      @scene.pbUpdateShield(@shieldCount, index)
    end
end


################################################################################
# Use Z-Move.
################################################################################
  def pbCanZMove?(index,forecast: false)
    return false if $game_switches[NO_Z_MOVE]
    return false if !@battlers[index].hasZMove?
    return false if !pbHasZRing(index)
    side=(pbIsOpposing?(index)) ? 1 : 0
    owner=pbGetOwnerIndex(index)
    return @zMove[side][owner]!=-2 if forecast
    if @zMove[side][owner]!=-1
      if (@zMove[side][owner]>=0 && @zMove[side][owner]==index)
        return true
      else
        return false
      end
    end
    return true
  end

  def pbRegisterZMove(index,movessetup=false)
    if movessetup==true
      $backuparray=[]
      if pbBelongsToPlayer?(index)
        for i in 0...4
          $backuparray.push(@battlers[index].moves[i])
          if @battlers[index].pbCompatibleZMoveFromMove?(@battlers[index].moves[i])
            @battlers[index].moves[i]=PokeBattle_ZMoves.new(self,@battlers[index],@battlers[index].moves[i],@battlers[index].item,false,true,i)
          end
        end
        return $backuparray
      end
    end
    side=(pbIsOpposing?(index)) ? 1 : 0
    owner=pbGetOwnerIndex(index)
    @zMove[side][owner]=index
  end

  def pbUseZMove(index,move,crystal,moveindex)
    return if !@battlers[index] || !@battlers[index].pokemon
    return if !(@battlers[index].hasZMove? rescue false)
    ownername=pbGetOwner(index).fullname
    ownername=pbGetOwner(index).name if pbBelongsToPlayer?(index)
    pbDisplay(_INTL("{1} surrounded itself with its Z-Power!",@battlers[index].pbThis))
    pbCommonAnimation("ZPower",@battlers[index],nil)
    PokeBattle_ZMoves.new(self,@battlers[index],move,crystal,false,false,moveindex)
    side=(pbIsOpposing?(index)) ? 1 : 0
    owner=pbGetOwnerIndex(index)
    @zMove[side][owner]=-2
end


################################################################################
# Call battler.
################################################################################
  def pbCall(index)
    owner=pbGetOwner(index)
    pbDisplay(_INTL("{1} called {2}!",owner.name,@battlers[index].name))
    pbDisplay(_INTL("{1}!",@battlers[index].name))
    if @battlers[index].isShadow?
      if @battlers[index].inHyperMode?
        @battlers[index].pokemon.hypermode=false
        @battlers[index].pokemon.adjustHeart(-300)
        pbDisplay(_INTL("{1} came to its senses from the Trainer's call!",@battlers[index].pbThis))
      else
        pbDisplay(_INTL("But nothing happened!"))
      end
    elsif @battlers[index].status!=PBStatuses::SLEEP &&
          @battlers[index].pbCanIncreaseStatStage?(PBStats::ACCURACY)
      @battlers[index].pbIncreaseStat(PBStats::ACCURACY,1,true)
    else
      pbDisplay(_INTL("But nothing happened!"))
    end
  end

################################################################################
# Gaining Experience.
################################################################################
  def pbGainEXP
    return if !@internalbattle
    return if $game_switches[1075]
    successbegin=true
    eachActiveBattlerIndex do |i| # Not ordered by priority
      if pbIsOpposing?(i) && @battlers[i].participants.length>0 &&
         @battlers[i].isFainted?
        haveexpall=$PokemonSystem.expall
        # First count the number of participants
        partic=0
        expshare=0
        for j in @battlers[i].participants
          next if !@party1[j] || !pbIsOwner?(0,j)
          partic+=1 if @party1[j].hp>0 && !@party1[j].isEgg?
        end
        if !haveexpall
          for j in 0...@party1.length
            next if !@party1[j] || !pbIsOwner?(0,j)
            expshare+=1 if @party1[j].hp>0 && !@party1[j].isEgg? &&
                           (isConst?(@party1[j].item,PBItems,:EXPSHARE) ||
                           isConst?(@party1[j].itemInitial,PBItems,:EXPSHARE))
          end
        end
        # Now calculate EXP for the participants
        if partic>0 || expshare>0 || haveexpall
          if !@opponent && successbegin && pbAllFainted?(@party2)
            @scene.pbWildBattleSuccess
            successbegin=false
          end
          for j in 0...@party1.length
            next if !@party1[j] || !pbIsOwner?(0,j)
            next if @party1[j].hp<=0 || @party1[j].isEgg?
            haveexpshare=(isConst?(@party1[j].item,PBItems,:EXPSHARE) ||
                          isConst?(@party1[j].itemInitial,PBItems,:EXPSHARE))
            next if !haveexpshare && !@battlers[i].participants.include?(j)
            pbGainExpOne(j,@battlers[i],partic,expshare,haveexpall)
          end
          if haveexpall
            showmessage=true
            for j in 0...@party1.length
              next if !@party1[j] || !pbIsOwner?(0,j)
              next if @party1[j].hp<=0 || @party1[j].isEgg?
              next if isConst?(@party1[j].item,PBItems,:EXPSHARE) ||
                      isConst?(@party1[j].itemInitial,PBItems,:EXPSHARE)
              next if @battlers[i].participants.include?(j)
              pbDisplay(_INTL("The rest of your team gained Exp. Points thanks to the Exp. All!")) if showmessage
              showmessage=false
              pbGainExpOne(j,@battlers[i],partic,expshare,haveexpall,false)
            end
          end
        end
        # Now clear the participants array
        @battlers[i].participants=[]
      end
    end
  end

  def pbGainExpOne(index,defeated,partic,expshare,haveexpall,showmessages=true)
    thispoke=@party1[index]
    # Original species, not current species
    level=defeated.level
    baseexp=defeated.pokemon.baseExp
    # Gain experience
    ispartic=0
    ispartic=1 if defeated.participants.include?(index)
    haveexpshare=(isConst?(thispoke.item,PBItems,:EXPSHARE) ||
                  isConst?(thispoke.itemInitial,PBItems,:EXPSHARE)) ? 1 : 0
    exp=0
    if expshare>0
      if partic==0 # No participants, all Exp goes to Exp Share holders
        exp=(level*baseexp).floor
        exp=(exp/(NOSPLITEXP ? 1 : expshare)).floor*haveexpshare
      else
        if NOSPLITEXP
          exp=(level*baseexp).floor*ispartic
          exp=(level*baseexp/2).floor*haveexpshare if ispartic==0
        else
          exp=(level*baseexp/2).floor
          exp=(exp/partic).floor*ispartic + (exp/expshare).floor*haveexpshare
        end
      end
    elsif ispartic==1
      if haveexpall
        exp=(level*baseexp/(NOSPLITEXP ? 1 : partic)).floor
      else
        exp=(level*baseexp/(NOSPLITEXP ? 1 : partic)).floor
      end
    elsif haveexpall
      exp=((level*baseexp)/3).floor
    end
    return if exp<=0
    exp=(exp*3/2).floor if @opponent
    if USENEWEXPFORMULA # Use new (Gen 5) Exp. formula
      exp=(exp/6).floor
      leveladjust=(2*level+10.0)/(level+thispoke.level+10.0)
      leveladjust=leveladjust**5
      leveladjust=Math.sqrt(leveladjust)
      exp=(exp*leveladjust).floor
      exp+=1 if ispartic>0 || haveexpshare>0 || haveexpall
    else                  # Use old (Gen 1-4) Exp. formula
      exp=(exp/7).floor
    end
    isOutsider=((thispoke.trainerID != self.pbPlayer.id && thispoke.trainerID != 0) ||
               (thispoke.language!=0 && thispoke.language!=self.pbPlayer.language))
    if isOutsider
      if thispoke.language!=0 && thispoke.language!=self.pbPlayer.language
        exp=(exp*1.5).floor
      else
        exp=(exp*1.2).floor
      end
    end
    exp=(exp*3/2).floor if isConst?(thispoke.item,PBItems,:LUCKYEGG) ||
                           isConst?(thispoke.itemInitial,PBItems,:LUCKYEGG)
    friendship_multiplier=[(thispoke.happiness/100.0),0.5].max
    exp=(exp*friendship_multiplier).floor
    growthrate=thispoke.growthrate
#### SARDINES - LevelLimiter - START
    result = LevelLimitExpGain(thispoke, exp)
    if result == -1
      exp = 0
    else
      exp = result
    end
#### SARDINES - LevelLimiter - END
    newexp=PBExperience.pbAddExperience(thispoke.exp,exp,growthrate)
    exp=newexp-thispoke.exp
    if exp>0
#### KUROTSUNE - 020 - START
      if isOutsider || isConst?(thispoke.item,PBItems,:LUCKYEGG)
#### KUROTSUNE - 020 - END
        pbDisplay(_INTL("{1} gained a boosted {2} Exp. Points!",thispoke.name,exp))
      elsif !(ispartic==0 && haveexpall)
        pbDisplay(_INTL("{1} gained {2} Exp. Points!",thispoke.name,exp))
      end
      newlevel=PBExperience.pbGetLevelFromExperience(newexp,growthrate)
      tempexp=0
      curlevel=thispoke.level
      if newlevel<curlevel
        debuginfo="#{thispoke.name}: #{thispoke.level}/#{newlevel} | #{thispoke.exp}/#{newexp} | gain: #{exp}"
        raise RuntimeError.new(_INTL("The new level ({1}) is less than the Pokémon's\r\ncurrent level ({2}), which shouldn't happen.\r\n[Debug: {3}]",
                               newlevel,curlevel,debuginfo))
        return
      end
      if thispoke.respond_to?("isShadow?") && thispoke.isShadow?
        thispoke.exp+=exp
      else
        tempexp1=thispoke.exp
        tempexp2=0
        # Find battler
        battler=pbFindPlayerBattler(index)
        loop do
          # EXP Bar animation
          startexp=PBExperience.pbGetStartExperience(curlevel,growthrate)
          endexp=PBExperience.pbGetStartExperience(curlevel+1,growthrate)
          tempexp2=(endexp<newexp) ? endexp : newexp
          thispoke.exp=tempexp2
          @scene.pbEXPBar(thispoke,battler,startexp,endexp,tempexp1,tempexp2)
          tempexp1=tempexp2
          curlevel+=1
          if curlevel>newlevel
            thispoke.calcStats
            battler.pbUpdate(false) if battler
            @scene.pbRefresh
            break
          end
          thispoke.poklevel = curlevel
          oldtotalhp=thispoke.totalhp
          oldattack=thispoke.attack
          olddefense=thispoke.defense
          oldspeed=thispoke.speed
          oldspatk=thispoke.spatk
          oldspdef=thispoke.spdef
          if battler && battler.pokemon && @internalbattle
            battler.pokemon.changeHappiness("level up",true)
          end
          thispoke.gainLevelEVs(curlevel-1)
          thispoke.calcStats
          battler.pbUpdate(false) if battler
          @scene.pbRefresh
          pbDisplayPaused(_INTL("{1} grew to Level {2}!",thispoke.name,curlevel))
          @scene.pbLevelUp(thispoke,battler,oldtotalhp,oldattack,
                           olddefense,oldspeed,oldspatk,oldspdef)
          # Finding all moves learned at this level
          movelist=thispoke.getMoveList
          for k in movelist
             if k[0]==thispoke.level   # Learned a new move
              pbLearnMove(index,k[1])
              thispoke.firstmoves.push(k[1])
            end
          end
        end
      end
    end
  end

################################################################################
# Learning a move.
################################################################################
  def pbLearnMove(pkmnIndex,move)
    pokemon=@party1[pkmnIndex]
    return if !pokemon
    move=PBMove.current_id(move)
    pkmnname=pokemon.name
    battler=pbFindPlayerBattler(pkmnIndex)
    movename=PBMoves.getName(move)
    for i in 0...4
      if pokemon.moves[i].id==move
        return
      end
      if pokemon.moves[i].id==0
        pokemon.moves[i]=PBMove.new(move)
        battler.moves[i]=PokeBattle_Move.pbFromPBMove(self,pokemon.moves[i],battler) if battler
        pbDisplayPaused(_INTL("{1} learned {2}!",pkmnname,movename))
        return
      end
    end
    loop do
      pbDisplayPaused(_INTL("{1} is trying to learn {2}.",pkmnname,movename))
      pbDisplayPaused(_INTL("But {1} can't learn more than four moves.",pkmnname))
      if pbDisplayConfirm(_INTL("Delete a move to make room for {1}?",movename))
        pbDisplayPaused(_INTL("Which move should be forgotten?"))
        forgetmove=@scene.pbForgetMove(pokemon,move)
        if forgetmove >=0
          oldmovename=PBMoves.getName(pokemon.moves[forgetmove].id)
          pokemon.moves[forgetmove]=PBMove.new(move) # Replaces current/total PP
          battler.moves[forgetmove]=PokeBattle_Move.pbFromPBMove(self,pokemon.moves[forgetmove],battler) if battler
          pbDisplayPaused(_INTL("1,  2, and... ... ..."))
          pbDisplayPaused(_INTL("Poof!"))
          pbDisplayPaused(_INTL("{1} forgot {2}.",pkmnname,oldmovename))
          pbDisplayPaused(_INTL("And..."))
          pbDisplayPaused(_INTL("{1} learned {2}!",pkmnname,movename))
          return
        elsif pbDisplayConfirm(_INTL("Should {1} stop learning {2}?",pkmnname,movename))
          pbDisplayPaused(_INTL("{1} did not learn {2}.",pkmnname,movename))
          return
        end
      elsif pbDisplayConfirm(_INTL("Should {1} stop learning {2}?",pkmnname,movename))
        pbDisplayPaused(_INTL("{1} did not learn {2}.",pkmnname,movename))
        return
      end
    end
  end

################################################################################
# Abilities.
################################################################################
  def pbOnActiveAll
    eachActiveBattlerIndex do |i| # Currently unfainted participants will earn EXP even if they faint afterwards
      @battlers[i].pbUpdateParticipants if pbIsOpposing?(i)
      @amuletcoin=true if !pbIsOpposing?(i) &&
                          (isConst?(@battlers[i].item,PBItems,:AMULETCOIN) ||
                           isConst?(@battlers[i].item,PBItems,:LUCKINCENSE))
    end
    eachActiveBattlerIndex do |i|
      if !@battlers[i].isFainted?
        if @battlers[i].isShadow? && pbIsOpposing?(i)
          pbCommonAnimation("Shadow",@battlers[i],nil)
          pbDisplay(_INTL("Oh!\nA Shadow Pokémon!"))
        end
      end
    end
    # Weather-inducing abilities, Trace, Imposter, etc.
    @usepriority=false
    priority=pbPriority
    for i in priority
      i.pbAbilitiesOnSwitchIn(true)
    end
    # Check forms are correct
    eachActiveBattlerIndex do |i|
      next if @battlers[i].isFainted?
      @battlers[i].pbCheckForm
    end
  end

  def pbBlink(battler)
    return false if !battler || battler.isFainted?
    party_index=battler.pokemonIndex
    return false if party_index<0
    return false if !pbRecallAndReplace(battler.index,party_index,false)
    battler.pbAbilitiesOnSwitchIn(true)
    return true
  end

  def pbOnActiveOne(pkmn,onlyabilities=false)
    return false if pkmn.isFainted?
    pkmn.effects[PBEffects::BlinkEntryTurn]=@turncount if !onlyabilities
    if !onlyabilities
      if pkmn.pbHasType?(:FIRE) && pkmn.pbOwnSide.effects[PBEffects::Bonfire]>0
        pkmn.pbOwnSide.effects[PBEffects::Bonfire]+=1
        pbDisplay(_INTL("{1} stoked its team's bonfire!",pkmn.pbThis))
      end
      eachActiveBattlerIndex do |i| # Currently unfainted participants will earn EXP even if they faint afterwards
        @battlers[i].pbUpdateParticipants if pbIsOpposing?(i)
        @amuletcoin=true if !pbIsOpposing?(i) &&
                            (isConst?(@battlers[i].item,PBItems,:AMULETCOIN) ||
                             isConst?(@battlers[i].item,PBItems,:LUCKINCENSE))
      end
      if pkmn.isShadow? && pbIsOpposing?(pkmn.index)
        pbCommonAnimation("Shadow",pkmn,nil)
        pbDisplay(_INTL("Oh!\nA Shadow Pokémon!"))
      end
      # Healing Wish
      if pkmn.effects[PBEffects::HealingWish]
        pkmn.pbRecoverHP(pkmn.totalhp,true)
        pkmn.status=0
        pkmn.statusCount=0
        pkmn.pbIncreaseStat(PBStats::ATTACK, 1, true) if $fefieldeffect == 31 || $fefieldeffect == 34
        pkmn.pbIncreaseStat(PBStats::SPATK, 1, true) if $fefieldeffect == 31 || $fefieldeffect == 34
        pbDisplayPaused(_INTL("The healing wish came true for {1}!",pkmn.pbThis(true)))
        pkmn.effects[PBEffects::HealingWish]=false
      end
      # Lunar Dance
      if pkmn.effects[PBEffects::LunarDance]
        pkmn.pbRecoverHP(pkmn.totalhp,true)
        pkmn.status=0
        pkmn.statusCount=0
        pkmn.pbIncreaseStat(PBStats::ATTACK, 1, true) if $fefieldeffect == 35 || $fefieldeffect == 34
        pkmn.pbIncreaseStat(PBStats::DEFENSE, 1, true) if $fefieldeffect == 35
        pkmn.pbIncreaseStat(PBStats::SPATK, 1, true) if $fefieldeffect == 35 || $fefieldeffect == 34
        pkmn.pbIncreaseStat(PBStats::SPDEF, 1, true) if $fefieldeffect == 35
        pkmn.pbIncreaseStat(PBStats::SPEED, 1, true) if $fefieldeffect == 35
        pkmn.pbIncreaseStat(PBStats::ACCURACY, 1, true) if $fefieldeffect == 35
        pkmn.pbIncreaseStat(PBStats::EVASION, 1, true) if $fefieldeffect == 35
        for i in 0...4
          pkmn.moves[i].pp=pkmn.moves[i].totalpp
        end
        pbDisplayPaused(_INTL("{1} became cloaked in mystical moonlight!",pkmn.pbThis))
        pkmn.effects[PBEffects::LunarDance]=false
      end
      # Z-Memento/Parting Shot
      if pkmn.effects[PBEffects::ZHeal]
        pkmn.pbRecoverHP(pkmn.totalhp,false)
        pbDisplayPaused(_INTL("The Z-Power healed {1}!",pkmn.pbThis(true)))
        pkmn.effects[PBEffects::ZHeal]=false
      end
      pbApplyEntryHazards(pkmn)
    end
    # Pre-paralyzed Pokemon in intense mode (Minerva's Ponyta-Galar)
    owner = pbGetOwner(pkmn.index) if pbIsOpposing?(pkmn.index)
    if !onlyabilities && pbIsOpposing?(pkmn.index) &&
       owner && owner.trainertype && isConst?(owner.trainertype,PBTrainers,:MINERVA) &&
       $game_variables && $game_variables[:Difficulty_Mode] == 2
      if isConst?(pkmn.species,PBSpecies,:PONYTA) && pkmn.form == 1 && pkmn.status == 0
        pkmn.status = PBStatuses::PARALYSIS
        pkmn.statusCount = 0
        pbDisplay(_INTL("{1} entered the battle paralyzed!",pkmn.pbThis))
      end
    end
    pkmn.pbAbilityCureCheck
    if pkmn.isFainted?
      pbGainEXP
      pbSwitch if @faintswitch
      return false
    end
    if !onlyabilities
      pkmn.pbCheckForm
      pkmn.pbBerryCureCheck
    end
    return true
  end

  def pbApplyEntryHazards(pkmn)
      # Spikes
      pkmn.pbOwnSide.effects[PBEffects::Spikes]=0 if $fefieldeffect == 21 ||
       $fefieldeffect == 26
      if pkmn.pbOwnSide.effects[PBEffects::Spikes]>0
        if !pkmn.isAirborne?
          if !pkmn.hasWorkingAbility(:MAGICGUARD) && !(pkmn.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS) && !pkmn.hasWorkingAbility(:LIMBER)
            spikesdiv=[8,8,6,4][pkmn.pbOwnSide.effects[PBEffects::Spikes]]
            @scene.pbDamageAnimation(pkmn,0)
            pkmn.pbReduceHP([(pkmn.totalhp/spikesdiv).floor,1].max)
            pbDisplay(_INTL("{1} was hurt by spikes!",pkmn.pbThis))
          end
        end
      end
      pkmn.pbFaint if pkmn.isFainted?
      side = pkmn.pbOwnSide
      battler = pkmn
      if side.effects[PBEffects::Undertow]>0 && !battler.isFainted? &&
         !battler.hasWorkingItem(:HEAVYDUTYBOOTS) && battler.pbCanCrush?(false)
        side.effects[PBEffects::Undertow]-=1
        battler.pbCrush(battler)
        pbDisplay(_INTL("{1} was crushed by the undertow!",battler.pbThis))
      end
      # Caltrops
      if pkmn.pbOwnSide.effects[PBEffects::Caltrops]>0 &&
         !pkmn.isAirborne? && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS) && !pkmn.hasWorkingAbility(:LIMBER)
        stacks = pkmn.pbOwnSide.effects[PBEffects::Caltrops]
        if pkmn.pbApplyGrievousWounds(stacks)
          @scene.pbDamageAnimation(pkmn,0)
          pbDisplay(_INTL("{1} was wounded by caltrops!",pkmn.pbThis))
        end
      end
      # Presents
      if side.effects[PBEffects::Presents] > 0 && !battler.isFainted? &&
         !pkmn.isAirborne? && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS)
        stacks = side.effects[PBEffects::Presents]
        heal_frac = battler.totalhp*stacks/3
        heal_frac = [heal_frac, battler.totalhp - battler.hp].min
        if heal_frac > 0
          battler.pbRecoverHP(heal_frac,true)
          pbDisplay(_INTL("{1} recovered health from the presents!",battler.pbThis))
          side.effects[PBEffects::Presents] = 0
        end
      end
      # Stealth Rock
      if pkmn.pbOwnSide.effects[PBEffects::StealthRock]
        if !pkmn.hasWorkingAbility(:MAGICGUARD) && !(pkmn.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS) && !pkmn.hasWorkingAbility(:LIMBER)
          atype=getConst(PBTypes,:ROCK) || 0
          if $fefieldeffect == 25
              randtype = pbRandom(4)
              case randtype
                when 0
                  atype=getConst(PBTypes,:WATER) || 0
                when 1
                  atype=getConst(PBTypes,:GRASS) || 0
                when 2
                  atype=getConst(PBTypes,:FIRE) || 0
                when 3
                  atype=getConst(PBTypes,:PSYCHIC) || 0
              end
          elsif $fefieldeffect == 7 || $fefieldeffect == 16 || $fefieldeffect == 32 || $fefieldeffect == 45
            atype=getConst(PBTypes,:FIRE) || 0
          elsif $fefieldeffect == 41
            atype=getConst(PBTypes,:POISON) || 0
          end
          eff=PBTypes.getCombinedEffectiveness(atype,pkmn.type1,pkmn.type2)
          if $fefieldeffect == 36
            tempeff = 16 if eff == 0
            tempeff = 16 if eff == 1
            tempeff = 8 if eff == 2
            tempeff = 4 if eff == 4
            tempeff = 2 if eff == 8
            tempeff= 1 if eff == 16
            eff = tempeff
          end
          if isConst?(pkmn.species,PBSpecies,:GLACEON) && pkmn.hasWorkingItem(:GLACCREST)
            eff = 2
          end
          if eff>0
            if $fefieldeffect == 14 || $fefieldeffect == 23 ||
             ($fefieldeffect == 32 && basefield == 23)
              eff = eff*2
            end
            @scene.pbDamageAnimation(pkmn,0)
            pkmn.pbReduceHP([(pkmn.totalhp*eff/32).floor,1].max)
            if $fefieldeffect == 25
              pbDisplay(_INTL("{1} was hurt by the crystalized stealth rocks!",pkmn.pbThis))
            else
              pbDisplay(_INTL("{1} was hurt by stealth rocks!",pkmn.pbThis))
            end
          end
        end
      end
      pkmn.pbFaint if pkmn.isFainted?
      # Corrosive Field Entry
      if $fefieldeffect == 10
        if !pkmn.hasWorkingAbility(:MAGICGUARD) &&
         !pkmn.hasWorkingAbility(:POISONHEAL) &&
         !pkmn.hasWorkingAbility(:IMMUNITY) &&
         !pkmn.hasWorkingAbility(:WONDERGUARD) &&
         !pkmn.hasWorkingAbility(:TOXICBOOST) &&
         !pkmn.hasWorkingAbility(:PASTELVEIL) &&
         (!pkmn.isbossmon || !pkmn.immunities[:fieldEffectDamage].include?($fefieldeffect))
          if !pkmn.isAirborne?
            if !pkmn.pbHasType?(:POISON) && !pkmn.pbHasType?(:STEEL)
              atype=getConst(PBTypes,:POISON) || 0
              eff=PBTypes.getCombinedEffectiveness(atype,pkmn.type1,pkmn.type2)
              if eff>0
                eff=eff*2
                @scene.pbDamageAnimation(pkmn,0)
                pkmn.pbReduceHP([(pkmn.totalhp*eff/32).floor,1].max)
                pbDisplay(_INTL("{1} was seared by the corrosion!",pkmn.pbThis))
              end
            end
          end
        end
      end
      pkmn.pbFaint if pkmn.hp<=0
      # Mystical Tree
      if pkmn.pbOwnSide.effects[PBEffects::MysticTree]>0
        if !pkmn.hasWorkingAbility(:MAGICGUARD) && !(pkmn.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS) && !pkmn.hasWorkingAbility(:LIMBER)
          atype=getConst(PBTypes,:GRASS) || 0
          eff=PBTypes.getCombinedEffectiveness(atype,pkmn.type1,pkmn.type2)
          if $fefieldeffect == 36
            tempeff = 16 if eff == 0
            tempeff = 16 if eff == 1
            tempeff = 8 if eff == 2
            tempeff = 4 if eff == 4
            tempeff = 2 if eff == 8
            tempeff = 1 if eff == 16
            eff = tempeff
          end
          if eff>0
            eff *= pkmn.pbOwnSide.effects[PBEffects::MysticTree] # No. of layers
            @scene.pbDamageAnimation(pkmn,0)
            pkmn.pbReduceHP([(pkmn.totalhp*eff/48).floor,1].max)
            pbDisplay(_INTL("{1} was hurt by the mystical trees!",pkmn.pbThis))
          end
        end
      end
      trees=pkmn.pbOpposingSide.effects[PBEffects::MysticTree]
      if trees>0 && !pkmn.isFainted? && pkmn.pbHasType?(:GRASS)
        recovered=pkmn.pbRecoverHP(pkmn.totalhp*trees/12,true)
        pbDisplay(_INTL("{1} was healed by the mystical trees!",pkmn.pbThis)) if recovered>0
      end
      # Scorching Ground
      if side.effects[PBEffects::ScorchingGround] > 0
        if !pkmn.isAirborne? && !pkmn.hasWorkingAbility(:LIMBER) &&
           !pkmn.hasWorkingAbility(:MAGICGUARD) &&
           !(pkmn.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          atype=getConst(PBTypes,:FIRE) || 0
          eff=PBTypes.getCombinedEffectiveness(atype,pkmn.type1,pkmn.type2)
          if eff>0
            @scene.pbDamageAnimation(pkmn,0)
            pkmn.pbReduceHP([(pkmn.totalhp*eff/48).floor,1].max)
            pbDisplay(_INTL("{1} was burned by the scorching ground!",pkmn.pbThis))
          end
        end
      end
      pkmn.pbFaint if pkmn.hp<=0
      # Sticky Web
      if pkmn.pbOwnSide.effects[PBEffects::StickyWeb]
        if !pkmn.isAirborne? && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS) && !pkmn.hasWorkingAbility(:LIMBER)
          pbDisplay(_INTL("{1} was caught in a sticky web!",pkmn.pbThis))
          pkmn.pbReduceStat(PBStats::SPEED, 1, true)
        end
      end
      # Poison Barbs (formerly Toxic Spikes)
      pkmn.pbOwnSide.effects[PBEffects::ToxicSpikes]=0 if $fefieldeffect == 21 ||
       $fefieldeffect == 26
      if (pkmn.pbOwnSide.effects[PBEffects::ToxicSpikes] || 0) > 0
        if !pkmn.isAirborne? && !pkmn.hasWorkingAbility(:LIMBER)
          if pkmn.pbHasType?(:POISON) && $fefieldeffect != 10
            pkmn.pbOwnSide.effects[PBEffects::ToxicSpikes]=0
            pbDisplay(_INTL("{1} absorbed the poison barbs!",pkmn.pbThis))
          elsif pkmn.pbCanPoisonSpikes? && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS)
            # Badly poison if weak to Poison-type
            poisonmod = PBTypes.getCombinedEffectiveness(PBTypes::POISON,pkmn.type1,pkmn.type2)
            if poisonmod > 4
              pkmn.pbPoison(pkmn,true)
              pbDisplay(_INTL("{1} was badly poisoned by the poison barbs!",pkmn.pbThis))
            else
              pkmn.pbPoison(pkmn)
              pbDisplay(_INTL("{1} was poisoned by the poison barbs!",pkmn.pbThis))
            end
          end
        end
      end
  end

################################################################################
# Judging.
################################################################################
  def pbJudgeCheckpoint(attacker,move=0)
  end

  def pbDecisionOnTime
    count1=0
    count2=0
    hptotal1=0
    hptotal2=0
    for i in @party1
      next if !i
      if i.hp>0 && !i.isEgg?
        count1+=1
        hptotal1+=i.hp
      end
    end
    for i in @party2
      next if !i
      if i.hp>0 && !i.isEgg?
        count2+=1
        hptotal2+=i.hp
      end
    end
    return 1 if count1>count2     # win
    return 2 if count1<count2     # loss
    return 1 if hptotal1>hptotal2 # win
    return 2 if hptotal1<hptotal2 # loss
    return 5                      # draw
  end

  def pbDecisionOnTime2
    count1=0
    count2=0
    hptotal1=0
    hptotal2=0
    for i in @party1
      next if !i
      if i.hp>0 && !i.isEgg?
        count1+=1
        hptotal1+=(i.hp*100/i.totalhp)
      end
    end
    hptotal1/=count1 if count1>0
    for i in @party2
      next if !i
      if i.hp>0 && !i.isEgg?
        count2+=1
        hptotal2+=(i.hp*100/i.totalhp)
      end
    end
    hptotal2/=count2 if count2>0
    return 1 if count1>count2     # win
    return 2 if count1<count2     # loss
    return 1 if hptotal1>hptotal2 # win
    return 2 if hptotal1<hptotal2 # loss
    return 5                      # draw
  end

  def pbDecisionOnDraw
    return 5 # draw
  end

  def pbJudge
#   PBDebug.log("[Counts: #{pbPokemonCount(@party1)}/#{pbPokemonCount(@party2)}]")
    # When partner control is enabled, continue battle if one trainer faints
    if $game_switches[2030] && @player.is_a?(Array)
      # Check if both player and partner are fainted
      playerFainted = pbTrainerAllFainted?(0)
      partnerFainted = pbTrainerAllFainted?(2)

      if playerFainted && partnerFainted && pbAllFainted?(@party2)
        @decision=pbDecisionOnDraw() # Draw
        return
      end
      if playerFainted && partnerFainted
        @decision=2 # Loss - both player and partner fainted
        return
      end
      if pbAllFainted?(@party2)
        @decision=1 # Win
        return
      end
      # Battle continues if only one trainer fainted
      return
    end

    # Original logic for non-partner battles
    if pbAllFainted?(@party1) && pbAllFainted?(@party2)
      @decision=pbDecisionOnDraw() # Draw
      return
    end
    if pbAllFainted?(@party1)
      @decision=2 # Loss
      return
    end
    if pbAllFainted?(@party2)
      @decision=1 # Win
      return
    end
  end

################################################################################
# Messages and animations.
################################################################################
  def pbApplySceneBG(sprite,filename)
    @scene.pbApplyBGSprite(sprite,filename)
  end

  def pbDisplay(msg)
    @scene.pbDisplayMessage(msg)
  end

  def pbDisplayPaused(msg)
    @scene.pbDisplayPausedMessage(msg)
  end

  def pbDisplayBrief(msg)
    @scene.pbDisplayMessage(msg,true)
  end

  def pbDisplayConfirm(msg)
    @scene.pbDisplayConfirmMessage(msg)
  end

  def pbShowCommands(msg,commands,cancancel=true)
    @scene.pbShowCommands(msg,commands,cancancel)
  end

  def pbAnimation(move,attacker,opponent,hitnum=0)
    if @battlescene
      @scene.pbAnimation(move,attacker,opponent,hitnum)
    end
  end

  def pbCommonAnimation(name,attacker=nil,opponent=nil,hitnum=0)
    if @battlescene
      @scene.pbCommonAnimation(name,attacker,opponent,hitnum)
    end
  end

  def pbRestoreFieldBack
    if !($febackgroundstore.is_a?(String)) && !($febackgroundstore.nil?)
        #    $fefieldeffect = $feoverride
      if $febackgroundstore == 1
        backdrop="Electric"
      elsif $febackgroundstore == 2
        backdrop="Grassy"
      elsif $febackgroundstore == 3
        backdrop="Misty"
      elsif $febackgroundstore == 4
        backdrop="DarkCrystalCavern"
      elsif $febackgroundstore == 5
        backdrop="Chess"
      elsif $febackgroundstore == 6
        backdrop="BigTop"
      elsif $febackgroundstore == 7
        backdrop="Burning"
      elsif $febackgroundstore == 8
        backdrop="Swamp"
      elsif $febackgroundstore == 9
        backdrop="Rainbow"
      elsif $febackgroundstore == 10
        backdrop="Corrosive"
      elsif $febackgroundstore == 11
        backdrop="CorrosiveMist"
      elsif $febackgroundstore == 12
        backdrop="Desert"
      elsif $febackgroundstore == 13
        backdrop="Icy"
      elsif $febackgroundstore == 14
        backdrop="Rocky"
      elsif $febackgroundstore == 15
        backdrop="Forest"
      elsif $febackgroundstore == 16
        backdrop="Superheated"
      elsif $febackgroundstore == 17
        backdrop="Factory"
      elsif $febackgroundstore == 18
        backdrop="Shortcircuit"
      elsif $febackgroundstore == 19
        backdrop="Wasteland"
      elsif $febackgroundstore == 20
        backdrop="AshenBeach"
      elsif $febackgroundstore == 21
        backdrop="Water"
      elsif $febackgroundstore == 22
        backdrop="Underwater"
      elsif $febackgroundstore == 23
        backdrop="Cave"
      elsif $febackgroundstore == 24
        backdrop="Glitch"
      elsif $febackgroundstore == 25
        backdrop="CrystalCavern"
      elsif $febackgroundstore == 26
        if $game_map.map_id==415
          backdrop="Water2"
        else
          backdrop = "MurkwaterSurface"
        end
      elsif $febackgroundstore == 27
        backdrop="Mountain"
      elsif $febackgroundstore == 28
        backdrop="SnowyMountain"
      elsif $febackgroundstore == 29
        backdrop="Holy"
      elsif $febackgroundstore == 30
        backdrop="Mirror"
      elsif $febackgroundstore == 31
        backdrop="FairyTale"
      elsif $febackgroundstore == 32
        backdrop="DragonsDen"
      elsif $febackgroundstore == 33
        backdrop="FlowerGarden0"
      elsif $febackgroundstore == 34
        backdrop="Starlight1"
      elsif $febackgroundstore == 35
        backdrop="NewWorld"
      elsif $febackgroundstore == 36
        backdrop="Inverse"
      elsif $febackgroundstore == 37
        backdrop="Psychic"
      elsif $febackgroundstore == 38
        backdrop="Dimensional"
      elsif $febackgroundstore == 39
        backdrop="Angie"
      elsif $febackgroundstore == 40
        backdrop="Haunted"
      elsif $febackgroundstore == 41
        backdrop="Corrupted"
      elsif $febackgroundstore == 42
        backdrop="Darchlight"
      elsif $febackgroundstore == 43
        backdrop="GoldenArena"
      elsif $febackgroundstore == 44
        backdrop="ColosseumFieldPlaceholder"
      elsif $febackgroundstore == 45
        backdrop="InfernalFieldPlaceholder"
      elsif $febackgroundstore == 46
        backdrop="Beach"
      elsif $febackgroundstore == 47
        backdrop="Library"
      end
      backdrop ||= $febackup.is_a?(String) && !$febackup.empty? ? $febackup : "IndoorA"
      backdrop3 = backdrop
      $febackgroundstore = backdrop3
    else
      if !($febackgroundstore.nil?)
        backdrop=$febackgroundstore
      else
        backdrop=$febackup
        return pbChangeBGSprite
      end
    end
    battlebg,enemybase,playerbase=AzureBattlebackGraphics.paths(backdrop,environment)
    pbApplySceneBG("battlebg",battlebg)
    pbApplySceneBG("enemybase",enemybase)
    pbApplySceneBG("playerbase",playerbase)
  end

  def pbChangeBGSprite
        case $fefieldeffect
          when 0 # indoor
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgIndoorA.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseIndoorA.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseIndoorA.png")
          when 1 # electric
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgElectric.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseElectric.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseElectric.png")
          when 2 # grassy
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgGrassy.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseGrassy.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseGrassy.png")
          when 3 # misty
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgMisty.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseMisty.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseMisty.png")
          when 4 # dark crystal cavern
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgDarkCrystalCavern.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseDarkCrystalCavern.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseDarkCrystalCavern.png")
          when 5 # chess
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgChess.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseChess.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseChess.png")
          when 6 # bigtop
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgBigtop.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseBigtop.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseBigtop.png")
          when 7 # burning
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgVolcano.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseVolcano.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseVolcano.png")
          when 8 # swamp
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgSwamp.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseSwamp.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseSwamp.png")
          when 9 # rainbow
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgRainbow.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseRainbow.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseRainbow.png")
          when 10 # corrosive
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgPoison.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbasePoison.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybasePoison.png")
          when 11 # corrosive mist
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgCorrosiveMist.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseCorrosiveMist.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseCorrosiveMist.png")
          when 12 # desert
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgDesert.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseDesert.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseDesert.png")
          when 13 # icy
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgIcy.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseIcy.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseIcy.png")
          when 14 # rocky
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgRocky.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseRocky.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseRocky.png")
          when 15 # forest
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgForest.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseForest.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseForest.png")
          when 16 # superheated
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgVoltop.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseVoltop.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseVoltop.png")
          when 17 # factory
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgFactory.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseFactory.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseFactory.png")
          when 18 # short-circuit
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgShortcircuit.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseShortcircuit.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseShortcircuit.png")
          when 19 # wasteland
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgWasteland.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseWasteland.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseWasteland.png")
          when 20 # ashen beach
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgAshenBeach.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseAshenBeach.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseAshenBeach.png")
          when 21 # water surface
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgWater.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseWater.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseWater.png")
          when 22 # underwater
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgUnderwater.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseUnderwater.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseUnderwater.png")
          when 23 # cave
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgCave.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseCave.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseCave.png")
          when 24 # glitch
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgGlitch.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseGlitch.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseGlitch.png")
          when 25 # crystal cavern
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgAmethystCave.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseAmethystCave.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseAmethystCave.png")
          when 26 # murkwater surface
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgWater2.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseWater2.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseWater2.png")
          when 27 # mountain
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgMountain.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseMountain.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseMountain.png")
          when 28 # snowymountain
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgSnowyMountain.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseSnowyMountain.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseSnowyMountain.png")
          when 29 # holy
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgRuin.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseRuin.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseRuin.png")
          when 30 # mirror
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgMirror.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseMirror.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseMirror.png")
          when 31 # fairy tale
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgFairyTale.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseFairyTale.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseFairyTale.png")
          when 32 # dragons den
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgDragonsDen.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseDragonsDen.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseDragonsDen.png")
          when 33 # flower garden
            case $fecounter
              when 0
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgFlowerGarden0.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseFlowerGarden0.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseFlowerGarden0.png")
              when 1
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgFlowerGarden1.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseFlowerGarden1.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseFlowerGarden1.png")
              when 2
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgFlowerGarden2.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseFlowerGarden2.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseFlowerGarden2.png")
              when 3
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgFlowerGarden3.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseFlowerGarden3.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseFlowerGarden3.png")
              when 4
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgFlowerGarden4.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseFlowerGarden4.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseFlowerGarden4.png")
            end
          when 34 # starlight field
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgStarlight1.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseStarlight1.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseStarlight1.png")
          when 35 # new world
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgNewWorld.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseNewWorld.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseNewWorld.png")
          when 36 # inverse
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgInverse.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseInverse.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseInverse.png")
          when 37 # psychic
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgPsychic.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbasePsychic.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybasePsychic.png")
          when 38 # indoorA
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgDimensional.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseIndoorB.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseIndoorB.png")
          when 39 # indoorB
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgAngie.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseAngie.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseAngie.png")
          when 40 # Haunted
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgHaunted.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseHaunted.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseHaunted.png")
          when 41 # Corrupted Cave
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgCorrupted.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseCorrupted.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseCorrupted.png")
          when 42 # Darchlight Woods
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgDarchlight.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseDarchlight.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseDarchlight.png")
          when 43 # sky field
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgGoldenArena.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseGoldenArena.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseGoldenArena.png")
          when 44 # colosseum field
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgGoldenArena.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseGoldenArena.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseGoldenArena.png")
          when 45 # infernal field
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebgGoldenArena.png")
                pbApplySceneBG("playerbase","Graphics/Battlebacks/playerbaseGoldenArena.png")
                pbApplySceneBG("enemybase","Graphics/Battlebacks/enemybaseGoldenArena.png")
          when 46,47 # These backgrounds include their ground without separate bases.
                backdrop=$fefieldeffect==46 ? "Beach" : "Library"
                pbApplySceneBG("battlebg","Graphics/Battlebacks/battlebg#{backdrop}.png")
                pbApplySceneBG("playerbase",nil)
                pbApplySceneBG("enemybase",nil)
  end
 end

################################################################################
# Battle core.
################################################################################

def pbStartBattle(canlose=false)
    begin
      pbStartBattleCore(canlose)
    rescue BattleAbortedException
      @decision=0
      @scene.pbEndBattle(@decision)
    end
    return @decision
  end

  def pbStartBattleCore(canlose)
    if !@fullparty1 && @party1.length>MAXPARTYSIZE
      raise ArgumentError.new(_INTL("Party 1 has more than {1} Pokémon.",MAXPARTYSIZE))
    end
    if !@fullparty2 && @party2.length>MAXPARTYSIZE+10
      raise ArgumentError.new(_INTL("Party 2 has more than {1} Pokémon.",MAXPARTYSIZE))
    end
    if !@opponent
#========================
# Initialize wild PokÃ©mon
#========================
      if @party2.length==1
        if pbSideSize(1)>1 && !$game_switches[1998]
          raise _INTL("Only two wild Pokémon are allowed in double battles")
        end
        wildpoke=@party2[0]
        @battlers[1].pbInitialize(wildpoke,0,false)
        @peer.pbOnEnteringBattle(self,wildpoke)
        pbSetSeen(wildpoke)
        @scene.pbStartBattle(self)
        pbDisplayPaused(_INTL("Wild {1} appeared!",wildpoke.name)) if ($game_switches[1998]==false) && ($game_switches[290] == false)
        if ($game_switches[1998] == true) || ($game_switches[290] == true)
           if wildpoke.name == "Kyogre"
              pbDisplayPaused(_INTL("Ancient Leviathan {1} attacked!",wildpoke.name))
           elsif wildpoke.name == "Giratina"
            pbDisplayPaused(_INTL("The Anachronism attacked!",wildpoke.name))
          elsif wildpoke.name == "Regirock"
            pbDisplayPaused(_INTL("Guardian Soldier {1} attacked!",wildpoke.name))
          elsif wildpoke.name == "Gardevoir"
            pbDisplayPaused(_INTL("Angel of Death {1} attacked!",wildpoke.name))
          elsif wildpoke.name == "Hippowdon"
            pbDisplayPaused(_INTL("{1} is waiting...",wildpoke.name))
          else
            pbDisplayPaused(_INTL("{1} attacked!",wildpoke.name))
          end
        end
        # Call boss entry effects after scene is initialized
        if @battlers[1].isbossmon && @battlers[1].onEntryEffects
          pbShieldEffects(@battlers[1],@battlers[1].onEntryEffects,true)
        end
      elsif @party2.length==2
        if singleBattle?
          raise _INTL("Only one wild Pokémon is allowed in single battles")
        end
        @battlers[1].pbInitialize(@party2[0],0,false)
        @battlers[3].pbInitialize(@party2[1],1,false)
        @peer.pbOnEnteringBattle(self,@party2[0])
        @peer.pbOnEnteringBattle(self,@party2[1])
        pbSetSeen(@party2[0])
        pbSetSeen(@party2[1])
        @scene.pbStartBattle(self)
        pbDisplayPaused(_INTL("Wild {1} and\r\n{2} appeared!",
           @party2[0].name,@party2[1].name))
        # Call boss entry effects after scene is initialized
        if @battlers[1].isbossmon && @battlers[1].onEntryEffects
          pbShieldEffects(@battlers[1],@battlers[1].onEntryEffects,true)
        end
        if @battlers[3].isbossmon && @battlers[3].onEntryEffects
          pbShieldEffects(@battlers[3],@battlers[3].onEntryEffects,true)
        end
      else
        raise _INTL("Only one or two wild Pokémon are allowed")
      end
    elsif @opponent
#=======================================
# Initialize opponents in double battles
#=======================================
      if @opponent.is_a?(Array)
        if @opponent.length==1
          @opponent=@opponent[0]
        elsif @opponent.length>2
          raise _INTL("Opponents with zero or more than two people are not allowed")
        end
      end
      if @player.is_a?(Array)
        if @player.length==1
          @player=@player[0]
        elsif @player.length>2
          raise _INTL("Player trainers with zero or more than two people are not allowed")
        end
      end
      @scene.pbStartBattle(self)
      if @opponent.is_a?(Array) && @opponent.length>=2
        pbDisplayBrief(_INTL("{1} and {2} want to battle!",@opponent[0].fullname,@opponent[1].fullname))
      else
        pbDisplayBrief(_INTL("{1}\r\nwould like to battle!",@opponent.fullname))
      end
      foeSendouts = pbPrepareTrainerSideSendOuts(true)
      foeSendouts.each do |battlerIndex,partyIndex,owner|
        ownerName = (owner && owner.respond_to?(:fullname)) ? owner.fullname : @opponent.fullname
        pbDisplayBrief(_INTL("{1} sent\r\nout {2}!",ownerName,@battlers[battlerIndex].name))
        pbSendOut(battlerIndex,@party2[partyIndex])
      end
    else
#======================================
# Initialize opponent in single battles
#======================================
      sendout=pbFindNextUnfainted(@party2,0)
      raise _INTL("Trainer has no unfainted Pokémon") if sendout<0
      if @opponent.is_a?(Array)
        raise _INTL("Opponent trainer must be only one person in single battles") if @opponent.length!=1
        @opponent=@opponent[0]
      end
      if @player.is_a?(Array)
        raise _INTL("Player trainer must be only one person in single battles") if @player.length!=1
        @player=@player[0]
      end
      trainerpoke=@party2[sendout]
      @scene.pbStartBattle(self)
      pbDisplayBrief(_INTL("{1}\r\nwould like to battle!",@opponent.fullname))
#### JERICHO - 001 - START
      @battlers[1].pbInitialize(trainerpoke,sendout,false) #ILLUSION
      pbDisplayBrief(_INTL("{1} sent\r\nout {2}!",@opponent.fullname,PBSpecies.getName(@battlers[1].species)))
#### JERICHO - 001 - END
      pbSendOut(1,trainerpoke)
    end
#=====================================
# Initialize players in double battles
#=====================================
    for i in @party1
      if i!=nil && isConst?(i.species,PBSpecies,:ZANGOOSE) && isConst?(i.item,PBItems,:ZANGCREST)
        if i.status==0
          i.status=PBStatuses::POISON
        end
      end
    end

    playerSendouts = pbPrepareTrainerSideSendOuts(false)
    playerSendouts.each do |battlerIndex,partyIndex,owner|
      if @player.is_a?(Array) && owner && owner!=@player[0]
        pbDisplayBrief(_INTL("{1} sent\r\nout {2}!",owner.fullname,@battlers[battlerIndex].name))
      else
        pbDisplayBrief(_INTL("Go! {1}!",@battlers[battlerIndex].name))
      end
      pbSendOut(battlerIndex,@party1[partyIndex])
    end
#==================
# Initialize battle
#==================
    if @weather==PBWeather::SUNNYDAY
      pbCommonAnimation("Sunny",nil,nil)
      pbDisplay(_INTL("The sunlight is strong."))
      #### DemICE - persistentweather - START
      @weatherbackup=PBWeather::SUNNYDAY
      @weatherbackupanim="Sunny"
      #### DemICE
    elsif @weather==PBWeather::RAINDANCE
      pbCommonAnimation("Rain",nil,nil)
      pbDisplay(_INTL("It is raining."))
      #### DemICE - persistentweather - START
      @weatherbackup=PBWeather::RAINDANCE
      @weatherbackupanim="Rain"
      #### DemICE
    elsif @weather==PBWeather::SANDSTORM
      pbCommonAnimation("Sandstorm",nil,nil)
      pbDisplay(_INTL("A sandstorm is raging."))
      #### DemICE - persistentweather - START
      @weatherbackup=PBWeather::SANDSTORM
      @weatherbackupanim="Sandstorm"
      #### DemICE
    elsif @weather==PBWeather::HAIL
      pbCommonAnimation("Hail",nil,nil)
      pbDisplay(_INTL("Hail is falling."))
      #### DemICE - persistentweather - START
      @weatherbackup=PBWeather::HAIL
      @weatherbackupanim="Hail"
      #### DemICE
    elsif @weather==PBWeather::STRONGWINDS
      pbDisplay(_INTL("The wind is strong."))
      #### DemICE - persistentweather - START
      @weatherbackup=PBWeather::STRONGWINDS
      @weatherbackupanim="Wind"
      #### DemICE
    end
   # Field Effects BEGIN UPDATE
   case $fefieldeffect
     when 1
      pbDisplay(_INTL("The field is hyper-charged!"))
     when 2
      pbDisplay(_INTL("The field is in full bloom."))
     when 3
      pbDisplay(_INTL("Mist settles on the field."))
     when 4
      pbDisplay(_INTL("Darkness is gathering..."))
     when 5
      pbDisplay(_INTL("Opening variation set."))
     when 6
      pbDisplay(_INTL("Now presenting...!"))
     when 7
      pbDisplay(_INTL("The heat is intense!"))
     when 8
      pbDisplay(_INTL("The field is swamped."))
     when 9
      pbDisplay(_INTL("What does it mean?"))
     when 10
      pbDisplay(_INTL("The field is corrupted!"))
     when 11
      pbDisplay(_INTL("Corrosive mist settles on the field!"))
     when 12
      pbDisplay(_INTL("The field is rife with sand."))
     when 13
      pbDisplay(_INTL("The field is covered in ice."))
     when 14
      pbDisplay(_INTL("The field is littered with rocks."))
     when 15
      pbDisplay(_INTL("Trees fill the arena!"))
     when 16
      pbDisplay(_INTL("The volcanic field's heat is intense!"))
     when 17
      pbDisplay(_INTL("Machines whir in the background."))
     when 18
      pbDisplay(_INTL("Bzzt!"))
     when 19
      pbDisplay(_INTL("The field is poisonous!"))
     when 20
      pbDisplay(_INTL("Ash and sand line the field."))
     when 21
      pbDisplay(_INTL("The water's surface is calm."))
     when 22
      pbDisplay(_INTL("Blub blub..."))
     when 23
      pbDisplay(_INTL("The cave echoes dully..."))
     when 24
      pbDisplay(_INTL("1n!taliz3 .b//////attl3"))
     when 25
      pbDisplay(_INTL("The cave is littered with crystals."))
     when 26
      pbDisplay(_INTL("The water is tainted..."))
     when 27
      pbDisplay(_INTL("High up!"))
     when 28
      pbDisplay(_INTL("The snow glows white on the mountain..."))
     when 29
      pbDisplay(_INTL("The field is blessed!"))
     when 30
      pbDisplay(_INTL("Mirrors are laid around the field!"))
     when 31
      pbDisplay(_INTL("Once upon a time..."))
     when 32
      pbDisplay(_INTL("If you wish to slay a dragon..."))
     when 33
      pbDisplay(_INTL("Seeds line the field."))
     when 34
      pbDisplay(_INTL("Starlight fills the battlefield."))
      eachActiveBattlerIndex do |i|
        if @battlers[i].hasWorkingAbility(:WORLDOFNIGHTMARES)
          pbDisplay(_INTL("The dawn of a New World shines down upon the broken land."))
          break
        end
      end
     when 35
      pbDisplay(_INTL("From darkness, from stardust,"))
      pbDisplay(_INTL("From memories of eons past and visions yet to come..."))
     when 36
      pbDisplay(_INTL("!trats elttaB"))
     when 37
      pbDisplay(_INTL("The field became mysterious!"))
     when 38
      pbDisplay(_INTL("Darkness radiates."))
     when 39
      pbDisplay(_INTL("Hate and anger radiates."))
     when 40
      pbDisplay(_INTL("The field is cursed!"))
     when 41
      pbDisplay(_INTL("Corruption seeps from every crevice!"))
     when 42
      pbDisplay(_INTL("Double, double toil and trouble..."))
     when 43
      pbDisplay(_INTL("The sky is filled with clouds."))
     when 44
      pbDisplay(_INTL("All eyes are on the combatants!"))
     when 45
      pbDisplay(_INTL("The souls of the damned burn on."))
     when 46
      pbDisplay(_INTL("The waves lap at the shore."))
	 when 47
      pbDisplay(_INTL("Pages flutter around!"))
    end
    if ($game_variables[702] == 1) || ($game_variables[702] == 4) ### Azery - Auto Perma TR switch.
      @trickroom=8
      for i in @battlers
        pbAnimation(499,i,nil)
        break
      end
      if $game_variables[646] == 87
         pbDisplay(_INTL("The Puppet Master's distortion has twisted the dimensions!"))
      else
         pbDisplay(_INTL("The dimensions have been twisted! Trick Room is active."))
      end
    elsif $game_variables[702] == 2 || ($game_variables[702] == 4) ### Azery - Auto Perma WR switch.
      @field.effects[PBEffects::WonderRoom]=8
      for i in @battlers
        pbAnimation(500,i,nil)
        pbDisplay(_INTL("The dimensions have been twisted! Wonder Room is active."))
        break
      end
    elsif $game_variables[702] == 3 || ($game_variables[702] == 5) ### Azery - Auto Perma WR switch.
      @field.effects[PBEffects::MagicRoom]=8
      for i in @battlers
        pbAnimation(485,i,nil)
        pbDisplay(_INTL("The dimensions have been twisted! Magic Room is active."))
        break
      end
    end
  # END OF UPDATE
    pbOnActiveAll   # Abilities
    @turncount=0
    if !opponent
      PBDebug.log("==============================") if $INTERNAL
      PBDebug.log("Battle Start!") if $INTERNAL
      PBDebug.log("Wild Battle") if $INTERNAL
      PBDebug.log("==============================") if $INTERNAL
    else
      PBDebug.log("==============================") if $INTERNAL
      PBDebug.log("Battle Start!") if $INTERNAL
      if @opponent.is_a?(Array)
        PBDebug.log("#{@opponent[0].trainertype} - #{@opponent[0].name}") if $INTERNAL
        PBDebug.log("#{@opponent[1].trainertype} - #{@opponent[1].name}") if $INTERNAL
      else
        PBDebug.log("#{@opponent.trainertype} - #{@opponent.name}") if $INTERNAL
      end
      #PBDebug.log("#{@opponent.trainertype} - #{@opponent.name}") if $INTERNAL
      PBDebug.log("==============================") if $INTERNAL
    end

    loop do   # Now begin the battle loop
      PBDebug.log("***Round #{@turncount+1}***") if $INTERNAL
      if @debug && @turncount>=100
        @decision=pbDecisionOnTime()
        PBDebug.log("***[Undecided after 100 rounds]")
        pbAbort
        break
      end
      PBDebug.logonerr{
         pbCommandPhase
      }
      break if @decision>0
      #CP_Profiler.print
      #$aitime = Time.now - $aitime
      #print $aitime
      #$aitime = nil
      PBDebug.logonerr{
         pbAttackPhase
      }
      break if @decision>0
      PBDebug.logonerr{
         pbEndOfRoundWithStall
      }
      break if @decision>0
      @turncount+=1
    end
    return pbEndOfBattle(canlose)
  end

################################################################################
# Command phase.
################################################################################
  def pbCommandMenu(i)
    return @scene.pbCommandMenu(i)
  end

  def pbItemMenu(i)
    return @scene.pbItemMenu(i)
  end

  def pbAutoFightMenu(i)
    return false
  end

  def pbCommandPhase
    @scene.pbBeginCommandPhase
    # Clear AI move score cache to avoid stale data between turns
    @aiMoveScoreCache = {}
    # Clear AI priority damage cache (stores pre-calculated priority damage for each attacker)
    @aiPriorityCache = {}
    # Clear AI mega evolution decision cache (stores pbEnemyShouldMegaEvolve results per battler)
    @aiMegaEvolveCache = {}
    # Clear AI damage cache (stores checkAIdamage results per attacker/defender pair)
    @aiDamageCache = {}
#### SARDINES - v17 - START
#    @scene.pbResetCommandIndices
#### SARDINES - v17 - END
    pbCommandPhaseBattlers.each do |i|   # Reset choices if commands can be shown
      if pbCanShowCommands?(i) || @battlers[i].isFainted?
        @battlers[i].pbDisableTributeDraco if @battlers[i].tributeDracoActive
        @battlers[i].effects[PBEffects::Attacking]=false
        @choices[i][0]=0
        @choices[i][1]=0
        @choices[i][2]=nil
        @choices[i][3]=-1
      else
        battler=@battlers[i]
        unless singleBattle? && pbIsDoubleBattler?(i)
          PBDebug.log("[reusing commands for #{battler.pbThis(true)}]") if $INTERNAL
        end
      end
    end
#### KUROTSUNE - 015 - START
    $randtype=0
    for i in 0...@battlers.length
      @switchedOut[i] = false
    end
#### KUROTSUNE - 015 - END
    # Reset choices to perform Mega Evolution/Z-Moves if it wasn't done somehow
    for i in 0...@megaEvolution[0].length
      @megaEvolution[0][i]=-1 if @megaEvolution[0][i]>=0
    end
    for i in 0...@megaEvolution[1].length
      @megaEvolution[1][i]=-1 if @megaEvolution[1][i]>=0
    end
    for i in 0...@zMove[0].length
      @zMove[0][i]=-1 if @zMove[0][i]>=0
    end
    for i in 0...@zMove[1].length
      @zMove[1][i]=-1 if @zMove[1][i]>=0
    end
    if @field.effects[PBEffects::WonderRoom]>0
      @battlers.each { |battler| battler.pbSwapDefenses if !battler.wonderroom }
    end
    pbAIPrepareTurnCoordination if @decision==0
    pbCommandPhaseBattlers.each do |i|
      break if @decision!=0
      next if @choices[i][0]!=0
      if !pbOwnedByPlayer?(i) || @controlPlayer
        #CP_Profiler.begin if !$aitime
        $aitime = Time.now if !$aitime
        if !@battlers[i].isFainted? && pbCanShowCommands?(i)
          @scene.pbChooseEnemyCommand(i)
        end
      else
        commandDone=false
        commandEnd=false
        if pbCanShowCommands?(i)
          loop do
            cmd=pbCommandMenu(i)
            if cmd==0 # Fight
              if pbCanShowFightMenu?(i)
                commandDone=true if pbAutoFightMenu(i)
                until commandDone
                  index=@scene.pbFightMenu(i)
                  if index<0
                    side=(pbIsOpposing?(i)) ? 1 : 0
                    owner=pbGetOwnerIndex(i)
                    if @megaEvolution[side][owner]==i
                      @megaEvolution[side][owner]=-1
                    end
                    if @zMove[side][owner]==i
                      @zMove[side][owner]=-1
                    end
                    break
                  end
                  if @battlers[i].moves[index].basedamage>0
                    @battlers[i].effects[PBEffects::Attacking]=true
                  end
                  next if !pbRegisterMove(i,index)
                  thismove=@battlers[i].moves[index]
                  target=@battlers[i].pbTarget(thismove)
                  if singleBattle? && [PBTargets::SingleNonUser,PBTargets::SingleOpposing,
                      PBTargets::AllOpposing,PBTargets::AllNonUsers].include?(target)
                    @battlers[i].effects[PBEffects::AttackingTarget].push(@battlers[i].pbOppositeOpposing.index)
                  end
                  if thismove.id==PBMoves::MINIMIZE
                    target=@scene.pbChooseTarget(i)
                    next if target<0
                    pbRegisterTarget(i,target)
                  elsif !singleBattle?
                    if [PBTargets::SingleNonUser,PBTargets::SingleOpposing,PBTargets::Partner].include?(target)
                      target=@scene.pbChooseTarget(i)
                      next if target<0
                      pbRegisterTarget(i,target)
                      @battlers[i].effects[PBEffects::AttackingTarget].push(target)
                    elsif target==PBTargets::UserOrPartner # Acupressure
                      target=@scene.pbChooseTargetAcupressure(i)
                      next if target<0 || (target&1)!=(i&1)
                      pbRegisterTarget(i,target)
                    elsif target==PBTargets::AllOpposing
                      eachOtherSideBattler(i) do |battler|
                        next if battler.isFainted? || !pbMoveCanTargetInTriple?(@battlers[i],battler,thismove)
                        @battlers[i].effects[PBEffects::AttackingTarget].push(battler.index)
                      end
                    elsif target==PBTargets::AllNonUsers
                      eachOtherSideBattler(i) do |battler|
                        next if battler.isFainted? || !pbMoveCanTargetInTriple?(@battlers[i],battler,thismove)
                        @battlers[i].effects[PBEffects::AttackingTarget].push(battler.index)
                      end
                      eachSameSideBattler(i) do |battler|
                        next if battler.index==i || battler.isFainted? ||
                          !pbMoveCanTargetInTriple?(@battlers[i],battler,thismove)
                        @battlers[i].effects[PBEffects::AttackingTarget].push(battler.index)
                      end
                    end
                  end
                  commandDone=true
                end
              else
                pbAutoChooseMove(i)
                commandDone=true
              end
            elsif cmd==1 # Bag
              if (!@internalbattle || $game_variables[646]==65 && $game_variables[200]!=1)
                if pbOwnedByPlayer?(i)
                  pbDisplay(_INTL("Items can't be used here."))
                end
              else
                item=pbItemMenu(i)
                if item[0]>0 && pbRegisterItem(i,item[0],item[1],item[2])
                  pbConsumeItemInBattle($PokemonBag,item[0])
                  pbCleanupItemBelt
                  commandDone=true
                end
              end
            elsif cmd==2 # PokÃ©mon
              pkmn=pbSwitchPlayer(i,false,true)
              if pbShiftSelection?(pkmn)
                shiftTarget=pbDecodeShiftSelection(pkmn)
                if pbRegisterShift(i,shiftTarget)
                  commandDone=true
                end
              elsif pkmn>=0
                if pbRegisterSwitch(i,pkmn)
                  commandDone=true
                end
              end
            elsif cmd==3   # Run
              run=pbRun(i)
              if run>0
                commandDone=true
                return
              elsif run<0
                commandDone=true
                side=(pbIsOpposing?(i)) ? 1 : 0
                owner=pbGetOwnerIndex(i)
                if @megaEvolution[side][owner]==i
                  @megaEvolution[side][owner]=-1
                end
                if @zMove[side][owner]==i
                  @zMove[side][owner]=-1
                end
              end
            elsif cmd==4   # Call
              thispkmn=@battlers[i]
              @choices[i][0]=4   # "Call PokÃ©mon"
              @choices[i][1]=0
              @choices[i][2]=nil
              side=(pbIsOpposing?(i)) ? 1 : 0
              owner=pbGetOwnerIndex(i)
              if @megaEvolution[side][owner]==i
                @megaEvolution[side][owner]=-1
              end
              @battlers[i].effects[PBEffects::Attacking]=false
              if @zMove[side][owner]==i
                @zMove[side][owner]=-1
              end
              commandDone=true
            elsif cmd==-1   # Go back to first battler's choice
              @battlers[i].effects[PBEffects::Attacking]=false
              @battlers[i].effects[PBEffects::AttackingTarget].clear
              for side in 0...@megaEvolution.length
                for owner in 0...@megaEvolution[side].length
                  @megaEvolution[side][owner]=-1 if @megaEvolution[side][owner]>=0
                end
              end
              for side in 0...@zMove.length
                for owner in 0...@zMove[side].length
                  @zMove[side][owner]=-1 if @zMove[side][owner]>=0
                end
              end
              # Restore the item the player's first PokÃ©mon was due to use
              pbActiveBattlerIndicesForSide(false).each do |battlerIndex|
                if @choices[battlerIndex][0]==3 && $PokemonBag && $PokemonBag.pbCanStore?(@choices[battlerIndex][1])
                  $PokemonBag.pbStoreItem(@choices[battlerIndex][1])
                end
              end
              pbCommandPhase
              return
            end
            break if commandDone
          end
        end
      end
    end
  end

################################################################################
# Attack phase.
################################################################################
  def pbResolveForebode(priority)
    priority.each do |target|
      due_turn,source_index,source_party_index=target.effects[PBEffects::Forebode]
      next if !due_turn || due_turn>@turncount || target.isFainted? || target.effects[PBEffects::Commander]
      target.effects[PBEffects::Forebode]=[false,-1,-1]
      source=@battlers[source_index]
      original=pbParty(source_index)[source_party_index]
      source=pbMakeFakeBattler(original,false,source,true) if original &&
        (source.isFainted? || source.pokemonIndex!=source_party_index)
      next if !source.pokemon
      move=PokeBattle_Move.pbFromPBMove(self,PBMove.new(PBMoves::FOREBODE),source)
      move.forebode_strike=true
      pbDisplay(_INTL("{1}'s grim fate came to pass!",target.pbThis))
      target.pbPrepareMoveDamageState
      damage=move.pbEffect(source,target)
      if target.isFainted?
        target.pbFaint
      elsif damage>0 && !target.damagestate.substitute && !target.hasWorkingAbility(:INNERFOCUS)
        target.effects[PBEffects::Flinch]=true
      end
    end
  end

  def pbAttackPhase
    @scene.pbBeginAttackPhase
    eachActiveBattlerIndex do |i|
      @successStates[i].clear
      if @choices[i][0]!=1 && @choices[i][0]!=2
        @battlers[i].effects[PBEffects::DestinyBond]=false
        @battlers[i].effects[PBEffects::Grudge]=false
      end
      if @battlers[i].effects[PBEffects::ShieldLife]==0 && @shieldCount>0 && (!pbBelongsToPlayer?(i)) && pbIsOpposing?(i)
        shieldlife=[(@battlers[i].totalhp/4).floor,1].max
        @battlers[i].effects[PBEffects::ShieldLife]=shieldlife
      end
      @battlers[i].turncount+=1 if !@battlers[i].isFainted?
      @battlers[i].effects[PBEffects::TributeDamageTaken] = 0
      @battlers[i].effects[PBEffects::Rage]=false if !pbChoseMove?(i,:RAGE)
      @battlers[i].effects[PBEffects::Round]=false
      @battlers[i].effects[PBEffects::Howl]=false
      @battlers[i].pbRememberTimetwisterState
      #@battlers[i].pbCustapBerry
      # If Rift/Boss mon and shieldCount == -1,
      # update @battle.shieldCount (when enters battle in rift form)
      if !pbBelongsToPlayer?(i) && @bossfight && isBossPokemonInRiftForm?(@battlers[i]) && @shieldCount==-1
        @battlers[i].isBoss = true

        @scene.pbUpdateBattleShield(i)
      end
    end
    # Prepare for Z Moves
    eachActiveBattlerIndex do |i|
      next if @choices[i][0]!=1
      move=@choices[i][2]
      move.pbApplyTributeQueuedEffect(@battlers[i]) if move
      side=(pbIsOpposing?(i)) ? 1 : 0
      owner=pbGetOwnerIndex(i)
      if @zMove[side][owner]==i && @choices[i][0]==1 && @choices[i][2]
        @choices[i][2].zmove=true
      end
    end
    # Calculate priority at this time
    @usepriority=false
    priority=pbPriority
    priority.each { |battler| battler.pbResolveReverbEchoes }
    return if @decision!=0
#    # Mega Evolution Moved to after switching + items
#    for i in priority
#      next if @choices[i.index][0]!=1
#      side=(pbIsOpposing?(i.index)) ? 1 : 0
#      owner=pbGetOwnerIndex(i.index)
#      if @megaEvolution[side][owner]==i.index
#        pbMegaEvolve(i.index)
#      end
#    end
#    priority=pbPriority(false,true)
    # Call at PokÃ©mon
    for i in priority
      if @choices[i.index][0]==4
        pbCall(i.index)
      end
    end
    # Switch out PokÃ©mon
    @switching=true
    switched=[]
    shifted=[]
    for i in priority
      if @choices[i.index][0]==2
        index=@choices[i.index][1] # party position of PokÃ©mon to switch to
        if @choices[i.index][2]==:shift
          targetIndex=@choices[i.index][3]
          if targetIndex && targetIndex>=0 && !i.isFainted?
            targetBattler=@battlers[targetIndex]
            if targetBattler && !targetBattler.isFainted?
              if pbShiftBattlers(i.index,targetIndex)
                pbDisplayBrief(_INTL("{1} shifted lanes with {2}!",i.name,targetBattler.name))
                shifted.push(i,targetBattler)
              end
            end
          end
          next
        end
        self.lastMoveUser=i.index
        if !pbOwnedByPlayer?(i.index)
          owner=pbGetOwner(i.index)
          pbDisplayBrief(_INTL("{1} withdrew {2}!",owner.fullname,PBSpecies.getName(i.species)))
        else
          pbDisplayBrief(_INTL("{1}, that's enough!\r\nCome back!",i.name))
        end
        if @field.effects[PBEffects::WonderRoom]!=0
          if i.wonderroom==true
            i.pbSwapDefenses
          end
        end
        for j in priority
          next if j.isFainted? || !i.pbIsOpposing?(j.index)
          # if Pursuit and this target ("i") was chosen
          if !i.hasWorkingAbility(:RUNAWAY) && pbChoseMoveFunctionCode?(j.index,0x88) &&
             !j.effects[PBEffects::Pursuit] &&
             (@choices[j.index][3]==-1 || @choices[j.index][3]==i.index)
            if j.status!=PBStatuses::SLEEP &&
               j.status!=PBStatuses::FROZEN &&
               (!j.hasWorkingAbility(:TRUANT) || !j.effects[PBEffects::Truant])
              pursuit_choice=@choices[j.index].dup
              pursuit_choice[3]=i.index
              j.pbUseMove(pursuit_choice)
              j.effects[PBEffects::Pursuit]=true
              # UseMove calls pbGainEXP as appropriate
              if @decision>0
                @switching=false
                return
              end
            end
          end
          break if i.isFainted?
        end
        if !pbRecallAndReplace(i.index,index)
          # If a forced switch somehow occurs here in single battles
          # the attack phase now ends
          if singleBattle?
            @switching=false
            return
          end
        else
          switched.push(i.index)
        end
      end
    end
    @switching=false
    if @neutralizingGasEnded
      @neutralizingGasEnded=false
      pbNeutralizingGasEnded(switched)
    end
    if switched.length>0
      for i in priority
        i.pbAbilitiesOnSwitchIn(true) if switched.include?(i.index)
      end
    end
    shifted.each { |battler| battler.azureCommanderCheck }
    @partnerswitch.clear
    eachActiveBattlerIndex do |i|
       if !switched.include?(i)
         @battlers[i].pbCustapBerry
       end
    end
    # Use items
    for i in priority
      if pbIsOpposing?(i.index) && @choices[i.index][0]==3
        pbEnemyUseItem(@choices[i.index][1],i)
        i.itemUsed = true
        i.itemUsed2 = true
      elsif @choices[i.index][0]==3
        # Player use item
        item=@choices[i.index][1]
        if item>0
          usetype=$ItemData[item][ITEMBATTLEUSE]
          if usetype==1 || usetype==3
            if @choices[i.index][2] && @choices[i.index][2]>=0
              pbUseItemOnPokemon(item,@choices[i.index][2],i,@scene,@choices[i.index][4])
              i.itemUsed = true
              i.itemUsed2 = true
            end
          elsif usetype==2 || usetype==4
            if !ItemHandlers.hasUseInBattle(item) # PokÃ© Ball/PokÃ© Doll used already
              pbUseItemOnBattler(item,@choices[i.index][2],i,@scene)
               i.itemUsed = true
               i.itemUsed2 = true
            end
          end
        end
      end
    end
    # Mega Evolution
    for i in priority
      next if @choices[i.index][0]!=1
      side=(pbIsOpposing?(i.index)) ? 1 : 0
      owner=pbGetOwnerIndex(i.index)
      if @megaEvolution[side][owner]==i.index
        pbMegaEvolve(i.index)
      end
    end
    move_order_keys={}
    priority=pbPriority(false,true,move_order_keys: move_order_keys)
    pbResolveForebode(priority)
    return if @decision!=0
#### KUROTSUNE - 014 - START
#### KUROTSUNE - 014 - END
# Crest Stat Check
    for i in priority
      if (isConst?(i.species,PBSpecies,:CLAYDOL) && i.hasWorkingItem(:CLAYCREST))
        i.spatk = i.defense
      end
      if (isConst?(i.species,PBSpecies,:DEDENNE) && i.hasWorkingItem(:DEDECREST))
        i.attack = i.pbSpeed
      end
      if (isConst?(i.species,PBSpecies,:TYPHLOSION) && i.hasWorkingItem(:TYPHCREST))
        i.attack = i.spatk
      end
    end
# Use Attacks
    for i in priority
      if pbChoseMoveFunctionCode?(i.index,0x115) && @choices[i.index][2].id!=PBMoves::UNSTABLEMATTER
        pbCommonAnimation("FocusPunch",i,nil)
        pbDisplay(_INTL("{1} is tightening its focus!",i.pbThis))
      end
    end
    for i in priority
      if pbChoseMoveFunctionCode?(i.index,0x15D) # Beak Blast
        pbCommonAnimation("BeakBlast",i,nil)
        i.effects[PBEffects::BeakBlast]=true
        pbDisplay(_INTL("{1} is heating up!",i.pbThis))
      end
    end
    for i in priority
      if pbChoseMoveFunctionCode?(i.index,0x16B) # Shell Trap
        pbCommonAnimation("ShellTrap",i,nil)
        i.effects[PBEffects::ShellTrap]=true
        pbDisplay(_INTL("{1} set a shell trap!",i.pbThis))
      end
    end
    pbResolveAttackTurns(priority,move_order_keys)
    pbWait(20) if @decision==0
  end

  #pk code
  def pbPendingAttack?(battler)
    return false if !@attackTurnOrder || !battler || battler.isFainted? || battler.hasMovedThisRound?
    choice=@choices[battler.index]
    return @attackTurnOrder[:pending].include?(battler) && choice[0]==1 && !choice[2].nil?
  end

  def pbRefreshAttackTurnOrder
    order=@attackTurnOrder
    pending=order[:pending]
    priorityarray=[]
    for i in 0...pending.length
      battler=pending[i]
      rank=order[:ranks].fetch(battler)
      if battler.isFainted?
        priorityarray[i]=[0,0,0,0,-rank,i]
      elsif (nextmove=order[:next].index(battler))
        priorityarray[i]=[3,0,0,0,-nextmove,i]
      elsif (lastmove=order[:last].index(battler))
        priorityarray[i]=[1,0,0,0,-lastmove,i]
      else
        movepri,itempri=order[:keys].fetch(battler,[0,0])
        speed=@trickroom>0 ? -battler.pbSpeed : battler.pbSpeed
        priorityarray[i]=[2,movepri,itempri,speed,-rank,i]
      end
    end
    priorityarray.sort! { |a,b| b <=> a }
    pending.replace(priorityarray.map { |entry| pending[entry[-1]] })
    @priority.replace(order[:acted]+pending)
  end

  def pbProcessQueuedAttackTurn(battler)
    if @attackTurnOrder
      order=@attackTurnOrder
      return false if !order[:pending].delete(battler)
      order[:acted].push(battler)
      order[:next].delete(battler)
      order[:last].delete(battler)
      @priority.replace(order[:acted]+order[:pending])
    end
    return false if battler.isFainted? || battler.hasMovedThisRound?
    battler.pbProcessTurn(@choices[battler.index])
    return true
  end

  def pbResolveAttackTurns(priority,move_order_keys)
    @attackTurnOrder={pending: priority.dup,acted: [],next: [],last: [],
                      keys: move_order_keys,ranks: priority.each_with_index.to_h}
    pbRefreshAttackTurnOrder
    while (i=@attackTurnOrder[:pending].first)
      next unless pbProcessQueuedAttackTurn(i)
      # Round chaining: If this battler used Round and any ally selected Round but hasn't moved,
      # make those allies move immediately after (regardless of Speed)
      if i.effects[PBEffects::Round]
        attacker_side = i.index % 2
        @battlers.each do |ally|
          next if !ally || ally.index == i.index
          next if ally.index % 2 != attacker_side
          next if ally.isFainted? || ally.hasMovedThisRound?
          next unless pbChoseMoveFunctionCode?(ally.index, 0x83) # Ally selected Round
          pbProcessQueuedAttackTurn(ally)
          return if @decision>0
        end
      end
      # Howl chaining: If this battler used Howl and any ally selected Howl but hasn't moved,
      # make those allies move immediately after (regardless of Speed)
      if i.effects[PBEffects::Howl]
        attacker_side = i.index % 2
        @battlers.each do |ally|
          next if !ally || ally.index == i.index
          next if ally.index % 2 != attacker_side
          next if ally.isFainted? || ally.hasMovedThisRound?
          next unless pbChoseMove?(ally.index, :HOWL)
          pbProcessQueuedAttackTurn(ally)
          return if @decision>0
        end
      end
      if @choices[i.index][0]==1 && @choices[i.index][2]
        move = @choices[i.index][2]
        tribute_chain = (move.respond_to?(:tribute_attack?) && move.tribute_attack?(i,:FISTTRIBUTE) && move.heroic_tribute?(i,:PASSIMIAN)) ||
                        (move.respond_to?(:tribute_attack?) && move.tribute_attack?(i,:MINDTRIBUTE) && move.heroic_tribute?(i,:ORANGURU))
        if tribute_chain && i.lastMoveUsed==move.id
          pbTriggerTributeChain(i,move)
          return if @decision>0
        end
      end

      if (symbiosis=pbSymbiosisCheck(@priority))
        for s in symbiosis
          s.sameSideLivingBattlers(false).each do |ally|
            for stat in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,PBStats::SPATK,
                         PBStats::SPDEF,PBStats::EVASION,PBStats::ACCURACY]
              ally.stages[stat] = s.stages[stat]
            end
            pbDisplay(_INTL("{1} shared its stat changes with {2}!",s.pbThis,ally.pbThis(true)))
          end
        end
      end
      return if @decision>0
      pbRefreshAttackTurnOrder
    end
  ensure
    @attackTurnOrder=nil
  end

  # Checks if anyone can share stat changes through Symbiosis
  def pbSymbiosisCheck(battlers)
      result = []
      for i in battlers
        next if i.pokemon.nil?
        next if i.isFainted?
        next if i.sameSideLivingBattlers(false).empty?
        result << i if i.hasWorkingAbility(:SYMBIOSIS)
      end
      return result if result.any?
      return false
    end

    def pbShieldDamage(battler,damage,move=nil)
      if battler.effects[PBEffects::ShieldLife]>0
        if !(move.nil?)
          if move.id == PBMoves::THEOLIASTRIKE
            battler.effects[PBEffects::ShieldLife]=0
            @shieldCount-=2
            scene.pbUpdateShield(@shieldCount,battler.index)
            scene.pbDamageAnimation(battler,0)
            if @shieldCount>0
              shieldlife=[(battler.totalhp/4).floor,1].max
              battler.effects[PBEffects::ShieldLife]=shieldlife
            elsif @shieldCount==0
              battler.pbReduceHP([(battler.totalhp/8).floor,1].max)
            end
            if battler.hasWorkingAbility(:SAVAGERY)
              pbDisplay(_INTL("Taking damage made {1} more savage!",battler.name))
              if !battler.pbTooHigh?(PBStats::ATTACK)
                battler.pbIncreaseStatBasic(PBStats::ATTACK,1)
                pbCommonAnimation("StatUp",battler,nil)
                pbDisplay(_INTL("{1}'s Savagery raised its Attack!",battler.name))
              end
              if !battler.pbTooHigh?(PBStats::SPATK)
                battler.pbIncreaseStatBasic(PBStats::SPATK,1)
                pbCommonAnimation("StatUp",battler,nil)
                pbDisplay(_INTL("{1}'s Savagery raised its Special Attack!",battler.name))
              end
            end
          else
            damage=battler.effects[PBEffects::ShieldLife] if damage>battler.effects[PBEffects::ShieldLife]
            battler.effects[PBEffects::ShieldLife]-=damage
            if battler.effects[PBEffects::ShieldLife]>0 && @shieldCount>0
              scene.pbUpdateShield(@shieldCount,battler.index)
              scene.pbDamageAnimation(battler,0)
              pbDisplayPaused(_INTL("{1}'s shields took the damage!",battler.name))
            end
            if battler.effects[PBEffects::ShieldLife]<=0
              battler.effects[PBEffects::ShieldLife]=0
              @shieldCount-=1
              scene.pbUpdateShield(@shieldCount,battler.index)
              scene.pbDamageAnimation(battler,0)
              pbDisplayPaused(_INTL("{1}'s shield broke!",battler.name))
              if @shieldCount>0
                shieldlife=[(battler.totalhp/4).floor,1].max
                battler.effects[PBEffects::ShieldLife]=shieldlife
              elsif @shieldCount==0
                battler.pbReduceHP([(battler.totalhp/8).floor,1].max)
              end
            end
            if battler.hasWorkingAbility(:SAVAGERY)
              pbDisplay(_INTL("Taking damage made {1} more savage!",battler.name))
              if !battler.pbTooHigh?(PBStats::ATTACK)
                battler.pbIncreaseStatBasic(PBStats::ATTACK,1)
                pbCommonAnimation("StatUp",battler,nil)
                pbDisplay(_INTL("{1}'s Savagery raised its Attack!",battler.name))
              end
              if !battler.pbTooHigh?(PBStats::SPATK)
                battler.pbIncreaseStatBasic(PBStats::SPATK,1)
                pbCommonAnimation("StatUp",battler,nil)
                pbDisplay(_INTL("{1}'s Savagery raised its Special Attack!",battler.name))
              end
            end
          end
        end
      end
    end
################################################################################
# End of round.
################################################################################
  TRIBUTE_BATTLER_DURATIONS=[
    PBEffects::Taunt,PBEffects::Disable,PBEffects::Encore,PBEffects::HealBlock,
    PBEffects::MagnetRise,PBEffects::LockOn,PBEffects::Embargo,PBEffects::Telekinesis,
    PBEffects::ThroatChop,PBEffects::PerishSong,PBEffects::Confusion,PBEffects::Blinded
  ].freeze
  TRIBUTE_SIDE_DURATIONS=[
    PBEffects::Reflect,PBEffects::LightScreen,PBEffects::AuroraVeil,PBEffects::Tailwind,
    PBEffects::LuckyChant,PBEffects::Safeguard,PBEffects::DuneDefense,PBEffects::Mist,
    PBEffects::Bonfire,PBEffects::ScorchingGround,PBEffects::PressurePlate,
    PBEffects::DoubleDose,PBEffects::EtherealCloak
  ].freeze
  TRIBUTE_FIELD_DURATIONS=[
    PBEffects::Gravity,PBEffects::MagicRoom,PBEffects::WonderRoom,PBEffects::Terrain,
    PBEffects::GrassyTerrain,PBEffects::MistyTerrain,PBEffects::ElectricTerrain,
    PBEffects::PsychicTerrain,PBEffects::Splintered,PBEffects::VileMercy,PBEffects::BlueShift,
    PBEffects::Rainbow,PBEffects::FairyLock
  ].freeze

  def pbTributeOnceUsed?(pokemon,effect)
    return @tributeOnceUses && @tributeOnceUses[[pokemon,effect]]
  end

  def pbMarkTributeOnceUsed(pokemon,effect)
    @tributeOnceUses ||= {}
    @tributeOnceUses[[pokemon,effect]]=true
  end

  def pbTributeDurationSnapshot
    durations={}
    eachActiveBattlerIndex do |index|
      battler=@battlers[index]
      next if !battler.pokemon || battler.isFainted?
      TRIBUTE_BATTLER_DURATIONS.each { |effect| durations[[battler,effect,battler.pokemon]]=battler.effects[effect] }
    end
    @sides.each do |side|
      TRIBUTE_SIDE_DURATIONS.each { |effect| durations[[side,effect]]=side.effects[effect] }
    end
    TRIBUTE_FIELD_DURATIONS.each { |effect| durations[[@field,effect]]=@field.effects[effect] }
    durations[[self,:trickroom]]=@trickroom
    durations[[self,:weather,@weather]]=@weatherduration if @weather!=0
    return durations
  end

  def pbSetTributeDuration(key, turns)
    owner,effect=key
    case effect
    when :trickroom then @trickroom=turns
    when :weather then @weatherduration=turns
    else owner.effects[effect]=turns
    end
  end

  def pbApplyTributeDurations(battler, before, fixed_turns=nil)
    return false if !before
    changed=false
    pbTributeDurationSnapshot.each do |key, turns|
      next if !turns.is_a?(Integer) || turns<=0 || turns==(before[key] || 0)
      if fixed_turns
        @tributeArticunoDurations&.delete(key)
        pbSetTributeDuration(key,fixed_turns)
      else
        @tributeArticunoDurations ||= {}
        @tributeArticunoDurations[key]=battler.pokemon
      end
      changed=true
    end
    return changed
  end

  def pbUpdateTributeDurations
    return if !@tributeArticunoDurations || @tributeArticunoDurations.empty?
    durations=pbTributeDurationSnapshot
    active=activeBattlerIndices.filter_map do |index|
      battler=@battlers[index]
      battler.pokemon if !battler.isFainted?
    end
    hail=pbWeather==PBWeather::HAIL
    if hail && @weatherduration==1 && @weatherbackup!=PBWeather::HAIL && !azureJetstreamWeatherExtended?
      hail=@tributeArticunoDurations.key?([self,:weather,PBWeather::HAIL])
    end
    @tributeArticunoDurations.delete_if do |key, pokemon|
      turns=durations[key]
      next true if !turns.is_a?(Integer) || turns<=0
      sustained=active.include?(pokemon) || hail
      pbSetTributeDuration(key,sustained ? [turns,2].max : 1)
      !sustained
    end
  end

  def pbScheduleTributeMukRevival(pokemon)
    @tributeMukRevival ||= {}
    @tributeMukRevival[pokemon]=@turncount+2
  end

  def pbProcessTributeMukRevival
    return if !@tributeMukRevival
    @tributeMukRevival.delete_if do |pokemon, turn|
      next false if @turncount<turn
      if pokemon.hp<=0
        pokemon.hp=[pokemon.totalhp/2,1].max
        pbDisplay(_INTL("{1} revived in reserve!",pokemon.name))
      end
      true
    end
  end

  def pbEndOfRoundWithStall
    pbEndOfRoundPhase
    return if @decision>0
    holder=pbCheckGlobalAbility(:STALL)
    return if !holder || holder.turncount<=0
    pbDisplay(_INTL("{1} stalls for time.",holder.name))
    pbEndOfRoundPhase
  end

  def pbEndOfRoundPhase
    pbUpdateTributeDurations
    eachActiveBattlerIndex do |i|
      @battlers[i].pbExpireCoconBerryShield
      @battlers[i].forcedSwitchEarlier = false
      @battlers[i].effects[PBEffects::Roost]=false
      @battlers[i].effects[PBEffects::Protect]=false
      @battlers[i].effects[PBEffects::KingsShield]=false # add this line
      @battlers[i].effects[PBEffects::ProtectNegation]=false
      @battlers[i].effects[PBEffects::Endure]=false
      if @battlers[i].effects[PBEffects::HyperBeam]>0
        @battlers[i].effects[PBEffects::HyperBeam]-=1
        # Early Bird - 2x speed after recharging
        if @battlers[i].effects[PBEffects::HyperBeam]==0 && @battlers[i].hasWorkingAbility(:EARLYBIRD)
          @battlers[i].effects[PBEffects::EarlyBirdBoost]=2
        end
      end
      # Decrement Early Bird boost counter
      @battlers[i].effects[PBEffects::EarlyBirdBoost]-=1 if @battlers[i].effects[PBEffects::EarlyBirdBoost]>0
      @battlers[i].effects[PBEffects::SpikyShield]=false
      @battlers[i].effects[PBEffects::Stormhold]=false
      @battlers[i].effects[PBEffects::BanefulBunker]=false
      @battlers[i].effects[PBEffects::SilkTrap]=false
      @battlers[i].effects[PBEffects::BurningBulwark]=false
      @battlers[i].effects[PBEffects::Obstruct]=false
      @battlers[i].effects[PBEffects::BeakBlast]=false
      @battlers[i].effects[PBEffects::ClangedScales]=false
      @battlers[i].effects[PBEffects::ShellTrap]=false
      @battlers[i].effects[PBEffects::AttackingTarget].clear
#### KUROTSUNE - 023 - START
      @battlers[i].effects[PBEffects::Powder]  = false
#### KUROTSUNE - 023 - END
#### KUROTSUNE - 032 - START
      @battlers[i].effects[PBEffects::MeFirst] = false
      if @battlers[i].effects[PBEffects::ThroatChop]>0
        @battlers[i].effects[PBEffects::ThroatChop]-=1
      end
#### KUROTSUNE - 032 - END
      @battlers[i].itemUsed                    = false
      @battlers[i].pbCheckFormRoundEnd
    end
    eachActiveBattlerIndex do |i|
      battler = @battlers[i]
      battler.effects[PBEffects::TributeProtection] = 0
      if battler.effects[PBEffects::TributeTypeShift] > 0
        battler.effects[PBEffects::TributeTypeShift] -= 1
        if battler.effects[PBEffects::TributeTypeShift] <= 0
          data = battler.effects[PBEffects::TributeTypeShiftData]
          if data
            battler.type1 = data[:type1] if data[:type1]
            battler.type2 = data[:type2] if data[:type2]
          end
          battler.effects[PBEffects::TributeTypeShiftData] = nil
        end
      end
      effect=battler.effects[PBEffects::TributeMukMystic]
      if effect && !battler.isFainted? && @turncount>effect[:last_turn]
        effect[:last_turn]=@turncount
        if @turncount>=effect[:expires_turn]
          pbWithStatChangeSource([:item,PBItems::TOXICTRIBUTE,:muk_rebound]) do
            battler.pbReduceStat(PBStats::DEFENSE,3,false,nil,nil,true,false,false)
            battler.pbReduceStat(PBStats::SPDEF,3,false,nil,nil,true,false,false)
          end
          battler.effects[PBEffects::TributeMukMystic] = nil
        else
          battler.pbRecoverHP(battler.totalhp/8,true)
        end
      end
      next if !battler.effects[PBEffects::TributeMoltresSwitch]
      battler.effects[PBEffects::TributeMoltresSwitch] = false
      battler.pbRecoverHP((battler.totalhp/2).floor,true)
      next if !pbCanChooseNonActive?(battler.index)
      pbDisplay(_INTL("{1} wheeled back to safety!",battler.pbThis))
      newpoke = pbSwitchInBetween(battler.index,true,false)
      pbMessagesOnReplace(battler.index,newpoke)
      battler.vanished = false
      battler.pbResetForm
      pbReplace(battler.index,newpoke,false)
      pbOnActiveOne(battler)
      battler.pbAbilitiesOnSwitchIn(true)
    end
    pbProcessTributeMukRevival
#### KUROTSUNE - 013 - START
    @field.effects[PBEffects::IonDeluge]       = false
#### KUROTSUNE - 013 - END
    for i in 0...2
      sides[i].effects[PBEffects::MatBlock]=false
    end
    @usepriority=false  # recalculate priority
    priority=pbPriority(true) # Ignoring Quick Claw here
#### AME - 003 - START
    # Field Effects
    endmessage=false
    hazardsOnSide = false
    # Vespi Crest
    for i in priority
      next if i.isFainted?
      if isConst?(i.species,PBSpecies,:VESPIQUEN) && i.hasWorkingItem(:VESPICREST)
        mon = i
        if mon.effects[PBEffects::VespiCrest] == 0
           if (mon.totalhp != mon.hp)
            pbDisplay(_INTL("Vespiquen's swarm patched up her injuries!",i.pbThis)) if endmessage == false
            endmessage=true
            hpgain=(mon.totalhp/16).floor
            hpgain=mon.pbRecoverHP(hpgain,true)
          end
      end
    end
  end
    for i in priority
      next if i.isFainted?
      case $fefieldeffect
        when 2 # Grassy Field
          next if i.hp<=0
          if !i.isAirborne?
            if i.effects[PBEffects::HealBlock]==0 && i.totalhp != i.hp
              pbDisplay(_INTL("The grassy terrain healed the Pokémon on the field.",i.pbThis)) if endmessage == false
              endmessage=true
              hpgain=(i.totalhp/16).floor
              hpgain=(hpgain*1.3).floor if isConst?(i.item,PBItems,:BIGROOT)
              hpgain=i.pbRecoverHP(hpgain,true)
            end
          end
        when 7 # Volcanic Field
          next if i.hp<=0
          if !i.isAirborne?
            if isConst?(i.ability,PBAbilities,:FLASHFIRE)
              if !i.effects[PBEffects::FlashFire]
                i.effects[PBEffects::FlashFire]=true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!",
                i.pbThis,PBAbilities.getName(i.ability)))
              end
            end
            if !i.pbHasType?(:FIRE) && !i.effects[PBEffects::AquaRing] &&
             !isConst?(i.ability,PBAbilities,:FLAREBOOST) &&
             !isConst?(i.ability,PBAbilities,:MAGICGUARD) &&
             !isConst?(i.ability,PBAbilities,:FLASHFIRE) &&
             !isConst?(i.ability,PBAbilities,:HEATPROOF) &&
             !SilvallyCheck(i,PBTypes::STEEL) &&
             !i.isBoss &&
             !isConst?(i.ability,PBAbilities,:MAGMAARMOR) &&
             !isConst?(i.ability,PBAbilities,:FLAMEBODY) &&
             ![0xCA,0xCB].include?(PBMoveData.new(i.effects[PBEffects::TwoTurnAttack]).function) # Dig, Dive
              atype=getConst(PBTypes,:FIRE) || 0
              eff=PBTypes.getCombinedEffectiveness(atype,i.type1,i.type2)
              if isConst?(i.species,PBSpecies,:LEAFEON) && i.hasWorkingItem(:LEAFCREST)
                eff = 4
              end
              if i.effects[PBEffects::TarShot]==true
                eff *= 2
              end
              if eff>0
                @scene.pbDamageAnimation(i,0)
                 if isConst?(i.ability,PBAbilities,:LEAFGUARD) ||
                  isConst?(i.ability,PBAbilities,:ICEBODY) ||
                  isConst?(i.ability,PBAbilities,:FLUFFY)
                  eff = eff*2
                end
                pbDisplay(_INTL("The Pokémon were burned by the field!",i.pbThis)) if endmessage == false
                endmessage=true
                i.pbReduceHP([(i.totalhp*eff/32).floor,1].max)
                if i.hp<=0
                  return if !i.pbFaint
                end
              end
            end
          end
        when 10 # Corrosive Field
          next if i.hp<=0
          if i.hasWorkingAbility(:POISONHEAL)
            if !i.isAirborne?
              if i.effects[PBEffects::HealBlock]==0
                if i.hp<i.totalhp
                  pbCommonAnimation("Poison",i,nil)
                  i.pbRecoverHP((i.totalhp/8).floor,true)
                  pbDisplay(_INTL("{1} was healed by poison!",i.pbThis))
                end
              end
            end
          end
        when 11 # Corrosive Mist Field
          if i.pbCanPoison?(false) && pbCheckGlobalAbility(:NEUTRALIZINGGAS)==nil
            pbDisplay(_INTL("The Pokémon were poisoned by the corroded mist!",i.pbThis))   if endmessage == false
            endmessage=true
            i.pbPoison(i)
          end
          if isConst?(i.ability,PBAbilities,:POISONHEAL)
            if i.effects[PBEffects::HealBlock]==0
              if i.hp<i.totalhp
                pbCommonAnimation("Poison",i,nil)
                i.pbRecoverHP((i.totalhp/8).floor,true)
                pbDisplay(_INTL("{1} was healed by poison!",i.pbThis))
              end
            end
          end
        when 15 # Forest Field
          next if i.hp<=0
          if i.hasWorkingAbility(:SAPSIPPER) && i.effects[PBEffects::HealBlock]==0
            hpgain=(i.totalhp/16).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} drank tree sap to recover!",i.pbThis)) if hpgain>0
          end
        when 16 # Volcano Top Field
# eruption check - insane, too much, but makes typh op, so i no question
          next if i.hp<=0
          if @eruption
            if i.pbHasType?(:FIRE) ||
               i.hasWorkingAbility(:MAGMAARMOR) || i.hasWorkingAbility(:FLASHFIRE) ||
               i.hasWorkingAbility(:FLAREBOOST) || i.hasWorkingAbility(:BLAZE) ||
               i.hasWorkingAbility(:FLAMEBODY) || i.hasWorkingAbility(:SOLIDROCK) ||
               i.hasWorkingAbility(:STURDY) || i.hasWorkingAbility(:BATTLEARMOR) ||
               isConst?(i.species,PBSpecies,:GIRATINA) ||
               i.hasWorkingAbility(:SHELLARMOR) || i.hasWorkingAbility(:WATERBUBBLE) ||
               i.hasWorkingAbility(:MAGICGUARD) || i.hasWorkingAbility(:WONDERGUARD) ||
               i.hasWorkingAbility(:PRISMARMOR) || i.effects[PBEffects::AquaRing] ||
               (i.pbOwnSide.effects[PBEffects::AreniteWall]>0) ||
               SilvallyCheck(i,PBTypes::ROCK)
              pbDisplay(_INTL("{1} is immune to the eruption!",i.pbThis))
            else
              atype=getConst(PBTypes,:FIRE) || 0
              denominator = 4.0
              denominator = 8.0 if PBTypes.isNormalEffective?(atype,i.type1,i.type2)
              denominator = 16.0 if PBTypes.isNotVeryEffective?(atype,i.type1,i.type2)
              denominator *= 2 if (i.hasWorkingAbility(:THICKFAT) || SilvallyCheck(i,PBTypes::ICE))
              denominator /= 1.25 if (i.effects[PBEffects::TarShot])
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP([(i.totalhp/denominator).floor,1].max)
              pbDisplay(_INTL("{1} is hurt by the eruption!",i.pbThis))
              if i.hp<=0
                return if !i.pbFaint
              end
            end
            if i.hasWorkingAbility(:MAGMAARMOR)
              boost = false
              if !i.pbTooHigh?(PBStats::DEFENSE)
                i.pbIncreaseStatBasic(PBStats::DEFENSE,1)
                pbCommonAnimation("StatUp",i,nil)
                boost=true
              end
              if !i.pbTooHigh?(PBStats::SPDEF)
                i.pbIncreaseStatBasic(PBStats::SPDEF,1)
                pbCommonAnimation("StatUp",i,nil)
                boost=true
              end
              if boost
                pbDisplay(_INTL("{1}'s Magma Armor raised its defenses!",i.pbThis))
              end
            end
            if i.hasWorkingAbility(:FLAREBOOST)
              if !i.pbTooHigh?(PBStats::SPATK)
                i.pbIncreaseStatBasic(PBStats::SPATK,1)
                pbCommonAnimation("StatUp",i,nil)
                pbDisplay(_INTL("{1}'s Flare Boost raised its Sp. Attack!",i.pbThis))
              end
            end
            if isConst?(i.ability,PBAbilities,:FLASHFIRE)
              if !i.effects[PBEffects::FlashFire]
                i.effects[PBEffects::FlashFire]=true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!",
                i.pbThis,PBAbilities.getName(i.ability)))
              end
            end
            if isConst?(i.ability,PBAbilities,:BLAZE)
              if !i.effects[PBEffects::Blazed]
                i.effects[PBEffects::Blazed]=true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!",
                i.pbThis,PBAbilities.getName(i.ability)))
              end
            end
            if i.status==PBStatuses::SLEEP && !isConst?(i.ability,PBAbilities,:SOUNDPROOF)
              i.pbCureStatus
              pbDisplay(_INTL("{1} woke up due to the eruption!",i.pbThis))
            end
          end
# eruption check - insane, too much, but makes typh op, so i no question
        when 18 # Shortcircuit Field
          next if i.hp<=0
          if i.hasWorkingAbility(:VOLTABSORB) && i.effects[PBEffects::HealBlock]==0
            hpgain=(i.totalhp/16).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} absorbed stray electricity!",i.pbThis)) if hpgain>0
          end
        when 19 # Wasteland
          if i.hasWorkingAbility(:POISONHEAL)
            if !i.isAirborne?
              if i.effects[PBEffects::HealBlock]==0
                if i.hp<i.totalhp
                  pbCommonAnimation("Poison",i,nil)
                  i.pbRecoverHP((i.totalhp/8).floor,true)
                  pbDisplay(_INTL("{1} was healed by poison!",i.pbThis))
                end
              end
            end
          end
        when 21 # Water Surface
          next if i.hp<=0
          if i.hasWorkingAbility(:WATERABSORB) && i.effects[PBEffects::HealBlock]==0
            if !i.isAirborne?
              hpgain=(i.totalhp/16).floor
              hpgain=i.pbRecoverHP(hpgain,true)
              pbDisplay(_INTL("{1} absorbed some of the water!",i.pbThis)) if hpgain>0
            end
          end
          if i.effects[PBEffects::TarShot]==true
            pbCommonAnimation("StatUp",i,nil)
            pbDisplay(_INTL("{1} was cleansed of Tar Shot!",i.pbThis))
          end
        when 22 # Underwater
          next if i.hp<=0
          if !i.pbHasType?(:WATER) &&
           !i.hasWorkingAbility(:SWIFTSWIM) &&
           !i.hasWorkingAbility(:MAGICGUARD)
            atype=getConst(PBTypes,:WATER) || 0
            eff=PBTypes.getCombinedEffectiveness(atype,i.type1,i.type2)
            if eff>4
              @scene.pbDamageAnimation(i,0)
              if i.hasWorkingAbility(:FLAMEBODY) ||
               i.hasWorkingAbility(:MAGMAARMOR)
                eff = eff*2
              end
              i.pbReduceHP([(i.totalhp*eff/32).floor,1].max)
              pbDisplay(_INTL("{1} struggled in the water!",i.pbThis))
              if i.hp<=0
                return if !i.pbFaint
              end
            end
          end
        when 26 # Murkwater Surface
          if !i.pbHasType?(:STEEL) && !i.pbHasType?(:POISON) &&
           !i.hasWorkingAbility(:POISONHEAL) &&
           !i.hasWorkingAbility(:MAGICGUARD) &&
           !i.hasWorkingAbility(:WONDERGUARD) &&
           !i.hasWorkingAbility(:SURGESURFER) &&
           !i.hasWorkingAbility(:TOXICBOOST) &&
           !i.hasWorkingAbility(:IMMUNITY) &&
           !i.hasWorkingAbility(:PASTELVEIL)
            atype=getConst(PBTypes,:POISON) || 0
            eff=PBTypes.getCombinedEffectiveness(atype,i.type1,i.type2)
            if i.hasWorkingAbility(:FLAMEBODY) ||
             i.hasWorkingAbility(:MAGMAARMOR) ||
             i.hasWorkingAbility(:DRYSKIN) ||
             i.hasWorkingAbility(:WATERABSORB)
              eff = eff*2
            end
            if PBMoveData.new(i.effects[PBEffects::TwoTurnAttack]).function==0xCB && !(i.pbHasType?(:STEEL) || i.pbHasType?(:POISON))# Dive
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP([(i.totalhp*eff/8).floor,1].max)
              pbDisplay(_INTL("{1} suffocated underneath the toxic water!",i.pbThis))
            else
              if !i.isAirborne?
                @scene.pbDamageAnimation(i,0)
                i.pbReduceHP([(i.totalhp*eff/32).floor,1].max)
                pbDisplay(_INTL("{1} was hurt by the toxic water!",i.pbThis))
              end
            end
          end
          if i.isFainted?
            return if !i.pbFaint
          end
          if i.hasWorkingAbility(:POISONHEAL)
            if !i.isAirborne?
              if i.effects[PBEffects::HealBlock]==0
                if i.hp<i.totalhp
                  pbCommonAnimation("Poison",i,nil)
                  i.pbRecoverHP((i.totalhp/8).floor,true)
                  pbDisplay(_INTL("{1} was healed by poisoned water!",i.pbThis))
                end
              end
            end
          end
          if i.pbHasType?(:POISON) && (i.hasWorkingAbility(:WATERABSORB) || i.hasWorkingAbility(:DRYSKIN))
            if !i.isAirborne?
              if i.effects[PBEffects::HealBlock]==0
                if i.hp<i.totalhp
                  pbCommonAnimation("Poison",i,nil)
                  i.pbRecoverHP((i.totalhp/8).floor,true)
                  pbDisplay(_INTL("{1} was healed by the poisoned water!",i.pbThis))
                end
              end
            end
          end
        when 35 # New World
          $fecounter = 1
        when 38 # Dimension Field
          if i.effects[PBEffects::HealBlock]!=0
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP((i.totalhp/16).floor)
            pbDisplay(_INTL("{1} was damaged by the Heal Block!",i.pbThis))
            if i.hp<=0
              return if !i.pbFaint
            end
          end
        when 41 # Corrupted Cave Field
          next if i.hp<=0
          if i.hasWorkingAbility(:LEAFGUARD) ||
           i.hasWorkingAbility(:FLOWERVEIL) || SilvallyCheck(i,PBTypes::GRASS)
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP((i.totalhp/8).floor)
            pbDisplay(_INTL("{1}'s foliage caused harm!",i.pbThis))
            if i.hp<=0
              return if !i.pbFaint
            end
          end
          if i.hasWorkingAbility(:POISONHEAL)
            if !i.isAirborne?
              if i.effects[PBEffects::HealBlock]==0
                if i.hp<i.totalhp
                  pbCommonAnimation("Poison",i,nil)
                  i.pbRecoverHP((i.totalhp/8).floor,true)
                  pbDisplay(_INTL("{1} was healed in the corruption!",i.pbThis))
                end
              end
            end
          end
          if !i.isAirborne? && !i.pbHasType?(:POISON) && !i.isBoss &&
           !i.hasWorkingAbility(:IMMUNITY) &&
           !i.hasWorkingAbility(:PASTELVEIL)
            if i.pbCanPoison?(false)
              pbDisplay(_INTL("{1} was poisoned!",i.pbThis)) if endmessage == false
              endmessage=true
              i.pbPoison(i)
            end
          end
        when 42 # Bewitched Woods
          next if i.hp<=0
          if !i.isAirborne? && i.pbHasType?(:GRASS)
            if i.effects[PBEffects::HealBlock]==0 && i.totalhp != i.hp
              pbDisplay(_INTL("The woods healed the grass Pokémon on the field.",i.pbThis)) if endmessage == false
              endmessage=true
              if !(@field.effects[PBEffects::GrassyTerrain]>0)
                hpgain=(i.totalhp/16).floor
              else
                hpgain=(i.totalhp/8).floor
              end
              hpgain=(hpgain*1.3).floor if isConst?(i.item,PBItems,:BIGROOT)
              hpgain=i.pbRecoverHP(hpgain,true)
            end
          end
          if i.hasWorkingAbility(:NATURALCURE) || (i.hasWorkingAbility(:TRACE) &&
            i.effects[PBEffects::TracedAbility]==30)
            i.status=0
          end
        when 45 # Infernal Field
          next if i.hp<=0
          if !i.isAirborne?
            if i.effects[PBEffects::Torment]
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP((i.totalhp/8).floor)
              pbDisplay(_INTL("{1} was damaged by the torment!",i.pbThis))
              if i.hp<=0
                return if !i.pbFaint
              end
            end
            if isConst?(i.ability,PBAbilities,:FLASHFIRE)
              if !i.effects[PBEffects::FlashFire]
                i.effects[PBEffects::FlashFire]=true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!",
                i.pbThis,PBAbilities.getName(i.ability)))
              end
            end
          end
      end
    end
    if $fefieldeffect == 11 && pbCheckGlobalAbility(:NEUTRALIZINGGAS)
      pbDisplay(_INTL("Neutralizing Gas prevents poisoning."))
    end
    for i in priority
      if @field.effects[PBEffects::GrassyTerrain]>0
        if  !($fefieldeffect==2 || $fefieldeffect==42) # Grassy Terrain - Terrain Overlay
          next if i.hp<=0
          if !i.isAirborne?
            if i.effects[PBEffects::HealBlock]==0 && i.totalhp != i.hp
              pbDisplay(_INTL("The grassy terrain healed the Pokémon on the field.",i.pbThis)) if endmessage == false
              endmessage=true
              hpgain=(i.totalhp/16).floor
              hpgain=i.pbRecoverHP(hpgain,true)
            end
          end
        end
      end
    end
# eruption check
    if $fefieldeffect == 16
      if @eruption
        hazardsOnSide = false
        for i in priority
          if i.effects[PBEffects::LeechSeed]>=0
            i.effects[PBEffects::LeechSeed] = -1
            pbDisplay(_INTL("{1}'s Leech Seed burned away in the eruption!",i.pbThis))
          end
          if i.pbOwnSide.effects[PBEffects::Spikes]>0
            i.pbOwnSide.effects[PBEffects::Spikes]=0
            hazardsOnSide = true
          end
          if (i.pbOwnSide.effects[PBEffects::ToxicSpikes] || 0) > 0
            i.pbOwnSide.effects[PBEffects::ToxicSpikes]=0
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[PBEffects::StealthRock]
            i.pbOwnSide.effects[PBEffects::StealthRock]=false
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[PBEffects::StickyWeb]
            i.pbOwnSide.effects[PBEffects::StickyWeb]=false
            hazardsOnSide = true
          end
        end
        if hazardsOnSide
          pbDisplay(_INTL("The eruption removed all hazards from the field!"))
        end
      end
    end
# eruption check
  # End Field stuff
  if $fefieldeffect == 34
    for i in priority
      if i.hasWorkingAbility(:WORLDOFNIGHTMARES)
        $fecounter=i.turncount
        if $fecounter==8
          $fefieldeffect = 35
          pbChangeBGSprite
          pbDisplay(_INTL("The New World has taken shape!"))
          @weatherduration=0
          @field.effects[PBEffects::Terrain]=0
          seedCheck
        end
      end
    end
  end
#### AME - 003 - END # Weather
    if $fefieldeffect != 22
      if @weather != PBWeather::HAIL && $fefieldeffect == 27
        $fecounter = 0
      end
    # Tempest
  for i in priority
    if i.hasWorkingAbility(:TEMPEST)
      weathers=rand(5)
      case weathers
       when 0
          @weather=PBWeather::RAINDANCE
          @weatherduration=8
          pbCommonAnimation("Rain",nil,nil)
          pbDisplay(_INTL("Storm-9 created a downpour!"))
       when 1
          @weather=PBWeather::HAIL
          @weatherduration=8
          pbCommonAnimation("Hail",nil,nil)
          pbDisplay(_INTL("Storm-9 brought hailfall!"))
       when 2
          @weather=PBWeather::SANDSTORM
          @weatherduration=8
          pbCommonAnimation("Sandstorm",nil,nil)
          pbDisplay(_INTL("Storm-9 whipped up a dust storm!"))
       when 3
          @weather=PBWeather::STRONGWINDS
          @weatherduration=8
          pbCommonAnimation("Wind",nil,nil)
          pbDisplay(_INTL("Storm-9 whipped up terrible winds!"))
       when 4
          @weather=PBWeather::SHADOWSKY
          @weatherduration=8
          pbCommonAnimation("ShadowSky",nil,nil)
          pbDisplay(_INTL("Storm-9 shrouded the sky in a dark aura..."))
       end
     end
  end
    case @weather
      when PBWeather::SUNNYDAY
        @weatherduration=@weatherduration-1 if @weatherduration>0 && !azureJetstreamWeatherExtended?
        if @weatherduration==0
          pbDisplay(_INTL("The sunlight faded."))
          @weather=0
          @field.effects[PBEffects::HarshSunlight] = false
          #### DemICE - persistentweather - START
          if @weatherbackup!=0
            pbCommonAnimation(@weatherbackupanim,nil,nil)
            @weather=@weatherbackup
            @weatherduration=-1
            pbDisplay(_INTL("The initial weather took over again!"))
          end
          #### DemICE
          if $febackup == 34
            $fefieldeffect = 34
            pbChangeBGSprite
            pbDisplay(_INTL("The starry sky shone through!"));
            seedCheck
          end
        elsif pbWeather==PBWeather::SUNNYDAY
          pbCommonAnimation("Sunny",nil,nil)
          if $fefieldeffect == 34 # Starlight Arena
            if $fefieldeffect == $febackup
              $fefieldeffect = 0
            else
              $fefieldeffect = $febackup
              $febackup= 34
            end
            pbChangeBGSprite
            pbDisplay(_INTL("The sunlight eclipsed the starry sky!"));
            seedCheck
          end
#          pbDisplay(_INTL("The sunlight is strong."));
          for i in priority
            next if i.isFainted?
            if (i.hasWorkingAbility(:SOLARPOWER) ||
               (isConst?(i.species,PBSpecies,:CASTFORM) && isConst?(i.item,PBItems,:CASTCREST) && i.form==1))
              pbDisplay(_INTL("{1} was hurt by the sunlight!",i.pbThis))
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP((i.totalhp/8).floor)
              if i.isFainted?
                return if !i.pbFaint
              end
            end
            if $fefieldeffect == 12
              if i.pbHasType?(:WATER) || i.pbHasType?(:GRASS)
                pbDisplay(_INTL("{1} was hurt by the sunlight!",i.pbThis))
                @scene.pbDamageAnimation(i,0)
                i.pbReduceHP((i.totalhp/8).floor)
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
          end
        end
      when PBWeather::RAINDANCE
        @weatherduration=@weatherduration-1 if @weatherduration>0 && !azureJetstreamWeatherExtended?
        if @weatherduration==0
          pbDisplay(_INTL("The rain stopped."))
          @weather=0
          @field.effects[PBEffects::HeavyRain] = false
          #### DemICE  - persistentweather - START
          if @weatherbackup!=0
            pbCommonAnimation(@weatherbackupanim,nil,nil)
            @weather=@weatherbackup
            @weatherduration=-1
            pbDisplay(_INTL("The initial weather took over again!"))
          end
          #### DemICE
          if $febackup == 34
            $fefieldeffect = 34
            pbChangeBGSprite
            pbDisplay(_INTL("The starry sky shone through!"));
            seedCheck
          end
        elsif $fefieldeffect == 45
          pbDisplay(_INTL("The rain evaporated away."))
          @weather=0
          @field.effects[PBEffects::HeavyRain] = false
        elsif pbWeather==PBWeather::RAINDANCE
          pbCommonAnimation("Rain",nil,nil)
#         pbDisplay(_INTL("Rain continues to fall."));
          if $fefieldeffect == 7 # Burning Field
            if $fefieldeffect == $febackup
              $fefieldeffect = 23
            else
              $febackup = 7
              $fefieldeffect = $febackup
            end
            pbChangeBGSprite
            pbDisplay(_INTL("The rain snuffed out the flame!"));
            seedCheck
          end
          if $fefieldeffect == 34 # Starlight Arena
            if $fefieldeffect == $febackup
              $fefieldeffect = 0
            else
              $fefieldeffect = $febackup
              $febackup= 34
            end
            pbChangeBGSprite
            pbDisplay(_INTL("The weather blocked out the starry sky!"));
            seedCheck
          end
        end
      when PBWeather::SANDSTORM
        @weatherduration=@weatherduration-1 if @weatherduration>0 && !azureJetstreamWeatherExtended?
        if @weatherduration==0
          pbDisplay(_INTL("The sandstorm subsided."))
          @weather=0
          #### DemICE  - persistentweather - START
          if @weatherbackup!=0
            pbCommonAnimation(@weatherbackupanim,nil,nil)
            @weather=@weatherbackup
            @weatherduration=-1
            pbDisplay(_INTL("The initial weather took over again!"))
          end
          #### DemICE
          if $febackup == 34
            $fefieldeffect = 34
            pbChangeBGSprite
            pbDisplay(_INTL("The starry sky shone through!"));
            seedCheck
          end
        elsif pbWeather==PBWeather::SANDSTORM
          pbCommonAnimation("Sandstorm",nil,nil)
#         pbDisplay(_INTL("The sandstorm rages."))
          if $fefieldeffect == 7 # Burning Field
            if $fefieldeffect == $febackup
              $fefieldeffect = 23
            else
              $febackup = 7
              $fefieldeffect = $febackup
            end
            pbChangeBGSprite
            pbDisplay(_INTL("The sand snuffed out the flame!"));
            seedCheck
          end
          if ($fefieldeffect == 9 && $febackup!=$fefieldeffect) || @field.effects[PBEffects::Rainbow]>0 # Rainbow Field ### Azery
            if $fefieldeffect == $febackup
              if @field.effects[PBEffects::Rainbow]>0
                $fefieldeffect = $febackup
              else
                $fefieldeffect = 0
              end
            else
              $fefieldeffect = $febackup
            end
            pbChangeBGSprite
            @field.effects[PBEffects::Rainbow]=0
            pbDisplay(_INTL("The weather blocked out the rainbow!"));
            seedCheck
          end
          if $fefieldeffect == 34 # Starlight Arena
            if $fefieldeffect == $febackup
              $fefieldeffect = 0
            else
              $fefieldeffect = $febackup
              $febackup = 34
            end
            pbChangeBGSprite
            pbDisplay(_INTL("The weather blocked out the starry sky!"));
            seedCheck
          end
          if pbWeather==PBWeather::SANDSTORM
            endmessage=false
            for i in priority
              next if i.isFainted?
              if (!i.pbHasType?(:GROUND) && !i.pbHasType?(:ROCK) && !i.pbHasType?(:STEEL) &&
               !i.hasWorkingAbility(:SANDVEIL) &&
               !i.hasWorkingAbility(:SANDRUSH) &&
               !i.hasWorkingAbility(:SANDFORCE) &&
               !i.hasWorkingAbility(:TEMPEST) &&
               !i.hasWorkingAbility(:MAGICGUARD) &&
               !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) &&
               !i.hasWorkingItem(:SAFETYGOGGLES) &&
               !i.hasWorkingAbility(:OVERCOAT) &&
               ![0xCA,0xCB].include?(PBMoveData.new(i.effects[PBEffects::TwoTurnAttack]).function)) || i.effects[PBEffects::DesertsMark]
                pbDisplay(_INTL("The Pokémon were buffeted by the sandstorm!",i.pbThis)) if endmessage==false
                endmessage=true
                @scene.pbDamageAnimation(i,0)
                if i.effects[PBEffects::ShieldLife]>0
                  sanddamage=i.totalhp/16
                  pbShieldDamage(i,sanddamage)
                else
                  if $fefieldeffect == 12
                    i.pbReduceHP((i.totalhp/8).floor)
                  else
                    i.pbReduceHP((i.totalhp/16).floor)
                  end
                end
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
          end
        end
      when PBWeather::HAIL
        @weatherduration=@weatherduration-1 if @weatherduration>0 && !azureJetstreamWeatherExtended?
        if @weatherduration==0
          pbDisplay(_INTL("The hail stopped."))
          @weather=0
          #### DemICE - persistentweather - START
          if @weatherbackup!=0
            pbCommonAnimation(@weatherbackupanim,nil,nil)
            @weather=@weatherbackup
            @weatherduration=-1
            pbDisplay(_INTL("The initial weather took over again!"))
          end
          #### DemICE
          if $febackup == 34
            $fefieldeffect = 34
            pbChangeBGSprite
            pbDisplay(_INTL("The starry sky shone through!"));
            seedCheck
          end
        elsif $fefieldeffect == 16 || $fefieldeffect == 7
          pbDisplay(_INTL("The hail melted away."))
          @weather=0
          if @weatherbackup!=0
            pbCommonAnimation(@weatherbackupanim,nil,nil)
            @weather=@weatherbackup
            @weatherduration=-1
            pbDisplay(_INTL("The initial weather took over again!"))
          end
        elsif $fefieldeffect == 32
          pbDisplay(_INTL("The hail melted away."))
          @weather=0
          if @weatherbackup!=0
            pbCommonAnimation(@weatherbackupanim,nil,nil)
            @weather=@weatherbackup
            @weatherduration=-1
            pbDisplay(_INTL("The initial weather took over again!"))
          end
        elsif $fefieldeffect == 45
          pbDisplay(_INTL("The hail melted away."))
          @weather=0
          if @weatherbackup!=0
            pbCommonAnimation(@weatherbackupanim,nil,nil)
            @weather=@weatherbackup
            @weatherduration=-1
            pbDisplay(_INTL("The initial weather took over again!"))
          end
        elsif pbWeather==PBWeather::HAIL
          pbCommonAnimation("Hail",nil,nil)
#         pbDisplay(_INTL("Hail continues to fall."))
          if ($fefieldeffect == 9 && $febackup!=$fefieldeffect) || @field.effects[PBEffects::Rainbow]>0 # Rainbow Field ### Azery
            if $fefieldeffect == $febackup
              if @field.effects[PBEffects::Rainbow]>0
                $fefieldeffect = $febackup
              else
                $fefieldeffect = 0
              end
            else
              $fefieldeffect = $febackup
            end
            pbChangeBGSprite
            @field.effects[PBEffects::Rainbow]=0
            pbDisplay(_INTL("The weather blocked out the rainbow!"));
            seedCheck
          end
          if $fefieldeffect == 34 # Starlight Arena
            if $fefieldeffect == $febackup
              $fefieldeffect = 0
            else
              $fefieldeffect = $febackup
              $febackup = 34
            end
            pbChangeBGSprite
            pbDisplay(_INTL("The weather blocked out the starry sky!"));
            seedCheck
          end
          if pbWeather==PBWeather::HAIL
            endmessage=false
            for i in priority
              next if i.isFainted?
              if !i.pbHasType?(:ICE) &&
                 !i.hasWorkingAbility(:ICEBODY) &&
                 !i.hasWorkingAbility(:TEMPEST) &&
                 !i.hasWorkingAbility(:MAGICGUARD) &&
                 !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) &&
                 !i.hasWorkingItem(:SAFETYGOGGLES) &&
                 !i.hasWorkingAbility(:OVERCOAT) &&
                 !(isConst?(i.species,PBSpecies,:EMPOLEON) && i.hasWorkingItem(:EMPCREST)) &&
                 ![0xCA,0xCB].include?(PBMoveData.new(i.effects[PBEffects::TwoTurnAttack]).function) # Dig, Dive
                pbDisplay(_INTL("The Pokémon were buffeted by the hail!",i.pbThis)) if endmessage==false
                endmessage=true
                @scene.pbDamageAnimation(i,0)
                if i.effects[PBEffects::ShieldLife]>0
                  haildamage=i.totalhp/16
                  pbShieldDamage(i,haildamage)
                else
                  if $fefieldeffect == 39
                    i.pbReduceHP((i.totalhp/8).floor)
                  else
                    i.pbReduceHP((i.totalhp/16).floor)
                  end
                end
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
            if $fefieldeffect  == 27
              $fecounter+=1
              if $fecounter == 3
                $fecounter = 0
                $fefieldeffect = 28
                pbChangeBGSprite
                pbDisplay(_INTL("The mountain was covered in snow!"))
                seedCheck
              end
            end
          end
        end
      when PBWeather::STRONGWINDS
        @weatherduration=@weatherduration-1 if @weatherduration>0 && !azureJetstreamWeatherExtended?
        if @weatherduration==0
          pbDisplay(_INTL("The strong winds subsided."))
          @weather=0
        else
          pbCommonAnimation("Wind",nil,nil)
#         pbDisplay(_INTL("The wind is strong."));
        end
      end
    end
    # Shadow Sky weather
    if isConst?(@weather,PBWeather,:SHADOWSKY)
      @weatherduration=@weatherduration-1 if @weatherduration>0 && !azureJetstreamWeatherExtended?
      if @weatherduration==0
        pbDisplay(_INTL("The shadow sky faded."))
        @weather=0
      else
        pbCommonAnimation("ShadowSky",nil,nil)
#        pbDisplay(_INTL("The shadow sky continues."));
        if isConst?(pbWeather,PBWeather,:SHADOWSKY)
          for i in priority
            next if i.isFainted?
            if !i.isShadow? && !i.hasWorkingAbility(:TEMPEST)
              pbDisplay(_INTL("{1} was hurt by the shadow sky!",i.pbThis))
              @scene.pbDamageAnimation(i,0)
              if $fefieldeffect == 38 || $fefieldeffect == 39
                  i.pbReduceHP((i.totalhp/8).floor)
                else
                  i.pbReduceHP((i.totalhp/16).floor)
              end
              if i.isFainted?
                return if !i.pbFaint
              end
            end
          end
        end
      end
    end
    # Temporal Shift
    for i in priority
      next if i.isFainted?
      if i.hasWorkingAbility(:TEMPORALSHIFT)
        for j in priority
          next if j.isFainted?
          if !(i==j || i.sameSideBattlers(false).include?(j) || j.pbHasType?(:NORMAL)) &&
           j.effects[PBEffects::FutureSight]==0
            j.effects[PBEffects::FutureSight]=3
            j.effects[PBEffects::FutureSightMove]=179
            j.effects[PBEffects::FutureSightUser]=i.index
            pbDisplay(_INTL("{1} casts a hex!",i.pbThis))
            break
          end
        end
      end
    end

    # Future Sight/Doom Desire
    for i in battlers   # not priority
      if i.isFainted? && i.effects[PBEffects::FutureSight]>0
        i.effects[PBEffects::FutureSight]-=1
        if i.effects[PBEffects::FutureSight]==0
          i.effects[PBEffects::FutureSightMove]=0
          i.effects[PBEffects::FutureSightDamage]=0
          i.effects[PBEffects::FutureSightUser]=-1
        end
      end
      next if i.isFainted?
      if i.effects[PBEffects::FutureSight]>0
        i.effects[PBEffects::FutureSight]-=1
        if i.effects[PBEffects::FutureSight]==0
          if i.effects[PBEffects::FutureSightMove]==PBMoves::PERFORATE
            source_index=i.effects[PBEffects::FutureSightUser]
            party_index=i.effects[PBEffects::FutureSightPkmnIdx]
            source=@battlers[source_index]
            i.effects[PBEffects::FutureSightMove]=0
            i.effects[PBEffects::FutureSightDamage]=0
            i.effects[PBEffects::FutureSightUser]=-1
            i.effects[PBEffects::FutureSightPkmnIdx]=-1
            source=allSameSideBattlers(source_index).find { |battler| battler.pokemonIndex==party_index } || source
            if source.pokemonIndex!=party_index || source.isFainted?
              pokemon=pbParty(source_index)[party_index]
              next unless pokemon
              source=pbMakeFakeBattler(pokemon,false,source,true)
            end
            move=PokeBattle_Move.pbFromPBMove(self,PBMove.new(PBMoves::PERFORATE),source)
            pbDisplay(_INTL("{1} took the {2} attack!",i.pbThis,move.name))
            i.pbPrepareMoveDamageState
            saved_moldbreaker=i.moldbroken
            begin
              i.moldbroken=source.pbBypassesTargetAbility?(move)
              type=move.pbType(move.type,source,i)
              effectiveness=move.pbTypeModifier(type,source,i)
              if !pbCheckGlobalAbility(:HEADSTRONG) && i.hasWorkingAbility(:WONDERGUARD) &&
                 !i.moldbroken && effectiveness<=4
                pbDisplay(_INTL("{1} avoided damage with Wonder Guard!",i.pbThis))
                next
              end
              if !pbCheckGlobalAbility(:HEADSTRONG) && effectiveness==0
                pbDisplay(_INTL("It doesn't affect {1}...",i.pbThis(true)))
                next
              end
              damage=move.pbCalcDamage(source,i)
              next if damage<=0
              pbAnimation(move.id,source,i) unless source.isFainted?
              move.pbReduceHPDamage(damage,source,i)
              move.pbEffectMessages(source,i)
            ensure
              i.moldbroken=saved_moldbreaker
            end
            return if i.isFainted? && !i.pbFaint
            next
          end
          moveuser=@battlers[i.effects[PBEffects::FutureSightUser]]
          if i.effects[PBEffects::FutureSightMove] == 516 #DoomDesire
            move=PokeBattle_Move.pbFromPBMove(self,PBMove.new(741),moveuser) #DoomDummy
            type=getConst(PBTypes,:STEEL)
          elsif i.effects[PBEffects::FutureSightMove] == 450 #FutureSight
            move=PokeBattle_Move.pbFromPBMove(self,PBMove.new(740),moveuser) #FutureDummy
            type=getConst(PBTypes,:PSYCHIC)
          elsif i.effects[PBEffects::FutureSightMove] == 179 #FutureSight
            move=PokeBattle_Move.pbFromPBMove(self,PBMove.new(754),moveuser) #HexDummy
            type=getConst(PBTypes,:GHOST)
          end
          pbDisplay(_INTL("{1} took the {2} attack!",i.pbThis,move.name))
          typemod = move.pbTypeModifierNonBattler(type,moveuser,i) # added
          if i.isFainted? || move.pbAccuracyCheck(moveuser,i) &&
           !(i.hasWorkingAbility(:WONDERGUARD) && typemod<=4)
            i.damagestate.reset
            damage = nil
            if i.effects[PBEffects::FutureSightMove] == 450 && !(i.pbHasType?(:DARK))
              pbAnimation(740,i,nil)
            elsif i.effects[PBEffects::FutureSightMove] == 516
              pbAnimation(741,i,nil)
            elsif i.effects[PBEffects::FutureSightMove] == 179
              pbAnimation(754,i,nil)
            end
            move.pbReduceHPDamage(damage,moveuser,i)
            move.pbEffectMessages(moveuser,i)
          elsif i.hasWorkingAbility(:WONDERGUARD) && typemod<=4 #added
            pbDisplay(_INTL("{1} avoided damage with Wonder Guard!",i.pbThis)) #added
          else
            pbDisplay(_INTL("But it failed!"))
          end
          i.effects[PBEffects::FutureSight]=0
          i.effects[PBEffects::FutureSightMove]=0
          i.effects[PBEffects::FutureSightDamage]=0
          i.effects[PBEffects::FutureSightUser]=-1
          if i.isFainted?
            return if !i.pbFaint
            next
          end
        end
      end
    end
    for i in priority
      next if i.isFainted?
      # Meganium + Meganium Crest
      if (isConst?(i.species,PBSpecies,:MEGANIUM) && i.hasWorkingItem(:MEGCREST)) ||
       i.sameSideLivingBattlers(false).any? { |ally| isConst?(ally.species,PBSpecies,:MEGANIUM) && ally.hasWorkingItem(:MEGCREST) }
        hpgain=i.pbRecoverHP((i.totalhp/16).floor,true)
        pbDisplay(_INTL("The Meganium Crest restored {1}'s HP a little!",i.pbThis(true))) if hpgain>0
      end
      # Rain Dish
      if pbWeather==PBWeather::RAINDANCE && !i.hasWorkingItem(:UTILITYUMBRELLA) && (i.hasWorkingAbility(:RAINDISH) ||
       ( isConst?(i.species,PBSpecies,:CASTFORM) && isConst?(i.item,PBItems,:CASTCREST) && i.form==2) ) && i.effects[PBEffects::HealBlock]==0
        hpgain=i.pbRecoverHP((i.totalhp/16).floor,true)
        pbDisplay(_INTL("{1}'s Rain Dish restored its HP a little!",i.pbThis)) if hpgain>0
      end
      # Hydroplane
      if i.pbHydroplaneActive?
        @scene.pbDamageAnimation(i,0)
        hploss=i.pbReduceHP((i.totalhp/8).floor)
        pbDisplay(_INTL("{1} was hurt by hydroplaning!",i.pbThis)) if hploss>0
      end
      # Caretaker
      if i.hasWorkingAbility(:CARETAKER)
        i.sameSideLivingBattlers(false).each do |ally|
          next if ally.effects[PBEffects::HealBlock]>0
          hpgain=ally.pbRecoverHP((ally.totalhp/8).floor,true)
          pbDisplay(_INTL("{1}'s Caretaker restored {2}'s HP!",i.pbThis,ally.pbThis(true))) if hpgain>0
        end
      end
      # Dry Skin
      if isConst?(i.ability,PBAbilities,:DRYSKIN)
        if pbWeather==PBWeather::RAINDANCE && !i.hasWorkingItem(:UTILITYUMBRELLA) && i.effects[PBEffects::HealBlock]==0
          hpgain=i.pbRecoverHP((i.totalhp/8).floor,true)
          pbDisplay(_INTL("{1}'s Dry Skin was healed by the rain!",i.pbThis)) if hpgain>0
        elsif pbWeather==PBWeather::SUNNYDAY && !i.hasWorkingItem(:UTILITYUMBRELLA)
          @scene.pbDamageAnimation(i,0)
          hploss=i.pbReduceHP((i.totalhp/8).floor)
          pbDisplay(_INTL("{1}'s Dry Skin was hurt by the sunlight!",i.pbThis)) if hploss>0
        elsif ($fefieldeffect == 11 || $fefieldeffect == 41) && !i.pbHasType?(:STEEL)
          if !i.pbHasType?(:POISON)
            @scene.pbDamageAnimation(i,0)
            hploss=i.pbReduceHP((i.totalhp/8).floor)
            pbDisplay(_INTL("{1}'s Dry Skin absorbed the poison!",i.pbThis)) if hploss>0
          elsif i.effects[PBEffects::HealBlock]==0
            hpgain=i.pbRecoverHP((i.totalhp/8).floor,true)
            pbDisplay(_INTL("{1}'s Dry Skin was healed by the poison!",i.pbThis)) if hpgain>0
          end
        elsif $fefieldeffect == 12
          @scene.pbDamageAnimation(i,0)
          hploss=i.pbReduceHP((i.totalhp/8).floor)
          pbDisplay(_INTL("{1}'s Dry Skin was hurt by the desert air!",i.pbThis)) if hploss>0
        elsif ($fefieldeffect == 3 || $fefieldeffect == 8) && # Misty/Swamp Field only
          i.effects[PBEffects::HealBlock]==0
          hpgain=(i.totalhp/16).floor
          hpgain=i.pbRecoverHP(hpgain,true)
          pbDisplay(_INTL("{1}'s Dry Skin was healed by the mist!",i.pbThis)) if hpgain>0
        elsif ($fefieldeffect == 21 || $fefieldeffect == 22) && #Water fields
          i.effects[PBEffects::HealBlock]==0
          hpgain=(i.totalhp/16).floor
          hpgain=i.pbRecoverHP(hpgain,true)
          pbDisplay(_INTL("{1}'s Dry Skin was healed by the water!",i.pbThis)) if hpgain>0
        elsif $fefieldeffect == 46
          @scene.pbDamageAnimation(i,0)
          hploss=i.pbReduceHP((i.totalhp/8).floor)
          pbDisplay(_INTL("{1}'s Dry Skin was hurt by the saltwater!",i.pbThis)) if hploss>0
        end
      end
      # Druddigon Crest
      if isConst?(i.species,PBSpecies,:DRUDDIGON) && isConst?(i.item,PBItems,:DRUDDICREST)
        if pbWeather==PBWeather::SUNNYDAY && i.effects[PBEffects::HealBlock]==0
          hpgain=i.pbRecoverHP((i.totalhp/8).floor,true)
          pbDisplay(_INTL("{1} was replenished by the sunlight!",i.pbThis)) if hpgain>0
        elsif $fefieldeffect == 7 || $fefieldeffect == 16 || $fefieldeffect == 32  # Volcanic/Volcano Top Field/Dragon's Den
          i.effects[PBEffects::HealBlock]==0
          hpgain=(i.totalhp/16).floor
          hpgain=i.pbRecoverHP(hpgain,true)
          pbDisplay(_INTL("{1} was healed by the heat!",i.pbThis)) if hpgain>0
        end
      end
      # Ice Body
      if (pbWeather==PBWeather::HAIL || $fefieldeffect == 13 || $fefieldeffect == 39 ||
       $fefieldeffefct == 28) &&
       (i.hasWorkingAbility(:ICEBODY)) &&
       i.effects[PBEffects::HealBlock]==0
        hpgain=i.pbRecoverHP((i.totalhp/16).floor,true)
        pbDisplay(_INTL("{1}'s Ice Body restored its HP a little!",i.pbThis)) if hpgain>0
      end
      # Sunbathe - Restores 1/8th max HP each turn in Sun
      if pbWeather==PBWeather::SUNNYDAY && !i.hasWorkingItem(:UTILITYUMBRELLA) &&
       i.hasWorkingAbility(:SUNBATHE) && i.effects[PBEffects::HealBlock]==0
        hpgain=i.pbRecoverHP((i.totalhp/8).floor,true)
        pbDisplay(_INTL("{1}'s Sunbathe restored its HP!",i.pbThis)) if hpgain>0
      end
      # Haste - lose a positive Speed stage each turn
      if i.hasWorkingAbility(:HASTE) && i.stages[PBStats::SPEED] > 0
        i.stages[PBStats::SPEED] -= 1
        pbDisplay(_INTL("{1}'s {2} lowered its Speed stage!",i.pbThis,PBAbilities.getName(i.ability)))
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Wish
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Wish]>0
        i.effects[PBEffects::Wish]-=1
        if i.effects[PBEffects::Wish]==0
          i.effects[PBEffects::TributePendingShield]=true if i.effects[PBEffects::TributeWishOverheal]
          i.effects[PBEffects::TributeWishOverheal]=false
          hpgain=i.pbRecoverHP(i.effects[PBEffects::WishAmount],true)
          if i.effects[PBEffects::HealerWish] && i.status>0 && i.effects[PBEffects::Spritz]!=1
            i.pbCureStatus
          end
          if hpgain>0
            wishmaker=pbThisEx(i.index,i.effects[PBEffects::WishMaker])
            pbDisplay(_INTL("{1}'s wish came true!",wishmaker))
          end
        end
      end
    end
    # Fire Pledge + Grass Pledge combination damage - should go here
    for i in priority
      next if i.isFainted?
      # Shed Skin - sheds the first status condition, resets on switch out
      if i.status>0 && i.pbShedSkinReady?
        i.pbCureStatus(false)
        i.effects[PBEffects::ShedSkinUsed]=true
        pbDisplay(_INTL("{1}'s Shed Skin cured its status condition!",i.pbThis))
      end
      # Hydration
      if i.hasWorkingAbility(:HYDRATION) && pbWeather==PBWeather::RAINDANCE &&
         !i.hasWorkingItem(:UTILITYUMBRELLA)
        has_negative = false
        if i.status>0
          case i.status
            when PBStatuses::SLEEP
              pbDisplay(_INTL("{1}'s Hydration cured its sleep problem!",i.pbThis))
            when PBStatuses::FROZEN
              pbDisplay(_INTL("{1}'s Hydration cured its ice problem!",i.pbThis))
            when PBStatuses::BURN
              pbDisplay(_INTL("{1}'s Hydration cured its burn problem!",i.pbThis))
            when PBStatuses::POISON
              pbDisplay(_INTL("{1}'s Hydration cured its poison problem!",i.pbThis))
            when PBStatuses::PARALYSIS
              pbDisplay(_INTL("{1}'s Hydration cured its paralysis problem!",i.pbThis))
          end
          i.status=0
          i.statusCount=0
        end
        for stat in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
          if i.stages[stat] < 0
            i.stages[stat] = 0
            has_negative = true
          end
        end
        if has_negative
          pbDisplay(_INTL("{1}'s Hydration cleared its negative stat changes!",i.pbThis))
        end
      end
      # Leaf Guard - clears status and negative stats in Sun
      if i.hasWorkingAbility(:LEAFGUARD) && pbWeather==PBWeather::SUNNYDAY &&
         !i.hasWorkingItem(:UTILITYUMBRELLA)
        if i.status>0
          case i.status
            when PBStatuses::SLEEP
              pbDisplay(_INTL("{1}'s Leaf Guard cured its sleep problem!",i.pbThis))
            when PBStatuses::FROZEN
              pbDisplay(_INTL("{1}'s Leaf Guard cured its ice problem!",i.pbThis))
            when PBStatuses::BURN
              pbDisplay(_INTL("{1}'s Leaf Guard cured its burn problem!",i.pbThis))
            when PBStatuses::POISON
              pbDisplay(_INTL("{1}'s Leaf Guard cured its poison problem!",i.pbThis))
            when PBStatuses::PARALYSIS
              pbDisplay(_INTL("{1}'s Leaf Guard cured its paralysis problem!",i.pbThis))
          end
          i.status=0
          i.statusCount=0
        end
        # Clear negative stat stages
        hasNegative = false
        for stat in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
          if i.stages[stat] < 0
            i.stages[stat] = 0
            hasNegative = true
          end
        end
        if hasNegative
          pbDisplay(_INTL("{1}'s Leaf Guard cleared its negative stat changes!",i.pbThis))
        end
      end
      # Steam Engine
      if i.hasWorkingAbility(:STEAMENGINE) && ($fefieldeffect == 7 ||
       $fefieldeffect == 16 || $fefieldeffect == 21 || $fefieldeffect == 22 ||
       $fefieldeffect == 45)
        if !i.pbTooHigh?(PBStats::SPEED)
          i.pbIncreaseStatBasic(PBStats::SPEED,1)
          pbCommonAnimation("StatUp",i,nil)
          pbDisplay(_INTL("{1}'s Steam Engine raised its Speed!",i.pbThis))
        end
      end
      # Wandering Spirit
      if i.hasWorkingAbility(:WANDERINGSPIRIT) && ($fefieldeffect == 12 ||
       $fefieldeffect == 40)
        if !i.pbTooLow?(PBStats::SPEED)
          i.pbReduceStatBasic(PBStats::SPEED,1)
          pbCommonAnimation("StatDown",i,nil)
          pbDisplay(_INTL("{1}'s Wandering Spirit lowered its Speed!",i.pbThis))
        end
      end
    end
    # Held berries/Leftovers/Black Sludge
    for i in priority
      next if i.isFainted?
      i.pbBerryCureCheck(true)
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Aqua Ring
    for i in priority
      next if i.hp<=0
      if i.effects[PBEffects::AquaRing]
        if $fefieldeffect == 11 &&
         !i.pbHasType?(:STEEL) && !i.pbHasType?(:POISON)
          @scene.pbDamageAnimation(i,0)
          i.pbReduceHP((i.totalhp/16).floor)
          pbDisplay(_INTL("{1}'s Aqua Ring absorbed poison!",i.pbThis)) if hpgain>0
          if i.hp<=0
            return if !i.pbFaint
          end
        elsif i.effects[PBEffects::HealBlock]==0
          hpgain=(i.totalhp/16).floor
          hpgain=(hpgain*1.3).floor if isConst?(i.item,PBItems,:BIGROOT)
          hpgain=(hpgain*2).floor if $fefieldeffect == 3 ||
           $fefieldeffect == 8 || $fefieldeffect == 21 || $fefieldeffect == 22
          hpgain=i.pbRecoverHP(hpgain,true)
          pbDisplay(_INTL("{1}'s Aqua Ring restored its HP a little!",i.pbThis)) if hpgain>0
        end
      end
    end
    # Ingrain
    for i in priority
      next if i.hp<=0
      if i.effects[PBEffects::Ingrain]
        if ($fefieldeffect == 8 || $fefieldeffect == 10 || $fefieldeffect == 41) &&
         (!i.pbHasType?(:STEEL) && !i.pbHasType?(:POISON))
          @scene.pbDamageAnimation(i,0)
          i.pbReduceHP((i.totalhp/16).floor)
          pbDisplay(_INTL("{1} absorbed foul nutrients with its roots!",i.pbThis))
          if i.hp<=0
            return if !i.pbFaint
          end
        else
          if ($fefieldeffect == 33 && $fecounter >2)
            hpgain=(i.totalhp/4).floor
          elsif ($fefieldeffect == 15 || ($fefieldeffect == 33 && $fecounter >0))
            hpgain=(i.totalhp/8).floor
          elsif i.effects[PBEffects::HealBlock]==0
            hpgain=(i.totalhp/16).floor
          end
          if i.effects[PBEffects::HealBlock]==0
            hpgain=(hpgain*1.3).floor if isConst?(i.item,PBItems,:BIGROOT)
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} absorbed nutrients with its roots!",i.pbThis)) if hpgain>0
          end
        end
      end
    end
    # Leech Seed
    for i in priority
      next if i.isFainted?
      if (i.effects[PBEffects::LeechSeed]>=0)
        recipient=@battlers[i.effects[PBEffects::LeechSeed]]
        if recipient && !recipient.isFainted?  && !i.hasWorkingAbility(:MAGICGUARD) &&  !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) # if recipient exists
          pbCommonAnimation("LeechSeed",recipient,i)
          hploss=(i.totalhp/8).floor
          ooze=i.hasWorkingAbility(:LIQUIDOOZE)
          if i.effects[PBEffects::ShieldLife]>0
            pbShieldDamage(i,hploss)
          else
            hploss=i.pbReduceHP(hploss,true)
          end
          if ooze && hploss>0
            recipient.pbTakeLiquidOozeDamage(hploss)
          elsif recipient.effects[PBEffects::HealBlock]==0 && hploss>0
            hploss*=2 if $fefieldeffect==19
            hploss=(hploss*1.3).floor if recipient.hasWorkingItem(:BIGROOT)
            pbDisplay(_INTL("{1}'s health was sapped by Leech Seed!",i.pbThis)) if recipient.pbRecoverHP(hploss,true)>0
          end
          if i.isFainted?
            return if !i.pbFaint
          end
          if recipient.isFainted?
            return if !recipient.pbFaint
          end
        end
      end
    end
    for i in priority
      next if i.isFainted?
      if (i.effects[PBEffects::Crushing]>=0)
        recipient=@battlers[i.effects[PBEffects::Crushing]]
        if recipient && !recipient.isFainted?  && !i.hasWorkingAbility(:MAGICGUARD) &&  !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) # if recipient exists
          pbCommonAnimation("Crushing",recipient,i)
          if i.effects[PBEffects::ShieldLife]>0
            petridamage=i.totalhp/8
            pbShieldDamage(i,petridamage)
          else
            hploss=i.pbReduceHP((i.totalhp/8).floor,true)
          end
          hploss= hploss * 2 if $fefieldeffect == 19
          recipient.effects[PBEffects::HealBlock]==0
          hploss=(hploss*1.3).floor if recipient.hasWorkingItem(:BIGROOT)
          recipient.pbRecoverHP(hploss,true)
          pbDisplay(_INTL("{1}'s health was drained by {2}!",i.pbThis,recipient.pbThis))
          if i.isFainted?
            return if !i.pbFaint
          end
          if recipient.isFainted?
            return if !recipient.pbFaint
          end
        end
      end
    end
    if @field.effects[PBEffects::VileMercy]>0
      for battler in priority
        next if battler.isFainted? || !battler.pbCanPoison?(false)
        battler.pbPoison(battler)
        pbDisplay(_INTL("{1} was poisoned by the vile miasma!",battler.pbThis))
      end
    end
    for i in priority
      next if i.isFainted?
      # Poison/Bad poison
      if isConst?(i.species,PBSpecies,:ZANGOOSE) && isConst?(i.item,PBItems,:ZANGCREST)
        if i.pbCanPoison?(false)
          pbDisplay(_INTL("{1} was poisoned by the Zangoose Crest!",i.pbThis))
          i.pbPoison(i)
        end
      end
      if i.status==PBStatuses::POISON  && !i.hasWorkingAbility(:MAGICGUARD) && !i.hasWorkingAbility(:TOXICBOOST) &&
        !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        if i.hasWorkingAbility(:POISONHEAL) || (isConst?(i.species,PBSpecies,:ZANGOOSE) &&
           isConst?(i.item,PBItems,:ZANGCREST))
          if i.effects[PBEffects::HealBlock]==0
            if i.hp<i.totalhp
              pbCommonAnimation("Poison",i,nil)
              i.pbRecoverHP((i.totalhp/8).floor,true)
              pbDisplay(_INTL("{1} is healed by poison!",i.pbThis))
            end
            if i.statusCount>0 && !i.isBoss
              i.effects[PBEffects::Toxic]+=1
              i.effects[PBEffects::Toxic]=[15,i.effects[PBEffects::Toxic]].min
            end
          end
        else
          i.pbContinueStatus
          if i.effects[PBEffects::ShieldLife]>0
            poisondamage=i.totalhp/8
            pbShieldDamage(i,poisondamage)
          elsif i.isBoss
            poisondamage=i.totalhp/16
            pbShieldDamage(i,poisondamage)
          elsif (i.statusCount==0)
            i.pbReduceHP((i.totalhp/8).floor)
          else
            if !i.isBoss
              i.effects[PBEffects::Toxic]+=1
              i.effects[PBEffects::Toxic]=[15,i.effects[PBEffects::Toxic]].min
              i.pbReduceHP((i.totalhp/16).floor*i.effects[PBEffects::Toxic])
            end
          end
        end
      end
      # Burn
      if i.status==PBStatuses::BURN &&!i.hasWorkingAbility(:MAGICGUARD) && !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        i.pbContinueStatus
        if i.effects[PBEffects::ShieldLife]>0
          burndamage=i.totalhp/16
          pbShieldDamage(i,burndamage)
        elsif i.hasWorkingAbility(:HEATPROOF) || SilvallyCheck(i,PBTypes::STEEL) || $fefieldeffect == 13
          i.pbReduceHP((i.totalhp/32).floor)
        else
          i.pbReduceHP((i.totalhp/16).floor)
        end
      end
      # Paralysis - saps HP like burn
      if i.status==PBStatuses::PARALYSIS && !i.hasWorkingAbility(:MAGICGUARD) && !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        i.pbContinueStatus
        if i.effects[PBEffects::ShieldLife]>0
          paradamage=i.totalhp/16
          pbShieldDamage(i,paradamage)
        else
          i.pbReduceHP((i.totalhp/16).floor)
        end
      end
      # Freeze - saps HP like burn
      if i.status==PBStatuses::FROZEN && !i.hasWorkingAbility(:MAGICGUARD) && !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        i.pbContinueStatus
        if i.effects[PBEffects::ShieldLife]>0
          freezedamage=i.totalhp/16
          pbShieldDamage(i,freezedamage)
        else
          i.pbReduceHP((i.totalhp/16).floor)
        end
      end
      if i.effects[PBEffects::FlameWreath]>0
        i.effects[PBEffects::FlameWreath]-=1
      end
      if i.effects[PBEffects::MudBath]>0
        pbWithStatChangeSource([:move,PBMoves::MUDBATH,i.effects[PBEffects::MudBath]]) do
          [PBStats::DEFENSE,PBStats::SPDEF].each do |stat|
            i.pbIncreaseStat(stat,1,false,PBMoves::MUDBATH,i)
          end
        end
        i.effects[PBEffects::MudBath]-=1
      end
      [PBEffects::CarapaceShed,PBEffects::CarapaceGift].each do |effect|
        overlay=i.effects[effect]
        i.effects[effect]=nil if overlay && @turncount+1>=overlay[1]
      end
      # Circadian Rhythm sleep-turn growth
      if i.effects[PBEffects::CircadianRhythm]
        if i.status==PBStatuses::SLEEP && !i.isFainted?
          showanim=true
          [PBStats::ATTACK,PBStats::SPATK,PBStats::SPEED].each do |stat|
            next if !i.pbCanIncreaseStatStage?(stat,false)
            i.pbIncreaseStat(stat,1,false,PBMoves::CIRCADIANRRHYTHM,i,showanim)
            showanim=false
          end
        else
          i.effects[PBEffects::CircadianRhythm]=false
        end
      end
      # Molten Stance converts its defensive posture at the end of this turn.
      if i.effects[PBEffects::MoltenStance]
        i.effects[PBEffects::MoltenStance]=false
        if !i.isFainted?
          showanim=true
          [PBStats::DEFENSE,PBStats::SPDEF].each do |stat|
            next if !i.pbCanReduceStatStage?(stat,false)
            i.pbReduceStat(stat,2,false,PBMoves::MOLTENSTANCE,i,showanim)
            showanim=false
          end
          if i.pbCanIncreaseStatStage?(PBStats::SPEED,false)
            i.pbIncreaseStat(PBStats::SPEED,2,false,PBMoves::MOLTENSTANCE,i,showanim)
          end
        end
      end
      # One embedded needle is consumed every end of round.
      if i.effects[PBEffects::Needles]>0 && !i.isFainted?
        i.azureConsumeNeedle
        if i.isFainted?
          return if !i.pbFaint
          next
        end
      end
      # Wounds - saps 1/12 HP each turn
      if i.effects[PBEffects::Wounded]>0 && !i.hasWorkingAbility(:MAGICGUARD) && !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        pbDisplay(_INTL("{1} is hurt by its wounds!",i.pbThis))
        if i.effects[PBEffects::ShieldLife]>0
          wounddamage=i.totalhp/12
          pbShieldDamage(i,wounddamage)
        else
          i.pbReduceHP((i.totalhp/12).floor)
        end
        i.effects[PBEffects::Wounded]-=1
        pbDisplay(_INTL("{1}'s wounds healed!",i.pbThis)) if i.effects[PBEffects::Wounded]<=0
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Curse
    for i in priority
      next if i.isFainted?
      if $fefieldeffect == 29 && i.effects[PBEffects::Curse]
        i.effects[PBEffects::Curse] = false
        pbDisplay(_INTL("{1}'s curse was lifted!",i.pbThis))
      end
      if i.effects[PBEffects::Curse] &&
          !i.hasWorkingAbility(:MAGICGUARD) &&
          !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          pbCommonAnimation("Curse",i,nil)
        pbDisplay(_INTL("{1} is afflicted by the curse!",i.pbThis))
        if i.effects[PBEffects::ShieldLife]>0
          cursedamage=i.totalhp/8
          pbShieldDamage(i,cursedamage)
        else
          if !i.isBoss
            i.pbReduceHP((i.totalhp/4).floor,true)
          else
            i.pbReduceHP((i.totalhp/16).floor,true)
          end
        end
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Aftershock delayed hits
    for target in priority
      next if target.effects[PBEffects::Aftershock]<=0
      moveid=target.effects[PBEffects::AftershockMove]
      userindex=target.effects[PBEffects::AftershockUser]
      target.effects[PBEffects::Aftershock]=0
      target.effects[PBEffects::AftershockMove]=0
      target.effects[PBEffects::AftershockUser]=-1
      next if target.isFainted? || !moveid || moveid<=0
      user=(userindex && userindex>=0) ? @battlers[userindex] : nil
      next if !user || !user.pokemon
      move=PokeBattle_Move.pbFromPBMove(self,PBMove.new(moveid),user)
      next if !move
      move.instance_variable_set(:@azure_aftershock_echo,true)
      pbDisplay(_INTL("The aftershock struck {1}!",target.pbThis))
      target.damagestate.reset
      move.pbEffect(user,target,0,nil,true)
      if target.damagestate.calcdamage>0 &&
         !(user.hasWorkingAbility(:SHEERFORCE) || SilvallyCheck(user,PBTypes::GROUND)) &&
         ((!target.hasWorkingAbility(:SHIELDDUST) || target.moldbroken) || move.hasFlags?("m")) &&
         target.pbOwnSide.effects[PBEffects::LuckyChant]==0
        chance=move.addlEffect
        chance*=2 if user.hasWorkingAbility(:SERENEGRACE) || $fefieldeffect==9 ||
          @field.effects[PBEffects::Rainbow]>0
        pbWithStatChangeSource([:move,move.id]) do
          move.pbApplyAdditionalEffects(user,target,chance)
        end
      end
      if target.isFainted?
        return if !target.pbFaint
      end
    end
    # Counterpoise retains doubled Defense through delayed attacks, then swaps.
    for battler in priority
      next if battler.isFainted? || !battler.effects[PBEffects::Counterpoise]
      battler.effects[PBEffects::Counterpoise]=false
      battler.effects[PBEffects::PowerTrick]=!battler.effects[PBEffects::PowerTrick]
      pbDisplay(_INTL("{1} swapped its Attack and Defense!",battler.pbThis))
    end
    # Salt Cure
    for i in priority
      next if i.isFainted? || !i.effects[PBEffects::SaltCure]
      next if i.hasWorkingAbility(:MAGICGUARD)
      next if i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect==44
      divisor=(i.pbHasType?(:STEEL) || i.pbHasType?(:WATER)) ? 4 : 8
      damage=[(i.totalhp/divisor).floor,1].max
      pbCommonAnimation("SaltCure",i,nil)
      pbDisplay(_INTL("{1} is hurt by Salt Cure!",i.pbThis))
      i.pbReduceHP(damage,true)
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Multi-turn attacks (Bind/Clamp/Fire Spin/Magma Storm/Sand Tomb/Whirlpool/Wrap)
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::MultiTurn]>0
        if i.effects[PBEffects::MultiTurnAttack]==PBMoves::TOUGHLOVE
          source_index=i.effects[PBEffects::MultiTurnUser]
          source=source_index>=0 ? @battlers[source_index] : nil
          if source && !source.isFainted? && source.effects[PBEffects::HealBlock]==0
            restored=source.pbRecoverHP([source.totalhp/8,1].max,true)
            pbDisplay(_INTL("{1}'s HP was restored by Tough Love!",source.pbThis)) if restored>0
          end
        end
        i.effects[PBEffects::MultiTurn]-=1
        movename=PBMoves.getName(i.effects[PBEffects::MultiTurnAttack])
        if i.effects[PBEffects::MultiTurn]==0
          pbDisplay(_INTL("{1} was freed from {2}!",i.pbThis,movename))
          i.pbClearMultiTurn
        elsif !i.hasWorkingAbility(:MAGICGUARD)
          pbDisplay(_INTL("{1} is hurt by {2}!",i.pbThis,movename))
          if isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:BIND)
            pbCommonAnimation("Bind",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:CLAMP)
            pbCommonAnimation("Clamp",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:FIRESPIN)
            pbCommonAnimation("FireSpin",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:MAGMASTORM)
            pbCommonAnimation("MagmaStorm",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:SANDTOMB)
            pbCommonAnimation("SandTomb",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:WRAP)
            pbCommonAnimation("Wrap",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:INFESTATION)
            pbCommonAnimation("Infestation",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:WHIRLPOOL)
            pbCommonAnimation("Whirlpool",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:QUICKSILVERSPEAR)
            pbCommonAnimation("QuicksilverSpear",i,nil)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:DESERTSMARK)
            pbCommonAnimation("DesertsMark",i,nil)
          else
            pbCommonAnimation("Wrap",i,nil)
          end
          @scene.pbDamageAnimation(i,0)
        if !(i.effects[PBEffects::ShieldLife]>0)
          if i.effects[PBEffects::MultiTurnBindingBand]
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:MAGMASTORM) &&
           $fefieldeffect == 32
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:FIRESPIN) &&
           $fefieldeffect == 40
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:SANDTOMB) &&
           $fefieldeffect == 12
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:DESERTSMARK) &&
           $fefieldeffect == 12
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:WHIRLPOOL) &&
           ($fefieldeffect == 21 || $fefieldeffect == 22)
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:INFESTATION) &&
           $fefieldeffect == 15
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:SNAPTRAP) &&
           $fefieldeffect == 2
            i.pbReduceHP((i.totalhp/6).floor)
          elsif isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:INFESTATION) &&
           $fefieldeffect == 33 && $fecounter > 1
              case $fecounter
                when 2
                  i.pbReduceHP((i.totalhp/6).floor)
                when 3
                  i.pbReduceHP((i.totalhp/4).floor)
                when 4
                  i.pbReduceHP((i.totalhp/3).floor)
              end
          else
            i.pbReduceHP((i.totalhp/8).floor)
          end
        else
          if isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:QUICKSILVERSPEAR)
            multiturndamage=i.totalhp/4
            pbShieldDamage(i,multiturndamage)
          else
            multiturndamage=i.totalhp/8
            pbShieldDamage(i,multiturndamage)
          end
        end
          if isConst?(i.effects[PBEffects::MultiTurnAttack],PBMoves,:SANDTOMB) &&
           $fefieldeffect == 20
            i.pbCanReduceStatStage?(PBStats::ACCURACY)
            i.pbReduceStat(PBStats::ACCURACY,1,true)
          end
        end
      end
      if i.hp<=0
        return if !i.pbFaint
        next
      end
    end
    # Syrup Bomb
    for i in priority
      next if i.isFainted? || i.effects[PBEffects::SyrupBombTurns]<=0
      sourceindex=i.effects[PBEffects::SyrupBombUser]
      source=(sourceindex && sourceindex>=0) ? @battlers[sourceindex] : nil
      if i.pbCanReduceStatStage?(PBStats::SPEED,false)
        pbCommonAnimation("StatDown",i,nil)
        i.pbReduceStat(PBStats::SPEED,1,false,PBMoves::SYRUPBOMB,source,false,false)
      end
      i.effects[PBEffects::SyrupBombTurns]-=1
      if i.effects[PBEffects::SyrupBombTurns]<=0
        i.effects[PBEffects::SyrupBombTurns]=0
        i.effects[PBEffects::SyrupBombUser]=-1
      end
    end
    # Timed infatuation
    for i in priority
      next if i.isFainted? || i.effects[PBEffects::AttractTurns]<=0
      i.effects[PBEffects::AttractTurns]-=1
      if i.effects[PBEffects::Attract]>=0 && i.effects[PBEffects::AttractTurns]==0
        i.pbCureAttract
        pbDisplay(_INTL("{1}'s infatuation wore off!",i.pbThis))
      end
    end
    # Taunt
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Taunt]>0
        i.effects[PBEffects::Taunt]-=1
        if i.effects[PBEffects::Taunt]==0
          pbDisplay(_INTL("{1} recovered from the taunting!",i.pbThis))
        end
      end
    end
    # Encore
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Encore]>0
        if i.moves[i.effects[PBEffects::EncoreIndex]].id!=i.effects[PBEffects::EncoreMove]
          i.effects[PBEffects::Encore]=0
          i.effects[PBEffects::EncoreIndex]=0
          i.effects[PBEffects::EncoreMove]=0
        else
          i.effects[PBEffects::Encore]-=1
          if i.effects[PBEffects::Encore]==0 || i.moves[i.effects[PBEffects::EncoreIndex]].pp==0
            i.effects[PBEffects::Encore]=0
            pbDisplay(_INTL("{1}'s encore ended!",i.pbThis))
          end
        end
      end
    end
    # Disable/Cursed Body
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Disable]>0
        i.effects[PBEffects::Disable]-=1
        if i.effects[PBEffects::Disable]==0
          i.effects[PBEffects::DisableMove]=0
          pbDisplay(_INTL("{1} is disabled no more!",i.pbThis))
        end
      end
    end
    # Magnet Rise
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::MagnetRise]>0 && !(isConst?(i.species,PBSpecies,:PROBOPASS) && isConst?(i.item,PBItems,:PROBOCREST))
        i.effects[PBEffects::MagnetRise]-=1
        if i.effects[PBEffects::MagnetRise]==0
          pbDisplay(_INTL("{1} stopped levitating.",i.pbThis))
        end
      end
    end
    # Telekinesis
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Telekinesis]>0
        i.effects[PBEffects::Telekinesis]-=1
        if i.effects[PBEffects::Telekinesis]==0
          pbDisplay(_INTL("{1} stopped levitating.",i.pbThis))
        end
      end
    end
    # Heal Block
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::HealBlock]>0
        i.effects[PBEffects::HealBlock]-=1
        if i.effects[PBEffects::HealBlock]==0
          pbDisplay(_INTL("The heal block on {1} ended.",i.pbThis))
        end
      end
    end
    # Embargo
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Embargo]>0
        i.effects[PBEffects::Embargo]-=1
        if i.effects[PBEffects::Embargo]==0
          pbDisplay(_INTL("The embargo on {1} was lifted.",i.pbThis(true)))
        end
      end
    end
    # LeerBlock
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::LeerBlock]>0
        i.effects[PBEffects::LeerBlock]-=1
        if i.effects[PBEffects::LeerBlock]==0
          pbDisplay(_INTL("{1} can eat again!",i.pbThis))
        end
      end
    end
    # Frisk Lock
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::FriskLock]>0
        i.effects[PBEffects::FriskLock]-=1
        if i.effects[PBEffects::FriskLock]==0
          pbDisplay(_INTL("{1}'s item is no longer locked!",i.pbThis))
        end
      end
    end
    # Forewarn Disable
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::ForewarnDisable]>0
        i.effects[PBEffects::ForewarnDisable]-=1
        if i.effects[PBEffects::ForewarnDisable]==0
          i.effects[PBEffects::ForewarnDisableMove]=0
          pbDisplay(_INTL("{1} is no longer forewarned!",i.pbThis))
        end
      end
    end
    # Yawn
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Yawn]>0
        i.effects[PBEffects::Yawn]-=1
        if i.effects[PBEffects::Yawn]==0 && i.pbCanSleepYawn?
          i.pbSleepSelf(2)  # Yawn causes 1 full turn of sleep
          pbDisplay(_INTL("{1} fell asleep!",i.pbThis))
        end
      end
    end
    # Perish Song
    perishSongUsers=[]
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::PerishSong]>0
        i.effects[PBEffects::PerishSong]-=1
        pbDisplay(_INTL("{1}'s Perish count fell to {2}!",i.pbThis,i.effects[PBEffects::PerishSong]))
        if i.effects[PBEffects::PerishSong]==0
          perishSongUsers.push(i.effects[PBEffects::PerishSongUser])
          i.pbReduceHP(i.hp,true)
        end
      end
      if i.isFainted?
        return if !i.pbFaint
      end
    end
    if perishSongUsers.length>0
      # If all remaining Pokemon fainted by a Perish Song triggered by a single side
      if (perishSongUsers.find_all{|item| pbIsOpposing?(item) }.length==perishSongUsers.length) ||
         (perishSongUsers.find_all{|item| !pbIsOpposing?(item) }.length==perishSongUsers.length)
        pbJudgeCheckpoint(@battlers[perishSongUsers[0]])
      end
    end
    if @decision>0
      pbGainEXP
      return
    end
    # Reflect
    for i in 0...2
      if sides[i].effects[PBEffects::Reflect]>0
        sides[i].effects[PBEffects::Reflect]-=1
        if sides[i].effects[PBEffects::Reflect]==0
          pbDisplay(_INTL("Your team's Reflect faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Reflect faded!")) if i==1
        end
      end
    end
    # Light Screen
    for i in 0...2
      if sides[i].effects[PBEffects::LightScreen]>0
        sides[i].effects[PBEffects::LightScreen]-=1
        if sides[i].effects[PBEffects::LightScreen]==0
          pbDisplay(_INTL("Your team's Light Screen faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Light Screen faded!")) if i==1
        end
      end
    end
    # Aurora Veil
    for i in 0...2
      if sides[i].effects[PBEffects::AuroraVeil]>0
        sides[i].effects[PBEffects::AuroraVeil]-=1
        if sides[i].effects[PBEffects::AuroraVeil]==0
          pbDisplay(_INTL("Your team's Aurora Veil faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Aurora Veil faded!")) if i==1
        end
      end
    end
    # Arenite Veil
    for i in 0...2
      if sides[i].effects[PBEffects::AreniteWall]>0
        sides[i].effects[PBEffects::AreniteWall]-=1
        if sides[i].effects[PBEffects::AreniteWall]==0
          pbDisplay(_INTL("Your team's Arenite Wall faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Arenite Wall faded!")) if i==1
        end
      end
    end
    # Wide Guard
    for i in 0...2
      if sides[i].effects[PBEffects::WideGuard]>0
        sides[i].effects[PBEffects::WideGuard]-=1
        if sides[i].effects[PBEffects::WideGuard]==0
          pbDisplay(_INTL("Your team's Wide Guard faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Wide Guard faded!")) if i==1
        end
      end
    end
    # Quick Guard
    for i in 0...2
      if sides[i].effects[PBEffects::QuickGuard]>0
        sides[i].effects[PBEffects::QuickGuard]-=1
        if sides[i].effects[PBEffects::QuickGuard]==0
          pbDisplay(_INTL("Your team's Quick Guard faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Quick Guard faded!")) if i==1
        end
      end
    end
    # Mirror Coat / Counter Stance buff turn countdown
    for battler in @battlers
      next if battler.nil?
      if battler.effects[PBEffects::MirrorCoatBuff] > 0
        battler.effects[PBEffects::MirrorCoatBuff] -= 1
      end
      if battler.effects[PBEffects::CounterStance] > 0
        battler.effects[PBEffects::CounterStance] -= 1
      end
    end
    # Bonfire
    for i in 0...2
      next if sides[i].effects[PBEffects::Bonfire] <= 0
      for battler in @battlers
        next if battler.isFainted?
        next if pbIsOpposing?(battler.index) != (i==1)
        hpgain = [(battler.totalhp/8).floor,1].max
        hpgain = battler.pbRecoverHP(hpgain,true)
        pbDisplay(_INTL("{1} was soothed by the bonfire!",battler.pbThis)) if hpgain>0
      end
      sides[i].effects[PBEffects::Bonfire] -= 1
      if sides[i].effects[PBEffects::Bonfire] == 0
        pbDisplay(_INTL("The bonfire on your side burned out!")) if i==0
        pbDisplay(_INTL("The bonfire on the opposing side burned out!")) if i==1
      end
    end
    # Scorching Ground
    for i in 0...2
      next if sides[i].effects[PBEffects::ScorchingGround] <= 0
      sides[i].effects[PBEffects::ScorchingGround] -= 1
      if sides[i].effects[PBEffects::ScorchingGround] == 0
        pbDisplay(_INTL("The scorching ground on your side cooled off!")) if i==0
        pbDisplay(_INTL("The scorching ground on the opposing side cooled off!")) if i==1
      end
    end
    # Safeguard
    for i in 0...2
      if sides[i].effects[PBEffects::Safeguard]>0
        sides[i].effects[PBEffects::Safeguard]-=1
        if sides[i].effects[PBEffects::Safeguard]==0
          pbDisplay(_INTL("Your team is no longer protected by Safeguard!")) if i==0
          pbDisplay(_INTL("The opposing team is no longer protected by Safeguard!")) if i==1
        end
      end
    end
    # Mist
    for i in 0...2
      if sides[i].effects[PBEffects::Mist]>0
        sides[i].effects[PBEffects::Mist]-=1
        if sides[i].effects[PBEffects::Mist]==0
          pbDisplay(_INTL("Your team's Mist faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Mist faded!")) if i==1
        end
      end
    end
    # Tailwind
    for i in 0...2
      if sides[i].effects[PBEffects::Tailwind]>0
        sides[i].effects[PBEffects::Tailwind]-=1 if !azureJetstreamForSide?(i)
        if sides[i].effects[PBEffects::Tailwind]==0
          pbDisplay(_INTL("Your team's tailwind stopped blowing!")) if i==0
          pbDisplay(_INTL("The opposing team's tailwind stopped blowing!")) if i==1
        end
      end
    end
    # Lucky Chant
    for i in 0...2
      if sides[i].effects[PBEffects::LuckyChant]>0
        sides[i].effects[PBEffects::LuckyChant]-=1
        if sides[i].effects[PBEffects::LuckyChant]==0
          pbDisplay(_INTL("Your team's Lucky Chant faded!")) if i==0
          pbDisplay(_INTL("The opposing team's Lucky Chant faded!")) if i==1
        end
      end
    end
    # Plus/Minus signals
    for i in 0...2
      if sides[i].effects[PBEffects::PlusSignal]>0
        sides[i].effects[PBEffects::PlusSignal]-=1
        if sides[i].effects[PBEffects::PlusSignal]==0
          pbDisplay(_INTL("Plus energy faded for that side!")) if i==0
          pbDisplay(_INTL("Plus energy faded for the opposing side!")) if i==1
        end
      end
      if sides[i].effects[PBEffects::MinusSignal]>0
        sides[i].effects[PBEffects::MinusSignal]-=1
        if sides[i].effects[PBEffects::MinusSignal]==0
          pbDisplay(_INTL("Minus energy faded for that side!")) if i==0
          pbDisplay(_INTL("Minus energy faded for the opposing side!")) if i==1
        end
      end
    end
    # Pressure Plate
    for i in 0...2
      if sides[i].effects[PBEffects::PressurePlate]>0
        sides[i].effects[PBEffects::PressurePlate]-=1
        if sides[i].effects[PBEffects::PressurePlate]==0
          pbDisplay(_INTL("The pressure plate beneath your team crumbled!")) if i==0
          pbDisplay(_INTL("The pressure plate beneath the opposing team crumbled!")) if i==1
        end
      end
    end
    # Vile Mercy
    if @field.effects[PBEffects::VileMercy]>0
      @field.effects[PBEffects::VileMercy]-=1
      if @field.effects[PBEffects::VileMercy]==0
        pbDisplay(_INTL("The vile miasma dispersed."))
      end
    end
    # Blue Shift
    if @field.effects[PBEffects::BlueShift]>0
      @field.effects[PBEffects::BlueShift]-=1
      if @field.effects[PBEffects::BlueShift]==0
        pbDisplay(_INTL("The type chart returned to normal."))
      end
    end
    @sides.each_with_index do |side,index|
      expiring=side.effects[PBEffects::DoubleDose]==1
      [PBEffects::EtherealCloak,PBEffects::DoubleDose].each do |effect|
        side.effects[effect]-=1 if side.effects[effect]>0
      end
      if expiring
        activeBattlerIndices.each do |slot|
          @battlers[slot].pbDiscardConsumableHeldItemDose if (slot%2)==index
        end
      end
    end
    # Gravity
    if @field.effects[PBEffects::Gravity]>0 && $fefieldeffect!=39
      @field.effects[PBEffects::Gravity]-=1
      if @field.effects[PBEffects::Gravity]==0
        pbDisplay(_INTL("Gravity returned to normal."))
        if $febackup == 35 && $fefieldeffect != 35
          $fefieldeffect = $febackup
          pbDisplay(_INTL("The world broke apart again!"))
          @weatherduration=0
          @field.effects[PBEffects::Terrain]=0
          pbChangeBGSprite
          seedCheck
        end
      end
    end
    # Terrain
    if @field.effects[PBEffects::Splintered]>0
      @field.effects[PBEffects::Splintered]-=1
      if @field.effects[PBEffects::Splintered]==0
        $fefieldeffect = $febackup
        pbChangeBGSprite
        seedCheck
      end
    end
    if @field.effects[PBEffects::Terrain]>0
      terrain=[@field.effects[PBEffects::Terrain]].max
      terrain-=1
      @field.effects[PBEffects::Terrain] = terrain
      if terrain==0
        if pbFieldEffectID($game_variables[708])==$febackup && $game_variables[298]==40 #pk code
          $fefieldeffect=$game_variables[298]
        else
          $fefieldeffect = $febackup
        end
        pbDisplay(_INTL("The terrain returned to normal."))
        if $fefieldeffect>0
          pbRestoreFieldBack
        else
          pbChangeBGSprite
        end
        #pbChangeBGSprite
        seedCheck
      end
    end
    # Trick Room
    if @trickroom > 0 && $fefieldeffect!=39 && !($game_variables[702]==1 || $game_variables[702]==4)
      @trickroom=@trickroom-1
      if @trickroom == 0
          pbDisplay(_INTL("The twisted dimensions returned to normal!"))
      end
    end
    # Wonder Room
#### KUROTSUNE - 014 - START
    if @field.effects[PBEffects::WonderRoom] > 0 && $fefieldeffect!=39 && !($game_variables[702]==2 || $game_variables[702]==4)
      @field.effects[PBEffects::WonderRoom] -= 1
      if @field.effects[PBEffects::WonderRoom] == 0
        for i in @battlers
          if i.wonderroom
            i.pbSwapDefenses
          end
        end
        pbDisplay(_INTL("Wonder Room wore off, and the Defense and Sp. Def stats returned to normal!"))
      end
    end
#### KUROTSUNE - 014 - END
    # Magic Room
    if @field.effects[PBEffects::MagicRoom]>0 && $fefieldeffect!=39 && !($game_variables[702]==3 || $game_variables[702]==5)
      @field.effects[PBEffects::MagicRoom]-=1
      if @field.effects[PBEffects::MagicRoom]==0
        pbDisplay(_INTL("The area returned to normal."))
      end
    end
    # Overlaying Terrain
    if @field.effects[PBEffects::ElectricTerrain]>0
      @field.effects[PBEffects::ElectricTerrain]-=1
      if @field.effects[PBEffects::ElectricTerrain]==0
        pbDisplay(_INTL("The surging electricity dissipated."))
      end
    end
    if @field.effects[PBEffects::MistyTerrain]>0
      @field.effects[PBEffects::MistyTerrain]-=1
      if @field.effects[PBEffects::MistyTerrain]==0
        pbDisplay(_INTL("The surrounding mist dispersed."))
      end
    end
    if @field.effects[PBEffects::GrassyTerrain]>0
      if $fefieldeffect==7 || $fefieldeffect==16 || $fefieldeffect==45
        @field.effects[PBEffects::GrassyTerrain]=0
        pbDisplay(_INTL("The surrounding grass was burnt to a crisp!"))
      else
        @field.effects[PBEffects::GrassyTerrain]-=1
        if @field.effects[PBEffects::GrassyTerrain]==0
          pbDisplay(_INTL("The surrounding grass withered."))
        end
      end
    end
    if @field.effects[PBEffects::PsychicTerrain]>0
      @field.effects[PBEffects::PsychicTerrain]-=1
      if @field.effects[PBEffects::PsychicTerrain]==0
        pbDisplay(_INTL("The psychic energy left as mysteriously as it came."))
      end
    end
    if @field.effects[PBEffects::Rainbow]>0
      @field.effects[PBEffects::Rainbow]-=1
      if @field.effects[PBEffects::Rainbow]==0
        pbDisplay(_INTL("The rainbow disappeared."))
      end
    end
    # Fairy Lock
    if @field.effects[PBEffects::FairyLock]>0
      @field.effects[PBEffects::FairyLock]-=1
      if @field.effects[PBEffects::FairyLock]==0
        # Fairy Lock seems to have no end-of-effect text so I've added some.
        pbDisplay(_INTL("The Fairy Lock was released."))
      end
    end
    # Uproar
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::Uproar]>0
        for j in priority
          if !j.isFainted? && j.status==PBStatuses::SLEEP && !j.hasWorkingAbility(:SOUNDPROOF) && j.effects[PBEffects::Spritz] != 1
            j.status=0
            j.statusCount=0
            pbDisplay(_INTL("{1} woke up in the uproar!",j.pbThis))
          end
        end
        i.effects[PBEffects::Uproar]-=1
        if i.effects[PBEffects::Uproar]==0
          pbDisplay(_INTL("{1} calmed down.",i.pbThis))
        else
          pbDisplay(_INTL("{1} is making an uproar!",i.pbThis))
        end
      end
    end
    # Fever Pitch
    for i in priority
      next if i.isFainted?
      if i.effects[PBEffects::FeverPitch]==true
        for j in priority
          if !j.isFainted? && j.status==PBStatuses::SLEEP && !j.hasWorkingAbility(:SOUNDPROOF) && j.effects[PBEffects::Spritz] != 1
            j.status=0
            j.statusCount=0
            pbDisplay(_INTL("{1} woke up in the uproar!",j.pbThis))
          end
        end
      end
    end
    #Wasteland hazard interaction
    if $fefieldeffect == 19
      for i in priority
        next if i.isFainted?
        # SR
        if i.pbOwnSide.effects[PBEffects::StealthRock]==true
          pbDisplay(_INTL("The waste swallowed up the pointed stones!"))
          i.pbOwnSide.effects[PBEffects::StealthRock]=false
          pbDisplay(_INTL("...Rocks spewed out from the ground below!"))
          atype=getConst(PBTypes,:ROCK) || 0
          if !i.isFainted?
            eff=PBTypes.getCombinedEffectiveness(atype,i.type1,i.type2)
            if eff>0
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP([(i.totalhp*eff/16).floor,1].max)
            end
          end
          i.sameSideLivingBattlers(false).each do |ally|
            eff=PBTypes.getCombinedEffectiveness(atype,ally.type1,ally.type2)
            if eff>0
              @scene.pbDamageAnimation(ally,0)
              ally.pbReduceHP([(ally.totalhp*eff/16).floor,1].max)
            end
          end
        end
        # Spikes
        if i.pbOwnSide.effects[PBEffects::Spikes]>0
          pbDisplay(_INTL("The waste swallowed up the spikes!"))
          i.pbOwnSide.effects[PBEffects::Spikes]=0
          pbDisplay(_INTL("...Stalagmites burst up from the ground!"))
          if !i.isFainted? && !i.isAirborne?
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP([(i.totalhp/3).floor,1].max)
          end
          i.sameSideLivingBattlers(false).each do |ally|
            if !ally.isAirborne?
              @scene.pbDamageAnimation(ally,0)
              ally.pbReduceHP([(ally.totalhp/3).floor,1].max)
            end
          end
        end
        # Poison Barbs
        if i.pbOwnSide.effects[PBEffects::ToxicSpikes]>0
          pbDisplay(_INTL("The waste swallowed up the poison barbs!"))
          i.pbOwnSide.effects[PBEffects::ToxicSpikes]=0
          pbDisplay(_INTL("...Poison needles shot up from the ground!"))
          if !i.isFainted? && !i.isAirborne? &&
           !i.pbHasType?(:STEEL) && !i.pbHasType?(:POISON)
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP([(i.totalhp/8).floor,1].max)
            if i.status==0 && i.pbCanPoison?(false)
              i.status=PBStatuses::POISON
              i.statusCount=1
              i.effects[PBEffects::Toxic]=0
              pbCommonAnimation("Poison",i,nil)
            end
          end
          i.sameSideLivingBattlers(false).each do |ally|
            if !ally.isAirborne? &&
             !ally.pbHasType?(:STEEL) && !ally.pbHasType?(:POISON)
              @scene.pbDamageAnimation(ally,0)
              ally.pbReduceHP([(ally.totalhp/8).floor,1].max)
              if ally.status==0 && ally.pbCanPoison?(false)
                ally.status=PBStatuses::POISON
                ally.statusCount=1
                ally.effects[PBEffects::Toxic]=0
                pbCommonAnimation("Poison",i,nil)
              end
            end
          end
        end
        # StickyWeb
        if i.pbOwnSide.effects[PBEffects::StickyWeb]
          pbDisplay(_INTL("The waste swallowed up the sticky web!"))
          i.pbOwnSide.effects[PBEffects::StickyWeb]=false
          pbDisplay(_INTL("...Sticky string shot out of the ground!"))
          if !i.isFainted?
            if !i.pbTooLow?(PBStats::SPEED)
              i.pbReduceStatBasic(PBStats::SPEED,4)
              pbCommonAnimation("StatDown",i,nil)
              pbDisplay(_INTL("{1}'s Speed was severely lowered!",i.pbThis))
            end
          end
          i.sameSideLivingBattlers(false).each do |ally|
            if !ally.pbTooLow?(PBStats::SPEED)
              ally.pbReduceStatBasic(PBStats::SPEED,4)
              pbCommonAnimation("StatDown",ally,nil)
              pbDisplay(_INTL("{1}'s Speed was severely lowered!",ally.pbThis))
            end
          end
        end
        # Mystic Harvest Damage
        if i.pbOwnSide.effects[PBEffects::MysticTree]>0
          pbDisplay(_INTL("The waste swallowed up the trees!"))
          i.pbOwnSide.effects[PBEffects::MysticTree]=0
          pbDisplay(_INTL("...Leaves and branches spewed out from the ground!"))
          atype=getConst(PBTypes,:GRASS) || 0
          if !i.isFainted?
            eff=PBTypes.getCombinedEffectiveness(atype,i.type1,i.type2)
            if eff>0
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP([(i.totalhp*eff/24).floor,1].max)
            end
          end
          i.sameSideLivingBattlers(false).each do |ally|
            eff=PBTypes.getCombinedEffectiveness(atype,ally.type1,ally.type2)
            if eff>0
              @scene.pbDamageAnimation(ally,0)
              ally.pbReduceHP([(ally.totalhp*eff/24).floor,1].max)
            end
          end
        end
        if i.hp<=0
          return if !i.pbFaint
          next
        end
      end
    end
    # End Wasteland hazards
    for i in priority
      next if i.isFainted?
      # Mimicry
      if i.hasWorkingAbility(:MIMICRY)
        protype = -1
        case $fefieldeffect
        when 1
          protype = :ELECTRIC || 0
        when 2
          protype = :GRASS || 0
        when 3
          protype = :FAIRY || 0
        when 4
          protype = :DARK || 0
        when 5
          protype = :PSYCHIC || 0
        when 6
          protype = :NORMAL || 0
        when 7
          protype = :FIRE || 0
        when 8
          protype = :WATER || 0
        when 9
          protype = :DRAGON || 0
        when 10
          protype = :POISON || 0
        when 11
          protype = :POISON || 0
        when 12
          protype = :GROUND || 0
        when 13
          protype = :ICE || 0
        when 14
          protype = :ROCK || 0
        when 15
          protype = :BUG || 0
        when 16
          protype = :FIRE || 0
        when 17
          protype = :STEEL || 0
        when 18
          protype = :ELECTRIC || 0
        when 19
          protype = :POISON || 0
        when 20
          protype = :GROUND || 0
        when 21
          protype = :WATER || 0
        when 22
          protype = :WATER || 0
        when 23
          protype = :ROCK || 0
        when 24
          protype = :FLYING || 0
        when 25
          rnd=pbRandom(4)
          case rnd
          when 0
            protype = :GRASS || 0
          when 1
            protype = :WATER || 0
          when 2
            protype = :FIRE || 0
          when 3
            protype = :PSYCHIC || 0
          end
        when 26
          protype = :POISON || 0
        when 27
          protype = :ROCK || 0
        when 28
          protype = :ICE || 0
        when 29
          protype = :NORMAL || 0
        when 30
          protype = :STEEL || 0
        when 31
          protype = :FAIRY || 0
        when 32
          protype = :DRAGON || 0
        when 33
          protype = :GRASS || 0
        when 34
          protype = :DARK || 0
        when 35
          rnd=pbRandom(18)
          case rnd
          when 0
            protype = :NORMAL || 0
          when 1
            protype = :WATER || 0
          when 2
            protype = :FIRE || 0
          when 3
            protype = :ELECTRIC || 0
          when 4
            protype = :GRASS || 0
          when 5
            protype = :ICE || 0
          when 6
            protype = :FIGHTING || 0
          when 7
            protype = :POISON || 0
          when 8
            protype = :GROUND || 0
          when 9
            protype = :PSYCHIC || 0
          when 10
            protype = :ROCK || 0
          when 11
            protype = :FLYING || 0
          when 12
            protype = :BUG || 0
          when 13
            protype = :GHOST || 0
          when 14
            protype = :DRAGON || 0
          when 15
            protype = :DARK || 0
          when 16
            protype = :STEEL || 0
          when 17
            protype = :FAIRY || 0
          end
        when 36
          protype = :NORMAL || 0
        when 37
          protype = :PSYCHIC || 0
        when 38
          protype = :DARK || 0
        when 39
          protype = :ICE || 0
        when 40
          protype = :GHOST || 0
        when 41
          protype = :POISON || 0
        when 42
          protype = :FAIRY || 0
        when 43
          protype = :FLYING || 0
        when 44
          protype = :STEEL || 0
        when 45
          protype = :FIRE || 0
        when 46
          protype = :GROUND || 0
        end
        prot1 = i.type1
        prot2 = i.type2
        camotype = getConst(PBTypes,protype) || 0
        if camotype>0 && (!i.pbHasType?(camotype) || (defined?(prot2) && prot1 != prot2))
          i.type1=camotype
          i.type2=camotype
          typename=PBTypes.getName(camotype)
          pbDisplay(_INTL("{1} had its type changed to {2}!",i.pbThis,typename))
        end
      end
      # Speed Boost
      # A PokÃ©mon's turncount is 0 if it became active after the beginning of a round
      if i.turncount>0 && i.hasWorkingAbility(:SPEEDBOOST)
        if !i.pbTooHigh?(PBStats::SPEED)
          i.pbIncreaseStatBasic(PBStats::SPEED,1)
          pbCommonAnimation("StatUp",i,nil)
          pbDisplay(_INTL("{1}'s Speed Boost raised its Speed!",i.pbThis))
        end
      end
      # Accumulation
      if i.hasWorkingAbility(:ACCUMULATION) && i.turncount>0 && i.lastMoveUsed!=395
        if i.effects[PBEffects::Stockpile] <3
          i.effects[PBEffects::Stockpile] +=1
          i.pbIncreaseStatBasic(PBStats::DEFENSE,1)
          i.effects[PBEffects::StockpileDef] +=1
          i.pbIncreaseStatBasic(PBStats::SPDEF,1)
          i.effects[PBEffects::StockpileSpDef] +=1
          pbDisplay(_INTL("{1} stockpiled with {2}!",i.pbThis,PBAbilities.getName(i.ability)))
        end
        if i.hp!=i.totalhp
          i.pbRecoverHP((i.totalhp/8).floor,true)
          pbDisplay(_INTL("{1} is healed by the stockpiles!",i.pbThis))
        end
      end
      if i.turncount>0 && $fefieldeffect == 8 && # Swamp Field
       !isConst?(i.ability,PBAbilities,:WHITESMOKE) &&
       !isConst?(i.ability,PBAbilities,:CLEARBODY) &&
       !isConst?(i.ability,PBAbilities,:QUICKFEET) &&
       !isConst?(i.ability,PBAbilities,:TEMPORALSHIFT) &&
       !isConst?(i.ability,PBAbilities,:SWIFTSWIM) &&
       !isConst?(i.ability,PBAbilities,:PROPELLERTAIL)
        if !i.isAirborne?
          boost = 1
          if i.effects[PBEffects::MultiTurn] > 0
            boost = 2
          end
          if i.hasWorkingAbility(:CONTRARY)
            i.pbIncreaseStat(PBStats::SPEED,boost,false,nil,nil,true,false,false,false)
            pbDisplay(_INTL("{1}'s {2} boosted its Speed!",i.pbThis,PBAbilities.getName(i.ability)))
          else
            i.pbReduceStat(PBStats::SPEED,boost,false,nil,nil,true,false,false,false)
            pbDisplay(_INTL("{1}'s Speed sank...!",i.pbThis))
          end
        end
      end
     #sleepyswamp
    if i.status==PBStatuses::SLEEP && !isConst?(i.ability,PBAbilities,:MAGICGUARD)
      if $fefieldeffect == 8 # Swamp Field
        if i.effects[PBEffects::ShieldLife]>0
          nightmaredamage=i.totalhp/16
          pbShieldDamage(i,nightmaredamage)
          hploss=nightmaredamage
        else
          if i.effects[PBEffects::MultiTurn] > 0
            hpdown = (i.totalhp/8).floor
            hploss=i.pbReduceHP(hpdown,true)
          else
            hpdown = (i.totalhp/16).floor
            hploss=i.pbReduceHP(hpdown,true)
          end
        end
        pbDisplay(_INTL("{1}'s strength is sapped by the swamp!",i.pbThis)) if hploss>0
      end
    end
    if i.hp<=0
      return if !i.pbFaint
      next
    end
    if i.effects[PBEffects::Octolock]==true
      locklowered = false
      if !i.pbTooLow?(PBStats::DEFENSE)
        contcheck = (i.ability == PBAbilities::CONTRARY)
        i.pbReduceStat(PBStats::DEFENSE,1,false,nil,nil,false,false,false,contcheck)
        locklowered = true if !contcheck
      end
      if !i.pbTooLow?(PBStats::SPDEF)
        contcheck = (i.ability == PBAbilities::CONTRARY)
        i.pbReduceStat(PBStats::SPDEF,1,false,nil,nil,false,false,false,contcheck)
        locklowered = true if !contcheck
      end
      if locklowered
        pbCommonAnimation("StatDown",i,nil)
        pbDisplay(_INTL("The Octolock lowered {1}'s defenses!",i.pbThis))
      end
    end
    #sleepyrainbow
    if i.status==PBStatuses::SLEEP
      if ($fefieldeffect == 9 || @field.effects[PBEffects::Rainbow]>0) && i.effects[PBEffects::HealBlock]==0#Rainbow Field
      hpgain=(i.totalhp/16).floor
      hpgain=(hpgain*1.3).floor if isConst?(i.item,PBItems,:BIGROOT)
      hpgain=i.pbRecoverHP(hpgain,true)
      pbDisplay(_INTL("{1} recovered health in its peaceful sleep!",i.pbThis))
      end
    end
    #DimenSleep
    if i.status==PBStatuses::SLEEP && $fefieldeffect == 38 && !i.isFainted? # Dimen
      if i.effects[PBEffects::ShieldLife]>0
        nightmaredamage=i.totalhp/16
        pbShieldDamage(i,nightmaredamage)
        hploss=nightmaredamage
      else
        hploss=i.pbReduceHP((i.totalhp/16).floor,true)
      end
      pbDisplay(_INTL("{1}'s dream is corrupted by the dimension!",i.pbThis)) if hploss>0
    end
    #MeliaHelps
    if $game_switches[755]==true &&
      $fefieldeffect == 31 &&
      isConst?(i.ability,PBAbilities,:INTIMIDATE2)
      hploss=i.pbReduceHP((i.totalhp/6).floor,true)
      pbDisplay(_INTL("Melia harmed Gyarados from outside the rift!",i.pbThis)) if hploss>0
    end
    #HauntedSleep
    if i.status==PBStatuses::SLEEP && !i.pbHasType?(:GHOST) && $fefieldeffect == 40 # Haunted
      if !i.opposingAbilityHolder(:SHADOWTAG).nil?
        if i.effects[PBEffects::ShieldLife]>0
          nightmaredamage=i.totalhp/16
          pbShieldDamage(i,nightmaredamage)
          hploss=nightmaredamage
        else
          hploss=i.pbReduceHP((i.totalhp/8).floor,true)
        end
      else
        if i.effects[PBEffects::ShieldLife]>0
          nightmaredamage=i.totalhp/16
          pbShieldDamage(i,nightmaredamage)
        else
          hploss=i.pbReduceHP((i.totalhp/16).floor,true)
        end
      end
      pbDisplay(_INTL("{1}'s dream is corrupted by the evil spirits!",i.pbThis)) if hploss>0
    end
    if i.hp<=0
      return if !i.pbFaint
      next
    end
    #FairyRingSleep
    if i.status==PBStatuses::SLEEP &&
     $fefieldeffect == 42 # Bewitched woods
      if i.effects[PBEffects::ShieldLife]>0
        nightmaredamage=i.totalhp/16
        pbShieldDamage(i,nightmaredamage)
        hploss=nightmaredamage
      else
        hploss=i.pbReduceHP((i.totalhp/8).floor,true)
      end
      pbDisplay(_INTL("{1}'s dream is corrupted by the evil in the woods!",i.pbThis)) if hploss>0
    end
    if i.hp<=0
      return if !i.pbFaint
      next
    end
    #sleepycorro
    if i.status==PBStatuses::SLEEP && i.hasWorkingAbility(:MAGICGUARD) &&
     !i.hasWorkingAbility(:POISONHEAL) && !i.hasWorkingAbility(:TOXICBOOST) &&
     !i.hasWorkingAbility(:WONDERGUARD) &&
     !i.pbHasType?(:STEEL) && !i.pbHasType?(:POISON) &&
     $fefieldeffect == 10 # Corrosive Field
     if i.effects[PBEffects::ShieldLife]>0
      nightmaredamage=i.totalhp/16
      pbShieldDamage(i,nightmaredamage)
      else
        hploss=i.pbReduceHP((i.totalhp/16).floor,true)
      end
      pbDisplay(_INTL("{1} is seared by the corrosion!",i.pbThis)) if hploss>0
    end
    if i.hp<=0
      return if !i.pbFaint
      next
    end
    # Water Compaction on Water-based Fields
    if i.hasWorkingAbility(:WATERCOMPACTION)
      if $fefieldeffect==8 || $fefieldeffect==21 || $fefieldeffect==22 ||
        $fefieldeffect==26 || $fefieldeffect == 46 # Swamp, Water Surface, Underwater, Murkwater
        if !i.pbTooHigh?(PBStats::DEFENSE)
          i.pbIncreaseStatBasic(PBStats::DEFENSE,2)
          pbCommonAnimation("StatUp",i,nil)
          pbDisplay(_INTL("{1}'s Water Compaction sharply raised its defense!",
           i.pbThis))
         end
       end
    end
    # World of Nightmares
    if !i.opposingAbilityHolder(:WORLDOFNIGHTMARES).nil?
        i.effects[PBEffects::WorldOfNightmares]+=1
        nightmarechip=[64,i.effects[PBEffects::WorldOfNightmares]].min
        if $fefieldeffect==35 # new world
          nightmarechip*=2
        end
        hploss=i.pbReduceHP((i.totalhp/32).floor*nightmarechip,true)
        pbDisplay(_INTL("{1}'s nightmares are becoming a reality!",i.pbThis)) if hploss>0
    end
    # Nightmare Aura
    if i.status==PBStatuses::SLEEP && !i.hasWorkingAbility(:MAGICGUARD) &&
       !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect==44) && $fefieldeffect!=9 &&
       i.opposingLivingBattlers.any? { |foe| foe.effects[PBEffects::NightmareAura] }
      hploss=i.pbReduceHP([i.totalhp/8,1].max,true)
      pbDisplay(_INTL("{1} is writhing having a bad dream!",i.pbThis)) if hploss>0
    end
    if i.isFainted?
      return if !i.pbFaint
      next
    end
    # Harvest
    sunny = pbWeather==PBWeather::SUNNYDAY && !i.hasWorkingItem(:UTILITYUMBRELLA)
    harvested_berry = i.pokemon.harvestBerry
    if i.hasWorkingAbility(:HARVEST) && i.item<=0 && harvested_berry.to_i>0 &&
       (!i.pokemon.harvestUsed || sunny)
      i.item=harvested_berry
      i.pokemon.itemInitial=harvested_berry
      i.pokemon.itemRecycle=0
      i.pokemon.harvestBerry=0
      i.pokemon.harvestUsed=true
      firstberryletter=PBItems.getName(i.item).split(//).first
      if firstberryletter=="A" || firstberryletter=="E" || firstberryletter=="I" ||
        firstberryletter=="O" || firstberryletter=="U"
            pbDisplay(_INTL("{1} harvested an {2}!",i.pbThis,PBItems.getName(i.item)))
      else
        pbDisplay(_INTL("{1} harvested a {2}!",i.pbThis,PBItems.getName(i.item)))
      end
      i.pbBerryCureCheck(true)
    end
    i.pokemon.harvestBerry=0
    i.pokemon.harvestUsed=false if sunny
    if !i.hasWorkingItem(:LEFTOVERS) && !i.hasWorkingItem(:BLACKSLUDGE) &&
       !i.hasWorkingItem(:SPIRITCREST)  && !i.hasWorkingItem(:INFCREST)
      i.pbBerryCureCheck(true)
    end
    # Ball Fetch
    if i.hasWorkingAbility(:BALLFETCH) && i.effects[PBEffects::BallFetch]!=0 && i.item<=0
      pokeball=i.effects[PBEffects::BallFetch]
      i.item=pokeball
      i.pokemon.itemInitial=pokeball
      PBDebug.log("[Ability triggered] #{i.pbThis}'s Ball Fetch found #{PBItems.getName(ball)}")
      pbDisplay(_INTL("{1} fetched a {2}!",i.pbThis,PBItems.getName(ball)))
      i.sameSideLivingBattlers(false).each do |ally|
        ally.effects[PBEffects::BallFetch]=0 if ally.hasWorkingAbility(:BALLFETCH)
      end
    end
    if i.hasWorkingAbility(:HONEYGATHER) && !i.isFainted?
      if !i.effects[PBEffects::UsedAttackThisTurn] && i.effects[PBEffects::HealBlock]==0 && i.hp<i.totalhp
        hpgain=i.pbRecoverHP((i.totalhp/8).floor,true)
        pbDisplay(_INTL("{1} healed itself with gathered honey!",i.pbThis)) if hpgain>0
      end
    end
  end
    for i in priority
      next if i.isFainted?
      expiry=i.effects[PBEffects::BurnUp]
      if expiry && @turncount+1>=expiry
        i.effects[PBEffects::BurnUp]=false
        pbDisplay(_INTL("{1} reignited its flame!",i.pbThis))
      end
    end
    for i in priority
      next if i.isFainted?
      # Toxic Orb
      if i.hasWorkingItem(:TOXICORB) && i.status==0 && i.pbCanPoison?(false,true)
        i.status=PBStatuses::POISON
        i.statusCount=1
        i.effects[PBEffects::Toxic]=0
        pbCommonAnimation("Poison",i,nil)
        pbDisplay(_INTL("{1} was poisoned by its {2}!",i.pbThis,PBItems.getName(i.item)))
      end
      # Flame Orb
      if i.hasWorkingItem(:FLAMEORB) && i.status==0 && i.pbCanBurn?(false)
        i.status=PBStatuses::BURN
        i.statusCount=0
        pbCommonAnimation("Burn",i,nil)
        pbDisplay(_INTL("{1} was burned by its {2}!",i.pbThis,PBItems.getName(i.item)))
      end
      # Shock Orb
      if i.hasWorkingItem(:SHOCKORB) && i.status==0 && i.pbCanParalyze?(false)
        i.pbParalyze(i)
        pbDisplay(_INTL("{1} was paralyzed by its {2}!",i.pbThis,PBItems.getName(i.item)))
      end
      # Frost Orb
      if i.hasWorkingItem(:FROSTORB) && i.status==0 && i.pbCanFreeze?(false)
        i.pbFreeze
        pbDisplay(_INTL("{1} was frozen by its {2}!",i.pbThis,PBItems.getName(i.item)))
      end
      # Drowsy Orb
      if i.hasWorkingItem(:DROWSYORB) && i.effects[PBEffects::Yawn]==0 && i.pbCanSleep?(false,true)
        i.effects[PBEffects::Yawn]=2
        pbDisplay(_INTL("{1} became drowsy because of its {2}!",i.pbThis,PBItems.getName(i.item)))
      end
      # Pressure Orb
      if i.hasWorkingItem(:PRESSUREORB) && i.status==0 && i.pbCanCrush?(false)
        i.pbCrush(i)
        pbDisplay(_INTL("{1} was crushed by its {2}!",i.pbThis,PBItems.getName(i.item)))
      end
      # Sticky Barb
      if i.hasWorkingItem(:STICKYBARB) && !i.hasWorkingAbility(:MAGICGUARD) &&
         !(i.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        pbDisplay(_INTL("{1} is hurt by its {2}!",i.pbThis,PBItems.getName(i.item)))
        @scene.pbDamageAnimation(i,0)
        i.pbReduceHP((i.totalhp/8).floor)
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
#### SARDINES - v17 - START
    # Slow Start's end message
    eachActiveBattlerIndex do |i|
      if @battlers[i].hasWorkingAbility(:SLOWSTART) && @battlers[i].turncount==5
        pbDisplay(_INTL("{1} finally got its act together!", @battlers[i].name))
      end
      @battlers[i].pbRewindTimetwister
    end
#### SARDINES - v17 - END
    # Hunger Switch
    for i in priority
      next if i.isFainted?
      next if !i.hasWorkingAbility(:HUNGERSWITCH) || !isConst?(i.species,PBSpecies,:MORPEKO)
      if i.form==0 && i.hp>0
        healed=i.pbRecoverHP((i.totalhp/8).floor,true)
        pbDisplay(_INTL("{1}'s {2} restored its health!",i.pbThis,PBAbilities.getName(i.ability))) if healed>0
      end
      i.form=(i.form==0) ? 1 : 0
      i.pbUpdate(true)
      scene.pbChangePokemon(i,i.pokemon)
      pbDisplay(_INTL("{1} transformed!",i.pbThis))
    end
#### SAVAGERY - START
#### SAVAGERY - END
    # Form checks
    eachActiveBattlerIndex do |i|
      next if @battlers[i].isFainted?
      @battlers[i].pbCheckForm
    end
    pbGainEXP
##### KUROTSUNE - 009 - START
    # Checks if a pokemon on either side has fainted on this turn
    # for retaliate
    [false,true].each do |opposing|
      sideIndices = pbActiveBattlerIndicesForSide(opposing)
      sideHasFainted = sideIndices.any? { |idx| @battlers[idx].isFainted? }
      sideIndices.each do |idx|
        @battlers[idx].pbOwnSide.effects[PBEffects::Retaliate] = sideHasFainted
      end
    end
##### KUROTSUNE - 009 - END
    for i in priority
      next if i.isFainted?
      next if i.nil?
      next if @party2[0].nil?
      sameSideSOS = false
      eachSameSideBattler(i.index) do |battler|
        next if battler.index==i.index
        if battler.issossmon
          sameSideSOS = true
          break
        end
      end
      if @field.effects[PBEffects::SosBuffer] == 0 && i.isbossmon && sameSideSOS
        @field.effects[PBEffects::SosBuffer] = i.sosDetails && i.sosDetails[:sosBuffer] ? i.sosDetails[:sosBuffer] : 3
      end
    end
    # sosBuffer
    if @field.effects[PBEffects::SosBuffer]>0
      @field.effects[PBEffects::SosBuffer]-=1
    end
    pbBossSOS(priority) if @field.effects[PBEffects::SosBuffer] == 0
    @faintswitch = true
    pbSwitch
    @faintswitch = false
    return if @decision>0
    for i in priority
      next if i.isFainted?
      i.pbAbilitiesOnSwitchIn(false)
    end
    # Healing Wish/Lunar Dance - should go here
    # Spikes/Toxic Spikes/Stealth Rock - should go here (in order of their 1st use)
    eachActiveBattlerIndex do |i|
      if @battlers[i].turncount>0 && @battlers[i].hasWorkingAbility(:TRUANT)
        @battlers[i].effects[PBEffects::Truant]=!@battlers[i].effects[PBEffects::Truant]
      end
      if @battlers[i].effects[PBEffects::LockOn]>0   # Also Mind Reader
        @battlers[i].effects[PBEffects::LockOn]-=1
        @battlers[i].effects[PBEffects::LockOnPos]=-1 if @battlers[i].effects[PBEffects::LockOn]==0
      end
      @battlers[i].effects[PBEffects::Flinch]=false
      if !(@battlers[i].hasWorkingAbility(:MIRRORARMOR) && $fefieldeffect==34)
        @battlers[i].effects[PBEffects::FollowMe]=false
      end
      @battlers[i].effects[PBEffects::RagePowder]=false
      @battlers[i].effects[PBEffects::HelpingHand]=false
      @battlers[i].effects[PBEffects::MagicCoat]=false
      @battlers[i].effects[PBEffects::Switched]=false
      @battlers[i].effects[PBEffects::Snatch]=false
#### KUROTSUNE - 024 - START
      @battlers[i].effects[PBEffects::Electrify]=false
#### KUROTSUNE - 024 - END
      @battlers[i].lastHPLost=0
      @battlers[i].lastAttacker=-1
      @battlers[i].effects[PBEffects::DamagingMoveThisTurn]=false
      @battlers[i].effects[PBEffects::TributeDamageTaken]=0
      shield=@battlers[i].effects[PBEffects::TributeOverhealShield]
      if shield && shield[:expires]<=@turncount
        @battlers[i].effects[PBEffects::TributeOverhealShield]=nil
      end
      @battlers[i].effects[PBEffects::UsedAttackThisTurn]=false
      @battlers[i].effects[PBEffects::Spritz]=0
      pbResolveRebuild(@battlers[i])
      @battlers[i].azureStatsRaisedThisRound=false
    end
    pbResolveMirrorHerbs
    # invalidate stored priority
    @usepriority=false
    @eruption=false
    # Boss Shield's Can Be Setup Again cause set to -1
    if @shieldCount == 0
      @shieldSetup = -1
      @shieldCount = -1
    end
  end

  def pbResolveRebuild(battler)
    turns=battler.effects[PBEffects::Rebuild]
    return if battler.isFainted? || turns<=0
    battler.effects[PBEffects::Rebuild]-=1
    return unless turns==1
    stages=battler.stages
    if battler.effects[PBEffects::MultiTurnAttack]==PBMoves::BINDINGWORD
      stages=battler.effects[PBEffects::StatChangeHolder]
    end
    boosts=0
    stages.each_with_index do |stage,stat|
      next if !stage || stage<=0
      boosts+=stage
      stages[stat]=0
    end
    return if boosts==0
    move=battler.moves.find { |candidate| candidate && candidate.id==PBMoves::REBUILD }
    move||=PokeBattle_Move.pbFromPBMove(self,PBMove.new(PBMoves::REBUILD),battler)
    recovered=move.pbRecoverMoveHP(battler,battler,battler.totalhp*boosts/5)
    pbDisplay(_INTL("{1} restored its HP by rebuilding!",battler.pbThis)) if recovered>0
  end

################################################################################
# End of battle.
################################################################################
  def pbEndOfBattle(canlose=false)
    case @decision
    ##### WIN #####
    when 1
      $febackgroundstore=0
      if @opponent
        @scene.pbTrainerBattleSuccess
        if @opponent.is_a?(Array)
          pbDisplayPaused(_INTL("{1} defeated {2} and {3}!",self.pbPlayer.name,@opponent[0].fullname,@opponent[1].fullname))
        else
          pbDisplayPaused(_INTL("{1} defeated\r\n{2}!",self.pbPlayer.name,@opponent.fullname))
        end
        @scene.pbShowOpponent(0)
        pbDisplayPaused(@endspeech.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
        if @opponent.is_a?(Array)
          @scene.pbHideOpponent
          @scene.pbShowOpponent(1)
          pbDisplayPaused(@endspeech2.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
        end
        # Calculate money gained for winning
        if @internalbattle
          tmoney=0
          if @opponent.is_a?(Array)   # Double battles
            maxlevel1=0; maxlevel2=0; limit=pbSecondPartyBegin(1)
            for i in 0...limit
              if @party2[i]
                maxlevel1=@party2[i].level if maxlevel1<@party2[i].level
              end
              if @party2[i+limit]
                maxlevel2=@party2[i+limit].level if maxlevel1<@party2[i+limit].level
              end
            end
            tmoney+=maxlevel1*@opponent[0].moneyEarned
            tmoney+=maxlevel2*@opponent[1].moneyEarned
          else
            maxlevel=0
            for i in @party2
              next if !i
              maxlevel=i.level if maxlevel<i.level
            end
            tmoney+=maxlevel*@opponent.moneyEarned
          end
          #On game switch
          tmoney=0 if $game_switches[1351]
          # If Amulet Coin/Luck Incense's effect applies, double money earned
          tmoney*=2 if @amuletcoin
          # If Happy Hour's effect applies, double money earned
          tmoney*=2 if @doublemoney
          oldmoney=self.pbPlayer.money
          self.pbPlayer.money+=tmoney
          moneygained=self.pbPlayer.money-oldmoney
          if moneygained>0
            pbDisplayPaused(_INTL("{1} got ${2}\r\nfor winning!",self.pbPlayer.name,pbCommaNumber(tmoney)))
          end
        end
      end
      if @party2[0].isbossmon
        bossname = $bosscache[@party2[0].bossId].name
        # Boss win music goes here
        pbDisplayPaused(_INTL("{1} defeated\r\n{2}!",self.pbPlayer.name,bossname))
      end
      if @internalbattle && @extramoney>0
        @extramoney*=2 if @amuletcoin
        oldmoney=self.pbPlayer.money
        self.pbPlayer.money+=@extramoney
        moneygained=self.pbPlayer.money-oldmoney
        if moneygained>0
          pbDisplayPaused(_INTL("{1} picked up ${2}!",self.pbPlayer.name,pbCommaNumber(@extramoney)))
        end
      end
      for pkmn in @snaggedpokemon
        pbStorePokemon(pkmn)
        self.pbPlayer.shadowcaught=[] if !self.pbPlayer.shadowcaught
        self.pbPlayer.shadowcaught[pkmn.species]=true
      end
      @snaggedpokemon.clear
    ##### LOSE, DRAW #####
    when 2, 5
      if @internalbattle
        pbDisplayPaused(_INTL("{1} is out of usable Pokémon!",self.pbPlayer.name)) if !@forfeited #pk code
        moneylost=pbMaxLevelFromIndex(0)
        $game_switches[:No_Catch]=false
        $febackgroundstore=0
        multiplier=[8,16,24,36,48,64,80,100,120,144,178,206,234,266,298,334,370,410,450,500] #Badge no. multiplier for money lost
        moneylost*=multiplier[[multiplier.length-1,self.pbPlayer.numbadges].min]
        moneylost=self.pbPlayer.money if moneylost>self.pbPlayer.money
        moneylost=0 if $game_switches[NO_MONEY_LOSS]
        self.pbPlayer.money-=moneylost
        if @opponent
          if @opponent.is_a?(Array)
            pbDisplayPaused(_INTL("{1} lost against {2} and {3}!",self.pbPlayer.name,@opponent[0].fullname,@opponent[1].fullname))
          else
            pbDisplayPaused(_INTL("{1} lost against\r\n{2}!",self.pbPlayer.name,@opponent.fullname))
          end
          if moneylost>0
            pbDisplayPaused(_INTL("{1} paid ${2}\r\nas the prize money...",self.pbPlayer.name,pbCommaNumber(moneylost)))
            pbDisplayPaused(_INTL("...")) if !canlose
          end
        else
          if moneylost>0
            pbDisplayPaused(_INTL("{1} panicked and lost\r\n${2}...",self.pbPlayer.name,pbCommaNumber(moneylost)))
            pbDisplayPaused(_INTL("...")) if !canlose
          end
        end
        pbDisplayPaused(_INTL("{1} blacked out!",self.pbPlayer.name)) if !canlose
      elsif @decision==2
        @scene.pbShowOpponent(0)
        $febackgroundstore=0
        pbDisplayPaused(@endspeechwin.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
        if @opponent.is_a?(Array)
          @scene.pbHideOpponent
          @scene.pbShowOpponent(1)
          pbDisplayPaused(@endspeechwin2.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
        end
      elsif @decision==5
        PBDebug.log("***[Draw game]") if $INTERNAL
      end
    end
    # Pass on PokÃ©rus within the party
    infected=[]
    for i in 0...$Trainer.party.length
      if $Trainer.party[i].pokerusStage==1
        infected.push(i)
      end
    end
    if infected.length>=1
      for i in infected
        strain=$Trainer.party[i].pokerus/16
        if i>0 && $Trainer.party[i-1].pokerusStage==0
          $Trainer.party[i-1].givePokerus(strain) if rand(3)==0
        end
        if i<$Trainer.party.length-1 && $Trainer.party[i+1].pokerusStage==0
          $Trainer.party[i+1].givePokerus(strain) if rand(3)==0
        end
      end
    end
    @scene.pbEndBattle(@decision)
    for i in @battlers
      i.pbResetForm
    end
    ([*@party1, *@party2].compact.uniq).each do |pkmn|
      pkmn.makeUnmega if !pkmn.azureMegaPreviousForm.nil?
      pkmn.clearBeneficialStatus if pkmn.respond_to?(:clearBeneficialStatus)
      pkmn.tributeDracoPP=nil if pkmn.respond_to?(:tributeDracoPP=)
    end
    eachActiveBattlerIndex do |index|
      @battlers[index].pbDiscardConsumableHeldItemDose
    end
    for i in $Trainer.party
      i.setItem(i.itemInitial)
      i.itemInitial=i.itemRecycle=0
    end
    return @decision
  end
end
