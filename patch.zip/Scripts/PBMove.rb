class PBMoveData
  attr_reader :id
  attr_reader :function,:basedamage,:type,:accuracy
  attr_reader :totalpp,:addlEffect,:target,:priority
  attr_reader :flags
  attr_reader :contestType,:category

  def initialize(moveid)
    @id          = moveid
    @function    = $pkmn_move[moveid][0]
    @basedamage  = $pkmn_move[moveid][1]
    @type        = $pkmn_move[moveid][2]
    @category    = $pkmn_move[moveid][3]
    @accuracy    = @category==2 ? 0 : $pkmn_move[moveid][4] #pk code
    @totalpp     = $pkmn_move[moveid][5]
    @addlEffect  = $pkmn_move[moveid][6]
    @target      = $pkmn_move[moveid][7]
    @priority    = $pkmn_move[moveid][8]
    @flags       = $pkmn_move[moveid][9]
  end
  def isSoundBased?
    return (@flags&0x400)!=0 # Sound Flag ("k") needed checkable for substitute
  end

  #pk code
  class << self
    # Use the original constructor on reload.
    define_method(:azure_uncached_new, Class.instance_method(:new))

    def normalize_id(value)
      return value if value.is_a?(Numeric)
      begin
        return nil if !value.is_a?(Symbol) && !value.is_a?(String)
        key=value.to_sym
        return nil if !PBMoves.const_defined?(key)
        return PBMoves.const_get(key)
      rescue
        return nil
      end
    end

    def new(moveid)
      id=normalize_id(moveid)
      return azure_uncached_new(moveid) if id.nil?
      source=$pkmn_move
      source_id=source ? source.object_id : nil
      if @azure_source_id!=source_id
        @azure_source_id=source_id
        @azure_cache=[]
      end
      row=source ? source[id] : nil
      cached=@azure_cache[id] if @azure_cache && id>=0
      if cached && cached.instance_variable_get(:@azure_source_row).equal?(row)
        return cached
      end
      data=azure_uncached_new(id)
      data.instance_variable_set(:@azure_source_row,row)
      @azure_cache[id]=data if id>=0
      return data
    end

    def get(move)
      id=normalize_id(move)
      raise ArgumentError.new("Unknown move #{move.inspect}") if id.nil? ||
        !$pkmn_move || !$pkmn_move[id]
      return new(id)
    end

    def try_get(move)
      id=normalize_id(move)
      return nil if id.nil? || !$pkmn_move || !$pkmn_move[id]
      return new(id)
    end

    def exists?(move)
      return !try_get(move).nil?
    end

    def each
      return enum_for(:each) if !block_given?
      return if !$pkmn_move
      for id in 0...$pkmn_move.length
        yield new(id) if $pkmn_move[id]
      end
    end

    def clear_cache
      @azure_source_id=nil
      @azure_cache=[]
    end
  end
end

#pk code
def pbIsHiddenPowerMove?(move)
  return false if move.nil?
  return move == PBMoves::HIDDENPOWER ||
         (move >= PBMoves::HIDDENPOWERNOR && move <= PBMoves::HIDDENPOWERFAI)
end

class PBMove
  HIDDEN_POWER_PP=5 #pk code

  #pk code
  # Keep the old move IDs readable in saves.
  LEGACY_DUPLICATE_MOVES={
    661=>:ORIGINPULSE,
    662=>:PRECIPICEBLADES,
    663=>:DRAGONASCENT,
    664=>:THOUSANDARROWS,
    665=>:THOUSANDWAVES,
    666=>:DIAMONDSTORM,
    668=>:STEAMERUPTION
  }.freeze

  RETIRED_MOVE_REPLACEMENTS={
    215=>:SLEEPPOWDER,
    237=>:MUDSLAP,
    481=>:SANDATTACK,
    558=>:WATERGUN,
    1033=>:DISHEARTEN,
    1034=>:EPHEMERATE,
    1035=>:ANTICLINE
  }.freeze

  def self.current_id(moveid)
    replacement=LEGACY_DUPLICATE_MOVES[moveid] || RETIRED_MOVE_REPLACEMENTS[moveid]
    return replacement ? PBMoves.const_get(replacement) : moveid
  end

  def id
    @id=PBMove.current_id(@id)
  end

  attr_writer(:pp)
  attr_accessor(:ppup)   # Gets the number of PP Ups used for this move.
  attr_accessor(:totalpp)# Gets the total number of PP this move can have.

# Gets this move's type.
  def type
    return $pkmn_move[id][2]
  end

  #pk code
  def pp
    @pp=HIDDEN_POWER_PP if @pp && @pp>HIDDEN_POWER_PP && pbIsHiddenPowerMove?(@id)
    return @pp
  end

# Gets the maximum PP for this move.
  def totalpp
    return HIDDEN_POWER_PP if pbIsHiddenPowerMove?(id) #pk code
    return @totalpp if defined?(@totalpp)
    moveid=id
    return 0 if moveid==0 || !$pkmn_move[moveid]
    tpp=$pkmn_move[moveid][5]
    return 0 if !tpp
    return tpp+(tpp*@ppup/5).floor
  end

# Gets basedamage for this move
  def basedamage
    return $pkmn_move[id][1]
  end
  
# Initializes this object to the specified move ID.
  def initialize(moveid)
    @id=PBMove.current_id(moveid)
    @ppup=0
    @pp=totalpp
  end
end
