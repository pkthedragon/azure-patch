def pbSetWindowText(string)
  System.set_window_title(string || System.game_title)
end