class PokeBattle_Battler
  attr_reader :battle
  attr_reader :pokemon
  attr_reader :name
  attr_reader :index
  attr_accessor :pokemonIndex
  attr_reader :totalhp
  attr_accessor :fainted
  attr_reader :usingsubmove
  attr_accessor :lastAttacker
  attr_accessor :faintingMove
  attr_accessor :turncount
  attr_accessor :effects
  attr_accessor :species
  attr_writer :type1
  attr_writer :type2
  attr_accessor :ability
  attr_accessor :gender
  attr_accessor :attack
  attr_accessor :defense
  attr_accessor :spatk
  attr_accessor :spdef
  attr_accessor :speed
  attr_accessor :stages
  attr_accessor :iv
  attr_accessor :moves
  attr_accessor :participants
  attr_accessor :lastHPLost
  attr_accessor :lastMoveUsed
  attr_accessor :lastMoveUsedSketch
  attr_accessor :lastRegularMoveUsed
  attr_accessor :lastRoundMoved
  attr_accessor :movesUsed
  attr_accessor :currentMove
  attr_accessor :damagestate
  attr_accessor :unburdened
  attr_accessor :previousMove
  #### KUROTSUNE - 010 - START
  attr_accessor :selectedMove
  #### KUROTSUNE - 010 - END
  #### KUROTSUNE - 014 - START
  attr_accessor :wonderroom
  #### KUROTSUNE - 014 - END
  attr_accessor :tributeDracoActive
  attr_accessor :tributeDracoBattleMove
  attr_accessor :tributeDracoOriginalMove
  attr_accessor :itemUsed
  attr_accessor :itemUsed2  #Stays while the battler is out
  attr_accessor :userSwitch
  attr_accessor :forcedSwitch
  attr_accessor :forcedSwitchEarlier
  attr_accessor :vanished
  attr_accessor :custap
  attr_accessor :moldbroken
  attr_accessor :corroded
  attr_accessor :startform
  attr_accessor :sleeptalkUsed
  attr_accessor :missed
  attr_accessor :missAcc
  attr_accessor :grazed  # Track when attack misses accuracy but still deals partial damage
  attr_accessor :statLowered
  attr_accessor :hasmegad
  attr_accessor :passing
  attr_accessor :obhp
  attr_accessor :obatk
  attr_accessor :obdef
  attr_accessor :obspe
  attr_accessor :obspa
  attr_accessor :obspd
  # for boss system
  attr_accessor :isBoss
  attr_accessor :onBreakEffects
  attr_accessor :onEntryEffects
  attr_accessor :chargeAttack
  attr_accessor :immunities
  attr_accessor :capturable
  attr_accessor :shieldCount
  attr_accessor :barGraphic
  attr_accessor :entryText
  attr_accessor :sosDetails
  attr_accessor :randomSetChanges
  attr_accessor :shieldsBroken
  attr_accessor :shieldsBrokenThisTurn
  attr_accessor :currentSOS
  attr_accessor :moveHistory
  # boss system end
  def inHyperMode?; return false; end
  def isShadow?; return false; end

  ################################################################################
  # Complex accessors
  ################################################################################
  def nature
    return (@pokemon) ? @pokemon.nature : 0
  end

  def ev
    return (@pokemon) ? @pokemon.ev : 0
  end

  def happiness
    return (@pokemon) ? @pokemon.happiness : 0
  end

  def pokerusStage
    return (@pokemon) ? @pokemon.pokerusStage : 0
  end

  def isbossmon
    return (@pokemon) ? @pokemon.isbossmon : false
  end

  def issossmon
    return (@pokemon) ? @pokemon.sosmon : false
  end

  def premega
    return (@pokemon) ? @pokemon.premega : false
  end

  attr_reader :form

  def form=(value)
    @form=value
    @pokemon.form=value if @pokemon
  end

  def hasMega?
    if @pokemon
      return (@pokemon.hasMegaForm? rescue false)
    end
    return false
  end

  def pbZCrystalFromType(type)
    case type
    when 0
      crystal = (PBItems::NORMALIUMZ2)
    when 1
      crystal = (PBItems::FIGHTINIUMZ2)
    when 2
      crystal = (PBItems::FLYINIUMZ2)
    when 3
      crystal = (PBItems::POISONIUMZ2)
    when 4
      crystal = (PBItems::GROUNDIUMZ2)
    when 5
      crystal = (PBItems::ROCKIUMZ2)
    when 6
      crystal = (PBItems::BUGINIUMZ2)
    when 7
      crystal = (PBItems::GHOSTIUMZ2)
    when 8
      crystal = (PBItems::STEELIUMZ2)
    when 10
      crystal = (PBItems::FIRIUMZ2)
    when 11
      crystal = (PBItems::WATERIUMZ2)
    when 12
      crystal = (PBItems::GRASSIUMZ2)
    when 13
      crystal = (PBItems::ELECTRIUMZ2)
    when 14
      crystal = (PBItems::PSYCHIUMZ2)
    when 15
      crystal = (PBItems::ICIUMZ2)
    when 16
      crystal = (PBItems::DRAGONIUMZ2)
    when 17
      crystal = (PBItems::DARKINIUMZ2)
    when 18
      crystal = (PBItems::FAIRIUMZ2)
    end
    return crystal
  end

  def obhp
    return (@pokemon) ? @pokemon.obhp : 0
  end
  def obatk
    return (@pokemon) ? @pokemon.obatk : 0
  end
  def obdef
    return (@pokemon) ? @pokemon.obdef : 0
  end
  def obspe
    return (@pokemon) ? @pokemon.obspe: 0
  end
  def obspa
    return (@pokemon) ? @pokemon.obspa : 0
  end
  def obspd
    return (@pokemon) ? @pokemon.obspd : 0
  end

  def hasZMove?
    pkmn=self
    canuse=false
    case pkmn.item
    when (PBItems::NORMALIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 0}
    when (PBItems::FIGHTINIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 1}
    when (PBItems::FLYINIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 2}
    when (PBItems::POISONIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 3}
    when (PBItems::GROUNDIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 4}
    when (PBItems::ROCKIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 5}
    when (PBItems::BUGINIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 6}
    when (PBItems::GHOSTIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 7}
    when (PBItems::STEELIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 8}
    when (PBItems::FIRIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 10}
    when (PBItems::WATERIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 11}
    when (PBItems::GRASSIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 12}
    when (PBItems::ELECTRIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 13}
    when (PBItems::PSYCHIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 14}
    when (PBItems::ICIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 15}
    when (PBItems::DRAGONIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 16}
    when (PBItems::DARKINIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 17}
    when (PBItems::FAIRIUMZ2)
      canuse=pkmn.moves.any?{|stuffthings| stuffthings.type == 18}
    when (PBItems::ALORAICHIUMZ2)
      if pkmn.pokemon.species==26 && pkmn.form==1
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::THUNDERBOLT}
      end
    when (PBItems::DECIDIUMZ2)
      if pkmn.pokemon.species==724
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::SPIRITSHACKLE}
      end
    when (PBItems::INCINIUMZ2)
      if pkmn.pokemon.species==727
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::DARKESTLARIAT}
      end
    when (PBItems::PRIMARIUMZ2)
      if pkmn.pokemon.species==730
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::SPARKLINGARIA}
      end
    when (PBItems::EEVIUMZ2)
      if pkmn.pokemon.species==133
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::LASTRESORT}
      end
    when (PBItems::PIKANIUMZ2)
      if pkmn.pokemon.species==25
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::VOLTTACKLE}
      end
    when (PBItems::SNORLIUMZ2)
      if pkmn.pokemon.species==143
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::GIGAIMPACT}
      end
    when (PBItems::MEWNIUMZ2)
      if pkmn.pokemon.species==151
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::PSYCHIC}
      end
    when (PBItems::TAPUNIUMZ2)
      if pokemon.species==785 || pokemon.species==786 || pokemon.species==787 || pokemon.species==788
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::NATURESMADNESS}
      end
    when (PBItems::MARSHADIUMZ2)
      if pkmn.pokemon.species==802
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::SPECTRALTHIEF}
      end
    when (PBItems::KOMMONIUMZ2)
      if pkmn.pokemon.species==784
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::CLANGINGSCALES}
      end
    when (PBItems::LYCANIUMZ2)
      if pkmn.pokemon.species==745
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::STONEEDGE}
      end
    when (PBItems::MIMIKIUMZ2)
      if pkmn.pokemon.species==778
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::PLAYROUGH}
      end
    when (PBItems::SOLGANIUMZ2)
      if (pkmn.pokemon.species==800 && pkmn.form==1) || pkmn.pokemon.species==791
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::SUNSTEELSTRIKE}
      end
    when (PBItems::LUNALIUMZ2)
      if (pkmn.pokemon.species==800 && pkmn.form==2) || pkmn.pokemon.species==792
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::MOONGEISTBEAM}
      end
    when (PBItems::ULTRANECROZIUMZ2)
      if pkmn.pokemon.species==800 && pkmn.form==3
         canuse=pkmn.moves.any?{|stuffthings| stuffthings.id == PBMoves::PHOTONGEYSER}
      end
    when (PBItems::INTERCEPTZ2)
      if $game_variables[646]>=95 && $game_variables[646]<100
        canuse=true
      end
    end
    return canuse
  end

  def pbCompatibleZMoveFromMove?(move)
    pkmn=self
    case pkmn.item
    when PBItems::NORMALIUMZ2
        return true if move.type==0
    when PBItems::FIGHTINIUMZ2
        return true if move.type==1
    when PBItems::FLYINIUMZ2
        return true if move.type==2
    when PBItems::POISONIUMZ2
        return true if move.type==3
    when PBItems::GROUNDIUMZ2
        return true if move.type==4
    when PBItems::ROCKIUMZ2
        return true if move.type==5
    when PBItems::BUGINIUMZ2
        return true if move.type==6
    when PBItems::GHOSTIUMZ2
        return true if move.type==7
    when PBItems::STEELIUMZ2
        return true if move.type==8
    when PBItems::FIRIUMZ2
        return true if move.type==10
    when PBItems::WATERIUMZ2
        return true if move.type==11
    when PBItems::GRASSIUMZ2
        return true if move.type==12
    when PBItems::ELECTRIUMZ2
        return true if move.type==13
    when PBItems::PSYCHIUMZ2
        return true if move.type==14
    when PBItems::ICIUMZ2
        return true if move.type==15
    when PBItems::DRAGONIUMZ2
        return true if move.type==16
    when PBItems::DARKINIUMZ2
        return true if move.type==17
    when PBItems::FAIRIUMZ2
        return true if move.type==18
    when PBItems::ALORAICHIUMZ2
        return true if move.id==(PBMoves::THUNDERBOLT)
    when PBItems::DECIDIUMZ2
        return true if move.id==(PBMoves::SPIRITSHACKLE)
    when PBItems::INCINIUMZ2
        return true if move.id==(PBMoves::DARKESTLARIAT)
    when PBItems::PRIMARIUMZ2
        return true if move.id==(PBMoves::SPARKLINGARIA)
    when PBItems::EEVIUMZ2
        return true if move.id==(PBMoves::LASTRESORT)
    when PBItems::PIKANIUMZ2
        return true if move.id==(PBMoves::VOLTTACKLE)
    when PBItems::SNORLIUMZ2
        return true if move.id==(PBMoves::GIGAIMPACT)
    when PBItems::MEWNIUMZ2
        return true if move.id==(PBMoves::PSYCHIC)
    when PBItems::TAPUNIUMZ2
        return true if move.id==(PBMoves::NATURESMADNESS)
    when PBItems::MARSHADIUMZ2
        return true if move.id==(PBMoves::SPECTRALTHIEF)
    when PBItems::KOMMONIUMZ2
        return true if move.id==(PBMoves::CLANGINGSCALES)
    when PBItems::LYCANIUMZ2
        return true if move.id==(PBMoves::STONEEDGE)
    when PBItems::MIMIKIUMZ2
        return true if move.id==(PBMoves::PLAYROUGH)
    when PBItems::SOLGANIUMZ2
        return true if move.id==(PBMoves::SUNSTEELSTRIKE)
    when PBItems::LUNALIUMZ2
        return true if move.id==(PBMoves::MOONGEISTBEAM)
    when PBItems::ULTRANECROZIUMZ2
        return true if move.id==(PBMoves::PHOTONGEYSER)
    when PBItems::INTERCEPTZ2
        return true
    end
    return false
  end

  def pbCompatibleZMoveFromIndex?(moveindex)
    pkmn=self
    case pkmn.item
    when PBItems::NORMALIUMZ2
        return true if pkmn.moves[moveindex].type==0
    when PBItems::FIGHTINIUMZ2
        return true if pkmn.moves[moveindex].type==1
    when PBItems::FLYINIUMZ2
        return true if pkmn.moves[moveindex].type==2
    when PBItems::POISONIUMZ2
        return true if pkmn.moves[moveindex].type==3
    when PBItems::GROUNDIUMZ2
        return true if pkmn.moves[moveindex].type==4
    when PBItems::ROCKIUMZ2
        return true if pkmn.moves[moveindex].type==5
    when PBItems::BUGINIUMZ2
        return true if pkmn.moves[moveindex].type==6
    when PBItems::GHOSTIUMZ2
        return true if pkmn.moves[moveindex].type==7
    when PBItems::STEELIUMZ2
        return true if pkmn.moves[moveindex].type==8
    when PBItems::FIRIUMZ2
        return true if pkmn.moves[moveindex].type==10
    when PBItems::WATERIUMZ2
        return true if pkmn.moves[moveindex].type==11
    when PBItems::GRASSIUMZ2
        return true if pkmn.moves[moveindex].type==12
    when PBItems::ELECTRIUMZ2
        return true if pkmn.moves[moveindex].type==13
    when PBItems::PSYCHIUMZ2
        return true if pkmn.moves[moveindex].type==14
    when PBItems::ICIUMZ2
        return true if pkmn.moves[moveindex].type==15
    when PBItems::DRAGONIUMZ2
        return true if pkmn.moves[moveindex].type==16
    when PBItems::DARKINIUMZ2
        return true if pkmn.moves[moveindex].type==17
    when PBItems::FAIRIUMZ2
        return true if pkmn.moves[moveindex].type==18
    when PBItems::ALORAICHIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::THUNDERBOLT)
    when PBItems::DECIDIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::SPIRITSHACKLE)
    when PBItems::INCINIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::DARKESTLARIAT)
    when PBItems::PRIMARIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::SPARKLINGARIA)
    when PBItems::EEVIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::LASTRESORT)
    when PBItems::PIKANIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::VOLTTACKLE)
    when PBItems::SNORLIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::GIGAIMPACT)
    when PBItems::MEWNIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::PSYCHIC)
    when PBItems::TAPUNIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::NATURESMADNESS)
    when PBItems::MARSHADIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::SPECTRALTHIEF)
    when PBItems::KOMMONIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::CLANGINGSCALES)
    when PBItems::LYCANIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::STONEEDGE)
    when PBItems::MIMIKIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::PLAYROUGH)
    when PBItems::SOLGANIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::SUNSTEELSTRIKE)
    when PBItems::LUNALIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::MOONGEISTBEAM)
    when PBItems::ULTRANECROZIUMZ2
        return true if pkmn.moves[moveindex].id==(PBMoves::PHOTONGEYSER)
    when PBItems::INTERCEPTZ2
        return true
    end
    return false
  end

  def battlerToPokemon
    return @pokemon
  end

  def isMega?
    if @pokemon
      return (@pokemon.isMega? rescue false)
    end
    return false
  end

  def hasCrest?
    if isConst?(self.species,PBSpecies,:MAGCARGO) &&
      isConst?(self.item,PBItems,:MAGCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:FEAROW) &&
      isConst?(self.item,PBItems,:FEARCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:STANTLER) &&
      isConst?(self.item,PBItems,:STANTCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:HYPNO) &&
      isConst?(self.item,PBItems,:HYPCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:GLACEON) &&
      isConst?(self.item,PBItems,:GLACCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:LEAFEON) &&
      isConst?(self.item,PBItems,:LEAFCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:RELICANTH) &&
      isConst?(self.item,PBItems,:RELICREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:ORICORIO) &&
      isConst?(self.item,PBItems,:ORICREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:SEVIPER) &&
      isConst?(self.item,PBItems,:SEVCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:COFAGRIGUS) &&
      isConst?(self.item,PBItems,:COFCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:DUSKNOIR) &&
      isConst?(self.item,PBItems,:DUSKCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:SKUNTANK) &&
      isConst?(self.item,PBItems,:SKUNCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:DARMANITAN) &&
      isConst?(self.item,PBItems,:DARMCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:CHERRIM) &&
      isConst?(self.item,PBItems,:CHERCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:CLAYDOL) &&
      isConst?(self.item,PBItems,:CLAYCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:DEDENNE) &&
      isConst?(self.item,PBItems,:DEDECREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:ZANGOOSE) &&
      isConst?(self.item,PBItems,:ZANGCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:BASTIODON) &&
      isConst?(self.item,PBItems,:BASTCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:MEGANIUM) &&
      isConst?(self.item,PBItems,:MEGCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:TYPHLOSION) &&
      isConst?(self.item,PBItems,:TYPHCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:FERALIGATR) &&
      isConst?(self.item,PBItems,:FERACREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:RAMPARDOS) &&
      isConst?(self.item,PBItems,:RAMPCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:LEDIAN) &&
      isConst?(self.item,PBItems,:LEDICREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:ARIADOS) &&
      isConst?(self.item,PBItems,:ARIACREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:SPIRITOMB) &&
      isConst?(self.item,PBItems,:SPIRITCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:WHISCASH) &&
      isConst?(self.item,PBItems,:WHISCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:BEHEEYEM) &&
      isConst?(self.item,PBItems,:BEHECREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:TORTERRA) &&
      isConst?(self.item,PBItems,:TORCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:INFERNAPE) &&
      isConst?(self.item,PBItems,:INFCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:EMPOLEON) &&
      isConst?(self.item,PBItems,:EMPCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:CRYOGONAL) &&
      isConst?(self.item,PBItems,:CRYCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:CASTFORM) &&
      isConst?(self.item,PBItems,:CASTCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:THIEVUL) &&
      isConst?(self.item,PBItems,:THIEVCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:LUXRAY) &&
      isConst?(self.item,PBItems,:LUXCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:SAMUROTT) &&
      isConst?(self.item,PBItems,:SAMUCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:PHIONE) &&
      isConst?(self.item,PBItems,:PHIONECREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:BOLTUND) &&
      isConst?(self.item,PBItems,:BOLTCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:NOCTOWL) &&
      isConst?(self.item,PBItems,:NOCCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:VESPIQUEN) &&
      isConst?(self.item,PBItems,:VESPICREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:DRUDDIGON) &&
      isConst?(self.item,PBItems,:DRUDDICREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:CINCCINO) &&
      isConst?(self.item,PBItems,:CINCCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:PROBOPASS) &&
      isConst?(self.item,PBItems,:PROBOCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:DELCATTY) &&
      isConst?(self.item,PBItems,:DELCREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:SWALOT) &&
      isConst?(self.item,PBItems,:SWACREST)
      return true
    end
    if isConst?(self.species,PBSpecies,:SILVALLY)
      if ((@battle.pbOwnedByPlayer?(self.index) && $PokemonBag.pbHasItem?(:SILVCREST)))
        return true
      end
      if (!@battle.pbOwnedByPlayer?(self.index))
        return true
      end
    end
    return false
  end


  attr_reader :level

  def level=(value)
    @level=value
    @pokemon.level=(value) if @pokemon
  end



  attr_reader :status

  def status=(value)
    if @status==PBStatuses::SLEEP && value==0
      @effects[PBEffects::Truant]=false
    end
    @status=value
    @pokemon.status=value if @pokemon
    if value!=PBStatuses::POISON
      @effects[PBEffects::Toxic]=0
    end
    if value!=PBStatuses::POISON && value!=PBStatuses::SLEEP
      @statusCount=0
      @pokemon.statusCount=0 if @pokemon
    end
  end

  attr_reader :statusCount
  attr_reader :critted

  def critted=(value)
    @critted=value
    @pokemon.critted=value if @pokemon
  end

  def statusCount=(value)
    @statusCount=value
    @pokemon.statusCount=value if @pokemon
  end

  attr_reader :hp

  def hp=(value)
    @hp=value.to_i
    @pokemon.hp=value.to_i if @pokemon
  end

  def beneficialStatus
    return (@pokemon) ? @pokemon.beneficialStatus : @beneficialStatus
  end

  def beneficialStatus=(value)
    @beneficialStatus=value
    @pokemon.beneficialStatus=value if @pokemon
  end

  def beneficialStatusData
    data=(@pokemon) ? @pokemon.beneficialStatusData : @beneficialStatusData
    return data || nil
  end

  def beneficialStatusData=(value)
    @beneficialStatusData=value
    @pokemon.beneficialStatusData=value if @pokemon
  end

  def pbClearBeneficialStatus
    self.beneficialStatus=nil
    self.beneficialStatusData=nil
  end

  def pbShieldHP
    data=beneficialStatusData
    return 0 if beneficialStatus!=:SHIELD || !data
    return [data[:hp].to_i,0].max
  end

  def pbShielded?
    return pbShieldHP>0
  end

  def pbSetShieldHP(value,cocon=0)
    value=[value.to_i,0].max
    if value<=0
      pbClearBeneficialStatus
      return 0
    end
    self.beneficialStatus=:SHIELD
    self.beneficialStatusData={ :hp => value, :cocon => [cocon,value].min }
    return value
  end

  def pbApplyShield(shieldhp,message=nil)
    return false if shieldhp.nil? || shieldhp<=0
    shieldhp=[shieldhp.to_i,1].max
    total=[pbShieldHP+shieldhp,totalhp].min
    pbSetShieldHP(total,pbCoconShieldHP)
    @battle.pbDisplay(message) if message && @battle
    return true
  end

  def pbConsumeShield(amount)
    return amount if amount.nil? || amount<=0
    tribute_shield=@effects[PBEffects::TributeOverhealShield]
    if tribute_shield
      absorbed=[amount,tribute_shield[:hp]].min
      tribute_shield[:hp]-=absorbed
      amount-=absorbed
      @effects[PBEffects::TributeOverhealShield]=nil if tribute_shield[:hp]<=0
      return 0 if amount<=0
    end
    shieldhp=pbShieldHP
    return amount if shieldhp<=0
    absorbed=[amount,shieldhp].min
    remaining=shieldhp-absorbed
    pbSetShieldHP(remaining,[pbCoconShieldHP-absorbed,0].max)
    if remaining<=0 && @battle
      @battle.pbDisplay(_INTL("{1}'s shield shattered!",pbThis))
    end
    return amount-absorbed
  end

  def pbCoconShieldHP
    return 0 if beneficialStatus!=:SHIELD
    return (beneficialStatusData || {})[:cocon].to_i
  end

  def pbApplyCoconBerryShield(dose)
    shieldhp=pbShieldHP
    added=[totalhp-shieldhp,totalhp*dose/3].min
    return false if added<=0
    pbSetShieldHP(shieldhp+added,pbCoconShieldHP+added)
    @battle.pbDisplay(_INTL("{1} shielded itself with the {2}!",pbThis,PBItems.getName(PBItems::COCONBERRY)))
    return true
  end

  def pbExpireCoconBerryShield
    cocon=pbCoconShieldHP
    pbSetShieldHP(pbShieldHP-cocon) if cocon>0
  end

  def pbHasDracoTributeMove?
    return false if !@pokemon || !hasWorkingItem(:DRACOTRIBUTE)
    moveid=PBMove.current_id(@pokemon.tributeDracoMove)
    return moveid && moveid>0 && PBMoveData.exists?(moveid)
  end

  def pbInitializeTributeDraco
    @tributeDracoActive=false
    @tributeDracoOriginalMove=nil
    @tributeDracoBattleMove=nil
  end

  def pbPrepareTributeDraco
    return nil if !pbHasDracoTributeMove?
    moveid=PBMove.current_id(@pokemon.tributeDracoMove)
    return @tributeDracoBattleMove if @tributeDracoBattleMove&.id==moveid
    moveobj=PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(moveid),self)
    if @pokemon.tributeDracoPP && moveobj.totalpp && moveobj.totalpp>0
      moveobj.pp=[[ @pokemon.tributeDracoPP, moveobj.totalpp ].min,0].max
    end
    @tributeDracoBattleMove=moveobj
  end

  def pbEnableTributeDraco
    return false if !pbPrepareTributeDraco || !@moves || !@moves[0]
    @tributeDracoOriginalMove=@moves[0] if !@tributeDracoActive
    @moves[0]=@tributeDracoBattleMove
    @tributeDracoActive=true
    return true
  end

  def pbDisableTributeDraco
    if @tributeDracoActive && @moves && @tributeDracoOriginalMove
      @moves[0]=@tributeDracoOriginalMove
    end
    @tributeDracoActive=false
    @tributeDracoOriginalMove=nil
    return true
  end

  def pbSyncTributeDracoPP
    return if !@pokemon || !@tributeDracoBattleMove
    @pokemon.tributeDracoPP=@tributeDracoBattleMove.pp
  end

  def pbWithDracoTributeSelfDrops(move,target)
    return yield if target==self || !move.tribute_attack?(self,:DRACOTRIBUTE) ||
      !move.heroic_tribute?(self,:DRAPION_MYSTIC)
    previous_capture=@tributeDracoSelfDrops
    capture=[move.id,Hash.new(0)]
    @tributeDracoSelfDrops=capture
    previous_hp=target.hp
    result=yield
    @tributeDracoSelfDrops=previous_capture
    if target.hp<previous_hp && !target.isFainted?
      capture[1].each do |stat,amount|
        target.pbReduceStat(stat,amount,false,move.id,self)
      end
    end
    return result
  ensure
    @tributeDracoSelfDrops=previous_capture if capture
  end

  attr_reader :item

  def item=(value)
    @effects[PBEffects::ConsumableItemDose]=nil if @effects && @item!=value
    # UPDATE 11/19/2013
    # Initial pass for implementing UNBURDEN
    # pokemon has lost their item
    if @item != 0 && value == 0
      if isConst?(@ability, PBAbilities, :UNBURDEN) && !@unburdened
        @unburdened = true
      end
    end
    # end update
    @item=value
    @pokemon.item=value if @pokemon
  end

  def pbSwapHeldItems(other)
    own_item,other_item=item,other.item
    own_dose=@effects[PBEffects::ConsumableItemDose]
    other_dose=other.effects[PBEffects::ConsumableItemDose]
    self.item=other_item
    other.item=own_item
    @effects[PBEffects::ConsumableItemDose]=other_dose
    other.effects[PBEffects::ConsumableItemDose]=own_dose
  end

  def weight
    w=(@pokemon) ? @pokemon.weight : 500
    w*=2 if self.hasWorkingAbility(:HEAVYMETAL) && !(self.moldbroken)
    w/=2 if self.hasWorkingAbility(:LIGHTMETAL) && !(self.moldbroken)
    w/=2 if self.hasWorkingItem(:FLOATSTONE)
    w*=@effects[PBEffects::WeightMultiplier]
    w=1 if w<1
    return w
  end

  def owned(form=0)
    if form==0
      return (@pokemon) ? $Trainer.owned[@pokemon.species] && !@battle.opponent : false
    else
      return (@pokemon) ? $Trainer.owned[@pokemon.species] && !@battle.opponent && @pokemon.form==form : false
    end
  end

  ################################################################################
  # Creating a battler
  ################################################################################
  def initialize(btl,index,fakebattler=false)
    @battle       = btl
    @index        = index
    @hp           = 0
    @totalhp      = 0
    @fainted      = true
    @usingsubmove = false
    @stages       = []
    @effects      = []
    @damagestate  = PokeBattle_DamageState.new
    @unburdened   = false
    @wonderroom   = false
    @userSwitch   = false
    @forcedSwitch = false
    @forcedSwitchEarlier = false
    @vanished     = false
    @passing      = false
    @custap       = false
    @moldbroken   = false
    @corroded     = false
    @effects[PBEffects::EarlyBirdBoost] = 0
    @critted      = false
    @sleeptalk    = false
    @missed       = true
    @missAcc      = false
    @grazed       = false
    @statLowered  = false
    @hasmegad     = false
    @capturable   = false
    pbInitBlank
    pbInitEffects(false,true,true,fakebattler)
    pbInitPermanentEffects
  end

  def pbInitPokemon(pkmn,pkmnIndex,wonderroom=false,initialize_tribute=true)
    pbExpireCoconBerryShield
    pbDiscardConsumableHeldItemDose
    @faintAbilitySource=nil
    @faintCopiedAbility=nil
    @name         = pkmn.name
    @species      = pkmn.species
    @level        = pkmn.level
    @hp           = pkmn.hp
    @totalhp      = pkmn.totalhp
    @gender       = pkmn.gender
    @ability      = PBAbilityData.canonical_id(pkmn.ability)
    @type1        = pkmn.type1
    @type2        = pkmn.type2
    @form         = pkmn.form
    @attack       = pkmn.attack
    @defense      = pkmn.defense
    @speed        = pkmn.speed
    @spatk        = pkmn.spatk
    @spdef        = pkmn.spdef
	@shieldCount = $game_variables[704]
    if wonderroom
      aux=pkmn.spdef
      @spdef=pkmn.defense
      @defense = aux
    end
    @status       = pkmn.status
    @statusCount  = pkmn.statusCount
    @pokemon      = pkmn
    @pokemonIndex = pkmnIndex
    @participants = [] # Participants will earn Exp. Points if this battler is defeated
    @moves        = [
      PokeBattle_Move.pbFromPBMove(@battle,pkmn.moves[0],self),
      PokeBattle_Move.pbFromPBMove(@battle,pkmn.moves[1],self),
      PokeBattle_Move.pbFromPBMove(@battle,pkmn.moves[2],self),
      PokeBattle_Move.pbFromPBMove(@battle,pkmn.moves[3],self)
    ]
    @beneficialStatus = pkmn.beneficialStatus
    @beneficialStatusData = pkmn.beneficialStatusData
    @iv           = []
    @iv[0]        = pkmn.iv[0]
    @iv[1]        = pkmn.iv[1]
    @iv[2]        = pkmn.iv[2]
    @iv[3]        = pkmn.iv[3]
    @iv[4]        = pkmn.iv[4]
    @iv[5]        = pkmn.iv[5]
    @item         = pkmn.item
    pbInitializeTributeDraco if initialize_tribute
    @missed       = true
    @missAcc      = false
    @grazed       = false
    @statLowered  = false
    @startform = @form
  end

  def pbInitBlank
    @name         = ""
    @species      = 0
    @level        = 0
    @hp           = 0
    @totalhp      = 0
    @gender       = 0
    @ability      = 0
    @type1        = 0
    @type2        = 0
    @form         = 0
    @attack       = 0
    @defense      = 0
    @speed        = 0
    @spatk        = 0
    @spdef        = 0
    @status       = 0
    @statusCount  = 0
    @pokemon      = nil
    @pokemonIndex = -1
    @participants = []
    @moves        = [nil,nil,nil,nil]
    @iv           = [0,0,0,0,0,0]
    @item         = 0
    @beneficialStatus = nil
    @beneficialStatusData = nil
    @tributeDracoActive = false
    @tributeDracoBattleMove = nil
    @tributeDracoOriginalMove = nil
    @weight       = nil
    @missed       = true
    @missAcc      = false
    @grazed       = false
    @statLowered  = false
    @isBoss       = false
  end

  def pbInitPermanentEffects
    # These effects are always retained even if a PokÃ©mon is replaced
    @effects[PBEffects::FutureSight]       = 0
    @effects[PBEffects::FutureSightDamage] = 0
    @effects[PBEffects::FutureSightMove]   = 0
    @effects[PBEffects::FutureSightUser]   = -1
    @effects[PBEffects::FutureSightPkmnIdx] = -1
    @effects[PBEffects::Forebode]          = [false,-1,-1] # Active, user idx, party idx
    @effects[PBEffects::HealingWish]       = false
    @effects[PBEffects::LunarDance]        = false
    @effects[PBEffects::Wish]              = 0
    @effects[PBEffects::WishAmount]        = 0
    @effects[PBEffects::WishMaker]         = -1
    @effects[PBEffects::TributeWishOverheal] = false
    @effects[PBEffects::HealerWish]        = false
    @effects[PBEffects::ZHeal]             = false
    @effects[PBEffects::Blazed]            = false
    @effects[PBEffects::Savagery]          = 0
    @effects[PBEffects::RampCrestUsage]    = false
  end

  def pbInitEffects(batonpass,illusion=true,effectnegate=false,fakebattler=false)
    if isFainted?
      pbExpireCoconBerryShield
      pbDiscardConsumableHeldItemDose
    end
    if !batonpass
      # These effects are retained if Baton Pass is used
      @stages[PBStats::ATTACK]   = 0
      @stages[PBStats::DEFENSE]  = 0
      @stages[PBStats::SPEED]    = 0
      @stages[PBStats::SPATK]    = 0
      @stages[PBStats::SPDEF]    = 0
      @stages[PBStats::EVASION]  = 0
      @stages[PBStats::ACCURACY] = 0
      @lastMoveUsedSketch        = -1
      @effects[PBEffects::AquaRing]    = false
      @effects[PBEffects::Confusion]   = 0
      @effects[PBEffects::Curse]       = false
      @effects[PBEffects::Embargo]     = 0
      @effects[PBEffects::LeerBlock]   = 0
      @effects[PBEffects::FocusEnergy] = 0
      @effects[PBEffects::FriskLock]   = 0
      @effects[PBEffects::ForewarnDisable] = 0
      @effects[PBEffects::ForewarnDisableMove] = 0
      @effects[PBEffects::ShedSkinUsed] = false
      @effects[PBEffects::StenchUsed] = []
      @effects[PBEffects::LaserFocus]  = 0
      @effects[PBEffects::GastroAcid]  = false
      @effects[PBEffects::HealBlock]   = 0
      @effects[PBEffects::Ingrain]     = false
      @effects[PBEffects::JawLock]     = false
      @effects[PBEffects::JawLockUser] = -1
      @effects[PBEffects::NightmareAura]      = false
      @effects[PBEffects::EarlyBirdBoost] = 0
      if !fakebattler
        @battle.eachActiveBattlerIndex do |i|
          battler=@battle.battlers[i]
          next if !battler || battler.effects[PBEffects::JawLockUser]!=@index || !battler.effects[PBEffects::JawLock]
          battler.effects[PBEffects::JawLock]=false
          battler.effects[PBEffects::JawLockUser]=-1
        end
      end
      @effects[PBEffects::LeechSeed]   = -1
      @effects[PBEffects::Crushing]   = -1
      @effects[PBEffects::LockOn]      = 0
      @effects[PBEffects::LockOnPos]   = -1
      if !effectnegate && !fakebattler
        @battle.eachActiveBattlerIndex do |i|
          next if !@battle.battlers[i]
          if @battle.battlers[i].effects[PBEffects::LockOnPos]==@index &&
            @battle.battlers[i].effects[PBEffects::LockOn]>0
            @battle.battlers[i].effects[PBEffects::LockOn]=0
            @battle.battlers[i].effects[PBEffects::LockOnPos]=-1
          end
        end
      end
      @effects[PBEffects::MagnetRise]         = 0
      @effects[PBEffects::PerishSong]         = 0
      @effects[PBEffects::PerishSongUser]     = -1
      @effects[PBEffects::PowerTrick]         = false
      @effects[PBEffects::Substitute]         = 0
      @effects[PBEffects::Telekinesis]        = 0
    else
      # Baton Pass now only passes Speed stat, reset all others
      @stages[PBStats::ATTACK]   = 0
      @stages[PBStats::DEFENSE]  = 0
      # Keep Speed: @stages[PBStats::SPEED] is not reset
      @stages[PBStats::SPATK]    = 0
      @stages[PBStats::SPDEF]    = 0
      @stages[PBStats::EVASION]  = 0
      @stages[PBStats::ACCURACY] = 0
      if @effects[PBEffects::LockOn]>0
        @effects[PBEffects::LockOn]=2
      else
        @effects[PBEffects::LockOn]=0
      end
      #      if @effects[PBEffects::PowerTrick]
      #        s=@attack
      #        @attack=@defense
      #        @defense=a
      #      end
    end
    @damagestate.reset
    @fainted        = false
    @lastAttacker   = -1
    @faintingMove   = nil
    @lastHPLost     = 0
    @lastMoveUsed   = -1
    @moveHistory    = []
    @lastRoundMoved = -1
    @itemUsed       = false
    @itemUsed2      = false
    @movesUsed      = []
    @turncount      = 0
    pbCureAttract
    if !effectnegate
      @battle.eachActiveBattlerIndex do |i|
        next if !@battle.battlers[i] || fakebattler
        if @battle.battlers[i].effects[PBEffects::Attract]==@index
          @battle.battlers[i].pbCureAttract
        end
      end
    end
    @effects[PBEffects::Charge]           = false
    @effects[PBEffects::AbilityCharge]    = false
    @effects[PBEffects::CellSplitter]     = 0
    @effects[PBEffects::ChoiceBand]       = -1
    @effects[PBEffects::CounterStance]    = 0
    @effects[PBEffects::DefenseCurl]      = false
    @effects[PBEffects::DestinyBond]      = false
    @effects[PBEffects::Disable]          = 0
    @effects[PBEffects::DisableMove]      = 0
    @effects[PBEffects::EchoedVoice]      = 0
    @effects[PBEffects::Encore]           = 0
    @effects[PBEffects::EncoreIndex]      = 0
    @effects[PBEffects::EncoreMove]       = 0
    @effects[PBEffects::Disguise]         = false
    @effects[PBEffects::IceFace]          = false
    @effects[PBEffects::Disguise]         = true if self.species==778 && self.form==0 # Mimikyu
    @effects[PBEffects::IceFace]          = true if self.species==875 && self.form==0 # Eiscue
    @effects[PBEffects::Endure]           = false
    @effects[PBEffects::MiracleGuard]     = false
    @effects[PBEffects::FairyLockRate]    = false
    @effects[PBEffects::Fertilize]        = false
    @effects[PBEffects::FlashFire]        = false
    @effects[PBEffects::FlameWreath]      = 0
    @effects[PBEffects::Flinch]           = false
    @effects[PBEffects::FollowMe]         = false
    @effects[PBEffects::RagePowder]       = false
    @effects[PBEffects::Rebuild]          = 0
    @effects[PBEffects::Foresight]        = false
    @effects[PBEffects::FuryCutter]       = 0
    @effects[PBEffects::Grudge]           = false
    @effects[PBEffects::HelpingHand]      = false
    @effects[PBEffects::HyperBeam]        = 0
    @effects[PBEffects::Imprison]         = false
    @effects[PBEffects::MagicCoat]        = false
    @effects[PBEffects::MagicBounced]     = false
    @effects[PBEffects::MeanLook]         = -1
    @effects[PBEffects::Blinded]          = -1
    @effects[PBEffects::Confusion]        = 0
    @effects[PBEffects::Wounded]          = 0
    @effects[PBEffects::AbsoluteZeroTurn] = -1
    @effects[PBEffects::RiteOfSpring]     = nil
    @effects[PBEffects::Inquisition]      = false
    if !effectnegate
      @battle.eachActiveBattlerIndex do |i|
        next if !@battle.battlers[i] || fakebattler
        if @battle.battlers[i].effects[PBEffects::MeanLook]==@index
          @battle.battlers[i].effects[PBEffects::MeanLook]=-1
          @battle.battlers[i].effects[PBEffects::Octolock] = false
        end
      end
    end
    @effects[PBEffects::Metronome]        = 0
    @effects[PBEffects::Minimize]         = false
    @effects[PBEffects::MiracleEye]       = false
    @effects[PBEffects::MirrorCoatBuff]   = 0
    @effects[PBEffects::MultiTurn]        = 0
    @effects[PBEffects::MultiTurnAttack]  = 0
    @effects[PBEffects::MultiTurnUser]    = -1
    @effects[PBEffects::MultiTurnBindingBand] = false
    if !effectnegate
      @battle.eachActiveBattlerIndex do |i|
        other=@battle.battlers[i]
        next if !other || fakebattler
        other.pbClearMultiTurn if other.effects[PBEffects::MultiTurnUser]==@index
      end
    end
    @effects[PBEffects::Outrage]          = 0
    @effects[PBEffects::Octolock]         = false
    @effects[PBEffects::Pinch]            = false
    @effects[PBEffects::Protect]          = false
    @effects[PBEffects::KingsShield]      = false # add this line
    @effects[PBEffects::SpikyShield]      = false # and this one
    @effects[PBEffects::WideGuardCheck]   = false
    @effects[PBEffects::WideGuardUser]    = false
    @effects[PBEffects::BanefulBunker]    = false
    @effects[PBEffects::SilkTrap]         = false
    @effects[PBEffects::BurningBulwark]   = false
    @effects[PBEffects::Commander]        = false
    @effects[PBEffects::Commandee]        = false
    @effects[PBEffects::Stormhold]        = false
    @effects[PBEffects::ProtectNegation]  = false
    @effects[PBEffects::ProtectRate]      = 1
    @effects[PBEffects::DestinyRate]      = 1
    @effects[PBEffects::Pursuit]          = false
    @effects[PBEffects::Rage]             = false
    @effects[PBEffects::FeverPitchBoost]  = false
    @effects[PBEffects::Revenge]          = 0
    @effects[PBEffects::Rollout]          = 0
    @effects[PBEffects::Roost]            = false
    @effects[PBEffects::SkyDrop]          = false
    @effects[PBEffects::SmackDown]        = false
    @effects[PBEffects::Snatch]           = false
    @effects[PBEffects::Stockpile]        = 0
    @effects[PBEffects::StockpileDef]     = 0
    @effects[PBEffects::StockpileSpDef]   = 0
    @effects[PBEffects::TarShot]          = false
    @effects[PBEffects::SaltCure]         = false
    @effects[PBEffects::SyrupBombTurns]   = 0
    @effects[PBEffects::SyrupBombUser]    = -1
    @effects[PBEffects::PsychicTypeLoss] = 0
    @effects[PBEffects::WaterTypeLoss]   = 0
    @effects[PBEffects::CircadianRhythm]  = false
    @effects[PBEffects::Needles]          = 0
    @effects[PBEffects::MoltenStance]     = false
    @effects[PBEffects::StatChangeHolder] = Array.new(8,0)
    @effects[PBEffects::Taunt]            = 0
    @effects[PBEffects::Torment]          = false
    @effects[PBEffects::Toxic]            = 0
    @effects[PBEffects::Trace]            = false
    @effects[PBEffects::TracedAbility]    = 0
    @effects[PBEffects::Transform]        = false
    @effects[PBEffects::Truant]           = false
    @effects[PBEffects::TwoTurnAttack]    = 0
    @effects[PBEffects::SkyDroppee]       = -1
    @effects[PBEffects::Uproar]           = 0
    @effects[PBEffects::Attacking]        = false
    @effects[PBEffects::AttackingTarget]  = []
    @effects[PBEffects::FeverPitch]       = false
    @effects[PBEffects::UsingSubstituteRightNow] = false
    @effects[PBEffects::WeightMultiplier] = 1.0
    @effects[PBEffects::Yawn]             = 0
    @effects[PBEffects::StatCapPositive] = {}
    @effects[PBEffects::StatCapNegative] = {}
    @effects[PBEffects::StatCapContributors] = {}
    @effects[PBEffects::StatCapPendingMessages] = []
    @effects[PBEffects::BeakBlast]        = false
    @effects[PBEffects::BurnUp]           = false
    @effects[PBEffects::FocusEnergyGuard] = -1
    @effects[PBEffects::ParadoxStat]      = nil
    @effects[PBEffects::ParadoxBooster]   = nil
    @effects[PBEffects::HardenGuard]      = -1
    @effects[PBEffects::LockOnMove]       = false
    @effects[PBEffects::ClangedScales]    = false
    @effects[PBEffects::ShellTrap]        = false
    @effects[PBEffects::SpeedSwap]        = 0
    @effects[PBEffects::Tantrum]          = false
    @effects[PBEffects::ThroatChop]      = 0
    @effects[PBEffects::ShieldLife]      = 0
    #### JERICHO - 001 - START
    if illusion==true
      if isConst?(self.ability,PBAbilities,:ILLUSION) #Illusion
        party=@battle.pbParty(@index)
        party=party.find_all {|item| item && !item.egg? && item.hp>0 }
        if party[party.length-1] != @pokemon
          @effects[PBEffects::Illusion] = party[party.length-1]
        end
      end
    end #Illusion
    #### JERICHO - 001 - END
    #### KUROTSUNE - 004 - START
    @effects[PBEffects::ParentalBond]     = false
    #### KUROTSUNE - 004 - END
    #### KUROTSUNE - 010 - START
    @effects[PBEffects::Round]            = false
    @effects[PBEffects::Howl]             = false
    #### KUROTSUNE - 010 - END
    #### KUROTSUNE - 024 - START
    @effects[PBEffects::Powder]           = false
    #### KUROTSUNE - 023 - END
    #### KUROTSUNE - 024 - START
    @effects[PBEffects::Electrify]        = false
    #### KUROTSUNE - 024 - END
    #### KUROTSUNE - 032 - START
    @effects[PBEffects::MeFirst]          = false
    #### KUROTSUNE - 032 - END
    @effects[PBEffects::TyphBond]         = false
    @effects[PBEffects::Switched]         = false
    @effects[PBEffects::VoreCopy]         = false
    @effects[PBEffects::NoRetreat]        = false
    @effects[PBEffects::BallFetch]        = 0
    @effects[PBEffects::ThunderRaidHit]   = 0
    @effects[PBEffects::TelekinesisBoost] = false
    @effects[PBEffects::TarShot]          = false
    @effects[PBEffects::CritCount]        = 0
    @effects[PBEffects::SusCrit]          = false
    @effects[PBEffects::Obstruct]         = false
    @effects[PBEffects::VespiCrest]       = -1
    @effects[PBEffects::DesertsMark]      = false
    @effects[PBEffects::WorldOfNightmares]= 0
    # Reverb ability effects
    @effects[PBEffects::ReverbEcho]       = {}
    # Stalwart ability effects
    @effects[PBEffects::StalwartMove]     = 0
    @effects[PBEffects::StalwartStacks]   = 0
    @effects[PBEffects::StatCapPositive] = {}
    @effects[PBEffects::StatCapNegative] = {}
    @effects[PBEffects::StatCapContributors] = {}
    @effects[PBEffects::StatCapPendingMessages] = []
    # Additional effect initializations
    @effects[PBEffects::Spritz]           = 0
    @effects[PBEffects::Aftershock]       = 0
    @effects[PBEffects::AftershockMove]   = 0
    @effects[PBEffects::AftershockUser]   = -1
    @effects[PBEffects::MudBath]          = 0
    @effects[PBEffects::NaturalOrder]     = 0
    @effects[PBEffects::CarapaceShed]     = nil
    @effects[PBEffects::CarapaceGift]     = nil
    @effects[PBEffects::PierceTheVeil]    = false
    @effects[PBEffects::DamagingMoveThisTurn] = false
    @effects[PBEffects::UsedAttackThisTurn] = false
    @effects[PBEffects::KingsRockGuardUsed] = false
    @effects[PBEffects::HeartLocketUsed]  = false
    @effects[PBEffects::TrickRoomOnEntry] = false
    @effects[PBEffects::BlinkEntryTurn]   = 0
    @effects[PBEffects::ActedThisTurn]    = false
    @effects[PBEffects::SpookyTribute]    = 0
    @spookyTributeLane=nil
    @effects[PBEffects::LiminalAttackBoost] = false
    @effects[PBEffects::LiminalAttackThisMove] = false
    @effects[PBEffects::LiminalStatusPriority] = false
    @effects[PBEffects::TimetwisterState] = nil
    @effects[PBEffects::TributePendingShield] = false
    @effects[PBEffects::TributeOverhealShield] = nil
    @effects[PBEffects::TributeDamageTaken] = 0
    @effects[PBEffects::TributeFlameRefresh] = false
    @effects[PBEffects::TributeMoltresSwitch] = false
    @effects[PBEffects::TributeRoostBoost] = false
    @effects[PBEffects::TributeProtection] = 0
    @effects[PBEffects::TributeMukMystic] = nil
    @effects[PBEffects::TributeSpookyPig] = false
    @effects[PBEffects::TributeSpookyPigData] = nil
    @effects[PBEffects::TributeTypeShift] = 0
    @effects[PBEffects::TributeTypeShiftData] = nil
    @effects[PBEffects::TributeOrthwormShedHP] = 0
    @effects[PBEffects::TrickRoom]        = 0
    @effects[PBEffects::Mimic]            = 0
    @effects[PBEffects::StrengthSap]      = 0
    @effects[PBEffects::SapSipper]        = 0
    @effects[PBEffects::Counterpoise] = false
    @effects[PBEffects::Resusitated]      = false
  end

  def pbUpdate(fullchange=false,wonderroom=false)
    if @pokemon
      @pokemon.calcStats
      @level     = @pokemon.level
      @hp        = @pokemon.hp
      @totalhp   = @pokemon.totalhp
      if !@effects[PBEffects::Transform]
        @attack    = @pokemon.attack
        @defense   = @pokemon.defense
        @speed     = @pokemon.speed
        @spatk     = @pokemon.spatk
        @spdef     = @pokemon.spdef
        if wonderroom
          aux = @pokemon.spdef
          @spdef = @pokemon.defense
          @defense = aux
        end
        if @effects[PBEffects::PierceTheVeil]
          @attack,@defense=@defense,@attack
          @spatk,@spdef=@spdef,@spatk
        end
        if fullchange
          @ability = PBAbilityData.canonical_id(@pokemon.ability)
          @type1   = @pokemon.type1
          @type2   = @pokemon.type2
        end
      end
    end
  end

  def pbInitialize(pkmn,index,batonpass)
    # Cure status of previous Pokemon with Natural Cure
    if self.hasWorkingAbility(:NATURALCURE) || (self.hasWorkingAbility(:TRACE) &&
        self.effects[PBEffects::TracedAbility]==30) && @pokemon
      self.status=0
    end
    if self.hasWorkingAbility(:REGENERATOR) || @battle.SilvallyCheck(self, "poison") ||
      (self.hasWorkingAbility(:TRACE) && self.effects[PBEffects::TracedAbility]==144) &&
      @pokemon
      self.pbRecoverHP((totalhp/3).floor)
    end
    pbInitPokemon(pkmn,index)
    pbInitEffects(batonpass)
    if self.isbossmon
      pbInitBoss(pkmn,index)
      @battle.shieldCount = pkmn.shieldCount ? pkmn.shieldCount : $game_variables[704]
      shieldlife=[(self.totalhp/4).floor,1].max
      self.effects[PBEffects::ShieldLife]=shieldlife
      # Note: Entry effects are called later in pbStartBattleCore after scene is initialized
    end
  end

  # Used only to erase the battler of a Shadow PokÃ©mon that has been snagged.
  def pbReset
    @pokemon                = nil
    @pokemonIndex           = -1
    self.hp                 = 0
    pbInitEffects(false)
    # reset status
    self.status             = 0
    self.statusCount        = 0
    @fainted                = true
    # reset choice
    @battle.choices[@index] = [0,0,nil,-1]
    return true
  end

  # Update PokÃ©mon who will gain EXP if this battler is defeated
  def pbUpdateParticipants
    return if self.isFainted? # can't update if already fainted
    if @battle.pbIsOpposing?(@index)
      @battle.eachOtherSideBattler(@index) do |battler|
        next if battler.isFainted?
        if !@participants.include?(battler.pokemonIndex)
          @participants[@participants.length]=battler.pokemonIndex
        end
      end
    end
  end

  ################################################################################
  # About this battler
  ################################################################################
  #### JERICHO - 001 - START
  def pbThis(lowercase=false)
    if @battle.pbIsOpposing?(@index)
      if @battle.opponent && !@battle.battlers[@index].isbossmon
        return lowercase ? _INTL("the foe {1}",self.name) : _INTL("The foe {1}",self.name)
      elsif @battle.battlers[@index].isbossmon
        return lowercase ? _INTL("{1}",self.name) : _INTL("{1}",self.name)
      else
        return lowercase ? _INTL("the wild {1}",self.name) : _INTL("The wild {1}",self.name)
      end
    elsif @battle.pbOwnedByPlayer?(@index)
      return _INTL("{1}",self.name)
    else
      return lowercase ? _INTL("the ally {1}",self.name) : _INTL("The ally {1}",self.name)
    end
  end

  def name #Illusion
    return @effects[PBEffects::Illusion] != nil  ? @effects[PBEffects::Illusion].name : @name
  end #Illusion
  #### JERICHO - 001 - END

  def species #Illusion
    return @effects[PBEffects::Illusion] != nil  ? @effects[PBEffects::Illusion].species : @species
  end

  def real_species
    return @species
  end


  def pbHasType?(type)
    if type.is_a?(Symbol) || type.is_a?(String)
      ret=isConst?(self.type1,PBTypes,type.to_sym) ||
      isConst?(self.type2,PBTypes,type.to_sym)
      return ret
    else
      return (self.type1==type || self.type2==type)
    end
  end

  def pbBurnedOut?
    @effects[PBEffects::BurnUp] && @battle.turncount<@effects[PBEffects::BurnUp]
  end

  def type1
    return pbCurrentTypes[0]
  end

  def type2
    return pbCurrentTypes[1]
  end

  def pbCurrentTypes
    return [PBTypes::PSYCHIC,PBTypes::PSYCHIC] if @effects[PBEffects::TributeSpookyPig]
    gift=@effects[PBEffects::CarapaceGift]
    shed=@effects[PBEffects::CarapaceShed]
    burned_out=pbBurnedOut?
    lost_psychic=@battle.turncount<@effects[PBEffects::PsychicTypeLoss].to_i
    lost_water=@battle.turncount<@effects[PBEffects::WaterTypeLoss].to_i
    return [@type1,@type2] if !gift && !shed && !burned_out && !lost_psychic && !lost_water
    types=gift ? [gift[0]] : [@type1,@type2].uniq
    types.delete(shed[0]) if shed
    types.delete(PBTypes::FIRE) if burned_out
    types.delete(PBTypes::PSYCHIC) if lost_psychic
    types.delete(PBTypes::WATER) if lost_water
    primary=types[0] || PBTypes::QMARKS
    return [primary,types[1] || primary]
  end

  def hasType?(type) # for typemod non-battler ease
    if type.is_a?(Symbol) || type.is_a?(String)
      ret=isConst?(self.type1,PBTypes,type.to_sym) ||
      isConst?(self.type2,PBTypes,type.to_sym)
      return ret
    else
      return (self.type1==type || self.type2==type)
    end
  end

  def pbCamouflageType
    # Field effects override terrain/environment
    if $fefieldeffect && $fefieldeffect>0
      case $fefieldeffect
      when 1  then return PBTypes::ELECTRIC
      when 2  then return PBTypes::GRASS
      when 3  then return PBTypes::FAIRY
      when 4  then return PBTypes::DARK
      when 5  then return PBTypes::PSYCHIC
      when 6  then return PBTypes::NORMAL
      when 7  then return PBTypes::FIRE
      when 8  then return PBTypes::WATER
      when 9  then return PBTypes::DRAGON
      when 10 then return PBTypes::POISON
      when 11 then return PBTypes::POISON
      when 12 then return PBTypes::GROUND
      when 13 then return PBTypes::ICE
      when 14 then return PBTypes::ROCK
      when 15 then return PBTypes::BUG
      when 17 then return PBTypes::STEEL
      when 18 then return PBTypes::ELECTRIC
      when 19 then return PBTypes::POISON
      when 20 then return PBTypes::GROUND
      when 21 then return PBTypes::WATER
      when 22 then return PBTypes::WATER
      when 23 then return PBTypes::ROCK
      when 24 then return PBTypes::FLYING
      when 25 then return [PBTypes::FIRE,PBTypes::WATER,PBTypes::GRASS,PBTypes::PSYCHIC][@battle.pbRandom(4)]
      when 26 then return PBTypes::POISON
      when 27 then return PBTypes::ROCK
      when 28 then return PBTypes::ICE
      when 29 then return PBTypes::NORMAL
      when 31 then return PBTypes::FAIRY
      when 32 then return PBTypes::DRAGON
      when 33 then return PBTypes::GRASS
      when 34 then return PBTypes::DARK
      when 35 then return @battle.pbRandom(PBTypes.maxValue+1)
      when 36 then return PBTypes::NORMAL
      when 40 then return PBTypes::GHOST
      when 41 then return PBTypes::POISON
      when 42 then return PBTypes::FAIRY
      when 43 then return PBTypes::FLYING
      #pk code
      when 44 then return PBTypes::STEEL
      when 45 then return PBTypes::FIRE
      when 46 then return PBTypes::GROUND
      when 47 then return PBTypes::NORMAL
      end
    end
    # Terrain overrides environment
    if @battle.field.effects[PBEffects::ElectricTerrain]>0
      return PBTypes::ELECTRIC
    elsif @battle.field.effects[PBEffects::GrassyTerrain]>0
      return PBTypes::GRASS
    elsif @battle.field.effects[PBEffects::MistyTerrain]>0
      return PBTypes::FAIRY
    elsif @battle.field.effects[PBEffects::PsychicTerrain]>0
      return PBTypes::PSYCHIC
    end
    case @battle.environment
    when PBEnvironment::Grass, PBEnvironment::TallGrass
      return PBTypes::GRASS
    when PBEnvironment::MovingWater, PBEnvironment::StillWater, PBEnvironment::Underwater
      return PBTypes::WATER
    when PBEnvironment::Sand
      return PBTypes::GROUND
    when PBEnvironment::Rock, PBEnvironment::Cave
      return PBTypes::ROCK
    else
      return PBTypes::NORMAL
    end
  end

  def pbApplyCamouflageMoveTypes(newtype)
    return if newtype.nil? || newtype <= 0
    normal_type = PBTypes::NORMAL
    for move in @moves
      next if move.type != normal_type
      move.type = newtype
    end
  end

  def pbHasMove?(id)
    if id.is_a?(String) || id.is_a?(Symbol)
      id=getID(PBMoves,id)
    end
    id=PBMove.current_id(id)
    return false if !id || id==0
    for i in @moves
      return true if i && i.id==id
    end
    return false
  end

  def pbHasMoveFunction?(code)
    return false if !code
    for i in @moves
      return true if i && i.function==code
    end
    return false
  end

  def hasMovedThisRound?
    return false if !@lastRoundMoved
    return @lastRoundMoved==@battle.turncount
  end

  def isFainted?
    return @hp<=0
  end

  def abilityWorks?(ignorefainted=false)
    return false if self.isFainted? if !ignorefainted
    return false if @effects[PBEffects::GastroAcid]
    return false if @effects[PBEffects::MultiTurnAttack]==PBMoves::BINDINGWORD
    return true if [PBAbilities::NEUTRALIZINGGAS,PBAbilities::STANCECHANGE,
      PBAbilities::SCHOOLING].include?(@ability)
    return !@battle.pbCheckGlobalAbility(:NEUTRALIZINGGAS)
  end

  def abilitynulled
    return !abilityWorks?
  end

  def pbSuppressAbility
    gas_ended=hasWorkingAbility(:NEUTRALIZINGGAS)
    @effects[PBEffects::GastroAcid]=true
    @effects[PBEffects::Truant]=false
    @battle.pbDisplay(_INTL("{1}'s ability was suppressed!",pbThis))
    @battle.pbNeutralizingGasEnded if gas_ended
  end

  def pbMarvelScaleActive?
    return status>0 || $fefieldeffect==3 || @battle.field.effects[PBEffects::MistyTerrain]>0
  end

  def pbPlusMinusBoost?
    return (hasWorkingAbility(:PLUS) && pbOwnSide.effects[PBEffects::MinusSignal]>0) ||
           (hasWorkingAbility(:MINUS) && pbOwnSide.effects[PBEffects::PlusSignal]>0)
  end

  def pbShedSkinReady?
    return hasWorkingAbility(:SHEDSKIN) && !@effects[PBEffects::ShedSkinUsed]
  end

  def hasWorkingAbility(ability,ignorefainted=false)
    return isConst?(PBAbilityData.canonical_id(@ability),PBAbilities,ability) &&
      abilityWorks?(ignorefainted)
  end

  def itemWorks?(ignorefainted=false)
    return false if self.isFainted? if !ignorefainted
    return false if @effects[PBEffects::Embargo]>0
    return false if @effects[PBEffects::FriskLock]>0
    return false if @effects[PBEffects::MultiTurnAttack]==PBMoves::BINDINGWORD
    return false if @battle.field.effects[PBEffects::MagicRoom]>0
    return false if pbKlutzActive?
    return true
  end

  def hasWorkingItem(item,ignorefainted=false)
    return false if self.isFainted? if !ignorefainted
    return false if @effects[PBEffects::Embargo]>0
    return false if @effects[PBEffects::FriskLock]>0
    return false if @effects[PBEffects::MultiTurnAttack]==PBMoves::BINDINGWORD
    return false if @battle.field.effects[PBEffects::MagicRoom]>0
    return false if pbKlutzActive?
    return isConst?(@item,PBItems,item)
  end

  def pbKlutzActive?
    return @effects[PBEffects::BlinkEntryTurn]==@battle.turncount &&
           hasWorkingAbility(:KLUTZ,true)
  end

  def pbNextRepeatCount(move_id)
    return 0 if move_id!=lastMoveUsed
    return (@effects[PBEffects::Metronome] || 0)+1
  end

  def pbRepeatDamageMultiplier(repeat_count)
    multiplier=1.0
    multiplier*=[1.0+0.1*repeat_count,2.0].min if hasWorkingAbility(:OWNTEMPO)
    multiplier*=[1.0+0.2*repeat_count,2.0].min if hasWorkingItem(:METRONOME)
    return multiplier
  end

  def pbWeatherDefenseMultiplier(stat)
    return 1.0 if moldbroken
    weather=@battle.pbWeather
    if stat==PBStats::DEFENSE
      return 1.5 if weather==PBWeather::SANDSTORM && hasWorkingAbility(:SANDVEIL)
      return 1.5 if weather==PBWeather::SUNNYDAY && !hasWorkingItem(:UTILITYUMBRELLA) &&
                    hasWorkingAbility(:FLOWERVEIL)
    elsif stat==PBStats::SPDEF
      return 1.5 if weather==PBWeather::HAIL && hasWorkingAbility(:SNOWVEIL)
      return 1.5 if weather==PBWeather::RAINDANCE && !hasWorkingItem(:UTILITYUMBRELLA) &&
                    hasWorkingAbility(:WATERVEIL)
    end
    return 1.0
  end

  def isAirborne?
    return false if self.hasWorkingItem(:IRONBALL)
    return false if @effects[PBEffects::Ingrain]
    return false if @effects[PBEffects::DesertsMark]
    return false if @effects[PBEffects::SmackDown]
    return true if @battle.field.effects[PBEffects::Gravity]>0 && self.hasWorkingItem(:ANTIGRAVITYCORE)
    return false if @battle.field.effects[PBEffects::Gravity]>0
    return true if self.pbHasType?(:FLYING) && @effects[PBEffects::Roost]==false
    return true if self.hasWorkingAbility(:LEVITATE)
    return true if (self.hasWorkingAbility(:SOLARIDOL) || self.hasWorkingAbility(:LUNARIDOL))
    return true if self.hasWorkingItem(:AIRBALLOON)
    return true if @effects[PBEffects::MagnetRise]>0
    return true if @effects[PBEffects::Telekinesis]>0
    return false
  end

  #>>>>DemICE entered the chat
  def pbHydroplaneActive?
    return hasWorkingAbility(:HYDROPLANE) &&
      (@battle.pbWeather==PBWeather::RAINDANCE || $fefieldeffect==21) &&
      !hasWorkingItem(:UTILITYUMBRELLA)
  end

  def pbAbilitySpecialAttack
    return hasWorkingAbility(:ESOTERIC) ? spatk*2 : pbParadoxAdjustedStat(spatk,PBStats::SPATK)
  end

  def pbParadoxAbility
    return PBAbilities::PROTOSYNTHESIS if hasWorkingAbility(:PROTOSYNTHESIS)
    return PBAbilities::QUARKDRIVE if hasWorkingAbility(:QUARKDRIVE)
    nil
  end

  def pbParadoxFieldActive?(source)
    case source
    when PBAbilities::PROTOSYNTHESIS
      return @battle.pbWeather==PBWeather::SUNNYDAY && !hasWorkingItem(:UTILITYUMBRELLA)
    when PBAbilities::QUARKDRIVE
      return $fefieldeffect==1 || @battle.field.effects[PBEffects::ElectricTerrain]>0
    end
    false
  end

  def pbParadoxHighestStat
    values={PBStats::ATTACK=>attack,PBStats::DEFENSE=>defense,PBStats::SPATK=>spatk,
      PBStats::SPDEF=>spdef,PBStats::SPEED=>speed}
    values.max_by do |stat,value|
      stage=stages[stat]
      stage>=0 ? value*(2+stage)/2.0 : value*2.0/(2-stage)
    end.first
  end

  def pbRefreshParadoxBoost
    field_stat=@effects[PBEffects::ParadoxStat]
    if field_stat && !pbParadoxFieldActive?(field_stat[0])
      @effects[PBEffects::ParadoxStat]=nil
    end
    source=pbParadoxAbility
    return if !source
    item_stat=@effects[PBEffects::ParadoxBooster]
    return if item_stat && item_stat[0]==source
    field_active=pbParadoxFieldActive?(source)
    return if @effects[PBEffects::ParadoxStat] && @effects[PBEffects::ParadoxStat][0]==source
    return if !field_active && !hasWorkingItem(:BOOSTERENERGY)
    stat=pbParadoxHighestStat
    if field_active
      @effects[PBEffects::ParadoxStat]=[source,stat]
    else
      @effects[PBEffects::ParadoxBooster]=[source,stat]
      pbUseConsumableHeldItem
    end
    @battle.pbDisplay(_INTL("{1}'s {2} heightened its {3}!",pbThis,PBAbilities.getName(source),pbGetStatName(stat)))
  end

  def pbParadoxAdjustedStat(value,stat)
    source=pbParadoxAbility
    return value if !source
    item_stat=@effects[PBEffects::ParadoxBooster]
    field_stat=@effects[PBEffects::ParadoxStat]
    boosted=if item_stat && item_stat[0]==source
      item_stat[1]
    elsif pbParadoxFieldActive?(source)
      field_stat && field_stat[0]==source ? field_stat[1] : pbParadoxHighestStat
    end
    return value if boosted!=stat
    return (value*(stat==PBStats::SPEED ? 1.5 : 1.3)).floor
  end

  def pbCalcAttack()
    stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
    stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
    atk=pbParadoxAdjustedStat(@attack,PBStats::ATTACK)
    atkstage=@stages[PBStats::ATTACK]+6
    if @effects[PBEffects::PowerTrick]
      atk=pbParadoxAdjustedStat(@defense,PBStats::DEFENSE)
      atkstage=@stages[PBStats::DEFENSE]+6
    end
    if @stages[PBStats::ATTACK] >= 0
      stagemulp=1+0.5*@stages[PBStats::ATTACK]
      atk=(atk*1.0*stagemulp).floor
    else
      atk=(atk*1.0*stagemul[atkstage]/stagediv[atkstage]).floor
    end
    if self.hasWorkingAbility(:HUSTLE)
      atk=(atk*1.5).round
    end
    if self.hasWorkingItem(:LIGHTBALL) && isConst?(self.species,PBSpecies,:PIKACHU)
      atk=self.pbSpeed
    end
    atkmult=0x1000
    atkmult=(atkmult*1.5).round if pbHydroplaneActive?
    if self.hasWorkingAbility(:GUTS) &&
      self.status!=0
      atkmult=(atkmult*1.5).round
    end
    if self.hasWorkingAbility(:DEFEATIST) &&
      self.hp<=(self.totalhp/2).floor
      atkmult=(atkmult*0.5).round
    end
    if ((self.hasWorkingAbility(:PUREPOWER) && $fefieldeffect!=37) ||
        self.hasWorkingAbility(:HUGEPOWER))
      atkmult=(atkmult*2.0).round
    end
    if self.hasWorkingAbility(:SLOWSTART) &&
      self.turncount<5
      atkmult=(atkmult*0.5).round
    end
    if pbPlusMinusBoost?
      atkmult=(atkmult*1.3).round
    end
    if self.hasWorkingAbility(:HARVESTMOON) &&
      (@battle.field.effects[PBEffects::GrassyTerrain]>0 || $fefieldeffect==2)
      atkmult=(atkmult*1.5).round
    end
    if (@battle.pbWeather==PBWeather::SUNNYDAY || $fefieldeffect == 33 ||
        (self.hasWorkingItem(:CHERCREST) && isConst?(self.species,PBSpecies,:CHERRIM)) ||
        self.sameSideLivingBattlers(false).any? { |ally| ally.hasWorkingItem(:CHERCREST) && isConst?(ally.species,PBSpecies,:CHERRIM) } )
      if self.hasWorkingAbility(:FLOWERGIFT) &&
        isConst?(self.species,PBSpecies,:CHERRIM)
        atkmult=(atkmult*1.5).round
      end
      if self.sameSideLivingBattlers(false).any? { |ally| ally.hasWorkingAbility(:FLOWERGIFT) && isConst?(ally.species,PBSpecies,:CHERRIM) }
        atkmult=(atkmult*1.5).round
      end
    end
    if self.hasWorkingItem(:THICKCLUB) &&
      (isConst?(self.species,PBSpecies,:CUBONE) ||
        isConst?(self.species,PBSpecies,:MAROWAK))
      atkmult=(atkmult*2.0).round
    end
    if self.hasWorkingItem(:LIGHTBALL) &&
      isConst?(self.species,PBSpecies,:PIKACHU)
      atkmult=(atkmult*2.0).round
    end
    if self.hasWorkingItem(:CHOICEBAND)
      atkmult=(atkmult*1.5).round
    end
    atkmult=(atkmult*0.5).round if self.status==PBStatuses::BURN && !self.hasWorkingAbility(:GUTS) #pk code
    if self.hasWorkingAbility(:LONGREACH) &&
      ($fefieldeffect==27 || $fefieldeffect==28)
      atkmult=(atkmult*1.5).round
    end
    atk=(atk*atkmult*1.0/0x1000).round
    return atk
  end

  def pbCalcSpAtk()
    stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
    stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
    atk=pbAbilitySpecialAttack
    atkstage=@stages[PBStats::SPATK]+6
    if @stages[PBStats::SPATK] >= 0
      stagemulp=1+0.5*@stages[PBStats::SPATK]
      atk=(atk*1.0*stagemulp).floor
    else
      atk=(atk*1.0*stagemul[atkstage]/stagediv[atkstage]).floor
    end
    atkmult=0x1000
    if pbPlusMinusBoost?
      atkmult=(atkmult*1.3).round
    end
    if self.hasWorkingAbility(:DUSTDEVIL) && @battle.pbWeather==PBWeather::SANDSTORM
      atkmult=(atkmult*1.5).round
    end
    if self.otherSameSideAbilityHolder(:BATTERY)
      atkmult=(atkmult*1.3).round
    end
    if self.hasWorkingAbility(:DEFEATIST) &&
      self.hp<=(self.totalhp/2).floor
      atkmult=(atkmult*0.5).round
    end
    if self.hasWorkingAbility(:PUREPOWER) && $fefieldeffect==37
      atkmult=(atkmult*2.0).round
    end
    if self.hasWorkingAbility(:SOLARPOWER) &&
      @battle.pbWeather==PBWeather::SUNNYDAY
      atkmult=(atkmult*1.5).round
    end
    if self.hasWorkingItem(:DEEPSEATOOTH) &&
      isConst?(self.species,PBSpecies,:CLAMPERL)
      atkmult=(atkmult*2.0).round
    end
    if self.hasWorkingItem(:LIGHTBALL) &&
      isConst?(self.species,PBSpecies,:PIKACHU)
      atkmult=(atkmult*2.0).round
    end
    if self.hasWorkingItem(:CHOICESPECS)
      atkmult=(atkmult*1.5).round
    end
    atkmult=(atkmult*0.5).round if self.status==PBStatuses::FROZEN #pk code
    if $fefieldeffect == 34 || $fefieldeffect == 35
      if self.hasWorkingAbility(:VICTORYSTAR)
        atkmult=(atkmult*1.5).round
      end
      partner=self.otherSameSideAbilityHolder(:VICTORYSTAR)
      if partner && partner.hasWorkingAbility(:VICTORYSTAR)
        atkmult=(atkmult*1.5).round
      end
    end
    if self.hasWorkingAbility(:LONGREACH) &&
      ($fefieldeffect==27 || $fefieldeffect==28)
      atkmult=(atkmult*1.5).round
    end
    atk=(atk*atkmult*1.0/0x1000).round
    return atk
  end

  def pbCalcDefense()
    stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
    stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
    applyhail=false
    defense=pbParadoxAdjustedStat(@defense,PBStats::DEFENSE)
    defstage=@stages[PBStats::DEFENSE]+6
    applyhail=true
    if @effects[PBEffects::PowerTrick]
      defense=pbParadoxAdjustedStat(@attack,PBStats::ATTACK)
      defstage=@stages[PBStats::DEFENSE]+6
    end
    defense*=2 if @effects[PBEffects::Counterpoise]
    # TODO: Wonder Room should apply around here
    if @stages[PBStats::DEFENSE] >= 0
      stagemulp=1+0.5*@stages[PBStats::DEFENSE]
      defense=(defense*1.0*stagemulp).floor
    else
      defense=(defense*1.0*stagemul[defstage]/stagediv[defstage]).floor
    end
    if @battle.pbWeather==PBWeather::HAIL &&
      self.pbHasType?(:ICE) && applyhail
      defense=(defense*1.5).round
    end
    defmult=0x1000
    if $fefieldeffect == 24 && @function==0xE0
      defmult=(defmult*0.5).round
    end
    if self.hasWorkingAbility(:MARVELSCALE) && pbMarvelScaleActive?
      defmult=(defmult*1.5).round
    end
    if self.hasWorkingAbility(:NATURALSHROUD) && pbTerrainActive?
      defmult=(defmult*1.5).round
    end
    defmult=(defmult*pbWeatherDefenseMultiplier(PBStats::DEFENSE)).round
    #### AME - 005 - START
    if self.hasWorkingAbility(:FURCOAT)
      defmult=(defmult*2).round
    end
    if self.hasWorkingAbility(:MAENADSFERVOR) && self.effects[PBEffects::Confusion]>0
      defmult=(defmult*1.5).round
    end
    if self.hasWorkingItem(:EVIOLITE)
      evos=pbGetEvolvedFormData(self.species)
      if evos && evos.length>0
        defmult=(defmult*1.5).round
      end
    end
    if self.hasWorkingItem(:METALPOWDER) &&
      isConst?(self.species,PBSpecies,:DITTO) &&
      !self.effects[PBEffects::Transform]
      defmult=(defmult*2.0).round
    end
    if (self.hasWorkingAbility(:PRISMARMOR) ||
        self.hasWorkingAbility(:SHADOWSHIELD)) && $fefieldeffect==4
      defmult=(defmult*2.0).round
    end
    if self.hasWorkingAbility(:PRISMARMOR) && ($fefieldeffect==9 || $fefieldeffect==25)
      defmult=(defmult*2.0).round
    end
    if self.hasWorkingAbility(:SHADOWSHIELD) && ($fefieldeffect==34 || $fefieldeffect==35)
      defmult=(defmult*2.0).round
    end
    defense=(defense*defmult*1.0/0x1000).round
    return defense
  end

  def pbCalcSpDef()
    stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
    stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
    applysandstorm=false
    defense=pbParadoxAdjustedStat(@spdef,PBStats::SPDEF)
    defstage=@stages[PBStats::SPDEF]+6
    applysandstorm=true
    if !self.hasWorkingAbility(:UNAWARE)
      if @stages[PBStats::SPDEF] >= 0
        stagemulp=1+0.5*@stages[PBStats::SPDEF]
        defense=(defense*1.0*stagemulp).floor
      else
        defense=(defense*1.0*stagemul[defstage]/stagediv[defstage]).floor
      end
    end
    if @battle.pbWeather==PBWeather::SANDSTORM &&
      self.pbHasType?(:ROCK) && applysandstorm
      defense=(defense*1.5).round
    end
    defmult=0x1000
    if $fefieldeffect == 24 && @function==0xE0
      defmult=(defmult*0.5).round
    end
    if $fefieldeffect == 3  &&
      self.pbHasType?(:FAIRY)
      defmult=(defmult*1.5).round
    end
    if $fefieldeffect == 12  &&
      self.pbHasType?(:GROUND)
      defmult=(defmult*1.5).round
    end
    if $fefieldeffect == 32 &&
      self.pbHasType?(:DRAGON)
      defmult=(defmult*1.5).round
    end
    if self.hasWorkingAbility(:NATURALSHROUD) && pbTerrainActive?
      defmult=(defmult*1.5).round
    end
    defmult=(defmult*pbWeatherDefenseMultiplier(PBStats::SPDEF)).round
    if self.hasWorkingAbility(:MARVELSCALE) && pbMarvelScaleActive?
      defmult=(defmult*1.5).round
    end
    #### AME - 005 - END
    if (@battle.pbWeather==PBWeather::SUNNYDAY || $fefieldeffect == 33 || $fefieldeffect == 42 ||
        (self.hasWorkingItem(:CHERCREST) && isConst?(self.species,PBSpecies,:CHERRIM)) ||
        self.sameSideLivingBattlers(false).any? { |ally| ally.hasWorkingItem(:CHERCREST) && isConst?(ally.species,PBSpecies,:CHERRIM) } )
      if self.hasWorkingAbility(:FLOWERGIFT) &&
        isConst?(self.species,PBSpecies,:CHERRIM)
        defmult=(defmult*1.5).round
      end
      if self.sameSideLivingBattlers(false).any? { |ally| ally.hasWorkingAbility(:FLOWERGIFT) && isConst?(ally.species,PBSpecies,:CHERRIM) }
        defmult=(defmult*1.5).round
      end
    end
    if self.hasWorkingAbility(:MAENADSFERVOR) && self.effects[PBEffects::Confusion]>0
      defmult=(defmult*1.5).round
    end
    if self.hasWorkingItem(:EVIOLITE)
      evos=pbGetEvolvedFormData(self.species)
      if evos && evos.length>0
        defmult=(defmult*1.5).round
      end
    end
    if self.hasWorkingItem(:ASSAULTVEST)
      defmult=(defmult*1.5).round
    end
    if self.hasWorkingItem(:DEEPSEASCALE) &&
      isConst?(self.species,PBSpecies,:CLAMPERL)
      defmult=(defmult*2.0).round
    end
    if self.hasWorkingItem(:METALPOWDER) &&
      isConst?(self.species,PBSpecies,:DITTO) &&
      !self.effects[PBEffects::Transform]
      defmult=(defmult*2.0).round
    end
    if (self.hasWorkingAbility(:PRISMARMOR) ||
        self.hasWorkingAbility(:SHADOWSHIELD)) && $fefieldeffect==4
      defmult=(defmult*2.0).round
    end
    if self.hasWorkingAbility(:PRISMARMOR) && ($fefieldeffect==9 || $fefieldeffect==25)
      defmult=(defmult*2.0).round
    end
    if self.hasWorkingAbility(:SHADOWSHIELD) && ($fefieldeffect==34 || $fefieldeffect==35)
      defmult=(defmult*2.0).round
    end
    defense=(defense*defmult*1.0/0x1000).round
    return defense
  end


  def pbCalcAcc()
    accstage=self.stages[PBStats::ACCURACY]
    accuracy=(accstage>=0) ? (accstage+3)*100/3 : 300/(3-accstage)
    accuracy*=1.5 if @battle.field.effects[PBEffects::Gravity]>0
    if self.hasWorkingAbility(:COMPOUNDEYES)
      accuracy*=1.3
    end
    if self.hasWorkingAbility(:VICTORYSTAR)
      accuracy*=1.1
    end
    partner=self.otherSameSideAbilityHolder(:VICTORYSTAR)
    if partner && partner.hasWorkingAbility(:VICTORYSTAR)
      accuracy*=1.1
    end
    if self.hasWorkingItem(:WIDELENS)
      accuracy*=1.1
    end
    if self.hasWorkingAbility(:LONGREACH) && ($fefieldeffect==14 || # Rocky Field
        $fefieldeffect==15) # Forest Field
      accuracy*=0.9
    end
    return accuracy
  end

  def pbCalcEva()
    evastage=self.stages[PBStats::EVASION]
    evastage=-6 if evastage<-6
    evastage=6 if evastage>6  #>>DemICE
    evastage=0 if self.effects[PBEffects::Foresight] ||
    self.effects[PBEffects::MiracleEye]
    evasion=(evastage>=0) ? (evastage+3)*100/3 : 300/(3-evastage)
    # Tangled Feet no longer gives evasion - now gives 1.5x speed, 0.5x defenses
    # Sand Veil no longer gives evasion - now gives 1.5x defense in sandstorm
    if self.hasWorkingItem(:BRIGHTPOWDER)
      evasion*=1.1
    end
    if self.hasWorkingItem(:LAXINCENSE)
      evasion*=1.1
    end
    return evasion
  end

  def pbCalcCrit()

    #### KUROTSUNE - 029 - END
    $buffs = 0
    if $fefieldeffect == 30
      $buffs = self.stages[PBStats::EVASION] if self.stages[PBStats::EVASION] > 0
      $buffs = $buffs.to_i + self.stages[PBStats::ACCURACY] if self.stages[PBStats::ACCURACY] > 0
    end
    c=0
    c+=self.effects[PBEffects::FocusEnergy]
    c+=1 if self.hasWorkingAbility(:SUPERLUCK) || self.hasWorkingAbility(:LONGREACH)
    if self.hasWorkingItem(:STICK) &&
      (isConst?(self.species,PBSpecies,:FARFETCHD) || isConst?(self.species,PBSpecies,:SIRFETCHD))
      c+=2
    end
    if self.hasWorkingItem(:LUCKYPUNCH) &&
      isConst?(self.species,PBSpecies,:CHANSEY)
      c+=2
    end
    c+=1 if self.hasWorkingItem(:RAZORCLAW)
    c+=1 if self.hasWorkingItem(:SCOPELENS)
    if $fefieldeffect == 30
      c += $buffs
    end
    c=3 if c>3
    return c
  end
  #DemICE left the chat>>>>

  def pbSpeed()
    stagemul=[10,10,10,10,10,10,10,15,20,25,30,35,40]
    stagediv=[40,35,30,25,20,15,10,10,10,10,10,10,10]
    if @effects[PBEffects::SpeedSwap] == 0
      speed=@speed
    else
      speed=@effects[PBEffects::SpeedSwap]
    end
    stage=@stages[PBStats::SPEED]+6
    speed=(speed*stagemul[stage]/stagediv[stage]).floor
    speed=pbParadoxAdjustedStat(speed,PBStats::SPEED)
    if isConst?(@ability, PBAbilities, :UNBURDEN) && @unburdened
      speed=speed*2
    end
    if self.pbOwnSide.effects[PBEffects::Tailwind]>0
      speed=speed*2
    end
    if self.hasWorkingAbility(:SWIFTSWIM) && @battle.pbWeather==PBWeather::RAINDANCE &&
      !self.hasWorkingItem(:UTILITYUMBRELLA)
      speed=speed*2
    elsif ($fefieldeffect == 21 || $fefieldeffect == 22 || $fefieldeffect == 26 || $fefieldeffect == 46) &&
      self.hasWorkingAbility(:SWIFTSWIM)
      speed=speed*2
    elsif (!self.pbHasType?(:WATER) && !self.hasWorkingAbility(:SWIFTSWIM) && !self.hasWorkingAbility(:STEELWORKER)) &&
      $fefieldeffect == 22
      speed=(speed*0.25).floor
    end
    if ((self.hasWorkingAbility(:SLUSHRUSH) || isConst?(self.species,PBSpecies,:EMPOLEON) && self.hasWorkingItem(:EMPCREST)) || (isConst?(self.species,PBSpecies,:CASTFORM) && isConst?(self.item,PBItems,:CASTCREST) && self.form==3)) &&
      (@battle.pbWeather==PBWeather::HAIL || $fefieldeffect==13 || $fefieldeffect==28 || $fefieldeffect==39)
      speed=speed*2
    end
    if self.hasWorkingAbility(:SURGESURFER) && (($fefieldeffect == 1) ||
        ($fefieldeffect==18) || ($fefieldeffect==21) || ($fefieldeffect==22) ||
        ($fefieldeffect==26) || (@battle.field.effects[PBEffects::ElectricTerrain]>0))
      speed=speed*2
    end
    if self.hasWorkingAbility(:TELEPATHY) && ($fefieldeffect==37)
      speed=speed*2
    end
    if $fefieldeffect == 35 && !self.isAirborne?
      speed=(speed*0.5).floor
    end
    if self.hasWorkingAbility(:CHLOROPHYLL) &&
      (@battle.pbWeather==PBWeather::SUNNYDAY ||
        ($fefieldeffect == 33 && $fecounter > 2)) &&
      !self.hasWorkingItem(:UTILITYUMBRELLA)
      speed=speed*2
    end
    if self.hasWorkingAbility(:SANDRUSH) &&
      (@battle.pbWeather==PBWeather::SANDSTORM ||
        $fefieldeffect == 12 || $fefieldeffect == 20 || $fefieldeffect == 46)
      speed=speed*2
    end
    if self.hasWorkingAbility(:QUICKFEET) && self.status>0
      speed=(speed*1.5).floor
    end
    if $fefieldeffect == 47 && self.effects[PBEffects::ThroatChop] > 0
      speed=(speed*0.5).floor
    end
    if self.hasWorkingAbility(:MAENADSFERVOR) && self.effects[PBEffects::Confusion]>0
      speed=(speed*2).floor
    end
    if self.hasWorkingAbility(:TANGLEDFEET)
      speed=(speed*1.5).floor
    end
    # Light Metal - double speed during gravity
    if self.hasWorkingAbility(:LIGHTMETAL) && @battle.field.effects[PBEffects::Gravity]>0
      speed=speed*2
    end
    # Early Bird - 2x speed the turn after waking/charging/recharging
    if @effects[PBEffects::EarlyBirdBoost] > 0 && self.hasWorkingAbility(:EARLYBIRD)
      speed=speed*2
    end
    if self.hasWorkingAbility(:HUNGERSWITCH) && isConst?(self.species,PBSpecies,:MORPEKO) &&
       self.form==1
      speed=(speed*1.5).floor
    end
    if self.hasWorkingItem(:MACHOBRACE) ||
      self.hasWorkingItem(:POWERWEIGHT) ||
      self.hasWorkingItem(:POWERBRACER) ||
      self.hasWorkingItem(:POWERBELT) ||
      self.hasWorkingItem(:POWERANKLET) ||
      self.hasWorkingItem(:POWERLENS) ||
      self.hasWorkingItem(:POWERBAND)
      speed=(speed/2).floor
    end
    if self.hasWorkingItem(:CHOICESCARF)
      speed=(speed*1.5).floor
    end
    if self.hasWorkingItem(:IRONBALL)
      speed=(speed/2).floor
    end
    if isConst?(self.species,PBSpecies,:DITTO) && !@effects[PBEffects::Transform] &&
      self.hasWorkingItem(:QUICKPOWDER)
      speed=speed*2
    end
    if self.hasWorkingAbility(:SLOWSTART) && self.turncount<=5
      speed=(speed/2).floor
    end
    if self.status==PBStatuses::PARALYSIS && !self.hasWorkingAbility(:QUICKFEET)
      speed=(speed/2).floor
    end
    if @battle.internalbattle && @battle.pbOwnedByPlayer?(@index)
      speed=(speed*1.1).floor if @battle.pbPlayer.numbadges>=BADGESBOOSTSPEED
    end
    return speed
  end

  ################################################################################
  # Change HP
  ################################################################################
  def pbAdjustElectricRecoilCrashDamage(damage)
    return 0 if damage<=0
    return 0 if $fefieldeffect == 1
    if @battle.field.effects[PBEffects::ElectricTerrain]>0
      damage = (damage/2).floor
    end
    return damage
  end

  def pbAdjustAbilityRecoilCrashDamage(damage)
    damage=pbAdjustElectricRecoilCrashDamage(damage)
    return 0 if damage<=0
    if self.hasWorkingAbility(:BIGBODY)
      damage=(damage*0.5).floor
      damage=1 if damage<=0
    end
    return damage
  end

  def pbRestoreTributePigState
    data=@effects[PBEffects::TributeSpookyPigData]
    return false if !data
    self.ability = data[:ability] if data.has_key?(:ability)
    @effects[PBEffects::TributeSpookyPig] = false
    @effects[PBEffects::TributeSpookyPigData] = nil
    if data[:source] && @effects[PBEffects::MeanLook] == data[:source].index
      @effects[PBEffects::MeanLook] = -1
    end
    @battle.pbNeutralizingGasStarted if hasWorkingAbility(:NEUTRALIZINGGAS)
    return true
  end

  def pbReduceHP(amt,anim=false)
    amt = pbConsumeShield(amt)
    return 0 if amt<=0
    if amt>=self.hp
      amt=self.hp
    elsif amt<=0 && !self.isFainted?
      amt=1
    end
    shielddam = false
    oldhp=self.hp
    if self.isbossmon
      if self.shieldCount>0
        onBreakdata = self.onBreakEffects ? self.onBreakEffects[self.shieldCount] : nil
        hpthreshold = (onBreakdata && onBreakdata[:threshold]) ? onBreakdata[:threshold] : 0
        if hpthreshold == 0.1 # unused currently, but can add. ex: Rejuv Admin
        else
          if (self.hp - amt) <= (self.totalhp*hpthreshold).round
            amt = (self.hp - (self.totalhp*hpthreshold).round)
            shielddam = true
          end
        end
      end
    end
    oldhp=self.hp
    amt=oldhp-1 if oldhp>0 && amt>=oldhp && pbSurvivesStoneTribute?
    self.hp-=amt
    @effects[PBEffects::TributeDamageTaken] += amt if amt>0
    raise _INTL("HP less than 0") if self.hp<0
    raise _INTL("HP greater than total HP") if self.hp>@totalhp
    @battle.scene.pbHPChanged(self,oldhp,anim) if amt>0

    if shielddam == true
      self.pbRecoverHP(self.totalhp,true) if self.hp==0
      @battle.pbShieldEffects(self,onBreakdata) if onBreakdata
      self.shieldCount-=1 if self.shieldCount>0
      @battle.scene.pbUpdateShield(self.shieldCount,self.index)
      battlerIndex = self.index
      if self.sosDetails
        @battle.pbBossSOS(@battle.battlers,shieldbreak=true)
      end
    end

    if @battle.raidbattle && !@battle.pbBelongsToPlayer?(self.index)
      limit = self.totalhp * 0.25
      if self.hp > 0 && oldhp > limit && self.hp < limit
        @battle.pbDisplay(_INTL("{1} has dropped its guard!!",pbThis))
      end
    end
    return amt
  end

  def pbRiteOfSpringSource
    source,pokemon=@effects[PBEffects::RiteOfSpring]
    return source if source && source.pokemon.equal?(pokemon) && !source.isFainted?
    @effects[PBEffects::RiteOfSpring]=nil
    return nil
  end

  def pbApplyGrievousWounds(turns)
    return false if isFainted? || pbOwnSide.effects[PBEffects::EtherealCloak]>0
    @effects[PBEffects::Wounded]=[turns,@effects[PBEffects::Wounded]].max
    return true
  end

  def pbRecoverHP(amt,anim=false)
    return 0 if amt.nil?
    amt=amt*3/2 if pbOwnSide.effects[PBEffects::EtherealCloak]>0
    # Wounds halve healing
    if @effects[PBEffects::Wounded]>0
      amt = (amt/2).floor
    end
    if self.hasWorkingAbility(:GLUTTONY)
      amt = (amt*1.1).floor
    end
    requested = amt
    if self.hp+amt>@totalhp
      amt=@totalhp-self.hp
    elsif amt<=0 && self.hp!=@totalhp
      amt=1
    end
    oldhp=self.hp
    self.hp+=amt
    @faintingMove=nil if oldhp<=0 && self.hp>0
    raise _INTL("HP less than 0") if self.hp<0
    raise _INTL("HP greater than total HP") if self.hp>@totalhp
    @battle.scene.pbHPChanged(self,oldhp,anim) if amt>0
    if @effects[PBEffects::TributePendingShield]
      overflow = requested-amt
      if overflow>0
        current=@effects[PBEffects::TributeOverhealShield]
        shield=[(current ? current[:hp] : 0)+overflow,@totalhp].min
        @effects[PBEffects::TributeOverhealShield]={:hp=>shield,:expires=>@battle.turncount+1}
        @battle.pbDisplay(_INTL("{1} gained a shield!",pbThis))
      end
      @effects[PBEffects::TributePendingShield] = false
    end
    if amt>0 && hasWorkingItem(:FLAMETRIBUTE) && defined?(pbHeroicPokemon?) &&
       pbHeroicPokemon?(self,:ARCANINE)
      @effects[PBEffects::TributeFlameRefresh] = true
    end
    return amt
  end

  def pbFaintCopyAbility
    if self.hasWorkingAbility(:POWEROFALCHEMY) || self.hasWorkingAbility(:RECEIVER)
      return @ability
    end
    return @faintAbilitySource if @ability==@faintCopiedAbility && abilityWorks?
    return nil
  end

  def pbCopyFaintedAbility(ability,source)
    return if !ability || ability==0 || PBStuff::ABILITYBLACKLIST.include?(ability)
    return if ability==@ability
    @faintAbilitySource=source
    @faintCopiedAbility=ability
    self.ability=ability
    @battle.pbDisplay(_INTL("{1} acquired {2}!",pbThis,PBAbilities.getName(ability)))
  end

  def pbSurvivesStoneTribute?
    return false if !hasWorkingItem(:STONETRIBUTE,true) || !pbHeroicPokemon?(self,:GOLEM_ALOLAN)
    return false if @battle.pbTributeOnceUsed?(@pokemon,:stone_survival)
    @battle.pbMarkTributeOnceUsed(@pokemon,:stone_survival)
    @battle.pbDisplay(_INTL("{1} endured with mystic stone!",pbThis))
    return true
  end

  def pbFaint(showMessage=true)
    if !self.isFainted?
      PBDebug.log("!!!***Can't faint with HP greater than 0") if $INTERNAL
      return true
    end
    faintingMove=@faintingMove
    @faintingMove=nil
    if @fainted
      #      PBDebug.log("!!!***Can't faint if already fainted") if $INTERNAL
      return true
    end
    if pbSurvivesStoneTribute?
      self.hp=1
      return true
    end
    gas_ended=hasWorkingAbility(:NEUTRALIZINGGAS,true)
    last_faint_turns = @battle.instance_variable_defined?(:@tributeLastAllyFaintTurn) ?
      @battle.instance_variable_get(:@tributeLastAllyFaintTurn) : [nil,nil]
    last_faint_turns[self.index & 1] = @battle.turncount
    @battle.instance_variable_set(:@tributeLastAllyFaintTurn,last_faint_turns)
    if self.isbossmon
      if self.shieldCount > 0
        onBreakdata = self.onBreakEffects ? self.onBreakEffects[self.shieldCount] : nil
        hpthreshold = (onBreakdata && onBreakdata[:threshold]) ? onBreakdata[:threshold] : 0
        case hpthreshold  # Add extra threshold effects here; ex: Rejuv Admin Regirock
        when 0
          boss = @battle.battlers[self.index]
          self.pbRecoverHP(self.totalhp,true)
          @battle.pbShieldEffects(self,onBreakdata) if onBreakdata
          self.shieldCount-=1 if self.shieldCount>0
          @battle.scene.pbUpdateShield(boss.shieldCount,self.index)
          if boss.sosDetails
            @battle.pbBossSOS(@battle.battlers,shieldbreak=true)
          end
        end
        return false
      end
    end
    if ((@species==PBSpecies::PARAS && @pokemon.form==1 || @species==PBSpecies::PARASECT && @pokemon.form==1) && @effects[PBEffects::Resusitated]==false)
      @battle.scene.pbFakeOutFainted(self)
      @effects[PBEffects::Resusitated]=true
      pbUpdate(true)
      self.pbRecoverHP((self.totalhp).floor,true)
      @battle.pbDisplayPaused(_INTL("{1} was resuscitated!",self.pbThis))
      if $fefieldeffect==40
        for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
          PBStats::SPATK,PBStats::SPDEF,PBStats::EVASION,PBStats::ACCURACY]
          @stages[i]=0 if @stages[i]<0
        end
      end
      return false
    else
      @battle.scene.pbFainted(self)
    end
    fainted_side=@index & 1
    @battle.lastFaintedAllyAbility[fainted_side]=@ability
    @battle.lastFaintedEnemyAbility[fainted_side ^ 1]=@ability
    @battle.battlers.each do |battler|
      next if battler.isFainted?
      source=battler.pbFaintCopyAbility
      expected=battler.pbIsOpposing?(@index) ? PBAbilities::POWEROFALCHEMY : PBAbilities::RECEIVER
      next if source!=expected
      previous_ability=battler.ability
      battler.pbCopyFaintedAbility(@ability,source)
      battler.pbAbilitiesOnSwitchIn(true) if battler.ability!=previous_ability
    end
    # Afterlife - punish the attacker when this Pokemon faints
    if faintingMove && !moldbroken && hasWorkingAbility(:AFTERLIFE,true)
      attacker, _move, previousHP = faintingMove
      if attacker!=self && !attacker.isFainted?
        if previousHP > (self.totalhp/2).floor
          lowered=@battle.pbWithStatChangeSource([:ability,ability]) do
            [PBStats::DEFENSE,PBStats::SPDEF].map do |stat|
              attacker.pbReduceStat(stat,1,false,nil,self,false,false,false,false)
            end.any?
          end
          if lowered
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s defenses!",pbThis,PBAbilities.getName(self.ability),attacker.pbThis(true)))
          end
        elsif attacker.pbCanParalyze?(false)
          attacker.pbParalyze(self)
          @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}!",pbThis,PBAbilities.getName(self.ability),attacker.pbThis(true))) #pk code
        end
      end
    end
    if faintingMove && !moldbroken
      attacker, move = faintingMove
      if attacker!=self && !attacker.isFainted? && move.isContactMove? &&
         !attacker.hasWorkingAbility(:LONGREACH) &&
         !attacker.hasWorkingItem(:PROTECTIVEPADS) && !hasWorkingItem(:PROTECTIVEPADS,true)
        if hasWorkingAbility(:STATIC,true) && attacker.pbCanParalyze?(false)
          attacker.pbParalyze(self)
          @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}!",pbThis,PBAbilities.getName(ability),attacker.pbThis(true)))
        elsif hasWorkingAbility(:FLAMEBODY,true) && attacker.pbCanBurn?(false)
          attacker.pbBurn(self)
          @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!",pbThis,PBAbilities.getName(ability),attacker.pbThis(true)))
        elsif hasWorkingAbility(:FROSTPOINT,true) && attacker.pbCanFreeze?(false)
          attacker.pbFreeze
          @battle.pbDisplay(_INTL("{1}'s {2} froze {3} solid!",pbThis,PBAbilities.getName(ability),attacker.pbThis(true)))
        end
      end
    end
    if faintingMove && !moldbroken && hasWorkingAbility(:EFFECTSPORE,true)
      attacker, move = faintingMove
      if move.isContactMove? && !attacker.hasWorkingAbility(:LONGREACH) &&
         !attacker.hasWorkingItem(:PROTECTIVEPADS) && !attacker.isFainted? &&
         attacker.effects[PBEffects::Yawn]==0 && attacker.pbCanSleep?(false)
        attacker.effects[PBEffects::Yawn]=2
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} drowsy!",pbThis,
            PBAbilities.getName(ability),attacker.pbThis(true)))
      end
    end
    # Cursed Body - disable the move that knocked it out
    if faintingMove && !moldbroken && hasWorkingAbility(:CURSEDBODY,true)
      attacker, move = faintingMove
      if !attacker.isFainted? && attacker.pbHasMove?(move.id)
        attacker.effects[PBEffects::DisableMove] = move.id
        attacker.effects[PBEffects::Disable] = 4
        @battle.pbDisplay(_INTL("{1}'s {2} disabled {3}'s {4}!",pbThis,PBAbilities.getName(@ability),attacker.pbThis(true),move.name))
      end
    end
    for i in @battle.battlers
      next if i.isFainted?
      if i.hasWorkingAbility(:SOULHEART) && !i.pbTooHigh?(PBStats::SPATK)
        @battle.pbDisplay(_INTL("{1}'s Soul-heart activated!",i.pbThis))
        @battle.statChangeSource=[:ability,i.ability]
        i.pbIncreaseStat(PBStats::SPATK,1,true)
        if ($fefieldeffect==3 || $fefieldeffect==9 || $fefieldeffect==31) && !i.pbTooHigh?(PBStats::SPDEF)
          i.pbIncreaseStat(PBStats::SPDEF,1,true)
        end
        @battle.statChangeSource=nil
      end
      # Pick Up - steal the fainted opponent's item
      if i.hasWorkingAbility(:PICKUP) && i.item==0 && self.item!=0 &&
         i.pbIsOpposing?(self.index) && !self.hasWorkingAbility(:STICKYHOLD,true) &&
         !@battle.pbIsUnlosableItem(self,self.item) && !@battle.pbIsUnlosableItem(i,self.item) &&
         (@battle.opponent || !@battle.pbIsOpposing?(i.index))
        stolenitem=self.item
        pbSwapHeldItems(i)
         if @battle.pbIsWild? && i.pokemon.itemInitial==0 && self.pokemon.itemInitial==stolenitem
           i.pokemon.itemInitial=stolenitem
           self.pokemon.itemInitial=0
         end
        @battle.pbDisplay(_INTL("{1}'s {2} picked up {3}'s {4}!",
            i.pbThis,PBAbilities.getName(i.ability),
            self.pbThis(true),PBItems.getName(stolenitem)))
      end
    end
    droprelease = self.effects[PBEffects::SkyDroppee]
    pbInitEffects(false)
    self.vanished=false
    # reset status
    self.status=0
    self.statusCount=0
    if @pokemon && @battle.internalbattle
      @pokemon.changeHappiness("faint")
    end
    if self.isMega?
      @pokemon.makeUnmega
    end
    if @battle.field.effects[PBEffects::WonderRoom] > 0
      for m in @battle.battlers
        if m.isFainted?
          if m.wonderroom
            m.pbSwapDefenses
          end
        end
      end
    end
    @fainted=true
    @battle.azureReleaseJetstream(self) if @azureJetstream
    # reset choice
    @battle.choices[@index]=[0,0,nil,-1]
    @battle.pbDisplay(_INTL("{1} fainted!",pbThis)) if showMessage
    @battle.pbNeutralizingGasEnded if gas_ended
    #@effects[PBEffects::Resusitated]==false
    #reset mimikyu form if it faints
    if @species==PBSpecies::MIMIKYU && @pokemon.form==1
      self.form=0
    end
    if @species==PBSpecies::PARASECT && @pokemon.form==2
      self.form=1
    end
    if droprelease!=nil && droprelease!=-1
      oppmon = @battle.battlers[droprelease]
      if oppmon
        oppmon.effects[PBEffects::SkyDrop]=false
        @battle.scene.pbUnVanishSprite(oppmon)
        @battle.pbDisplay(_INTL("{1} is freed from Sky Drop effect!",oppmon.pbThis))
      end
    end
    @battle.scene.partyBetweenKO1(@battle.pbIsOpposing?(self.index)) unless (@battle.pbSideSize(self.index)>1 || pbNonActivePokemonCount==0)
    #PBDebug.log("[#{pbThis} fainted]") if $INTERNAL
    return true
  end

  ################################################################################
  # Find other battlers/sides in relation to this battler
  ################################################################################
  # Returns the data structure for this battler's side
  def pbOwnSide
    return @battle.sides[index&1] # Player: 0 and 2; Foe: 1 and 3
  end

  # Returns the data structure for the opposing PokÃ©mon's side
  def pbOpposingSide
    return @battle.sides[(index&1)^1] # Player: 1 and 3; Foe: 0 and 2
  end

  # Returns whether the position belongs to the opposing PokÃ©mon's side
  def pbIsOpposing?(i)
    return (@index&1)!=(i&1)
  end

  # Returns the battler's partner
  def pbPartner
    partner=nil
    partnerDistance=nil
    @battle.eachSameSideBattler(@index) do |battler|
      next if battler.index==@index
      distance = (@battle.pbSidePosition(battler.index)-@battle.pbSidePosition(@index)).abs
      next if partner && partnerDistance && distance>partnerDistance
      if !partner || distance<partnerDistance || battler.index<partner.index
        partner=battler
        partnerDistance=distance
      end
    end
    if !partner
      fallbackIndex = (@index&1)|((@index&2)^2)
      partner = @battle.battlers[fallbackIndex] if fallbackIndex<@battle.battlers.length
    end
    return partner || self
  end

  # Returns the battler's first opposing PokÃ©mon
  def pbOpposing1
    return @battle.battlers[((@index&1)^1)]
  end

  # Returns the battler's second opposing PokÃ©mon
  def pbOpposing2
    return @battle.battlers[((@index&1)^1)+2]
  end

  def pbOppositeOpposing
    return @battle.battlers[(@index^1)]
  end

  def pbOppositeOpposing2
    return @battle.battlers[(@index^1)|((@index&2)^2)]
  end

  def pbNonActivePokemonCount()
    count=0
    party=@battle.pbParty(self.index)
    activeIndices=[]
    @battle.eachSameSideBattler(self.index) do |battler|
      activeIndices.push(battler.pokemonIndex) if !battler.isFainted?
    end
    for i in 0...party.length
      if party[i] && !party[i].isEgg? && party[i].hp>0 && !activeIndices.include?(i)
        count+=1
      end
    end
    return count
  end

  def pbFaintedPokemonCount()
    count=0
    party=@battle.pbParty(self.index)
    for i in 0...party.length
      if party[i] && !party[i].isEgg? && party[i].hp==0
        count+=1
      end
    end
    return count
  end

  def pbEnemyNonActivePokemonCount()
    count=0
    party=@battle.pbParty(pbOppositeOpposing.index)
    activeIndices=[]
    @battle.eachOtherSideBattler(self.index) do |battler|
      activeIndices.push(battler.pokemonIndex) if !battler.isFainted?
    end
    for i in 0...party.length
      if party[i] && !party[i].isEgg? && party[i].hp>0 && !activeIndices.include?(i)
        count+=1
      end
    end
    return count
  end

  def pbEnemyFaintedPokemonCount()
    count=0
    party=@battle.pbParty(pbOppositeOpposing.index)
    for i in 0...party.length
      if party[i] && !party[i].isEgg? && party[i].hp==0
        count+=1
      end
    end
    return count
  end

  def opposingBattlers
    ret=[]
    @battle.eachOtherSideBattler(@index) do |battler|
      ret.push(battler) if battler
    end
    return ret
  end

  def sameSideBattlers(include_self=true)
    ret=[]
    @battle.eachSameSideBattler(@index) do |battler|
      next if !battler
      next if !include_self && battler.index==@index
      ret.push(battler)
    end
    return ret
  end

  def sameSideLivingBattlers(include_self=true)
    return sameSideBattlers(include_self).find_all { |battler| battler && !battler.isFainted? }
  end

  TIMETWISTER_VOLATILES = [
    PBEffects::Confusion, PBEffects::Toxic, PBEffects::Wounded, PBEffects::Blinded,
    PBEffects::Yawn, PBEffects::HealBlock, PBEffects::Taunt,
    PBEffects::Torment, PBEffects::ThroatChop, PBEffects::Embargo, PBEffects::Substitute,
    PBEffects::SmackDown, PBEffects::MagnetRise, PBEffects::Telekinesis
  ].freeze

  def pbRememberTimetwisterState
    @effects[PBEffects::TimetwisterState]=nil
    return if !hasWorkingAbility(:TIMETWISTER)
    @effects[PBEffects::TimetwisterState]=[
      hp, status, statusCount, stages.dup, @effects.values_at(*TIMETWISTER_VOLATILES)
    ]
  end

  def pbRewindTimetwister
    snapshot=@effects[PBEffects::TimetwisterState]
    @effects[PBEffects::TimetwisterState]=nil
    return if !snapshot || !hasWorkingAbility(:TIMETWISTER) || hp*3>totalhp
    old_hp=hp
    had_substitute=@effects[PBEffects::Substitute]>0
    start_hp, start_status, start_status_count, start_stages, start_effects=snapshot
    self.hp=[start_hp,totalhp].min
    self.status=start_status
    self.statusCount=start_status_count
    self.stages=start_stages
    TIMETWISTER_VOLATILES.zip(start_effects).each { |effect,value| @effects[effect]=value }
    has_substitute=@effects[PBEffects::Substitute]>0
    if has_substitute && !had_substitute
      @battle.scene.pbSubstituteSprite(self,pbIsOpposing?(1))
    elsif had_substitute && !has_substitute
      @battle.scene.pbUnSubstituteSprite(self,pbIsOpposing?(1))
    end
    @battle.scene.pbHPChanged(self,old_hp,true) if old_hp!=hp
    @battle.pbDisplay(_INTL("{1}'s {2} rewound it to the start of the turn!",pbThis,PBAbilities.getName(ability)))
  end

  def pbTerrainActive?
    return true if @battle.field.effects[PBEffects::ElectricTerrain] > 0
    return true if @battle.field.effects[PBEffects::GrassyTerrain] > 0
    return true if @battle.field.effects[PBEffects::MistyTerrain] > 0
    return true if @battle.field.effects[PBEffects::PsychicTerrain] > 0
    return true if [1,2,3,18,21,22,26,37].include?($fefieldeffect)
    return false
  end

  def opposingLivingBattlers
    return opposingBattlers.find_all { |battler| battler && !battler.isFainted? }
  end

  def sameSideAbilityHolder(*abilities)
    sameSideLivingBattlers(true).each do |battler|
      abilities.each do |ability|
        return battler if battler.hasWorkingAbility(ability)
      end
    end
    return nil
  end

  def otherSameSideAbilityHolder(*abilities)
    sameSideLivingBattlers(false).each do |battler|
      abilities.each do |ability|
        return battler if battler.hasWorkingAbility(ability)
      end
    end
    return nil
  end

  def firstLivingAlly
    return sameSideLivingBattlers(false)[0]
  end

  def opposingAbilityHolder(*abilities)
    opposingLivingBattlers.each do |battler|
      abilities.each do |ability|
        return battler if battler.hasWorkingAbility(ability)
      end
    end
    return nil
  end

  def priorityBlockingBattlers
    ret=[]
    sameSideBattlers(true).each do |battler|
      next if battler.isFainted?
      next if battler.moldbroken
      if battler.hasWorkingAbility(:DAZZLING) ||
         ($fefieldeffect == 34 && battler.hasWorkingAbility(:MIRRORARMOR))
        ret.push(battler)
      end
    end
    return ret
  end

  def pbPreferredOpposingTarget(preferred=nil,move=nil)
    foes=opposingBattlers.find_all do |battler|
      battler && !battler.isFainted? &&
        (!move || @battle.pbMoveCanTargetInTriple?(self,battler,move))
    end
    return nil if foes.length==0
    if preferred && pbIsOpposing?(preferred.index)
      preferredPos=@battle.pbSidePosition(preferred.index)
      foes.sort_by! { |battler| [(@battle.pbSidePosition(battler.index)-preferredPos).abs,battler.index] }
    else
      myPos=@battle.pbSidePosition(@index)
      foes.sort_by! { |battler| [(@battle.pbSidePosition(battler.index)-myPos).abs,battler.index] }
    end
    return foes[0]
  end

  def pbAddClosestOpposingTarget(targets,preferred=nil,move=nil)
    target=pbPreferredOpposingTarget(preferred,move)
    return false if !target
    return pbAddTarget(targets,target,self,move)
  end
  ################################################################################
  # Forms
  ################################################################################
  def pbCheckForm(thismove = nil) # TODO: try and find a different way of doing this - I'm not liking this    return if @effects[PBEffects::Transform]
    transformed=false
    if !@effects[PBEffects::Transform] && real_species==PBSpecies::TERAPAGOS &&
       !isFainted? && form==0 && hasWorkingAbility(:TERASHIFT)
      self.form=1
      transformed=true
    end
    # Forecast
    if isConst?(self.species,PBSpecies,:CASTFORM)
      if self.hasWorkingAbility(:FORECAST)
        if @battle.pbWeather==PBWeather::SUNNYDAY && !self.hasWorkingItem(:UTILITYUMBRELLA)
          if self.form!=1
            self.form=1
            transformed=true
          end
        elsif @battle.pbWeather==PBWeather::RAINDANCE && !self.hasWorkingItem(:UTILITYUMBRELLA)
          if self.form!=2
            self.form=2
            transformed=true
          end
        elsif @battle.pbWeather==PBWeather::HAIL
          if self.form!=3
            self.form=3
            transformed=true
          end
        else
          if self.form!=0
            self.form=0
            transformed=true
          end
        end
      else
        if self.form!=0
          self.form=0
          transformed=true
        end
      end
      showmessage=transformed
    end
    # Cherrim
    if isConst?(self.species,PBSpecies,:CHERRIM) && !self.isFainted?
      if self.hasWorkingAbility(:FLOWERGIFT) && !self.hasWorkingItem(:UTILITYUMBRELLA)
        case @battle.pbWeather
        when PBWeather::SUNNYDAY
          if self.form!=1
            self.form=1
            transformed=true
          end
        else
          if ($fefieldeffect == 33 || isConst?(self.item,PBItems,:CHERCREST))
            if self.form!=1
              self.form=1
              transformed=true
            end
          elsif self.form!=0
            self.form=0
            transformed=true
          end
        end
      else
        if self.form!=0
          self.form=0
          transformed=true
        end
      end
    end
    # Shaymin
    if isConst?(self.species,PBSpecies,:SHAYMIN) && !self.isFainted?
      if self.form!=@pokemon.form
        self.form=@pokemon.form
        transformed=true
      end
    end
    # Giratina
    if isConst?(self.species,PBSpecies,:GIRATINA) && !self.isFainted?
      if self.form!=@pokemon.form
        self.form=@pokemon.form
        transformed=true
      end
    end
    # Arceus
    if isConst?(self.ability,PBAbilities,:MULTITYPE) &&
      isConst?(self.species,PBSpecies,:ARCEUS) && !self.isFainted?
      if self.form!=@pokemon.form
        if $fefieldeffect == 35 && $fecounter == 1
          @battle.pbDisplay(_INTL("{1}'s Multitype activated!",pbThis))
          $fecounter = 0
        end
        self.form=@pokemon.form
        transformed=true
      end
    end
    # Silvally
    if isConst?(self.ability,PBAbilities,:RKSSYSTEM) &&
      isConst?(self.species,PBSpecies,:SILVALLY) && !self.isFainted?
      if self.form!=@pokemon.form
        if $fefieldeffect == 35 && $fecounter == 1
          @battle.pbDisplay(_INTL("{1}'s RKS System activated!",pbThis))
          $fecounter = 0
        end
        self.form=@pokemon.form
        transformed=true
      end
    end
    # Zen Mode
    if isConst?(self.species,PBSpecies,:DARMANITAN) && !self.isFainted?
      if self.hasWorkingAbility(:ZENMODE) ||  (isConst?(self.item,PBItems,:DARMCREST) && self.form==0)
        if ($fefieldeffect == 20 ||  $fefieldeffect == 37) || (isConst?(self.item,PBItems,:DARMCREST) && self.form==0)
          if self.form==0
            self.form=1; transformed = true
          elsif self.form==2
            self.form=3; transformed = true
          end
        elsif @hp<=((@totalhp/2).floor)
          if self.form == 0
            self.form = 1; transformed=true
          elsif self.form == 2
            self.form = 3; transformed=true
          end
        elsif @hp>((@totalhp/2).floor) && !@effects[PBEffects::ZenModeSleep] &&
              !(isConst?(self.item,PBItems,:DARMCREST) && self.form==1)
          if self.form == 1
            self.form = 0; transformed=true
          elsif self.form == 3
            self.form = 2; transformed=true
          end
        end
      end
    end
    # Shift
    if @battle.shieldCount==0
      if isConst?(self.species,PBSpecies,:FERROTHORN) && !self.isFainted?
        if self.hasWorkingAbility(:SHIFT)
          if self.form!=2
            self.form=2; transformed=true
            pbBGMPlay("Battle - Pseudo Contribution",110)
            @battle.pbDisplay(_INTL("{1}'s form shifted!",pbThis))
          end
        end
      end
    end
    # Temporal Shift
    if isConst?(self.species,PBSpecies,:FROSLASS) && !self.isFainted?
      if self.hasWorkingAbility(:TEMPORALSHIFT)
        if @battle.shieldCount==0
          if self.form!=2
            self.form=2; transformed=true
            @battle.pbDisplay(_INTL("{1}'s form shifted!",pbThis))
          end
        end
      end
    end
    # Keldeo
    if isConst?(self.species,PBSpecies,:KELDEO) && !self.isFainted?
      if self.form!=@pokemon.form
        self.form=@pokemon.form
        transformed=true
      end
    end
    # Genesect
    if isConst?(self.species,PBSpecies,:GENESECT) && !self.isFainted?
      if self.form!=@pokemon.form
        self.form=@pokemon.form
        transformed=true
      end
    end
    # UPDATE 1/18/2014
    # Aegislash
    if isConst?(self.species, PBSpecies, :AEGISLASH) && !self.isFainted?
      if isConst?(self.ability, PBAbilities, :STANCECHANGE)

        # in Shield Forme and used a damaging move
        if self.form == 0 && !thismove.nil? && thismove.basedamage > 0
          self.form = 1 ; transformed = true
          # in Blade Forme and used King's Shield
        elsif self.form == 1 && !thismove.nil? && thismove.id == 584 # King's Shield
          self.form = 0 ; transformed = true
        end
      end
    end # end of update
    # Silvally
    if isConst?(self.ability,PBAbilities,:RKSSYSTEM) &&
      isConst?(self.species,PBSpecies,:SILVALLY) && !self.isFainted?
      if self.form!=@pokemon.form
        self.form=@pokemon.form
        transformed=true
      end
    end
    if transformed
      pbUpdate(true)
      @battle.scene.pbChangePokemon(self,@pokemon)
      if $fefieldeffect == 35 && (isConst?(self.species,PBSpecies,:ARCEUS) || isConst?(self.species,PBSpecies,:SILVALLY))
        typename=PBTypes.getName(@pokemon.type1)
        @battle.pbDisplay(_INTL("{1} rolled the {2} type!",pbThis,typename))
      else
        @battle.pbDisplay(_INTL("{1} transformed!",pbThis))
      end
      if isConst?(self.ability, PBAbilities, :STANCECHANGE) &&
        ($fefieldeffect == 5 || $fefieldeffect == 31)
        @battle.statChangeSource=[:ability,self.ability]
        if self.form == 1
          self.pbReduceStat(PBStats::DEFENSE,1,false)
          self.pbIncreaseStat(PBStats::ATTACK,1,false)
        else
          self.pbReduceStat(PBStats::ATTACK,1,false)
          self.pbIncreaseStat(PBStats::DEFENSE,1,false)
        end
        @battle.statChangeSource=nil
      end
    end
  end

  def pbCheckFormRoundEnd(thismove = nil)
    # Wishiwashi
    if isConst?(self.species,PBSpecies,:WISHIWASHI) && !self.isFainted?
      if self.hasWorkingAbility(:SCHOOLING)
        schoolHP = (self.totalhp/4).floor
        if (self.hp>schoolHP && self.level>19) || $fefieldeffect==21 ||
          $fefieldeffect==22 || $fefieldeffect==26
          if self.form!=1
            self.form=1
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self,@pokemon)
            @battle.pbDisplay(_INTL("{1} formed a school!",pbThis))
          end
        else
          if self.form!=0
            self.form=0
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self,@pokemon)
            @battle.pbDisplay(_INTL("{1} stopped schooling!",pbThis))
          end
        end
      end
    end
    # Minior
    if isConst?(self.species,PBSpecies,:MINIOR) && !self.isFainted?
      if self.hasWorkingAbility(:SHIELDSDOWN)
        coreHP = (self.totalhp/2).floor
        if self.hp>coreHP
          if self.form!=6
            self.form=6
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self,@pokemon)
            @battle.pbDisplay(_INTL("{1} shields came up!",pbThis))
          end
        else
          if self.form!=self.startform
            self.form=self.startform
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self,@pokemon)
            @battle.pbDisplay(_INTL("{1}'s shields went down!",pbThis))
          end
        end
      end
    end
    # Zygarde
    if isConst?(self.species,PBSpecies,:ZYGARDE) && !self.isFainted?
      if self.hasWorkingAbility(:POWERCONSTRUCT)
        completeHP = (self.totalhp/2).floor
        if self.hp<=completeHP
          if self.form!=2
            @battle.pbDisplay(_INTL("You sense the presence of many!"))
            self.form=2
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self,@pokemon)
            @battle.pbDisplay(_INTL("{1} transformed into its Complete Forme!",pbThis))
          end
        end
      end
    end
  end

  def pbBreakDisguise
    self.form=1
    pbUpdate(true)
    @battle.scene.pbChangePokemon(self,@pokemon)
  end

  def pbSUSlmao
    self.form=2
    @effects[PBEffects::Resusitated]=true
    pbUpdate(true)
    @battle.scene.pbChangePokemon(self,@pokemon)
  end

  def pbRegenFace
    self.form=0
    @effects[PBEffects::IceFace] = true
    pbUpdate(true)
    @battle.scene.pbChangePokemon(self,@pokemon)
  end

  def pbResetForm
    #### KUROTSUNE - 001 - START
    if !@effects[PBEffects::Transform]
      if isConst?(self.species,PBSpecies,:CASTFORM)   ||
        isConst?(self.species,PBSpecies,:CHERRIM)    ||
        isConst?(self.species,PBSpecies,:DARMANITAN) ||
        #isConst?(self.species,PBSpecies,:MELOETTA)   ||
        isConst?(self.species,PBSpecies,:AEGISLASH)  ||
        isConst?(self.species,PBSpecies,:KYOGRE)     ||
        isConst?(self.species,PBSpecies,:GROUDON)    ||
        isConst?(self.species,PBSpecies,:WISHIWASHI) ||
        (real_species==PBSpecies::TERAPAGOS && startform==0 && form==1)
        self.form=0
      elsif isConst?(self.species,PBSpecies,:ZYGARDE) ||
        isConst?(self.species,PBSpecies,:MINIOR)
        self.form=startform
      end
    end
    #### KUROTSUNE - 001 - END
    pbUpdate(true)
  end

  ################################################################################
  # Ability effects
  ################################################################################
  def pbChargeFromAbility
    return if @effects[PBEffects::Charge]
    @effects[PBEffects::Charge]=true
    @effects[PBEffects::AbilityCharge]=true
    @battle.pbDisplay(_INTL("{1}'s {2} charged it with electricity!",pbThis,PBAbilities.getName(ability)))
  end

  def pbWindAbilityBoost
    if hasWorkingAbility(:WINDRIDER)
      @battle.pbWithStatChangeSource([:ability,ability]) do
        [PBStats::ATTACK,PBStats::SPATK].each { |stat| pbIncreaseStat(stat,1,false,nil,self) }
      end
    elsif hasWorkingAbility(:WINDPOWER)
      pbChargeFromAbility
    end
  end

  def pbEntrySupportAbilities
    if hasWorkingAbility(:HOSPITALITY)
      partner=pbPartner
      if partner && partner!=self && !partner.isFainted? &&
         partner.effects[PBEffects::HealBlock]==0 && partner.pbRecoverHP([partner.totalhp/4,1].max,true)>0
        @battle.pbDisplay(_INTL("{1}'s {2} restored {3}'s HP!",pbThis,PBAbilities.getName(ability),partner.pbThis(true)))
      end
    elsif hasWorkingAbility(:SUPERSWEETSYRUP)
      opposingLivingBattlers.each do |foe|
        foe.pbReduceStat(PBStats::EVASION,1,false,nil,self)
      end
    end
  end

  def pbAbilitiesOnSwitchIn(onactive,megad=false,gas_ended=false)
    return if hp<=0
    if onactive
      @battle.pbClearTeraformWeatherAndTerrain(self) if hasWorkingAbility(:TERAFORMZERO)
      side=@index & 1
      if hasWorkingAbility(:POWEROFALCHEMY)
        pbCopyFaintedAbility(@battle.lastFaintedEnemyAbility[side],PBAbilities::POWEROFALCHEMY)
      elsif hasWorkingAbility(:RECEIVER)
        pbCopyFaintedAbility(@battle.lastFaintedAllyAbility[side],PBAbilities::RECEIVER)
      end
    end
    if @battle
      @battle.statChangeSource=[:ability,ability]
    end
    begin
    pbRefreshParadoxBoost
    pbEntrySupportAbilities if onactive && !gas_ended
    pbWindAbilityBoost if onactive && !gas_ended && pbOwnSide.effects[PBEffects::Tailwind]>0
    if self.hasWorkingAbility(:NEUTRALIZINGGAS)  && onactive
      @battle.pbNeutralizingGasStarted
    end
    if self.hasWorkingAbility(:HUNGERSWITCH) && isConst?(self.species,PBSpecies,:MORPEKO) && $fefieldeffect == 39 && !self.isFainted?
      self.form = 1
      pbUpdate(true)
      @battle.scene.pbChangePokemon(self,@pokemon)
    end
    ##### KUROTSUNE - 001 - START

    #### PRIMAL REVERSIONS

    #### Kyogre primal reversion
    #### Checks if the pokemon is Kyogre and is not fainted
    if isConst?(self.species, PBSpecies, :KYOGRE) && !self.isFainted?
      #### Checks if Kyogre is holding Blue Orb
      if isConst?(self.item, PBItems, :BLUEORB)
        #### Checks if Kyogre is already Primal or not
        if self.form == 0
          #### Sets new form and updates sprite.
          self.form = 1
          pbUpdate(true)
          @battle.scene.pbChangePokemon(self,@pokemon)
          @battle.pbDisplay(_INTL("Kyogre's Primal Reversion! It reverted to its primal form!",pbThis))
        end
      end
    end

    #### Groudon primal reversion
    #### Checks if the pokemon is Groudon and is not fainted
    if isConst?(self.species, PBSpecies, :GROUDON) && !self.isFainted?
      #### Checks if Groudon is holding Red Orb
      if isConst?(self.item, PBItems, :REDORB)
        #### Checks if Groudon is already Primal or not
        if self.form == 0
          #### Sets new for and updates sprite.
          self.form = 1
          pbUpdate(true)
          @battle.scene.pbChangePokemon(self,@pokemon)
          @battle.pbDisplay(_INTL("Groudon's Primal Reversion! It reverted to its primal form!",pbThis))
        end
      end
    end
    #### END OF PRIMAL REVERSIONS
    if isConst?(self.species, PBSpecies, :EISCUE) && !self.isFainted? &&
      self.effects[PBEffects::IceFace] && ($fefieldeffect==7 || $fefieldeffect==16 || $fefieldeffect==45)
      @battle.scene.pbDamageAnimation(self,0)
      self.pbBreakDisguise
      @battle.pbDisplayPaused(_INTL("{1} transformed!",self.name))
      self.effects[PBEffects::IceFace]=false
    end

    self.pbCheckFormRoundEnd
    if hasWorkingAbility(:COSTAR) && onactive
      partner=firstLivingAlly
      if partner && !partner.isFainted?
        for i in 0...8
          self.stages[i]=partner.stages[i]
        end
        @battle.pbDisplay(_INTL("{1}'s {2} copied {3}'s stat changes!",pbThis,
            PBAbilities.getName(ability),partner.pbThis(true)))
      end
    end
    if hasWorkingAbility(:EVENTHORIZON) && onactive && $fefieldeffect!=39
      turns=($fefieldeffect==38) ? 3+@battle.pbRandom(6) : 8
      if @battle.field.effects[PBEffects::Gravity]<turns
        @battle.pbIntensifyGravity(turns)
        @battle.pbDisplay(_INTL("{1}'s {2} intensified gravity!",pbThis,PBAbilities.getName(ability)))
      end
    end
    if self.hasWorkingAbility(:BADDREAMS) && onactive && !@effects[PBEffects::NightmareAura]
      nightmare=PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(PBMoves::NIGHTMARE),self)
      nightmare.pbEffect(self,self)
    end
    #### START OF WEATHER ABILITIES

    if hasWorkingAbility(:PRIMORDIALSEA) && onactive &&
      !@battle.field.effects[PBEffects::HeavyRain]
      @battle.field.effects[PBEffects::HeavyRain] = true
      @battle.weather=PBWeather::RAINDANCE
      @battle.weatherduration=-1
      @battle.pbDisplay(_INTL("A heavy rain began to fall!"))
      @battle.pbCommonAnimation("Rain",nil,nil)
    end

    if hasWorkingAbility(:DESOLATELAND) && onactive &&
      !@battle.field.effects[PBEffects::HarshSunlight]
      @battle.field.effects[PBEffects::HarshSunlight] = true
      @battle.weather=PBWeather::SUNNYDAY
      @battle.weatherduration=-1
      @battle.pbDisplay(_INTL("The sunlight turned extremely harsh!"))
      @battle.pbCommonAnimation("Sunny",nil,nil)
      # eruption check
      if $fefieldeffect == 16
        @battle.eruption = true
        @battle.pbDisplay(_INTL("The volcano top erupted!"))
      end
    end

    if hasWorkingAbility(:DELTASTREAM) && onactive &&
      @battle.weather!=PBWeather::STRONGWINDS
      @battle.weather=PBWeather::STRONGWINDS
      @battle.weatherduration=-1
      @battle.pbDisplay(_INTL("A mysterious air current is protecting Flying-type Pokémon!"))
    end

    # PRIMORDIAL WEATHER DEACTIVATION TESTS
    # Any primordial weather active?
    if @battle.field.effects[PBEffects::HeavyRain]     ||
      @battle.field.effects[PBEffects::HarshSunlight] ||
      @battle.weather == PBWeather::STRONGWINDS
      #      Flag to check whether weather should stay active
      primordialsea = false
      desolateland  = false
      deltastream   = false
      @battle.eachActiveBattlerIndex do |i|
        battler = @battle.battlers[i]
        next if !battler || battler.isFainted?
        if battler.hasWorkingAbility(:PRIMORDIALSEA)
          primordialsea = true
        elsif battler.hasWorkingAbility(:DESOLATELAND)
          desolateland  = true
        elsif battler.hasWorkingAbility(:DELTASTREAM)
          deltastream   = true
        end
      end

      if !primordialsea && @battle.weatherduration<=0
        if @battle.field.effects[PBEffects::HeavyRain]
          @battle.pbDisplay(_INTL("The heavy rain has lifted."))
          @battle.field.effects[PBEffects::HeavyRain] = false
          unless ((ability == PBAbilities::PRIMORDIALSEA) || (ability == PBAbilities::DESOLATELAND) ||
              (ability == PBAbilities::DELTASTREAM)) && onactive
            @battle.weatherduration = 0
            @battle.weather = 0
          end
          #### DemICE  - persistentweather - START
          if @battle.weatherbackup!=0
            @battle.pbCommonAnimation(@battle.weatherbackupanim,nil,nil)
            @battle.weather = @battle.weatherbackup
            @weatherduration=-1
            @battle.pbDisplay(_INTL("The initial weather took over again!"))
          end
          #### DemICE
        end
      end
      if !desolateland && @battle.weatherduration<=0
        if @battle.field.effects[PBEffects::HarshSunlight]
          @battle.pbDisplay(_INTL("The harsh sunlight faded!"))
          @battle.field.effects[PBEffects::HarshSunlight] = false
          unless ((ability == PBAbilities::PRIMORDIALSEA) || (ability == PBAbilities::DESOLATELAND) ||
              (ability == PBAbilities::DELTASTREAM)) && onactive
            @battle.weatherduration = 0
            @battle.weather = 0
          end
          #### DemICE  - persistentweather - START
          if @battle.weatherbackup!=0
            @battle.pbCommonAnimation(@battle.weatherbackupanim,nil,nil)
            @battle.weather = @battle.weatherbackup
            @weatherduration=-1
            @battle.pbDisplay(_INTL("The initial weather took over again!"))
          end
          #### DemICE
        end
      end
      if !($fefieldeffect==16 || $fefieldeffect==27 || $fefieldeffect==28 || $fefieldeffect==43)
        if !deltastream && $game_screen.weather_type != 8 && !ability == PBAbilities::TEMPEST
          if @battle.weather == PBWeather::STRONGWINDS
            @battle.pbDisplay(_INTL("The mysterious air current has dissipated!"))
            unless ((ability == PBAbilities::PRIMORDIALSEA) || (ability == PBAbilities::DESOLATELAND) ||
                (ability == PBAbilities::DELTASTREAM)) && onactive
              @battle.weatherduration = 0
              @battle.weather = 0
            end
            #### DemICE - persistentweather - START
            if @battle.weatherbackup!=0
              @battle.pbCommonAnimation(@battle.weatherbackupanim,nil,nil)
              @battle.weather = @battle.weatherbackup
              @weatherduration=-1
              @battle.pbDisplay(_INTL("The initial weather took over again!"))
            end
            #### DemICE
          end
        end
      end
    end
    # END OF PRIMAL WEATHER DEACTIVATION TESTS
    #Surges
    if hasWorkingAbility(:ELECTRICSURGE) && onactive && $fefieldeffect!=35
      @battle.pbAnimation(571,self,nil)
      field_present = ($fefieldeffect>0 && $fefieldeffect<51 && @battle.field.effects[PBEffects::Splintered]==0) || ($game_map.map_id==53)
      if field_present
        if @battle.field.effects[PBEffects::ElectricTerrain]==0
          @battle.field.effects[PBEffects::ElectricTerrain]=5
          if self.hasWorkingItem(:AMPLIFIELDROCK)
            @battle.field.effects[PBEffects::ElectricTerrain]=8
          end
          @battle.pbDisplay(_INTL("The terrain became electrified!"))
        end
      else
        $fetempfield = 1
        $fefieldeffect = $fetempfield
        @battle.pbChangeBGSprite
        @battle.field.effects[PBEffects::Terrain]=5
        @battle.field.effects[PBEffects::ElectricTerrain]=5
        @battle.field.effects[PBEffects::Terrain]=8 if self.hasWorkingItem(:AMPLIFIELDROCK)
        @battle.field.effects[PBEffects::ElectricTerrain]=8 if self.hasWorkingItem(:AMPLIFIELDROCK)
        @battle.pbDisplay(_INTL("The terrain became electrified!"))
      end
    end
    if (hasWorkingAbility(:GRASSYSURGE) || hasWorkingAbility(:HARVESTMOON)) && onactive && $fefieldeffect!=35
      @battle.pbAnimation(581,self,nil)
      terrain_turns=hasWorkingItem(:AMPLIFIELDROCK) ? 8 : 5
      field_present = ($fefieldeffect>0 && $fefieldeffect<51 && @battle.field.effects[PBEffects::Splintered]==0) || ($game_map.map_id==53)
      if field_present
        if @battle.field.effects[PBEffects::GrassyTerrain]==0
          @battle.field.effects[PBEffects::GrassyTerrain]=$fefieldeffect==42 ? 8 : terrain_turns
          @battle.pbDisplay(_INTL("The terrain became grassy!"))
        end
      else
        $fetempfield = 2
        $fefieldeffect = $fetempfield
        @battle.pbChangeBGSprite
        @battle.field.effects[PBEffects::Terrain]=terrain_turns
        @battle.field.effects[PBEffects::GrassyTerrain]=terrain_turns
        @battle.pbDisplay(_INTL("The terrain became grassy!"))
      end
    end
    if hasWorkingAbility(:MISTYSURGE) && onactive && $fefieldeffect!=35
      @battle.pbAnimation(588,self,nil)
      field_present = ($fefieldeffect>0 && $fefieldeffect<51 && @battle.field.effects[PBEffects::Splintered]==0) || ($game_map.map_id==53)
      if field_present
        if @battle.field.effects[PBEffects::MistyTerrain]==0
          @battle.field.effects[PBEffects::MistyTerrain]=5
          if self.hasWorkingItem(:AMPLIFIELDROCK)
            @battle.field.effects[PBEffects::MistyTerrain]=8
          end
          @battle.pbDisplay(_INTL("The terrain became misty!"))
        end
      else
        $fetempfield = 3
        $fefieldeffect = $fetempfield
        @battle.pbChangeBGSprite
        @battle.field.effects[PBEffects::Terrain]=5
        @battle.field.effects[PBEffects::MistyTerrain]=5
        @battle.field.effects[PBEffects::Terrain]=8 if self.hasWorkingItem(:AMPLIFIELDROCK)
        @battle.field.effects[PBEffects::MistyTerrain]=8 if self.hasWorkingItem(:AMPLIFIELDROCK)
        @battle.pbDisplay(_INTL("The terrain became misty!"))
      end
    end
    if hasWorkingAbility(:PSYCHICSURGE) && onactive && $fefieldeffect!=35
      @battle.pbAnimation(719,self,nil)
      field_present = ($fefieldeffect>0 && $fefieldeffect<51 && @battle.field.effects[PBEffects::Splintered]==0) || ($game_map.map_id==53)
      if field_present
        if @battle.field.effects[PBEffects::PsychicTerrain]==0
          @battle.field.effects[PBEffects::PsychicTerrain]=5
          if self.hasWorkingItem(:AMPLIFIELDROCK)
            @battle.field.effects[PBEffects::PsychicTerrain]=8
          end
          @battle.pbDisplay(_INTL("The terrain became mysterious!"))
        end
      else
        $fetempfield = 37
        $fefieldeffect = $fetempfield
        @battle.pbChangeBGSprite
        @battle.field.effects[PBEffects::Terrain]=5
        @battle.field.effects[PBEffects::PsychicTerrain]=5
        @battle.field.effects[PBEffects::Terrain]=8 if self.hasWorkingItem(:AMPLIFIELDROCK)
        @battle.field.effects[PBEffects::PsychicTerrain]=8 if self.hasWorkingItem(:AMPLIFIELDROCK)
        @battle.pbDisplay(_INTL("The terrain became mysterious!"))
      end
    end
    rainbowhold=0
    # Field Seeds
    @battle.seedCheck
    # Weather Abilities
    if hasWorkingAbility(:DRIZZLE) && onactive && $fefieldeffect != 38 &&
      @battle.weather!=PBWeather::RAINDANCE
      if @battle.field.effects[PBEffects::HeavyRain]
        @battle.pbDisplay(_INTL("There's no relief from this heavy rain!"))
      elsif @battle.field.effects[PBEffects::HarshSunlight]
        @battle.pbDisplay(_INTL("The extremely harsh sunlight was not lessened at all!"))
      elsif @battle.weather==PBWeather::STRONGWINDS #&& (@battle.battlers[0].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[1].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[2].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[3].hasWorkingAbility(:DELTASTREAM))
        @battle.pbDisplay(_INTL("The mysterious air current blows on regardless!"))
      elsif $fefieldeffect == 35
        @battle.pbDisplay(_INTL("The weather disappeared into space!"))
      else
        if @battle.weather==PBWeather::SUNNYDAY
          rainbowhold=5
          rainbowhold=8 if self.hasWorkingItem(:DAMPROCK)
        end
        @battle.weather=PBWeather::RAINDANCE
        @battle.weatherduration=5
        @battle.weatherduration=8 if self.hasWorkingItem(:DAMPROCK) || $fefieldeffect == 43
        if self.isbossmon
          @battle.weatherduration=-1
          @battle.weatherbackup=PBWeather::RAINDANCE
          @battle.weatherbackupanim="Rain"
        end
        @battle.pbCommonAnimation("Rain",nil,nil)
        @battle.pbDisplay(_INTL("{1}'s Drizzle made it rain!",pbThis))
      end
    end
    if (hasWorkingAbility(:SANDSTREAM) || hasWorkingAbility(:DUSTDEVIL)) && onactive && $fefieldeffect != 38 &&
      @battle.weather!=PBWeather::SANDSTORM
      if @battle.field.effects[PBEffects::HeavyRain]
        @battle.pbDisplay(_INTL("There's no relief from this heavy rain!"))
      elsif @battle.field.effects[PBEffects::HarshSunlight]
        @battle.pbDisplay(_INTL("The extremely harsh sunlight was not lessened at all!"))
      elsif @battle.weather==PBWeather::STRONGWINDS #&& (@battle.battlers[0].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[1].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[2].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[3].hasWorkingAbility(:DELTASTREAM))
        @battle.pbDisplay(_INTL("The mysterious air current blows on regardless!"))
      elsif $fefieldeffect == 35
        @battle.pbDisplay(_INTL("The weather disappeared into space!"))
      else
        @battle.weather=PBWeather::SANDSTORM
        @battle.weatherduration=5
        @battle.weatherduration=8 if hasWorkingItem(:SMOOTHROCK) ||
        $fefieldeffect == 12 || $fefieldeffect == 20 || $fefieldeffect == 43
        if self.isbossmon && hasWorkingAbility(:SANDSTREAM)
          @battle.weatherduration=-1
          @battle.weatherbackup=PBWeather::SANDSTORM
          @battle.weatherbackupanim="Sandstorm"
        end
        @battle.pbCommonAnimation("Sandstorm",nil,nil)
        @battle.pbDisplay(_INTL("{1}'s {2} whipped up a sandstorm!",pbThis,PBAbilities.getName(ability)))
      end
    end
    if hasWorkingAbility(:TEMPEST) && onactive
      weathers=rand(5)
      case weathers
       when 0
          @battle.weather=PBWeather::RAINDANCE
          @battle.weatherduration=8
          @battle.pbCommonAnimation("Rain",nil,nil)
          @battle.pbDisplay(_INTL("Storm-9 created a downpour!"))
       when 1
          @battle.weather=PBWeather::HAIL
          @battle.weatherduration=8
          @battle.pbCommonAnimation("Hail",nil,nil)
          @battle.pbDisplay(_INTL("Storm-9 brought hailfall!"))
       when 2
          @battle.weather=PBWeather::SANDSTORM
          @battle.weatherduration=8
          @battle.pbCommonAnimation("Sandstorm",nil,nil)
          @battle.pbDisplay(_INTL("Storm-9 whipped up a dust storm!"))
       when 3
          @battle.weather=PBWeather::STRONGWINDS
          @battle.weatherduration=8
          @battle.pbCommonAnimation("Wind",nil,nil)
          @battle.pbDisplay(_INTL("Storm-9 whipped up terrible winds!"))
       when 4
          @battle.weather=PBWeather::SHADOWSKY
          @battle.weatherduration=8
          @battle.pbCommonAnimation("ShadowSky",nil,nil)
          @battle.pbDisplay(_INTL("Storm-9 shrouded the sky in a dark aura..."))
       end
     end
    if hasWorkingAbility(:DROUGHT) && onactive && $fefieldeffect != 38 &&
      @battle.weather!=PBWeather::SUNNYDAY
      if @battle.field.effects[PBEffects::HeavyRain]
        @battle.pbDisplay(_INTL("There's no relief from this heavy rain!"))
      elsif @battle.field.effects[PBEffects::HarshSunlight]
        @battle.pbDisplay(_INTL("The extremely harsh sunlight was not lessened at all!"))
      elsif @battle.weather==PBWeather::STRONGWINDS #&& (@battle.battlers[0].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[1].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[2].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[3].hasWorkingAbility(:DELTASTREAM))
        @battle.pbDisplay(_INTL("The mysterious air current blows on regardless!"))
      elsif $fefieldeffect == 35
        @battle.pbDisplay(_INTL("The weather disappeared into space!"))
      else
        if @battle.weather==PBWeather::RAINDANCE
          rainbowhold=5
          rainbowhold=8 if self.hasWorkingItem(:HEATROCK)
        end
        @battle.weather=PBWeather::SUNNYDAY
        @battle.weatherduration=5
        @battle.weatherduration=8 if self.hasWorkingItem(:HEATROCK) ||
        $fefieldeffect == 12 || $fefieldeffect == 27 || $fefieldeffect == 28 || $fefieldeffect == 43 || $fefieldeffect == 46
        if self.isbossmon
          @battle.weatherduration=-1
          @battle.weatherbackup=PBWeather::SUNNYDAY
          @battle.weatherbackupanim="Sunny"
        end
        @battle.pbCommonAnimation("Sunny",nil,nil)
        @battle.pbDisplay(_INTL("{1}'s Drought intensified the sun's rays!",pbThis))
        if $fefieldeffect == 4
          $fefieldeffect = 25
          @battle.pbChangeBGSprite
          @effects[PBEffects::Terrain] = @battle.weatherduration
          @battle.pbDisplay(_INTL("The sun lit up the crystal cavern!"))
        end
      end
    end
    if hasWorkingAbility(:SNOWWARNING) && onactive && $fefieldeffect != 38 &&
      @battle.weather!=PBWeather::HAIL
      if @battle.field.effects[PBEffects::HeavyRain]
        @battle.pbDisplay(_INTL("There's no relief from this heavy rain!"))
      elsif @battle.field.effects[PBEffects::HarshSunlight]
        @battle.pbDisplay(_INTL("The extremely harsh sunlight was not lessened at all!"))
      elsif @battle.weather==PBWeather::STRONGWINDS #&& (@battle.battlers[0].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[1].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[2].hasWorkingAbility(:DELTASTREAM) || @battle.battlers[3].hasWorkingAbility(:DELTASTREAM))
        @battle.pbDisplay(_INTL("The mysterious air current blows on regardless!"))
      elsif $fefieldeffect == 35
        @battle.pbDisplay(_INTL("The weather disappeared into space!"))
      else
        @battle.weather=PBWeather::HAIL
        @battle.weatherduration=5
        @battle.weatherduration=8 if self.hasWorkingItem(:ICYROCK) ||
        $fefieldeffect == 13 || $fefieldeffect == 28 || $fefieldeffect == 39 || $fefieldeffect == 43
        if self.isbossmon
          @battle.weatherduration=-1
          @battle.weatherbackup=PBWeather::HAIL
          @battle.weatherbackupanim="Hail"
        end
        @battle.pbCommonAnimation("Hail",nil,nil)
        @battle.pbDisplay(_INTL("{1}'s Snow Warning made it hail!",pbThis))
        for facemon in @battle.battlers
          if facemon.species==875 && facemon.form==1 # Eiscue
            facemon.pbRegenFace
            @battle.pbDisplayPaused(_INTL("{1} transformed!",facemon.name))
          end
        end
      end
    end
    if rainbowhold != 0 && @battle.field.effects[PBEffects::Splintered]==0
      if $fefieldeffect != 9
        @battle.pbCommonAnimation("RainbowT",nil,nil)
      end
      if $febackup>0 && $febackup<51 && @battle.field.effects[PBEffects::Splintered]==0
        @battle.pbDisplay(_INTL("The weather created a rainbow!"))
        @battle.field.effects[PBEffects::Rainbow]= rainbowhold
      else
        $fefieldeffect = 9
        @battle.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The weather created a rainbow!"))
        @battle.field.effects[PBEffects::Terrain]= rainbowhold
        @battle.field.effects[PBEffects::Rainbow]= rainbowhold
      end
    end
    # Castform Crest
    if isConst?(self.species,PBSpecies,:CASTFORM) && isConst?(self.item,PBItems,:CASTCREST) &&
      self.turncount==0

      for i in self.moves
        movedata=PBMoveData.new(i.id)
        if movedata.function==0xFF # Sunny Day
          if @battle.weather!=PBWeather::SUNNYDAY
            @battle.weather=PBWeather::SUNNYDAY
            @battle.weatherduration=5
            @battle.weatherduration=8 if $fefieldeffect == 12 || $fefieldeffect == 27 || $fefieldeffect == 28 || $fefieldeffect == 43 || $fefieldeffect == 46
            @battle.pbCommonAnimation("Sunny",nil,nil)
            @battle.pbDisplay(_INTL("{1}'s Sunny Day intensified the sun's rays!",pbThis))
            self.pbCheckForm
          end
          break
        end
        if movedata.function==0x100 # Rain Dance
          if @battle.weather!=PBWeather::RAINDANCE
            @battle.weather=PBWeather::RAINDANCE
            @battle.weatherduration=5
            @battle.weatherduration=8 if $fefieldeffect == 43
            @battle.pbCommonAnimation("Rain",nil,nil)
            @battle.pbDisplay(_INTL("{1}'s Rain Dance made it rain!",pbThis))
            self.pbCheckForm
          end
          break
        end
        if movedata.function==0x101 # Sandstorm
          if @battle.weather!=PBWeather::SANDSTORM
            @battle.weather=PBWeather::SANDSTORM
            @battle.weatherduration=5
            @battle.weatherduration=8 if $fefieldeffect == 12 || $fefieldeffect == 20 || $fefieldeffect == 43
            @battle.pbCommonAnimation("Sandstorm",nil,nil)
            @battle.pbDisplay(_INTL("{1}'s Sandstorm whipped up a sandstorm!",pbThis))
            self.pbCheckForm
          end
          break
        end
        if movedata.function==0x102 # Hail
          if @battle.weather!=PBWeather::HAIL
            @battle.weather=PBWeather::HAIL
            @battle.weatherduration=5
            @battle.weatherduration=8 if $fefieldeffect == 13 || $fefieldeffect == 28 || $fefieldeffect == 39 || $fefieldeffect == 43
            @battle.pbCommonAnimation("Hail",nil,nil)
            @battle.pbDisplay(_INTL("{1}'s Hail made it hail!",pbThis))
            self.pbCheckForm
          end
          break
        end
      end
    end
    #### END OF WEATHER ABILITIES

    #### START OF WEATHER-CANCELLING ABILITIES
    if self.hasWorkingAbility(:AIRLOCK) && onactive
      @battle.pbDisplay(_INTL("The effects of the weather disappeared."))
    end

    if self.hasWorkingAbility(:CLOUDNINE) && onactive
      @battle.pbDisplay(_INTL("The effects of the weather disappeared."))
    end

    #### END OF WEATHER-CANCELLING ABILITIES

    ##### KUROTSUNE - 001 - END
    # Pressure message
    if self.hasWorkingAbility(:PRESSURE) && onactive
      @battle.pbDisplay(_INTL("{1} is exerting its Pressure!",pbThis))
    end
    # UPDATE : Mold Breaker
    if hasWorkingAbility(:MOLDBREAKER) && onactive
      @battle.pbDisplay(_INTL("{1} breaks the mold!",pbThis))
    end
    if hasWorkingAbility(:COMATOSE) && onactive && $fefieldeffect!=1
      @battle.pbDisplay(_INTL("{1} is drowsing!",pbThis))
    end
    #### AME - 001 - START
    if hasWorkingAbility(:TERAVOLT) && onactive
      @battle.pbDisplay(_INTL("{1} is radiating a bursting aura!",pbThis))
    end
    if hasWorkingAbility(:TURBOBLAZE) && onactive
      @battle.pbDisplay(_INTL("{1} is radiating a blazing aura!",pbThis))
    end
    #### AME - 001 - END
    if hasWorkingAbility(:FAIRYAURA) && onactive
      @battle.pbDisplay(_INTL("{1} is radiating a Fairy aura!",pbThis))
    end
    if hasWorkingAbility(:DARKAURA) && onactive
      @battle.pbDisplay(_INTL("{1} is radiating a Dark aura!",pbThis))
    end
    if hasWorkingAbility(:AURABREAK) && onactive
      @battle.pbDisplay(_INTL("{1} reversed all other Pokémon's auras!",pbThis))
    end
    # End of Update
    #### SARDINES - v17 - START
    # Slow Start Message
    if hasWorkingAbility(:SLOWSTART) && onactive
      @battle.pbDisplay(_INTL("{1} can't get it going because of its {2}", pbThis, PBAbilities.getName(ability)))
    end
    #### SARDINES - v17 - END
    # Balloon
    if self.hasWorkingItem(:AIRBALLOON) && onactive && !megad && !gas_ended
      @battle.pbDisplay(_INTL("{1} is floating on its balloon!",pbThis))
    end
    # Vengeant Diadem - raise highest stat if last in party, otherwise raise lowest
    if self.hasWorkingItem(:VENGEANTDIADEM) && onactive && !megad && !gas_ended
      party = @battle.pbParty(self.index)
      aliveCount = 0
      for poke in party
        next if !poke || poke.hp <= 0 || poke.isEgg?
        aliveCount += 1
      end
      # Find highest and lowest boostable stats
      statvals = {
        PBStats::ATTACK => self.attack,
        PBStats::DEFENSE => self.defense,
        PBStats::SPATK => self.spatk,
        PBStats::SPDEF => self.spdef,
        PBStats::SPEED => self.speed
      }
      highest = statvals.max_by { |k, v| v }[0]
      lowest = statvals.min_by { |k, v| v }[0]
      if aliveCount <= 1
        # Last in party - raise highest stat
        if pbCanIncreaseStatStage?(highest)
          pbIncreaseStatBasic(highest, 1)
          @battle.pbCommonAnimation("StatUp", self, nil)
          @battle.pbDisplay(_INTL("{1}'s Vengeant Diadem raised its {2}!",
              pbThis, pbGetStatName(highest)))
        end
      else
        # Not last - raise lowest stat
        if pbCanIncreaseStatStage?(lowest)
          pbIncreaseStatBasic(lowest, 1)
          @battle.pbCommonAnimation("StatUp", self, nil)
          @battle.pbDisplay(_INTL("{1}'s Vengeant Diadem raised its {2}!",
              pbThis, pbGetStatName(lowest)))
        end
      end
    end
    # Noxious Draught - deals 1/8th max HP damage to all other Pokemon on entry
    if self.hasWorkingItem(:NOXIOUSDRAUGHT) && onactive && !megad && !gas_ended
      @battle.pbDisplay(_INTL("{1}'s Noxious Draught released toxic fumes!",pbThis))
      for i in 0...4
        target = @battle.battlers[i]
        next if !target || target.isFainted? || target.index == self.index
        next if target.hasWorkingAbility(:MAGICGUARD)
        next if target.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44
        damage = (target.totalhp / 8).floor
        damage = 1 if damage < 1
        @battle.scene.pbDamageAnimation(target, 0)
        target.pbReduceHP(damage, true)
        @battle.pbDisplay(_INTL("{1} was hurt by the toxic fumes!",target.pbThis))
      end
    end
    # Trace
    if self.hasWorkingAbility(:TRACE) || (self.hasWorkingAbility(:ADAPTABILITY) &&
        $fefieldeffect == 34)
      @effects[PBEffects::TracedAbility]=0
      if @effects[PBEffects::Trace] || onactive
        choices=[]
        for i in 0...4
          if pbIsOpposing?(i) && !@battle.battlers[i].isFainted? && !@battle.battlers[i].isbossmon
            choices[choices.length]=i if @battle.battlers[i].ability!=0 &&
            (!isConst?(@battle.battlers[i].ability,PBAbilities,:MULTITYPE) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:COMATOSE) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:DISGUISE) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:ACCUMULATION) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:EXECUTION) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:SCHOOLING) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:IMPOSTER) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:SHIELDSDOWN) &&
              !isConst?(@battle.battlers[i].ability,PBAbilities,:RKSSYSTEM))
          end
        end
        if choices.length==0
          @effects[PBEffects::Trace]=true
        else
          choice=choices[@battle.pbRandom(choices.length)]
          battlername=@battle.battlers[choice].pbThis(true)
          battlerability=@battle.battlers[choice].ability
          @ability=battlerability
          abilityname=PBAbilities.getName(battlerability)
          @effects[PBEffects::TracedAbility]=battlerability
          if self.hasWorkingAbility(:ADAPTABILITY)
            @battle.pbDisplay(_INTL("{1} took on {2}'s {3}!",pbThis,battlername,abilityname))
          else
            @battle.pbDisplay(_INTL("{1} traced {2}'s {3}!",pbThis,battlername,abilityname))
          end
          @effects[PBEffects::Trace]=false
        end
      end
    end
    # Mimicry
    if self.hasWorkingAbility(:MIMICRY) && onactive
      protype = -1
      case $fefieldeffect
      when 1
        protype = :ELECTRIC || 0
      when 2
        protype = :GRASS || 0
      when 3
        protype = :FAIRY || 0
      when 4
        protype = :DARK || 0
      when 5
        protype = :PSYCHIC || 0
      when 6
        protype = :NORMAL || 0
      when 7
        protype = :FIRE || 0
      when 8
        protype = :WATER || 0
      when 9
        protype = :DRAGON || 0
      when 10
        protype = :POISON || 0
      when 11
        protype = :POISON || 0
      when 12
        protype = :GROUND || 0
      when 13
        protype = :ICE || 0
      when 14
        protype = :ROCK || 0
      when 15
        protype = :BUG || 0
      when 16
        protype = :FIRE || 0
      when 17
        protype = :STEEL || 0
      when 18
        protype = :ELECTRIC || 0
      when 19
        protype = :POISON || 0
      when 20
        protype = :GROUND || 0
      when 21
        protype = :WATER || 0
      when 22
        protype = :WATER || 0
      when 23
        protype = :ROCK || 0
      when 24
        protype = :QMARKS || 0
      when 25
        rnd=@battle.pbRandom(4)
        case rnd
        when 0
          protype = :GRASS || 0
        when 1
          protype = :WATER || 0
        when 2
          protype = :FIRE || 0
        when 3
          protype = :PSYCHIC || 0
        end
      when 26
        protype = :POISON || 0
      when 27
        protype = :ROCK || 0
      when 28
        protype = :ICE || 0
      when 29
        protype = :NORMAL || 0
      when 30
        protype = :STEEL || 0
      when 31
        protype = :FAIRY || 0
      when 32
        protype = :DRAGON || 0
      when 33
        protype = :GRASS || 0
      when 34
        protype = :DARK || 0
      when 35
        rnd=@battle.pbRandom(18)
        case rnd
        when 0
          protype = :NORMAL || 0
        when 1
          protype = :WATER || 0
        when 2
          protype = :FIRE || 0
        when 3
          protype = :ELECTRIC || 0
        when 4
          protype = :GRASS || 0
        when 5
          protype = :ICE || 0
        when 6
          protype = :FIGHTING || 0
        when 7
          protype = :POISON || 0
        when 8
          protype = :GROUND || 0
        when 9
          protype = :PSYCHIC || 0
        when 10
          protype = :ROCK || 0
        when 11
          protype = :FLYING || 0
        when 12
          protype = :BUG || 0
        when 13
          protype = :GHOST || 0
        when 14
          protype = :DRAGON || 0
        when 15
          protype = :DARK || 0
        when 16
          protype = :STEEL || 0
        when 17
          protype = :FAIRY || 0
        end
      when 36
        protype = :NORMAL || 0
      when 37
        protype = :PSYCHIC || 0
      when 38
        protype = :DARK || 0
      when 39
        protype = :ICE || 0
      when 40
        protype = :GHOST || 0
      when 41
        protype = :POISON || 0
      when 42
        protype = :FAIRY || 0
      when 43
        protype = :FLYING || 0
      when 44
        protype = :STEEL || 0
      when 45
        protype = :FIRE || 0
      when 46
        protype = :GROUND || 0
      end
      prot1 = self.type1
      prot2 = self.type2
      camotype = getConst(PBTypes,protype) || 0
      if camotype>0 && (!self.pbHasType?(camotype) || (defined?(prot2) && prot1 != prot2))
        self.type1=camotype
        self.type2=camotype
        typename=PBTypes.getName(camotype)
        @battle.pbDisplay(_INTL("{1} had its type changed to {2}!",pbThis,typename))
      end
    end
    # Pastel Veil
    if self.hasWorkingAbility(:PASTELVEIL) && $fefieldeffect!=45 && onactive
      sameSideBattlers(false).each do |ally|
        next if ally.status != PBStatuses::POISON
        @battle.pbDisplay(_INTL("{1}'s Pastel Veil cured {2}'s poison problem!",pbThis,ally.pbThis(true)))
        ally.status=0
        ally.statusCount=0
      end
    end
    # Intimidate
    if self.hasWorkingAbility(:INTIMIDATE) && onactive
      opposingBattlers.each do |battler|
        next if !battler || battler.isFainted?
        battler.pbReduceAttackStatStageIntimidate(self)
      end
    end
    # Intimidate
    if self.hasWorkingAbility(:INTIMIDATE2) && onactive
      opposingBattlers.each do |battler|
        next if !battler || battler.isFainted?
        battler.pbReduceAttackStatStageIntimidate(self)
      end
    end
    # Eldritch - Blinds all other Pokemon on entry
    if self.hasWorkingAbility(:ELDRITCH) && onactive
      blinded_any = false
      @battle.battlers.each do |target|
        next if !target || target.isFainted?
        next if target.index == self.index
        if target.effects[PBEffects::Blinded] <= 0 && !target.hasWorkingAbility(:ILLUMINATE)
          target.effects[PBEffects::Blinded] = 1
          blinded_any = true
        end
      end
      if blinded_any
        @battle.pbDisplay(_INTL("{1}'s {2} blinded the battlefield!",pbThis,PBAbilities.getName(ability)))
      end
    end
    # Keen Eye - Uses Lock-On and Laser Focus on entry
    if self.hasWorkingAbility(:KEENEYE) && onactive
      target=pbPreferredOpposingTarget
      if target
        target.effects[PBEffects::LockOn]=2
        target.effects[PBEffects::LockOnPos]=self.index
      end
      self.effects[PBEffects::LaserFocus]=2
      @battle.pbDisplay(_INTL("{1}'s {2} sharpened its focus!",pbThis,PBAbilities.getName(ability)))
    end
    # Haste - sharply raises Speed on entry
    if self.hasWorkingAbility(:HASTE) && onactive
      @battle.statChangeSource=[:ability,self.ability]
      if pbIncreaseStat(PBStats::SPEED,2,false,nil,nil,true,false,false)
        @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Speed!",pbThis,PBAbilities.getName(ability)))
      end
      @battle.statChangeSource=nil
    end
    # Illuminate - Raises accuracy on entry
    if self.hasWorkingAbility(:ILLUMINATE) && onactive
      @battle.statChangeSource=[:ability,self.ability]
      if pbIncreaseStat(PBStats::ACCURACY,1,false,nil,nil,true,false,false)
        @battle.pbDisplay(_INTL("{1}'s {2} boosted its Accuracy!",pbThis,PBAbilities.getName(ability)))
      end
      @battle.statChangeSource=nil
    end
    # Hypnotic - Confuses and infatuates enemies on entry
    if self.hasWorkingAbility(:HYPNOTIC) && onactive
      opposingBattlers.each do |opponent|
        next if !opponent || opponent.isFainted?
        if opponent.pbCanConfuse?(false)
          opponent.effects[PBEffects::Confusion]=3 #pk code
          @battle.pbCommonAnimation("Confusion",opponent,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} confused {3}!",pbThis,PBAbilities.getName(ability),opponent.pbThis(true)))
        end
        if opponent.pbCanAttract?(self,false) && @battle.pbCheckSideAbility(:AROMAVEIL,opponent)==nil
          opponent.effects[PBEffects::Attract]=self.index
          opponent.effects[PBEffects::AttractTurns]=3 #pk code
          @battle.pbCommonAnimation("Attract",opponent,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} enchanted {3}!",pbThis,PBAbilities.getName(ability),opponent.pbThis(true))) #pk code
        end
      end
    end
    # Keyholder - Imprisons on entry
    if self.hasWorkingAbility(:KEYHOLDER) && onactive && !self.effects[PBEffects::Imprison]
      self.effects[PBEffects::Imprison]=true
      @battle.pbDisplay(_INTL("{1} sealed the opponent's move(s) with its {2}!",pbThis,PBAbilities.getName(ability)))
    end
    # Frisk - Peek at enemy item and block usage for 1 turn
    if self.hasWorkingAbility(:FRISK) && onactive
      opposingBattlers.each do |opponent|
        next if !opponent || opponent.isFainted?
        if opponent.item > 0
          itemname = PBItems.getName(opponent.item)
          @battle.pbDisplay(_INTL("{1} frisked {2} and found its {3}!",pbThis,opponent.pbThis(true),itemname))
          opponent.effects[PBEffects::FriskLock] = 1
        end
      end
    end
    # Forewarn - Disable a foe's super-effective move on entry
    if self.hasWorkingAbility(:FOREWARN) && onactive
      opposingBattlers.each do |opponent|
        next if !opponent || opponent.isFainted?
        # Find a super-effective move
        for j in 0...4
          next if !opponent.moves[j] || opponent.moves[j].id == 0
          move=opponent.moves[j]
          next if move.basedamage==0
          movetype=move.pbType(move.type,opponent,self)
          if move.pbTypeModifier(movetype,opponent,self)>4
            opponent.effects[PBEffects::ForewarnDisable] = 1
            opponent.effects[PBEffects::ForewarnDisableMove] = move.id
            movename = move.name
            @battle.pbDisplay(_INTL("{1}'s {2} disabled {3}'s {4}!",pbThis,PBAbilities.getName(ability),opponent.pbThis(true),movename))
            break
          end
        end
      end
    end
    # Color Change - Uses Camouflage on entry
    if self.hasWorkingAbility(:COLORCHANGE) && onactive
      if !self.hasWorkingAbility(:MULTITYPE) && !self.hasWorkingAbility(:RKSSYSTEM)
        newtype = pbCamouflageType
        if newtype && (self.type1!=newtype || self.type2!=newtype)
          self.type1 = newtype
          self.type2 = newtype
          pbApplyCamouflageMoveTypes(newtype)
          typename = PBTypes.getName(newtype)
          @battle.pbDisplay(_INTL("{1}'s {2} changed it to {3} type!",pbThis,PBAbilities.getName(ability),typename))
        end
      end
    end
    # Download
    if (self.hasWorkingAbility(:DOWNLOAD) ||  @battle.SilvallyCheck(self,PBTypes::ELECTRIC)) && onactive
      odef=ospdef=0
      opposingBattlers.each do |opponent|
        next if !opponent || opponent.hp<=0
        odef+=opponent.defense
        ospdef+=opponent.spdef
      end
      if ospdef>odef
        if !pbTooHigh?(PBStats::ATTACK)
          if $fefieldeffect == 17
            pbIncreaseStatBasic(PBStats::ATTACK,2)
            @battle.pbDisplay(_INTL("{1}'s {2} sharply boosted its Attack!",
                pbThis,PBAbilities.getName(ability)))
          else
            pbIncreaseStatBasic(PBStats::ATTACK,1)
            @battle.pbDisplay(_INTL("{1}'s {2} boosted its Attack!",
                pbThis,PBAbilities.getName(ability)))
          end
        end
        if $fefieldeffect == 18 || $fefieldeffect == 24
          if !pbTooHigh?(PBStats::SPATK)
              pbIncreaseStatBasic(PBStats::SPATK,1)
              @battle.pbDisplay(_INTL("{1}'s {2} boosted its Special Attack!",
                  pbThis,PBAbilities.getName(ability)))
          end
        end
      else
        if !pbTooHigh?(PBStats::SPATK)
          if $fefieldeffect == 17
            pbIncreaseStatBasic(PBStats::SPATK,2)
            @battle.pbDisplay(_INTL("{1}'s {2} sharply boosted its Special Attack!",
                pbThis,PBAbilities.getName(ability)))
          else
            pbIncreaseStatBasic(PBStats::SPATK,1)
            @battle.pbDisplay(_INTL("{1}'s {2} boosted its Special Attack!",
                pbThis,PBAbilities.getName(ability)))
          end
        end
        if $fefieldeffect == 18 || $fefieldeffect == 24
          if !pbTooHigh?(PBStats::ATTACK)
              pbIncreaseStatBasic(PBStats::ATTACK,1)
              @battle.pbDisplay(_INTL("{1}'s {2} boosted its Attack!",
                  pbThis,PBAbilities.getName(ability)))
          end
        end
      end
    end
    # Screen Cleaner
    if self.hasWorkingAbility(:SCREENCLEANER) && onactive
      pbOwnSide.effects[PBEffects::Reflect]     = 0
      pbOwnSide.effects[PBEffects::LightScreen] = 0
      pbOwnSide.effects[PBEffects::AuroraVeil]  = 0
      pbOpposingSide.effects[PBEffects::Reflect]     = 0
      pbOpposingSide.effects[PBEffects::LightScreen] = 0
      pbOpposingSide.effects[PBEffects::AuroraVeil]  = 0
      @battle.pbDisplay(_INTL("{1} has {2}!",pbThis,PBAbilities.getName(self.ability)))
      @battle.pbDisplay(_INTL("The effects of protective barriers disappeared."))
    end
    # Dauntless Shield
    if self.hasWorkingAbility(:DAUNTLESSSHIELD) && onactive
      if !pbTooHigh?(PBStats::DEFENSE)
        pbIncreaseStatBasic(PBStats::DEFENSE,1)
        @battle.pbDisplay(_INTL("{1}'s {2} boosted its Defense!",
            pbThis,PBAbilities.getName(ability)))
      end
    end
    # Intrepid Sword
    if self.hasWorkingAbility(:INTREPIDSWORD) && onactive
      if !pbTooHigh?(PBStats::ATTACK)
        pbIncreaseStatBasic(PBStats::ATTACK,1)
        @battle.pbDisplay(_INTL("{1}'s {2} boosted its Attack!",
            pbThis,PBAbilities.getName(ability)))
      end
    end
    # Mirror Field Entry
    if $fefieldeffect == 30
      if !pbTooHigh?(PBStats::EVASION)
        if (self.hasWorkingAbility(:SANDVEIL) ||
            self.hasWorkingAbility(:TANGLEDFEET) || self.hasWorkingAbility(:MAGICBOUNCE) ||
            @battle.SilvallyCheck(self, "psychic") ||
            self.hasWorkingAbility(:COLORCHANGE)) && onactive
          pbIncreaseStatBasic(PBStats::EVASION,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} boosted its Evasion!",
              pbThis,PBAbilities.getName(ability)))
        elsif self.hasWorkingAbility(:ILLUSION)
          pbIncreaseStatBasic(PBStats::EVASION,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s ability boosted its Evasion!",
              pbThis,PBAbilities.getName(ability)))
        end
        if (self.hasWorkingItem(:BRIGHTPOWDER) ||
            self.hasWorkingItem(:LAXINCENSE)) && onactive
          pbIncreaseStatBasic(PBStats::EVASION,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s item boosted its Evasion!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      # Illuminate
      if self.hasWorkingAbility(:ILLUMINATE) && onactive
        opposingBattlers.each do |battler|
          next if !battler || battler.isFainted?
          battler.pbReduceIlluminate(self)
        end
      end
    end
    # Fairy Tale Field Entry
    if $fefieldeffect == 31
      if !pbTooHigh?(PBStats::DEFENSE)
        if (self.hasWorkingAbility(:BATTLEARMOR) || self.hasWorkingAbility(:SHELLARMOR) ||
            self.hasWorkingAbility(:POWEROFALCHEMY) || self.hasWorkingAbility(:MIRRORARMOR)
            self.hasWorkingAbility(:DAUNTLESSSHIELD)) && onactive
          @battle.pbCommonAnimation("StatUp",self,nil)
          if self.hasWorkingAbility(:MIRRORARMOR)
            pbIncreaseStatBasic(PBStats::SPDEF,1)
            @battle.pbDisplay(_INTL("{1}'s shining armor boosted its Special Defense!",pbThis,PBAbilities.getName(ability)))
          elsif self.hasWorkingAbility(:DAUNTLESSSHIELD)
            pbIncreaseStatBasic(PBStats::DEFENSE,1)
            @battle.pbDisplay(_INTL("{1}'s blessed shield boosted its Defense!",pbThis,PBAbilities.getName(ability)))
          else
            pbIncreaseStatBasic(PBStats::DEFENSE,1)
            @battle.pbDisplay(_INTL("{1}'s shining armor boosted its Defense!",pbThis,PBAbilities.getName(ability)))
          end
        end
        if ((!self.abilitynulled && self.ability == PBAbilities::STANCECHANGE)) && onactive
          @battle.pbCommonAnimation("StatUp",self,nil)
          pbIncreaseStatBasic(PBStats::DEFENSE,1)
        end
      end
      if !pbTooHigh?(PBStats::SPDEF)
        if (self.hasWorkingAbility(:MAGICGUARD) || self.hasWorkingAbility(:MAGICBOUNCE) ||
            self.hasWorkingAbility(:POWEROFALCHEMY) ||
            self.hasWorkingAbility(:PASTELVEIL) ||
            self.hasWorkingAbility(:DAUNTLESSSHIELD) || @battle.SilvallyCheck(self,PBTypes::PSYCHIC)) && onactive
          pbIncreaseStatBasic(PBStats::SPDEF,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s magical power boosted its Special Defense!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::ATTACK)
        if (self.hasWorkingAbility(:INTREPIDSWORD)) && onactive
          pbIncreaseStatBasic(PBStats::ATTACK,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s magical power boosted its Attack!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::SPATK)
        if (self.hasWorkingAbility(:MAGICIAN) || self.hasWorkingAbility(:INTREPIDSWORD)) && onactive
          pbIncreaseStatBasic(PBStats::SPATK,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s magical power boosted its Special Attack!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    # Chess Board Entry
    if $fefieldeffect == 5
      if (self.hasWorkingAbility(:STALL)) && onactive
        @battle.pbDisplay(_INTL("{1}'s Stall boosted its defenses!",
            pbThis,PBAbilities.getName(ability)))
        if !pbTooHigh?(PBStats::DEFENSE)
          pbIncreaseStatBasic(PBStats::DEFENSE,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
        end
      end
    end
    if isConst?(self.species,PBSpecies,:VESPIQUEN) && isConst?(self.item,PBItems,:VESPICREST) && onactive
      self.effects[PBEffects::VespiCrest]  = 1
      pbIncreaseStatBasic(PBStats::ATTACK,1)
      pbIncreaseStatBasic(PBStats::SPATK,1)
    end
    # Dragon's Den Entry
    if $fefieldeffect == 32
      if (self.hasWorkingAbility(:SHELLARMOR)) && onactive
        @battle.pbDisplay(_INTL("{1}'s Shell Armor boosted its Defense!",
            pbThis,PBAbilities.getName(ability)))
        if !pbTooHigh?(PBStats::DEFENSE)
          pbIncreaseStatBasic(PBStats::DEFENSE,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
        end
      end
    end
    # Flower Garden Entry
    if $fefieldeffect == 33
      tempcounter = $fecounter
      if (self.hasWorkingAbility(:FLOWERGIFT) ||
          self.hasWorkingAbility(:FLOWERVEIL) ||
          @battle.SilvallyCheck(self, "grass") ||
          self.hasWorkingAbility(:DROUGHT) ||
          self.hasWorkingAbility(:DRIZZLE)) && onactive
        $fecounter+=1 if $fecounter < 4
      end
      if tempcounter < $fecounter
        @battle.pbChangeBGSprite
        @battle.pbDisplay(_INTL("{1}'s {2} caused the garden to grow a little bit!",
            pbThis,PBAbilities.getName(ability)))
      end
    end
    # Starlight Arena Entry
    if $fefieldeffect == 34
      if !pbTooHigh?(PBStats::SPATK)
        if (self.hasWorkingAbility(:ILLUMINATE)) && onactive
          pbIncreaseStatBasic(PBStats::SPATK,2)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} flared up with starlight!",
              pbThis,PBAbilities.getName(ability)))
          partner = otherSameSideAbilityHolder(:MIRRORARMOR)
          if partner
            partner.effects[PBEffects::FollowMe]=true
            @battle.pbAnimation(getConst(PBMoves,:SPOTLIGHT),self,partner)
            @battle.pbDisplay(_INTL("{1}'s dazzling shine put a spotlight on its partner!",
            pbThis))
          end
        end
      end
    end
    # Psychic Terrain Entry
    if $fefieldeffect == 37 || @battle.field.effects[PBEffects::PsychicTerrain]>0
      if !pbTooHigh?(PBStats::SPATK)
        if (self.hasWorkingAbility(:ANTICIPATION) || self.hasWorkingAbility(:FOREWARN)) && onactive
          if $fefieldeffect==37
            pbIncreaseStatBasic(PBStats::SPATK,2)
          elsif @battle.field.effects[PBEffects::PsychicTerrain]>0 && self.hasWorkingAbility(:ANTICIPATION)
            pbIncreaseStatBasic(PBStats::SPATK,1)
          end
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    # Misty Terrain + Corrosive Mist Entry
    if $fefieldeffect == 3 || $fefieldeffect == 11
      if !pbTooHigh?(PBStats::DEFENSE)
        if (self.hasWorkingAbility(:WATERCOMPACTION)) && onactive
          pbIncreaseStatBasic(PBStats::DEFENSE,2)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s Water Compaction sharply raised its defense!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    # Dimensional + Frozen Dimensional + Haunted Entry
    if $fefieldeffect == 38 || $fefieldeffect == 39 || $fefieldeffect == 40
      if !pbTooHigh?(PBStats::SPEED)
        if (self.hasWorkingAbility(:RATTLED)) && onactive
          pbIncreaseStatBasic(PBStats::SPEED,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s Rattled raised its speed!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    # Sky Field Entry
    if $fefieldeffect == 43
      if !pbTooHigh?(PBStats::DEFENSE)
        if (self.hasWorkingAbility(:BIGPECKS)) && onactive
          pbIncreaseStatBasic(PBStats::DEFENSE,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} raised its defense in the skies!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::SPEED)
        if (self.hasWorkingAbility(:LEVITATE) || self.hasWorkingAbility(:SOLARIDOL) || self.hasWorkingAbility(:LUNARIDOL)) && onactive
          pbIncreaseStatBasic(PBStats::SPEED,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} made it go faster in the open skies!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    # Colosseum Field Entry
    if $fefieldeffect == 44
      if !pbTooHigh?(PBStats::DEFENSE)
        if (self.hasWorkingAbility(:DAUNTLESSSHIELD) || self.hasWorkingAbility(:BATTLEARMOR) ||
            self.hasWorkingAbility(:SHELLARMOR)) && onactive
          pbIncreaseStatBasic(PBStats::DEFENSE,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s shining armor boosted its Defense!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::SPDEF)
        if (self.hasWorkingAbility(:DAUNTLESSSHIELD) || self.hasWorkingAbility(:MIRRORARMOR) ||
            self.hasWorkingAbility(:MAGICGUARD)) && onactive
          pbIncreaseStatBasic(PBStats::SPDEF,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s magical power boosted its Special Defense!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::ATTACK)
        if (self.hasWorkingAbility(:INTREPIDSWORD) || self.hasWorkingAbility(:NOGUARD) ||
            self.hasWorkingAbility(:JUSTIFIED)) && onactive
          pbIncreaseStatBasic(PBStats::ATTACK,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s ferocious heart boosted its Attack!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::SPATK)
        if (self.hasWorkingAbility(:INTREPIDSWORD) || self.hasWorkingAbility(:NOGUARD) ||
            self.hasWorkingAbility(:JUSTIFIED)) && onactive
          pbIncreaseStatBasic(PBStats::SPATK,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s ferocious heart boosted its Special Attack!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    # Infernal Field Entry
    if $fefieldeffect == 45
      if !pbTooHigh?(PBStats::DEFENSE)
        if (self.hasWorkingAbility(:FLAMEBODY) ||
            self.hasWorkingAbility(:DESOLATELAND)) && onactive
          pbIncreaseStatBasic(PBStats::DEFENSE,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s armor boosted its Defense!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::SPDEF)
        if (self.hasWorkingAbility(:FLAMEBODY) ||
            self.hasWorkingAbility(:DESOLATELAND)) && onactive
          pbIncreaseStatBasic(PBStats::SPDEF,1)
          @battle.pbCommonAnimation("StatUp",self,nil)
          @battle.pbDisplay(_INTL("{1}'s armor boosted its Special Defense!",
              pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    # Beach Field Entry
    if $fefieldeffect == 46
      if !pbTooHigh?(PBStats::DEFENSE)
        if (self.hasWorkingAbility(:SHELLARMOR)) && onactive
          @battle.pbCommonAnimation("StatUp",self,nil)
          pbIncreaseStatBasic(PBStats::DEFENSE,1)
          @battle.pbDisplay(_INTL("The shells in the sand boosted {1}'s Defense!",pbThis,PBAbilities.getName(ability)))
        end
      end
      if !pbTooHigh?(PBStats::SPDEF)
        if (self.hasWorkingAbility(:SHELLARMOR)) && onactive
          @battle.pbCommonAnimation("StatUp",self,nil)
          pbIncreaseStatBasic(PBStats::SPDEF,1)
          @battle.pbDisplay(_INTL("The shells in the sand boosted {1}'s Special Defense!",pbThis,PBAbilities.getName(ability)))
        end
      end
    end
    if self.hasWorkingAbility(:PLUS) && onactive
      self.pbOwnSide.effects[PBEffects::PlusSignal]=3
      @battle.pbDisplay(_INTL("{1} charged up Plus energy for its side!",pbThis))
    end
    if self.hasWorkingAbility(:MINUS) && onactive
      self.pbOwnSide.effects[PBEffects::MinusSignal]=3
      @battle.pbDisplay(_INTL("{1} charged up Minus energy for its side!",pbThis))
    end
    if self.hasWorkingAbility(:UNNERVE) && onactive
      if @battle.pbOwnedByPlayer?(@index)
        @battle.pbDisplay(_INTL("The opposing team is too nervous to eat berries!",pbThis))
      elsif !@battle.pbOwnedByPlayer?(@index)
        @battle.pbDisplay(_INTL("Your team is too nervous to eat berries!",pbThis))
      end
    end
    # Imposter
    if self.hasWorkingAbility(:IMPOSTER) && !@effects[PBEffects::Transform] &&
      onactive && !opposingLivingBattlers.empty? # !@effects[PBEffects::Illusion]
      choice=pbPreferredOpposingTarget(pbOppositeOpposing)
      blacklist=[
        0xC9,    # Fly
        0xCA,    # Dig
        0xCB,    # Dive
        0xCC,    # Bounce
        0xCD,    # Shadow Force
        0xCE     # Sky Drop
      ]
      if choice.effects[PBEffects::Substitute]>0 ||
        choice.effects[PBEffects::Transform] ||
        choice.effects[PBEffects::SkyDrop] ||
        blacklist.include?(PBMoveData.new(choice.effects[PBEffects::TwoTurnAttack]).function)
        # Can't transform into chosen PokÃ©mon, so forget it
      else
        @battle.pbAnimation(getConst(PBMoves,:TRANSFORM),self,choice)
        @effects[PBEffects::Transform]=true
        @species=choice.species
        @type1=choice.type1
        @type2=choice.type2
        @ability=choice.ability
        irregularcopy=choice.clone
        totalev=0
        for k in 0...6
          totalev+=choice.ev[k]
        end
        if totalev>510
          ev1=0
          ev2=0
          count=0
          for i in choice.ev
            if i==choice.ev.max
              ev1=count
            elsif i==choice.ev.max_nth(2)
              ev2=count
            end
            count+=1
          end
          stat1=choice.ev.max
          stat2=choice.ev.max_nth(2)
          for i in 1...6
            irregularcopy.ev[i]=0
          end
          if stat1>252
            irregularcopy.ev[ev1]=252
          else
            irregularcopy.ev[ev1]=stat1
          end
          if stat2>252
            irregularcopy.ev[ev2]=252
          else
            irregularcopy.ev[ev2]=stat2
          end
        else
          for i in 1...6
            if irregularcopy.ev[i]>252
              irregularcopy.ev[i]=252
            end
          end
        end
        irregularcopy.pbUpdate(true)
        @attack=irregularcopy.attack
        @defense=irregularcopy.defense
        @speed=irregularcopy.speed
        @spatk=irregularcopy.spatk
        @spdef=irregularcopy.spdef
        for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
            PBStats::SPATK,PBStats::SPDEF,PBStats::EVASION,PBStats::ACCURACY]
          @stages[i]=choice.stages[i]
        end
        for i in 0...4
          @moves[i]=PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(choice.moves[i].id),self)
          @moves[i].pp=5
          @moves[i].totalpp=5
        end
        @effects[PBEffects::Disable]=0
        @effects[PBEffects::DisableMove]=0
        @battle.pbDisplay(_INTL("{1} transformed into {2}!",pbThis,choice.pbThis(true)))
      end
    end
    ensure
      @battle.statChangeSource=nil if @battle
    end
  end
  def pbDefensiveDamageAbilities(move,user,damage,previous_hp)
    return if damage<0 || user==self || damagestate.substitute || moldbroken
    if (damage>0 && hasWorkingAbility(:ELECTROMORPHOSIS)) ||
       ((damage>0 || move.basedamage==0) && hasWorkingAbility(:WINDPOWER) && PBStuff::WINDMOVE.include?(move.id))
      pbChargeFromAbility
    end
    return if damage<=0
    if hasWorkingAbility(:ANGERSHELL) && previous_hp*2>totalhp && hp*2<=totalhp
      @battle.pbDisplay(_INTL("{1}'s {2} was triggered!",pbThis,PBAbilities.getName(ability)))
      @battle.pbWithStatChangeSource([:ability,ability]) do
        [PBStats::DEFENSE,PBStats::SPDEF].each { |stat| pbReduceStat(stat,1,false,nil,self,true,true) }
        [PBStats::ATTACK,PBStats::SPATK,PBStats::SPEED].each { |stat| pbIncreaseStat(stat,1,false,nil,self) }
      end
    end
    if hasWorkingAbility(:TOXICDEBRIS,true) && pbOpposingSide.effects[PBEffects::ToxicSpikes]<2
      pbOpposingSide.effects[PBEffects::ToxicSpikes]+=1
      @battle.pbDisplay(_INTL("{1}'s {2} scattered Toxic Spikes on the opposing side!",pbThis,PBAbilities.getName(ability)))
    end
  end

  def pbEffectsOnDealingDamage(move,user,target,damage,innards,previous_hp=target.hp+target.damagestate.hplost)
    movetype=move.pbType(move.type,user,target)
    target.pbDefensiveDamageAbilities(move,user,damage,previous_hp)
    if damage>0 && user!=target && !target.damagestate.substitute &&
       !user.isFainted? && !user.hasWorkingAbility(:MAGICGUARD) &&
       !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
      stance=target.effects[PBEffects::CounterStance]>0 && move.pbIsPhysical?(movetype)
      coat=target.effects[PBEffects::MirrorCoatBuff]>0 && move.pbIsSpecial?(movetype)
      if stance || coat
        @battle.scene.pbDamageAnimation(user,0)
        user.pbReduceHP([damage/4,1].max)
        @battle.pbDisplay(stance ? _INTL("{1}'s stance countered the attack!",target.pbThis) :
                                  _INTL("{1}'s Mirror Coat reflected some damage!",target.pbThis))
      end
    end
    if damage>0 && !target.damagestate.substitute && target.pbIsOpposing?(user.index) &&
       target.hasWorkingAbility(:CUTECHARM) && !target.moldbroken &&
       user.pbCanAttract?(target,false)
      user.effects[PBEffects::Attract]=target.index
      user.effects[PBEffects::AttractTurns]=3 #pk code
      @battle.pbDisplay(_INTL("{1}'s {2} enchanted {3}!",target.pbThis, #pk code
          PBAbilities.getName(target.ability),user.pbThis(true)))
      if user.hasWorkingItem(:DESTINYKNOT) && target.pbCanAttract?(user,false)
        target.effects[PBEffects::Attract]=user.index
        target.effects[PBEffects::AttractTurns]=3 #pk code
        @battle.pbDisplay(_INTL("{1}'s {2} enchanted {3}!",user.pbThis, #pk code
            PBItems.getName(user.item),target.pbThis(true)))
      end
    end
    if damage>0 && !target.damagestate.substitute &&
      target.hasWorkingAbility(:WONDERSKIN,true) && !target.moldbroken && move.pbIsSpecial?(movetype) &&
      !user.isFainted? && !user.hasWorkingAbility(:MAGICGUARD) &&
      !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
      @battle.scene.pbDamageAnimation(user,0)
      user.pbReduceHP([1,user.totalhp/8].max)
      @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!",target.pbThis,
          PBAbilities.getName(target.ability),user.pbThis(true)))
    end
    if damage>0 && !target.damagestate.substitute && target.pbIsOpposing?(user.index) &&
       target.hasWorkingAbility(:PICKPOCKET) && !target.moldbroken &&
       target.item==0 && user.item>0 && !user.hasWorkingAbility(:STICKYHOLD,true) &&
       !@battle.pbIsUnlosableItem(user,user.item) && !@battle.pbIsUnlosableItem(target,user.item) &&
       (@battle.opponent || !@battle.pbIsOpposing?(target.index))
      user.pbSwapHeldItems(target)
      user.effects[PBEffects::ChoiceBand]=-1
      if @battle.pbIsWild? && target.pokemon.itemInitial==0 &&
         user.pokemon.itemInitial==target.item
        target.pokemon.itemInitial=target.item
        user.pokemon.itemInitial=0
      end
      @battle.pbDisplay(_INTL("{1} pickpocketed {2}'s {3}!",target.pbThis,
          user.pbThis(true),PBItems.getName(target.item)))
      @battle.statChangeSource=[:ability,target.ability]
      target.pbIncreaseStat(PBStats::SPEED,2,true)
      @battle.statChangeSource=nil
    end
    if damage>0 && move.isContactMove? && !user.hasWorkingAbility(:LONGREACH) &&
      !(user.hasWorkingItem(:PROTECTIVEPADS) || target.hasWorkingItem(:PROTECTIVEPADS))
      if !target.damagestate.substitute
        if target.hasWorkingItem(:STICKYBARB,true) && user.item==0 && !user.isFainted?
          user.pbSwapHeldItems(target)
          if !@battle.opponent && !@battle.pbIsOpposing?(user.index)
            if user.pokemon.itemInitial==0 && target.pokemon.itemInitial==user.item
              user.pokemon.itemInitial=user.item
              target.pokemon.itemInitial=0
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} was transferred to {3}!",
              target.pbThis,PBItems.getName(user.item),user.pbThis(true)))
        end
        if target.hasWorkingItem(:ROCKYHELMET,true) && !user.isFainted? &&
          !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          @battle.scene.pbDamageAnimation(user,0)
          user.pbReduceHP((user.totalhp/6).floor)
          @battle.pbDisplay(_INTL("{1} was hurt by the {2}!",user.pbThis,
              PBItems.getName(target.item)))
        end
        if target.effects[PBEffects::BeakBlast] && user.pbCanBurn?(false) &&
          !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1} was burned by the heat!",user.pbThis))
        end
        if target.hasWorkingAbility(:AFTERMATH,true) && !user.isFainted? &&
          target.hp <= 0 && !@battle.pbCheckGlobalAbility(:DAMP)  &&
          !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          PBDebug.log("[#{user.pbThis} hurt by Aftermath]")
          @battle.scene.pbDamageAnimation(user,0)
          #### AME - 006 - START
          if $fefieldeffect == 11
            user.pbReduceHP((user.totalhp/2).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the toxic aftermath!",user.pbThis))
          else
            user.pbReduceHP((user.totalhp/4).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the aftermath!",user.pbThis))
          end
          #### AME - 006 - END
        end
        if target.hasWorkingAbility(:IRONBARBS,true) && !user.isFainted? &&
          !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          @battle.scene.pbDamageAnimation(user,0)
          user.pbReduceHP((user.totalhp/8).floor)
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!",target.pbThis,
              PBAbilities.getName(target.ability),user.pbThis(true)))
        end
        if (target.hasWorkingAbility(:MUMMY,true) || @battle.SilvallyCheck(target,PBTypes::GHOST)) && !user.isFainted?
          if !isConst?(user.ability,PBAbilities,:MULTITYPE) && !((PBStuff::FIXEDABILITIES).include?(user.ability))
            user.ability=getConst(PBAbilities,:MUMMY) || 0
            @battle.pbDisplay(_INTL("{1} was mummified by {2}!",
                user.pbThis,target.pbThis(true)))
          end
        end
        if target.hasWorkingAbility(:WANDERINGSPIRIT,true) && !user.isFainted?
          if !isConst?(user.ability,PBAbilities,:WANDERINGSPIRIT) && !((PBStuff::FIXEDABILITIES).include?(user.ability))
            tmp=user.ability
            user.ability=target.ability
            target.ability=tmp
            @battle.pbDisplay(_INTL("{1} swapped its {2} Ability with its target!",
                target.pbThis,PBAbilities.getName(target.ability)))
            user.pbAbilitiesOnSwitchIn(true)
            target.pbAbilitiesOnSwitchIn(true)
          end
        end
        if target.hasWorkingAbility(:GOOEY)
          @battle.statChangeSource=[:ability,target.ability]
          if user.hasWorkingAbility(:CONTRARY)
            if $fefieldeffect == 8 || $fefieldeffect == 26
              user.pbReduceStat(PBStats::SPEED,2,false,nil,nil,true,false,false,false)
              @battle.pbDisplay(_INTL("{1}'s {2} sharply boosted {3}'s Speed!",target.pbThis,PBAbilities.getName(target.ability),user.pbThis(true)))
            else
              user.pbReduceStat(PBStats::SPEED,1,false,nil,nil,true,false,false,false)
              @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!",target.pbThis,PBAbilities.getName(target.ability),user.pbThis(true)))
            end
          elsif user.hasWorkingAbility(:WHITESMOKE) || user.hasWorkingAbility(:CLEARBODY) ||
            user.hasWorkingAbility(:FULLMETALBODY) || user.hasWorkingAbility(:TEMPORALSHIFT)
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",user.pbThis,PBAbilities.getName(user.ability)))
          elsif $fefieldeffect == 8 || $fefieldeffect == 26
            user.pbReduceStat(PBStats::SPEED,2,false,nil,nil,true,false,false,false)
            @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered {3}'s Speed!",target.pbThis,PBAbilities.getName(target.ability),user.pbThis(true)))
          else
            user.pbReduceStat(PBStats::SPEED,1,false,nil,nil,true,false,false,false)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!",target.pbThis,PBAbilities.getName(target.ability),user.pbThis(true)))
          end
          @battle.statChangeSource=nil
          if $fefieldeffect ==19 && user.pbCanPoison?(false)
            user.pbPoison(target)
            @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!",target.pbThis,
                PBAbilities.getName(target.ability),user.pbThis(true)))
          end
        end
        if target.hasWorkingAbility(:TANGLINGHAIR)
          @battle.statChangeSource=[:ability,target.ability]
          if user.hasWorkingAbility(:CONTRARY)
            user.pbReduceStat(PBStats::SPEED,1,false,nil,nil,true,false,false,false)
            @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!",target.pbThis,PBAbilities.getName(target.ability),user.pbThis(true)))
          elsif user.hasWorkingAbility(:WHITESMOKE) || user.hasWorkingAbility(:CLEARBODY) ||
            user.hasWorkingAbility(:FULLMETALBODY) || user.hasWorkingAbility(:TEMPORALSHIFT)
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",user.pbThis,PBAbilities.getName(user.ability)))
          else
            user.pbReduceStat(PBStats::SPEED,1,false,nil,nil,true,false,false,false)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!",target.pbThis,PBAbilities.getName(target.ability),user.pbThis(true)))
          end
          @battle.statChangeSource=nil
        end
        if target.hasWorkingAbility(:POISONPOINT,true) && user.pbCanPoison?(false)
          user.pbPoison(target)
          @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!",target.pbThis, PBAbilities.getName(target.ability),user.pbThis(true)))
        end
        if target.hasWorkingAbility(:ROUGHSKIN,true) && !user.isFainted? && !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          @battle.scene.pbDamageAnimation(user,0)
          user.pbReduceHP((user.totalhp/8).floor)
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!",target.pbThis,
              PBAbilities.getName(target.ability),user.pbThis(true)))
        end
        if target.hasWorkingAbility(:STICKYHOLD) && !target.moldbroken &&
          target.pbIsOpposing?(user.index) && !user.isFainted? && user.effects[PBEffects::MeanLook]<0
          user.effects[PBEffects::MeanLook]=target.index
          @battle.pbDisplay(_INTL("{1}'s {2} trapped {3}!",target.pbThis,
              PBAbilities.getName(target.ability),user.pbThis(true)))
        end
      end
      if user.hasWorkingAbility(:STICKYHOLD) && user.pbIsOpposing?(target.index) &&
         !target.isFainted? && !target.damagestate.substitute && target.effects[PBEffects::MeanLook]<0
        target.effects[PBEffects::MeanLook]=user.index
        @battle.pbDisplay(_INTL("{1}'s {2} trapped {3}!",user.pbThis,
            PBAbilities.getName(user.ability),target.pbThis(true)))
      end
      if user.hasWorkingAbility(:STENCH) && !target.isFainted? &&
         !target.damagestate.substitute && !target.effects[PBEffects::StenchUsed].include?(user.pokemon.object_id)
        target.effects[PBEffects::StenchUsed].push(user.pokemon.object_id)
        if (!target.hasWorkingAbility(:INNERFOCUS) && !target.hasWorkingAbility(:SHIELDDUST)) ||
           target.moldbroken
          target.effects[PBEffects::Flinch]=true
        end
      end
      if user.hasWorkingAbility(:POISONPOINT,true) && target.pbCanPoison?(false)
        target.pbPoison(user)
        @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!",user.pbThis,
            PBAbilities.getName(user.ability),target.pbThis(true)))
      end
      if user.hasWorkingAbility(:COTTONMOLT,true)
        @battle.pbDisplay(_INTL("{1}'s {2} scatters cotton around!",
            target.pbThis,PBAbilities.getName(target.ability)))
        for i in @battle.battlers
          next if i==target
          if i.pbCanReduceStatStage?(PBStats::SPEED)
            boost = 1
            if ($fefieldeffect == 2)
              boost = 2
            end
            i.pbReduceStat(PBStats::SPEED,boost,false)
          end
        end
      end
      if target.hasWorkingAbility(:PERISHBODY,true) && !$fefieldeffect==29 &&
        user.effects[PBEffects::PerishSong]==0 && target.effects[PBEffects::PerishSong]==0
        @battle.pbDisplay(_INTL("Both Pokémon will faint in three turns!"))
        if $fefieldeffect == 45
          user.effects[PBEffects::PerishSong]=2
          target.effects[PBEffects::PerishSong]=2
        else
          user.effects[PBEffects::PerishSong]=4
          target.effects[PBEffects::PerishSong]=4
        end
        if $fefieldeffect == 38 || $fefieldeffect == 40 || $fefieldeffect == 45
          target.effects[PBEffects::MeanLook]=user.index
          @battle.pbDisplay(_INTL("{1} can't escape now!",target.pbThis))
        end
      end
    end
    if damage>0
      if !target.damagestate.substitute && user.hasWorkingAbility(:ERRATIC,true) &&
         target.pbCanConfuse?(false)
        target.effects[PBEffects::Confusion]=3 #pk code
        @battle.pbCommonAnimation("Confusion",target,nil)
        @battle.pbDisplay(_INTL("{1}'s {2} confused {3}!",user.pbThis,
            PBAbilities.getName(user.ability),target.pbThis(true)))
      end
      if target.effects[PBEffects::ShellTrap] && move.pbIsPhysical?(movetype)
        target.effects[PBEffects::ShellTrap]=false
      end
      if target.hasWorkingAbility(:INNARDSOUT,true) && !user.isFainted? &&
        target.hp <= 0 && !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        PBDebug.log("[#{user.pbThis} hurt by Innards Out]")
        @battle.scene.pbDamageAnimation(user,0)
        user.pbReduceHP(innards)
        @battle.pbDisplay(_INTL("{1} was hurt by {2}'s innards!",user.pbThis,target.pbThis))
      end
      if (user.hasWorkingAbility(:MOXIE) || @battle.SilvallyCheck(user, PBTypes::FIRE)) &&
        user.hp>0 && target.hp<=0
        if !user.pbTooHigh?(PBStats::ATTACK)
          @battle.pbCommonAnimation("StatUp",self,nil)
          user.pbIncreaseStatBasic(PBStats::ATTACK,1)
          @battle.pbDisplay(_INTL("{1}'s Moxie raised its Attack!",user.pbThis))
        end
      end
      if user.hasWorkingAbility(:EXECUTION) &&
        user.hp>0 && target.hp<=0
        hpgain=(damage/8).floor
        hpgain=user.pbRecoverHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1}'s Execution healed some of its wounds!",user.pbThis))
      end
      if user.hasWorkingAbility(:SCAVENGER) &&
        user.hp>0 && target.hp<=0 && target.pbIsOpposing?(user.index) &&
        user.effects[PBEffects::HealBlock]==0
        hpgain=(user.totalhp/4).floor
        hpgain=user.pbRecoverHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1}'s Scavenger restored its HP!",user.pbThis)) if hpgain>0
      end
      if user.hasWorkingAbility(:BEASTBOOST) && user.hp>0 && target.hp<=0
        @battle.statChangeSource=[:ability,user.ability]
        increment = 1
        increment = 2 if $fefieldeffect == 38
        aBoost = user.attack
        dBoost = user.defense
        saBoost = user.spatk
        sdBoost = user.spdef
        spdBoost = user.speed
        boostStat = [aBoost,dBoost,saBoost,sdBoost,spdBoost].max
        case boostStat
        when aBoost
          if !user.pbTooHigh?(PBStats::ATTACK)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::ATTACK,increment)
            @battle.pbDisplay(_INTL("{1}'s Beast Boost raised its Attack!",user.pbThis))
          end
        when dBoost
          if !user.pbTooHigh?(PBStats::DEFENSE)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::DEFENSE,increment)
            @battle.pbDisplay(_INTL("{1}'s Beast Boost raised its Defense!",user.pbThis))
          end
        when saBoost
          if !user.pbTooHigh?(PBStats::SPATK)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::SPATK,increment)
            @battle.pbDisplay(_INTL("{1}'s Beast Boost raised its Special Attack!",user.pbThis))
          end
        when sdBoost
          if !user.pbTooHigh?(PBStats::SPDEF)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::SPDEF,increment)
            @battle.pbDisplay(_INTL("{1}'s Beast Boost raised its Special Defense!",user.pbThis))
          end
        when spdBoost
          if !user.pbTooHigh?(PBStats::SPEED)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::SPEED,increment)
            @battle.pbDisplay(_INTL("{1}'s Beast Boost raised its Speed!",user.pbThis))
          end
        end
        @battle.statChangeSource=nil
      end
      if $fefieldeffect == 44 && user.hp>0 && target.hp<=0
        increment=1 #pk code
        aBoost = target.attack
        dBoost = target.defense
        saBoost = target.spatk
        sdBoost = target.spdef
        spdBoost = target.speed
        boostStat = [aBoost,dBoost,saBoost,sdBoost,spdBoost].max
        case boostStat
        when aBoost
          if !user.pbTooHigh?(PBStats::ATTACK)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::ATTACK,increment)
            @battle.pbDisplay(_INTL("The cheering audience raised {1}'s Attack!",user.pbThis))
          end
        when dBoost
          if !user.pbTooHigh?(PBStats::DEFENSE)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::DEFENSE,increment)
            @battle.pbDisplay(_INTL("The cheering audience raised {1}'s Defense!",user.pbThis))
          end
        when saBoost
          if !user.pbTooHigh?(PBStats::SPATK)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::SPATK,increment)
            @battle.pbDisplay(_INTL("The cheering audience raised {1}'s Special Attack!",user.pbThis))
          end
        when sdBoost
          if !user.pbTooHigh?(PBStats::SPDEF)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::SPDEF,increment)
            @battle.pbDisplay(_INTL("The cheering audience raised {1}'s Special Defense!",user.pbThis))
          end
        when spdBoost
          if !user.pbTooHigh?(PBStats::SPEED)
            @battle.pbCommonAnimation("StatUp",self,nil)
            user.pbIncreaseStatBasic(PBStats::SPEED,increment)
            @battle.pbDisplay(_INTL("The cheering audience raised {1}'s Speed!",user.pbThis))
          end
        end
      end
      if !target.damagestate.substitute
        if target.hasWorkingAbility(:GULPMISSILE,true) && isConst?(target.species, PBSpecies, :CRAMORANT) && !user.isFainted? &&
          !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) && target.form!=0
          @battle.scene.pbDamageAnimation(user,0)
          user.pbReduceHP((user.totalhp/4).floor)
          if target.form==1 # Gulping Form
            if user.pbCanReduceStatStage?(PBStats::DEFENSE,false,true)

              @battle.statChangeSource=[:ability,target.ability]
              user.pbReduceStatBasic(PBStats::DEFENSE,1)
@battle.statChangeSource=nil
              @battle.pbCommonAnimation("StatDown",target,nil)
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!",
                  target.pbThis,PBAbilities.getName(target.ability)))
            end
          elsif target.form==2 # Gorging Form
            if user.pbCanParalyze?(false)
              user.pbParalyze(target)
              @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}!", #pk code
                  target.pbThis,PBAbilities.getName(target.ability),user.pbThis(true)))
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!",target.pbThis,
              PBAbilities.getName(target.ability),user.pbThis(true)))
          target.form = 0
          transformed = true
          target.pbUpdate(false)
          @battle.scene.pbChangePokemon(target,target.pokemon)
          @battle.pbDisplay(_INTL("{1} returned to normal!",target.pbThis))
        end
        if isConst?(target.species,PBSpecies,:BEHEEYEM) && target.hasWorkingItem(:BEHECREST,true)
          if user.effects[PBEffects::Disable]<=0 && move.pp>0 && !user.isFainted?
            user.effects[PBEffects::Disable]=4
            user.effects[PBEffects::DisableMove]=move.id
            @battle.pbDisplay(_INTL("{1}'s {2} disabled {3}!",target.pbThis,
                PBItems.getName(target.item),user.pbThis(true)))
          end
        end
        # Illusion goes here
        #### JERICHO - 001 - START
        if isConst?(target.ability,PBAbilities,:ILLUSION) #ILLUSION
          if target.effects[PBEffects::Illusion]!=nil
            # Break the illusion
            # Animation should go here
            target.effects[PBEffects::Illusion]=nil
            @battle.scene.pbChangePokemon(target,target.pokemon)
            @battle.pbDisplay(_INTL("{1}'s {2} was broken!",target.pbThis,
                PBAbilities.getName(target.ability)))
          end
        end #ILLUSION
        #### JERICHO - 001 - END
        if user.hasWorkingAbility(:MAGICIAN) && target.pbIsOpposing?(user.index) &&
          target.damagestate.calcdamage>0 && !target.damagestate.substitute && target.item!=0 &&
          user.item==0 && (@battle.opponent || !@battle.pbIsOpposing?(user.index))
          if target.hasWorkingAbility(:STICKYHOLD,true) && !target.moldbroken
            abilityname=PBAbilities.getName(target.ability)
            @battle.pbDisplay(_INTL("{1}'s {2} prevented item theft!",target.pbThis,abilityname))
          elsif !@battle.pbIsUnlosableItem(target,target.item) &&
                !@battle.pbIsUnlosableItem(user,target.item)
            itemname=PBItems.getName(target.item)
            user.pbSwapHeldItems(target)
            target.effects[PBEffects::ChoiceBand]=-1
            if @battle.pbIsWild? && # In a wild battle
              user.pokemon.itemInitial==0 &&
              target.pokemon.itemInitial==user.item
              user.pokemon.itemInitial=user.item
              target.pokemon.itemInitial=0
            end
            @battle.pbDisplay(_INTL("{1} stole {2}'s {3}!",user.pbThis,target.pbThis(true),itemname))
          end
        end
        if target.hasWorkingAbility(:RATTLED) &&
          (isConst?(movetype,PBTypes,:BUG) ||
            isConst?(movetype,PBTypes,:DARK) ||
            isConst?(movetype,PBTypes,:GHOST))
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)

            @battle.statChangeSource=[:ability,target.ability]
            target.pbIncreaseStatBasic(PBStats::SPEED,1)
@battle.statChangeSource=nil
            @battle.pbCommonAnimation("StatUp",target,nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its speed!",
                target.pbThis,PBAbilities.getName(target.ability)))
          end
        end
        if target.hasWorkingAbility(:WEAKARMOR) && move.pbIsPhysical?(movetype)

          @battle.statChangeSource=[:ability,target.ability]
          if target.pbCanReduceStatStage?(PBStats::DEFENSE,false,true)
            target.pbReduceStatBasic(PBStats::DEFENSE,1)
            @battle.pbCommonAnimation("StatDown",target,nil)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!",
                target.pbThis,PBAbilities.getName(target.ability)))
          end
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED,2)
            @battle.pbCommonAnimation("StatUp",target,nil)
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Speed!",
                target.pbThis,PBAbilities.getName(target.ability)))
          end
@battle.statChangeSource=nil
        end
        if target.hasWorkingAbility(:STAMINA)
          if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
            @battle.statChangeSource=[:ability,target.ability]
            target.pbIncreaseStatBasic(PBStats::DEFENSE,1)
            @battle.statChangeSource=nil
            target.pbDisplayStatCapMessages
            @battle.pbCommonAnimation("StatUp",target,nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!",
                target.pbThis,PBAbilities.getName(target.ability)))
          end
        end
        if target.hasWorkingAbility(:WATERCOMPACTION) && isConst?(movetype,PBTypes,:WATER)

          @battle.statChangeSource=[:ability,target.ability]
          if ($fefieldeffect!=20 && $fefieldeffect != 46)
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE,2)
              @battle.pbCommonAnimation("StatUp",target,nil)
              @battle.pbDisplay(_INTL("{1}'s Water Compaction sharply raised its Defense!",
                  target.pbThis,PBAbilities.getName(target.ability)))
            end
          else
            boost = false
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE,2)
              @battle.pbCommonAnimation("StatUp",target,nil) if !boost
              #@battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Defense!",
              #target.pbThis,PBAbilities.getName(target.ability)))
              boost = true
            end
            if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
              target.pbIncreaseStatBasic(PBStats::SPDEF,2)
              @battle.pbCommonAnimation("StatUp",target,nil) if !boost
              #@battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Defense!",
              #target.pbThis,PBAbilities.getName(target.ability)))
              boost = true
            end
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Defense and Special Defense!",
                target.pbThis,PBAbilities.getName(target.ability))) if boost
          end
@battle.statChangeSource=nil
        end
      end
      # Steam Engine
      if target.hasWorkingAbility(:STEAMENGINE) &&
        (isConst?(movetype,PBTypes,:WATER) || isConst?(movetype,PBTypes,:FIRE))
        if target.pbCanIncreaseStatStage?(PBStats::SPEED)

          @battle.statChangeSource=[:ability,target.ability]
          target.pbIncreaseStatBasic(PBStats::SPEED,6)
@battle.statChangeSource=nil
          @battle.pbCommonAnimation("StatUp",target,nil)
          @battle.pbDisplay(_INTL("{1}'s {2} drastically raised its Speed!",
              target.pbThis,PBAbilities.getName(target.ability)))
        end
      end
      # Cotton Down
      if target.hasWorkingAbility(:COTTONDOWN,true)
        @battle.pbDisplay(_INTL("{1}'s {2} scatters cotton around!",
            target.pbThis,PBAbilities.getName(target.ability)))
        for i in @battle.battlers
          next if i==target
          if i.pbCanReduceStatStage?(PBStats::SPEED)
            boost = 1
            if ($fefieldeffect == 2)
              boost = 2
            end
            i.pbReduceStat(PBStats::SPEED,boost,false)
          end
        end
      end
      # Sand Spit
      if target.hasWorkingAbility(:SANDSPIT)
        if !(@battle.field.effects[PBEffects::HeavyRain] || @battle.field.effects[PBEffects::HarshSunlight] ||
            @battle.weather==PBWeather::STRONGWINDS || @battle.weather==PBWeather::SANDSTORM ||
            $fefieldeffect==35)
          @battle.pbAnimation(getConst(PBMoves,:SANDSTORM),self,nil)
          @battle.weather=PBWeather::SANDSTORM
          @battle.weatherduration=5
          @battle.weatherduration=8 if (target.hasWorkingItem(:SMOOTHROCK) ||
            $fefieldeffect == 12 || $fefieldeffect == 20 || $fefieldeffect == 43)
          @battle.pbCommonAnimation("Sandstorm",nil,nil)
          @battle.pbDisplay(_INTL("A sandstorm brewed!"))
        end
        if ($fefieldeffect == 12 || $fefieldeffect == 20 || $fefieldeffect == 46) && user.pbCanReduceStatStage?(PBStats::ACCURACY)

          @battle.statChangeSource=[:ability,target.ability]
          user.pbReduceStatBasic(PBStats::ACCURACY,1)
@battle.statChangeSource=nil
          @battle.pbCommonAnimation("StatDown",user,nil)
          @battle.pbDisplay(_INTL("{1}'s accuracy fell!",user.pbThis))
        end
      end
      if !target.damagestate.substitute && target.hasWorkingItem(:AIRBALLOON,true)
        @battle.pbDisplay(_INTL("{1}'s Air Balloon popped!",target.pbThis))
        target.pbUseConsumableHeldItem
      end
      if !target.damagestate.substitute
        [[:ABSORBBULB,PBTypes::WATER,PBStats::SPATK],
         [:CELLBATTERY,PBTypes::ELECTRIC,PBStats::ATTACK],
         [:SNOWBALL,PBTypes::ICE,PBStats::ATTACK],
         [:LUMINOUSMOSS,PBTypes::WATER,PBStats::SPDEF]].each do |item,type,stat|
          target.pbUseHitStatItem(item,[stat]) if movetype==type
        end
        if move.pbIsPhysical?(movetype)
          target.pbUseHitStatItem(:KEEBERRY,[PBStats::DEFENSE])
          target.pbUseHitDamageBerry(:JABOCABERRY,user)
        elsif move.pbIsSpecial?(movetype)
          target.pbUseHitStatItem(:MARANGABERRY,[PBStats::SPDEF])
          target.pbUseHitDamageBerry(:ROWAPBERRY,user)
        end
        if target.damagestate.typemod>4
          target.pbUseHitStatItem(:WEAKNESSPOLICY,[PBStats::ATTACK,PBStats::SPATK],2)
        end
      end
      if target.hasWorkingItem(:REDCARD) && !target.damagestate.substitute && !user.isFainted? &&
        !(@battle.pbIsWild? && (@battle.pbParty(user.index) == @battle.party2))
        party=@battle.pbParty(user.index)
        if party.each_index.any? { |i| @battle.pbCanSwitchLax?(user.index,i,false) }
          @battle.pbDisplay(_INTL("#{target.pbThis}'s Red Card activates!"))
          target.pbUseConsumableHeldItem
          if user.hasWorkingAbility(:SUCTIONCUPS)
            @battle.pbDisplay(_INTL("{1} anchored itself with {2}!",user.pbThis,PBAbilities.getName(user.ability)))
          elsif user.effects[PBEffects::Ingrain]
            @battle.pbDisplay(_INTL("{1} anchored itself with its roots!",user.pbThis))
          else
            user.forcedSwitch = true
          end
        end
      end
      if target.hasWorkingItem(:EJECTBUTTON) && !target.damagestate.substitute
        if !target.isFainted? && @battle.pbCanChooseNonActive?(target.index) &&
          !@battle.pbAllFainted?(@battle.pbParty(target.index))
          @battle.pbDisplay(_INTL("#{target.pbThis}'s Eject Button activates!"))
          target.pbUseConsumableHeldItem
          @battle.pbClearChoices(target.index)
          target.userSwitch = true
        end
      end
    end
    user.pbAbilityCureCheck
    target.pbAbilityCureCheck
    # Synchronize here
    s=@battle.synchronize[0]
    t=@battle.synchronize[1]
    #   PBDebug.log("[synchronize: #{@battle.synchronize.inspect}]")
    if s>=0 && t>=0 && @battle.battlers[s].hasWorkingAbility(:SYNCHRONIZE) &&
      @battle.synchronize[2]>0 && !@battle.battlers[t].isFainted?
      # see [2024281]&0xF0, [202420C]
      sbattler=@battle.battlers[s]
      tbattler=@battle.battlers[t]
      if @battle.synchronize[2]==PBStatuses::POISON &&
        tbattler.pbCanPoisonSynchronize?(sbattler)
        # UPDATE 11/17/2013
        # allows for transfering of `badly poisoned` instead of just poison.
        #changed from: tbattler.pbPoison(sbattler)
        tbattler.pbPoison(sbattler, sbattler.statusCount == 1)
        @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!",sbattler.pbThis,
            PBAbilities.getName(sbattler.ability),tbattler.pbThis(true)))
      elsif @battle.synchronize[2]==PBStatuses::BURN &&
        tbattler.pbCanBurnSynchronize?(sbattler)
        tbattler.pbBurn(sbattler)
        @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!",sbattler.pbThis,
            PBAbilities.getName(sbattler.ability),tbattler.pbThis(true)))
      elsif @battle.synchronize[2]==PBStatuses::PARALYSIS &&
        tbattler.pbCanParalyzeSynchronize?(sbattler)
        tbattler.pbParalyze(sbattler)
        @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}!", #pk code
            sbattler.pbThis,PBAbilities.getName(sbattler.ability),tbattler.pbThis(true)))
      end
    end
  end

  def pbUseHitStatItem(symbol,stats,stages=1)
    return false if !hasWorkingItem(symbol)
    raised=@battle.pbWithStatChangeSource([:item,item]) do
      eligible=stats.select { |stat| pbCanIncreaseStatStage?(stat) }
      eligible.each { |stat| pbIncreaseStatBasic(stat,stages*pbHeldItemDose) }
      !eligible.empty?
    end
    return false unless raised
    @battle.pbCommonAnimation("StatUp",self,nil)
    @battle.pbDisplay(_INTL("{1}'s {2} raised its stats!",pbThis,PBItems.getName(item)))
    $belch=true if pbIsBerry?(item)
    return pbUseConsumableHeldItem
  end

  def pbUseHitDamageBerry(symbol,attacker)
    return false if !hasWorkingItem(symbol,true) || attacker.isFainted?
    return false if attacker.hasWorkingAbility(:MAGICGUARD) ||
      (attacker.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect==44)
    fraction=hasWorkingAbility(:RIPEN,true) ? 4 : 8
    @battle.scene.pbDamageAnimation(attacker,0)
    attacker.pbReduceHP([attacker.totalhp*pbHeldItemDose/fraction,1].max)
    @battle.pbDisplay(_INTL("{1} was hurt by the {2}!",attacker.pbThis,PBItems.getName(item)))
    $belch=true
    return pbUseConsumableHeldItem
  end

  def pbAbilityCureCheck
    return if self.isFainted?
    if self.hasWorkingAbility(:OBLIVIOUS) && @effects[PBEffects::Attract]>=0
      @battle.pbDisplay(_INTL("{1}'s Oblivious broke the enchantment!",pbThis)) #pk code
      pbCureAttract
    end
    if self.hasWorkingAbility(:INSOMNIA) && self.status==PBStatuses::SLEEP
      @battle.pbDisplay(_INTL("{1}'s Insomnia cured its sleep problem!",pbThis))
      self.status=0
    end
    if self.hasWorkingAbility(:PASTELVEIL) && self.status==PBStatuses::POISON
      @battle.pbDisplay(_INTL("{1}'s Pastel Veil cured its poison problem!",pbThis))
      self.status=0
    end
    if self.hasWorkingAbility(:IMMUNITY) && self.status==PBStatuses::POISON
      @battle.pbDisplay(_INTL("{1}'s Immunity cured its poison problem!",pbThis))
      self.status=0
    end
    if self.hasWorkingAbility(:IMMUNITY) && self.status==PBStatuses::PARALYSIS
      @battle.pbDisplay(_INTL("{1}'s Immunity cured its paralysis problem!",pbThis))
      self.status=0
    end
  end

  ################################################################################
  # Held item effects
  ################################################################################
  def pbRecordHarvestBerry(berry)
    return if !@pokemon
    return if !berry || berry<=0
    return if !pbIsBerry?(berry)
    return if !self.hasWorkingAbility(:HARVEST)
    return if @pokemon.harvestBerry && @pokemon.harvestBerry>0
    @pokemon.harvestBerry=berry
  end

  def pbHeldItemDose
    return pbOwnSide.effects[PBEffects::DoubleDose]>0 ? 2 : 1
  end

  def pbConsumableHeldItemRepeat?(symbol,ignorefainted=false)
    return @effects[PBEffects::ConsumableItemDose]==item && pbHeldItemDose>1 &&
           hasWorkingItem(symbol,ignorefainted)
  end

  def pbUseConsumableHeldItem(repeat: false)
    used_item=item
    return false if !@pokemon || !used_item || used_item<=0
    if repeat && pbHeldItemDose>1 && @effects[PBEffects::ConsumableItemDose]!=used_item
      @effects[PBEffects::ConsumableItemDose]=used_item
    else
      pbDiscardConsumableHeldItem
      $belch=true if pbIsBerry?(used_item)
    end
    pbApplyDoubleDosePoison
    return true
  end

  def pbDiscardConsumableHeldItemDose
    return unless @effects && @item && @item>0 && @effects[PBEffects::ConsumableItemDose]==@item
    pbDiscardConsumableHeldItem
  end

  def pbDiscardConsumableHeldItem
    return unless @pokemon && @item && @item>0
    pbRecordHarvestBerry(@item)
    @pokemon.itemRecycle=@item
    @pokemon.itemInitial=0 if @pokemon.itemInitial==@item
    self.item=0
  end

  def pbFinishHeldBerryUse(became_consumed)
    return unless became_consumed && item==0 && hasWorkingAbility(:CHEEKPOUCH) &&
                  @effects[PBEffects::HealBlock]==0
    pbRecoverHP(totalhp/3,true)
    @battle.pbDisplay(_INTL("{1}'s {2} restored health!",pbThis,PBAbilities.getName(ability)))
  end

  def pbRestoreAllMovesPP(amount)
    restored=0
    @moves.each do |move|
      next unless move && move.id>0 && move.pp>=0 && move.pp<move.totalpp
      previous=move.pp
      pbSetPP(move,[previous+amount,move.totalpp].min)
      restored+=move.pp-previous
    end
    return restored
  end

  def pbApplyDoubleDosePoison
    return if pbHeldItemDose==1
    moldbroken_before=moldbroken
    self.moldbroken=false
    if pbCanPoison?(false,true)
      pbPoison(self)
      @battle.pbDisplay(_INTL("{1} was poisoned by the double dose!",pbThis))
    end
  ensure
    self.moldbroken=moldbroken_before unless moldbroken_before.nil?
  end

  def pbConfusionBerry(symbol,flavor,message1,message2)
    if hasWorkingItem(symbol) && @effects[PBEffects::HealBlock]==0 && ((self.hasWorkingAbility(:GLUTTONY) && self.hp<=(self.totalhp/2).floor) || self.hp<=(self.totalhp/4).floor)
      if self.hasWorkingAbility(:RIPEN)
        pbRecoverHP(2*self.totalhp*pbHeldItemDose/3,true)
      else
        pbRecoverHP(self.totalhp*pbHeldItemDose/3,true)
      end
      @battle.pbDisplay(message1)
      if (self.nature%5) == flavor && (self.nature/5).floor != (self.nature%5)
        @battle.pbDisplay(message2)
        if @effects[PBEffects::Confusion]==0
          @effects[PBEffects::Confusion]=3 #pk code
          @battle.pbCommonAnimation("Confusion",self,nil)
          @battle.pbDisplay(_INTL("{1} became confused!",pbThis))
        end
      end
      pbUseConsumableHeldItem
    end
  end

  def pbStatIncreasingBerry(symbol,stat,message)
    if hasWorkingItem(symbol)
      if (self.hasWorkingAbility(:GLUTTONY) && self.hp<=(self.totalhp/2).floor) ||
        self.hp<=(self.totalhp/4).floor
        raised=@battle.pbWithStatChangeSource([:item,item]) do
          next false if !pbCanIncreaseStatStage?(stat)
          pbIncreaseStatBasic(stat,(hasWorkingAbility(:RIPEN) ? 2 : 1)*pbHeldItemDose)
        end
        return if !raised
        @battle.pbCommonAnimation("StatUp",self,nil)
        @battle.pbDisplay(message)
        pbUseConsumableHeldItem
      end
    end
  end

  def pbBerryCureCheck(hpcure=false)
    return if self.isFainted?
    starting_berry=pbIsBerry?(item)
    unnerver=(opposingBattlers.any? { |battler| battler.hasWorkingAbility(:UNNERVE) } ||
      @effects[PBEffects::LeerBlock]>0)
    itemname=(self.item==0) ? "" : PBItems.getName(self.item)
    if self.hasWorkingItem(:BERRYJUICE) && self.hp<=(self.totalhp/2).floor &&
      @effects[PBEffects::HealBlock]==0
      self.pbRecoverHP(20*pbHeldItemDose,true)
      @battle.pbDisplay(_INTL("{1}'s {2} restored health!",pbThis,itemname))
      pbUseConsumableHeldItem
    end
    if !unnerver
      if hasWorkingItem(:COCONBERRY) && pbApplyCoconBerryShield(pbHeldItemDose)
        pbUseConsumableHeldItem
      end
      if self.hasWorkingItem(:ORANBERRY) && self.hp<=(self.totalhp/2).floor &&
        @effects[PBEffects::HealBlock]==0

        if self.hasWorkingAbility(:RIPEN)
          self.pbRecoverHP(20*pbHeldItemDose,true)
        else
          self.pbRecoverHP(10*pbHeldItemDose,true)
        end
        @battle.pbDisplay(_INTL("{1}'s {2} restored health!",pbThis,itemname))
        pbUseConsumableHeldItem
      end
      if self.hasWorkingItem(:SITRUSBERRY) && self.hp<=(self.totalhp/2).floor &&
        @effects[PBEffects::HealBlock]==0

        if self.hasWorkingAbility(:RIPEN)
          self.pbRecoverHP(self.totalhp*pbHeldItemDose/2,true)
        else
          self.pbRecoverHP(self.totalhp*pbHeldItemDose/4,true)
        end
        @battle.pbDisplay(_INTL("{1}'s {2} restored health!",pbThis,itemname))
        pbUseConsumableHeldItem
      end
      #### JERICHO - 014 - START
      if self.hasWorkingItem(:ENIGMABERRY) && self.damagestate.typemod>4 &&
        @effects[PBEffects::HealBlock]==0

        if self.hasWorkingAbility(:RIPEN)
          self.pbRecoverHP(self.totalhp*pbHeldItemDose/2,true)
        else
          self.pbRecoverHP(self.totalhp*pbHeldItemDose/4,true)
        end
        @battle.pbDisplay(_INTL("{1}'s {2} restored health!",pbThis,itemname))
        pbUseConsumableHeldItem
      end
      #### JERICHO - 014 - END
      cures={ CHERIBERRY: PBStatuses::PARALYSIS, CHESTOBERRY: PBStatuses::SLEEP,
              PECHABERRY: PBStatuses::POISON, RAWSTBERRY: PBStatuses::BURN,
              ASPEARBERRY: PBStatuses::FROZEN, LEVIABERRY: PBStatuses::CRUSHED }
      cures.each do |berry,status|
        next unless hasWorkingItem(berry) && self.status==status &&
                    @effects[PBEffects::Spritz]!=1
        pbCureStatus(false)
        @battle.pbDisplay(_INTL("{1}'s {2} cured its status condition!",pbThis,itemname))
        pbUseConsumableHeldItem(repeat: true)
      end
      if self.hasWorkingItem(:LEPPABERRY)

        for i in 0...@pokemon.moves.length
          pokemove=@pokemon.moves[i]
          battlermove=self.moves[i]
          if pokemove.pp==0 && pokemove.id!=0
            movename=PBMoves.getName(pokemove.id)
            pokemove.pp=10*pbHeldItemDose
            pokemove.pp=pokemove.totalpp if pokemove.pp>pokemove.totalpp
            battlermove.pp=pokemove.pp
            @battle.pbDisplay(_INTL("{1}'s {2} restored {3}'s PP!",pbThis,itemname,movename))
            pbUseConsumableHeldItem
            break
          end
        end
      end
      if self.hasWorkingItem(:PERSIMBERRY) && @effects[PBEffects::Confusion]>0

        @effects[PBEffects::Confusion]=0
        @battle.pbDisplay(_INTL("{1}'s {2} cured its confusion problem!",pbThis,itemname))
        pbUseConsumableHeldItem(repeat: true)
      end
      if self.hasWorkingItem(:LUMBERRY) && ((self.status>0 && @effects[PBEffects::Spritz]!=1) || @effects[PBEffects::Confusion]>0)

        st=self.status; conf=@effects[PBEffects::Confusion]
        pbCureStatus(false) if @effects[PBEffects::Spritz]!=1
        @effects[PBEffects::Confusion]=0
        if conf>0
          @battle.pbDisplay(_INTL("{1}'s {2} cured its confusion problem!",pbThis,itemname))
        else
          case st
          when PBStatuses::PARALYSIS
            @battle.pbDisplay(_INTL("{1}'s {2} cured its paralysis problem!",pbThis,itemname))
          when PBStatuses::SLEEP
            @battle.pbDisplay(_INTL("{1}'s {2} cured its sleep problem!",pbThis,itemname))
          when PBStatuses::POISON
            @battle.pbDisplay(_INTL("{1}'s {2} cured its poison problem!",pbThis,itemname))
          when PBStatuses::BURN
            @battle.pbDisplay(_INTL("{1}'s {2} cured its burn problem!",pbThis,itemname))
          when PBStatuses::FROZEN
            @battle.pbDisplay(_INTL("{1}'s {2} cured its frozen problem!",pbThis,itemname))
          end
        end
        pbUseConsumableHeldItem(repeat: true)
      end
      pbConfusionBerry(:FIGYBERRY,0,
        _INTL("{1}'s {2} restored health!",pbThis,itemname),
        _INTL("For {1}, the {2} was too spicy!",pbThis(true),itemname))
      pbConfusionBerry(:WIKIBERRY,3,
        _INTL("{1}'s {2} restored health!",pbThis,itemname),
        _INTL("For {1}, the {2} was too dry!",pbThis(true),itemname))
      pbConfusionBerry(:MAGOBERRY,2,
        _INTL("{1}'s {2} restored health!",pbThis,itemname),
        _INTL("For {1}, the {2} was too sweet!",pbThis(true),itemname))
      pbConfusionBerry(:AGUAVBERRY,4,
        _INTL("{1}'s {2} restored health!",pbThis,itemname),
        _INTL("For {1}, the {2} was too bitter!",pbThis(true),itemname))
      pbConfusionBerry(:IAPAPABERRY,1,
        _INTL("{1}'s {2} restored health!",pbThis,itemname),
        _INTL("For {1}, the {2} was too sour!",pbThis(true),itemname))
      pbStatIncreasingBerry(:LIECHIBERRY,PBStats::ATTACK,
        _INTL("Using its {1}, the Attack of {2} rose!",itemname,pbThis(true)))
      pbStatIncreasingBerry(:GANLONBERRY,PBStats::DEFENSE,
        _INTL("Using its {1}, the Defense of {2} rose!",itemname,pbThis(true)))
      pbStatIncreasingBerry(:SALACBERRY,PBStats::SPEED,
        _INTL("Using its {1}, the Speed of {2} rose!",itemname,pbThis(true)))
      pbStatIncreasingBerry(:PETAYABERRY,PBStats::SPATK,
        _INTL("Using its {1}, the Special Attack of {2} rose!",itemname,pbThis(true)))
      pbStatIncreasingBerry(:APICOTBERRY,PBStats::SPDEF,
        _INTL("Using its {1}, the Special Defense of {2} rose!",itemname,pbThis(true)))
      if self.hasWorkingItem(:LANSATBERRY) && @effects[PBEffects::FocusEnergy]==0

        if (self.hasWorkingAbility(:GLUTTONY) && self.hp<=(self.totalhp/2).floor) ||
          (self.hp<=(self.totalhp/4).floor)
          @battle.pbDisplay(_INTL("{1} used its {2} to get pumped!",pbThis,itemname))
          @effects[PBEffects::FocusEnergy]=2*pbHeldItemDose
          pbUseConsumableHeldItem
        end
      end
      if hasWorkingItem(:STARFBERRY) && hp<=totalhp/(hasWorkingAbility(:GLUTTONY) ? 2 : 4)
        pbUseConsumableHeldItem if pbApplyStarfBerry(pbHeldItemDose)
      end
      pbFinishHeldBerryUse(starting_berry)
    end
    if self.hasWorkingItem(:WHITEHERB)
      reducedstats=false
      for i in [PBStats::ATTACK,PBStats::DEFENSE,
          PBStats::SPEED,PBStats::SPATK,PBStats::SPDEF,
          PBStats::EVASION,PBStats::ACCURACY]
        if @stages[i]<0
          @stages[i]=0; reducedstats=true
        end
      end
      if reducedstats
        @battle.pbDisplay(_INTL("{1}'s {2} restored its status!",pbThis,itemname))
        pbUseConsumableHeldItem(repeat: true)
      end
    end
    if self.hasWorkingItem(:MENTALHERB) &&
      (@effects[PBEffects::Attract]>=0 ||
        @effects[PBEffects::Taunt]>0 ||
        @effects[PBEffects::Encore]>0 ||
        @effects[PBEffects::Torment] ||
        @effects[PBEffects::Disable]>0)
      @battle.pbDisplay(_INTL("{1}'s {2} broke the enchantment!",pbThis,itemname)) if @effects[PBEffects::Attract]>=0 #pk code
      @battle.pbDisplay(_INTL("{1} is taunted no more!",pbThis)) if @effects[PBEffects::Taunt]>0
      @battle.pbDisplay(_INTL("{1}'s encore ended!",pbThis)) if @effects[PBEffects::Encore]>0
      @battle.pbDisplay(_INTL("{1} is tormented no more!",pbThis)) if @effects[PBEffects::Torment]
      @battle.pbDisplay(_INTL("{1} is disabled no more!",pbThis)) if @effects[PBEffects::Disable]>0
      pbCureAttract
      @effects[PBEffects::Taunt]=0
      @effects[PBEffects::Encore]=0
      @effects[PBEffects::EncoreMove]=0
      @effects[PBEffects::EncoreIndex]=0
      @effects[PBEffects::Torment]=false
      @effects[PBEffects::Disable]=0
      pbUseConsumableHeldItem(repeat: true)
    end
    if hpcure && self.hp!=self.totalhp && @effects[PBEffects::HealBlock]==0
      # Check for Unnerve/LeerBlock blocking Leftovers
      unnerver=(opposingBattlers.any? { |battler| battler.hasWorkingAbility(:UNNERVE) } ||
        @effects[PBEffects::LeerBlock]>0)
      if ((isConst?(self.species,PBSpecies,:INFERNAPE) && isConst?(self.item,PBItems,:INFCREST)) || self.hasWorkingItem(:LEFTOVERS)) && !unnerver
        pbRecoverHP((self.totalhp/16).floor,true)
        @battle.pbDisplay(_INTL("{1}'s {2} restored its HP a little!",pbThis,itemname))
      end
    end
    if hpcure && isConst?(self.species,PBSpecies,:SPIRITOMB) && self.hasWorkingItem(:SPIRITCREST) &&
      self.hp!=self.totalhp
      enemyfainted = pbEnemyFaintedPokemonCount
      pbRecoverHP(((self.totalhp*enemyfainted)/20).floor,true)
      @battle.pbDisplay(_INTL("{1}'s {2} restored its HP!",pbThis,itemname))
    end

    if hpcure && self.hasWorkingItem(:BLACKSLUDGE)
      if pbHasType?(:POISON) && @effects[PBEffects::HealBlock]==0
        if self.hp!=self.totalhp
          hpgain = self.totalhp/16
          hpgain = self.totalhp/8 if $fefieldeffect == 41
          pbRecoverHP((hpgain).floor,true)
          @battle.pbDisplay(_INTL("{1}'s {2} restored its HP a little!",pbThis,itemname))
        end
      elsif !self.hasWorkingAbility(:MAGICGUARD) && !(self.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
        hploss = self.totalhp/8
        hploss = self.totalhp/4 if $fefieldeffect == 41
        pbReduceHP((hploss).floor,true)
        @battle.pbDisplay(_INTL("{1} was hurt by its {2}!",pbThis,itemname))
      end
      pbFaint if self.isFainted?
    end
  end

  def pbEatHeldBerry
    return false if !itemWorks? || !pbIsBerry?(item)
    berry=item
    @battle.pbDisplay(_INTL("{1} ate its {2}!",pbThis,PBItems.getName(berry)))
    pbSpecialBerryUse(berry,pbHeldItemDose)
    pbUseConsumableHeldItem
    return true
  end

  def pbApplyStarfBerry(dose)
    @battle.pbWithStatChangeSource([:item,PBItems::STARFBERRY]) do
      stats=[PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,PBStats::SPATK,PBStats::SPDEF].select do |stat|
        pbCanIncreaseStatStage?(stat)
      end
      next false if stats.empty?
      pbIncreaseStat(stats[@battle.pbRandom(stats.length)],2*dose,true)
    end
  end

  def pbSpecialBerryUse(berry,dose=1)
    return if isFainted?
    strength=dose*(hasWorkingAbility(:RIPEN) ? 2 : 1)
    stat=nil
    recovery=0
    itemname=PBItems.getName(berry)
    case berry
    when PBItems::SITRUSBERRY,PBItems::ENIGMABERRY then recovery=totalhp*strength/4
    when PBItems::ORANBERRY then recovery=10*strength
    when PBItems::FIGYBERRY,PBItems::WIKIBERRY,PBItems::MAGOBERRY,PBItems::AGUAVBERRY,PBItems::IAPAPABERRY
      recovery=totalhp*strength/3
      flavor=[0,3,2,4,1][berry-PBItems::FIGYBERRY]
      pbConfuseSelf if nature%5==flavor && nature/5!=flavor
    when PBItems::CHERIBERRY then pbCureStatus if status==PBStatuses::PARALYSIS
    when PBItems::CHESTOBERRY then pbCureStatus if status==PBStatuses::SLEEP
    when PBItems::PECHABERRY then pbCureStatus if status==PBStatuses::POISON
    when PBItems::RAWSTBERRY then pbCureStatus if status==PBStatuses::BURN
    when PBItems::ASPEARBERRY then pbCureStatus if status==PBStatuses::FROZEN
    when PBItems::LEVIABERRY then pbCureStatus if status==PBStatuses::CRUSHED
    when PBItems::PERSIMBERRY
      pbCureConfusion if @effects[PBEffects::Confusion]>0
    when PBItems::LUMBERRY
      pbCureStatus if status>0
      pbCureConfusion if @effects[PBEffects::Confusion]>0
    when PBItems::LEPPABERRY
      known=moves.find { |attack| attack && attack.totalpp>0 && attack.pp<attack.totalpp }
      pbSetPP(known,[known.pp+10*dose,known.totalpp].min) if known
    when PBItems::HOPOBERRY then pbRestoreAllMovesPP(2*dose)
    when PBItems::COCONBERRY then pbApplyCoconBerryShield(dose)
    when PBItems::LIECHIBERRY then stat=PBStats::ATTACK
    when PBItems::GANLONBERRY then stat=PBStats::DEFENSE
    when PBItems::SALACBERRY then stat=PBStats::SPEED
    when PBItems::PETAYABERRY then stat=PBStats::SPATK
    when PBItems::APICOTBERRY then stat=PBStats::SPDEF
    when PBItems::LANSATBERRY
      if @effects[PBEffects::FocusEnergy]==0
        @effects[PBEffects::FocusEnergy]=2*dose
        @battle.pbDisplay(_INTL("{1} is getting pumped!",pbThis))
      end
    when PBItems::STARFBERRY
      pbApplyStarfBerry(dose)
    end
    if recovery>0 && @effects[PBEffects::HealBlock]==0 && pbRecoverHP(recovery,true)>0
      @battle.pbDisplay(_INTL("{1} restored its HP with the {2}!",pbThis,itemname))
    end
    if stat
      @battle.pbWithStatChangeSource([:item,berry]) { pbIncreaseStat(stat,strength,true) }
    end
    pbRecordHarvestBerry(berry)
    $belch=true
    if hasWorkingAbility(:CHEEKPOUCH) && @effects[PBEffects::HealBlock]==0
      pbRecoverHP(totalhp/3,true)
      @battle.pbDisplay(_INTL("{1}'s {2} restored health!",pbThis,PBAbilities.getName(ability)))
    end
  end

  def pbCustapBerry
    @custap=false
    return false unless hasWorkingItem(:CUSTAPBERRY)
    return false if opposingAbilityHolder(:UNNERVE) || @effects[PBEffects::LeerBlock]>0
    return false unless hp<=totalhp/(hasWorkingAbility(:GLUTTONY) ? 2 : 4)
    return false if @battle.choices[index][0]!=1
    @custap=true
    @battle.pbDisplay(_INTL("{1} ate its Custap berry to move first!",pbThis))
    pbUseConsumableHeldItem(repeat: true)
    pbFinishHeldBerryUse(true)
    return true
  end

  def pbUseBlunderPolicy
    return unless missAcc && hasWorkingItem(:BLUNDERPOLICY)
    @battle.pbWithStatChangeSource([:item,item]) do
      pbUseConsumableHeldItem if pbIncreaseStat(PBStats::SPEED,2*pbHeldItemDose,true)
    end
  end

  ################################################################################
  # Move user and targets
  ################################################################################
  def pbFindUser(choice,targets,moveid=choice[2].id)
    move=choice[2]
    if (moveid== 792 && choice[3].class== PokeBattle_Battler)
      target=choice[3].index
    else
      if (moveid== 395 && self.hasWorkingAbility(:ACCUMULATION))
        target=choice[3].index
      elsif !(choice[3].is_a?(Integer))
        target=choice[3].index
      else
        target=choice[3]
      end
    end
    user=self   # Normally, the user is self
    if moveid==PBMoves::PYROCLASM
      ring=@battle.activeBattlerIndices.sort_by do |index|
        side=@battle.pbIsOpposing?(index) ? 1 : 0
        lane=@battle.pbSidePosition(index)
        [side,side==0 ? lane : -lane]
      end
      ring.rotate(ring.index(@index)+1).each do |index|
        battler=@battle.battlers[index]
        targets.push(battler) unless battler.isFainted?
      end
      return user
    end
    if moveid==PBMoves::MINIMIZE
      selected=target>=0 ? @battle.battlers[target] : self
      if selected && (selected==self || pbIsOpposing?(selected.index))
        pbAddTarget(targets,selected,self,move)
      end
      return user
    end
    # Resolve all targets before applying redirection and spread protection.
    if pbFieldSpreadsMove?(move)
      pbAddClosestOpposingTarget(targets,pbOppositeOpposing,move)
      opposingLivingBattlers.each do |battler|
        pbAddTarget(targets,battler,self,move) unless targets.include?(battler)
      end
    else
      case pbTarget(move)
      when PBTargets::SingleNonUser
        if moveid== 395 || target>=0 || moveid== 792
          targetBattler=@battle.battlers[target]
          if targetBattler==self || !pbAddTarget(targets,targetBattler,self,move)
            pbAddClosestOpposingTarget(targets,targetBattler,move)
          end
        else
          pbRandomTarget(targets,move)
        end
      when PBTargets::SingleOpposing
        if target>=0
          targetBattler=@battle.battlers[target]
          if !targetBattler || !pbIsOpposing?(targetBattler.index) ||
             !pbAddTarget(targets,targetBattler,self,move)
            pbAddClosestOpposingTarget(targets,targetBattler,move)
          end
        else
          pbRandomTarget(targets,move)
        end
      when PBTargets::OppositeOpposing
        pbAddClosestOpposingTarget(targets,pbOppositeOpposing,move)
      when PBTargets::RandomOpposing
        pbRandomTarget(targets,move)
      when PBTargets::AllOpposing
        opposingBattlers.each do |battler|
          pbAddTarget(targets,battler,self,move)
        end
      when PBTargets::AllNonUsers
        @battle.eachActiveBattlerIndex do |i|
          pbAddTarget(targets,@battle.battlers[i],self,move) if i!=@index && @battle.battlers[i]
        end
      when PBTargets::DragonDarts
        smartDart = move.pbDragonDartTargetting(user)
        case smartDart.length
        when 1
          pbAddTarget(targets,smartDart[0],self,move)
        when 2
          pbAddTarget(targets,smartDart[0],self,move)
          pbAddTarget(targets,smartDart[1],self,move)
        end
      when PBTargets::ThunderRaid
        randomThunder = move.pbThunderRaidTargetting(user)
        case randomThunder.length
        when 1
          pbAddTarget(targets,randomThunder[0],self,move)
        when 5
          pbAddTarget(targets,randomThunder[0],self,move)
          pbAddTarget(targets,randomThunder[1],self,move)
          pbAddTarget(targets,randomThunder[2],self,move)
          pbAddTarget(targets,randomThunder[3],self,move)
          pbAddTarget(targets,randomThunder[4],self,move)
        end
      when PBTargets::UserOrPartner
        if target>=0 # Pre-chosen target
          targetBattler=@battle.battlers[target]
          pbAddTarget(targets,firstLivingAlly,self,move) if !pbAddTarget(targets,targetBattler,self,move)
        else
          pbAddTarget(targets,self,self,move)
        end
      when PBTargets::Partner
        chosen=@battle.battlers[target] if target>=0
        if !chosen || chosen==self || pbIsOpposing?(chosen.index) ||
           !pbAddTarget(targets,chosen,self,move)
          ally=sameSideLivingBattlers(false).find do |candidate|
            @battle.pbMoveCanTargetInTriple?(self,candidate,move)
          end
          pbAddTarget(targets,ally,self,move)
        end
      else
        if self.hasWorkingItem(:INTERCEPTZ2)
          if choice[1]==1 || choice[1]==3
            if target>=0 || moveid== 792
              targetBattler=@battle.battlers[target]
              if !pbIsOpposing?(targetBattler.index)
                pbAddClosestOpposingTarget(targets,targetBattler,move)
              else
                pbAddClosestOpposingTarget(targets,targetBattler,move) if !pbAddTarget(targets,targetBattler,self,move)
              end
            else
              pbRandomTarget(targets,move)
            end
          else
            move.pbAddTarget(targets,self)
          end
        else
          move.pbAddTarget(targets,self)
        end
      end
    end
    return user
  end

  def pbChangeUser(thismove,user)
    priority=@battle.pbPriority
    # Change user to user of Snatch
    if thismove.canSnatch?
      for i in priority
        if i.effects[PBEffects::Snatch]
          @battle.pbDisplay(_INTL("{1} snatched {2}'s move!",i.pbThis,user.pbThis(true)))
          i.effects[PBEffects::Snatch]=false
          target=user
          user=i
          # Snatch's PP is reduced if old user has Pressure
          userchoice=@battle.choices[user.index][1]
          if target.hasWorkingAbility(:PRESSURE) && userchoice>=0
            pressuremove=user.moves[userchoice]
            pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
          end
        end
      end
    end
    return user
  end

  FIELD_SPREAD_MOVES={
    33=>[PBMoves::PETALDANCE,PBMoves::COTTONSPORE,PBMoves::SLEEPPOWDER,
         PBMoves::SPORE,PBMoves::STUNSPORE,PBMoves::POISONPOWDER,PBMoves::PETALBLIZZARD,PBMoves::POWDER].freeze,
    40=>[PBMoves::FIRESPIN,PBMoves::MEANLOOK,PBMoves::OMINOUSWIND,PBMoves::INFERNO].freeze,
    47=>[PBMoves::FIRESPIN,PBMoves::MEANLOOK,PBMoves::OMINOUSWIND,PBMoves::INFERNO,PBMoves::WHIRLPOOL].freeze
  }.freeze

  def pbFieldSpreadsMove?(move)
    field_moves=FIELD_SPREAD_MOVES[$fefieldeffect]
    return true if field_moves && ($fefieldeffect!=33 || $fecounter==4) && field_moves.include?(move.id)
    return (move.id==PBMoves::NIGHTMARE && hasWorkingAbility(:WORLDOFNIGHTMARES)) ||
      (move.id==PBMoves::WEATHERBALL && hasWorkingAbility(:TEMPEST))
  end

  def pbTarget(move)
    if move && move.id==PBMoves::EXPANDINGFORCE && !isAirborne? && #pk code
       ($fefieldeffect==37 || @battle.field.effects[PBEffects::PsychicTerrain]>0)
      return PBTargets::AllOpposing
    end
    target=move.target
    if move.respond_to?(:pixie_tribute_target)
      target=move.pixie_tribute_target(self)
    end
    target=move.pbRefractingTarget(self) if move.id==PBMoves::REFRACTINGSTRIKE
    target=PBTargets::ThunderRaid if move.id==PBMoves::THUNDERRAID
    target=PBTargets::User if move.id==PBMoves::TOXIC && !pbHasType?(:POISON) &&
      (!move.respond_to?(:pixie_tribute_power) || move.pixie_tribute_power(self)<=0)
    if move.function==0x10D && pbHasType?(:GHOST) # Curse
      target=PBTargets::SingleNonUser
    end
    if move.tribute_has?(self,:EARTHTRIBUTE)
      return PBTargets::AllNonUsers
    end
    side=(pbIsOpposing?(self.index)) ? 1 : 0
    owner=@battle.pbGetOwnerIndex(self.index)
    if @battle.zMove[side][owner]==self.index && self.item == PBItems::KOMMONIUMZ2
      target=PBTargets::AllOpposing
    elsif @battle.zMove[side][owner]==self.index && (move.pbIsPhysical?(move.type) || move.pbIsSpecial?(move.type))
      target=PBTargets::SingleNonUser
    end
    return PBTargets::AllOpposing if pbFieldSpreadsMove?(move)
    return target
  end

  def pbAddTarget(targets,target,user=self,move=nil)
    if target && !target.isFainted?
      if move && !@battle.pbMoveCanTargetInTriple?(user,target,move)
        return false
      end
      targets[targets.length]=target
      return true
    end
    return false
  end

  def pbRandomTarget(targets,move=nil)
    choices=opposingBattlers.find_all do |battler|
      battler && !battler.isFainted? &&
        (!move || @battle.pbMoveCanTargetInTriple?(self,battler,move))
    end
    if choices.length>0
      pbAddTarget(targets,choices[@battle.pbRandom(choices.length)],self,move)
    end
  end

  def pbBypassesTargetAbility?(move)
    return hasWorkingAbility(:MOLDBREAKER) || hasWorkingAbility(:TERAVOLT) ||
           hasWorkingAbility(:TURBOBLAZE) ||
           (hasWorkingAbility(:SHADOWTAG) && $fefieldeffect==40) ||
           move.function==0x166 || move.name=="Decimation"
  end

  def pbFindFireOrWindRedirector(move,target,candidates)
    return nil if target==self || hasWorkingAbility(:OBLIVIOUS) || hasWorkingAbility(:INNERFOCUS) ||
      pbBypassesTargetAbility?(move) || @battle.pbCheckGlobalAbility(:HEADSTRONG)
    type=move.pbType(move.type,self,target)
    wind=PBStuff::WINDMOVE.include?(move.id)
    matches=lambda do |battler|
      (wind && battler.hasWorkingAbility(:WINDRIDER)) ||
        (type==PBTypes::FIRE && battler.hasWorkingAbility(:WELLBAKEDBODY))
    end
    return nil if matches.call(target)
    candidates.find do |battler|
      battler!=self && !battler.effects[PBEffects::Commander] &&
        @battle.pbMoveCanTargetInTriple?(self,battler,move) && matches.call(battler)
    end
  end

  def pbChangeTarget(thismove,userandtarget,targets)
    if thismove.function==0x179
      return true
    end
    priority=@battle.pbPriority
    changeeffect=0
    user=userandtarget[0]
    target=userandtarget[1]
    ignores_redirection=user.hasWorkingAbility(:OBLIVIOUS) || user.hasWorkingAbility(:INNERFOCUS)
    target_mode=user.pbTarget(thismove)
    redirectable=[PBTargets::SingleNonUser,PBTargets::SingleOpposing,PBTargets::RandomOpposing,PBTargets::OppositeOpposing].include?(target_mode)
    if redirectable && targets.length==1 && user!=target && !ignores_redirection
      move_type=thismove.pbType(thismove.type,user,target)
      redirect_ability=case move_type
      when PBTypes::ELECTRIC then :LIGHTNINGROD
      when PBTypes::WATER then :STORMDRAIN
      end
      if redirect_ability && !target.hasWorkingAbility(redirect_ability)
        redirector=priority.find do |battler|
          battler!=user && battler.hasWorkingAbility(redirect_ability) &&
            @battle.pbMoveCanTargetInTriple?(user,battler,thismove)
        end
        if redirector
          target=redirector
          changeeffect=(redirect_ability==:LIGHTNINGROD ? 1 : 2)
        end
      end
      if changeeffect==0 && (redirector=user.pbFindFireOrWindRedirector(thismove,target,priority))
        target=redirector
        changeeffect=5
      end
    end
    # Change target to user of Follow Me (overrides Magic Coat
    # because check for Magic Coat below uses this target)
    if redirectable && !ignores_redirection
      priority.reverse_each do |redirector|
        next unless user.pbIsOpposing?(redirector.index) && !redirector.isFainted?
        next unless @battle.pbMoveCanTargetInTriple?(user,redirector,thismove)
        follow_me=redirector.effects[PBEffects::FollowMe]
        rage_powder=redirector.effects[PBEffects::RagePowder]
        next unless follow_me || rage_powder
        next if !follow_me && (user.hasWorkingAbility(:OVERCOAT) || user.pbHasType?(:GRASS) ||
          user.hasWorkingItem(:SAFETYGOGGLES))
        target=redirector
        changeeffect=0
        break
      end
    end
    if target.pbIsOpposing?(user.index) && target.hasWorkingAbility(:PRESSURE)
      pbReducePPOther(thismove)
      if @battle.field.effects[PBEffects::Gravity]>0 || user.status==PBStatuses::CRUSHED
        pbReducePPOther(thismove)
      end
    end
    # Change user to user of Snatch
    if thismove.canSnatch?
      for i in priority
        if i.effects[PBEffects::Snatch]
          @battle.pbDisplay(_INTL("{1} Snatched {2}'s move!",i.pbThis,user.pbThis(true)))
          i.effects[PBEffects::Snatch]=false
          target=user
          user=i
          # Snatch's PP is reduced if old user has Pressure
          userchoice=@battle.choices[user.index][1]
          if target.hasWorkingAbility(:PRESSURE) && userchoice>=0
            pressuremove=user.moves[userchoice]
            pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            if $fefieldeffect==38
              pressuremove=user.moves[userchoice]
              pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            end
          end
        end
      end
    end
    userandtarget[0]=user
    userandtarget[1]=target
    if !@battle.pbCheckGlobalAbility(:HEADSTRONG) && target.hasWorkingAbility(:SOUNDPROOF) && thismove.isSoundBased? &&
      thismove.function!=0x19 &&   # Heal Bell handled elsewhere
      thismove.function!=0xE5 &&   # Perish Song handled elsewhere
      !user.pbBypassesTargetAbility?(thismove)
      @battle.pbDisplay(_INTL("{1}'s {2} blocks {3}!",target.pbThis,
          PBAbilities.getName(target.ability),thismove.name))
      return false
    end
    if thismove.canMagicCoat? && target.effects[PBEffects::MagicCoat]
      # switch user and target
      changeeffect=3
      target.effects[PBEffects::MagicCoat]=false
      tmp=user
      user=target
      target=tmp
      # Magic Coat's PP is reduced if old user has Pressure
      userchoice=@battle.choices[user.index][1]
      if target.hasWorkingAbility(:PRESSURE) && userchoice>=0
        pressuremove=user.moves[userchoice]
        pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
        if $fefieldeffect==38
          pressuremove=user.moves[userchoice]
          pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
        end
      end
    end
    if thismove.canMagicCoat? && (target.hasWorkingAbility(:MAGICBOUNCE) || @battle.SilvallyCheck(target, "psychic")) &&
       !user.pbBypassesTargetAbility?(thismove)
      target.effects[PBEffects::MagicBounced]=true
      # switch user and target
      changeeffect=4
      tmp=user
      user=target
      target=tmp
    end
    if changeeffect==1
      @battle.pbDisplay(_INTL("{1}'s Lightning Rod took the move!",target.pbThis))
    elsif changeeffect==2
      @battle.pbDisplay(_INTL("{1}'s Storm Drain took the move!",target.pbThis))
    elsif changeeffect==5
      @battle.pbDisplay(_INTL("{1}'s {2} drew in the move!",target.pbThis,PBAbilities.getName(target.ability)))
    elsif changeeffect==3
      # Target refers to the move's old user
      @battle.pbDisplay(_INTL("{1}'s {2} was bounced back by Magic Coat!",user.pbThis,thismove.name))
    elsif changeeffect==4 && !(thismove.target==PBTargets::AllOpposing && (user.index==0 || user.index==1))
      # Target refers to the move's old user
      # UPDATE 11/17/2013
      # not a listed bug - but I came across it.
      # was previously stating the incorrect Pokemon name (not the one that bounced it back
      # but instead the one that received it).
      # changed from: @battle.pbDisplay(_INTL("{1} bounced the {2} back!",target.pbThis,thismove.name))
      @battle.pbDisplay(_INTL("{1} bounced the {2} back!",user.pbThis,thismove.name))
      if $fefieldeffect == 30
        if user.pbCanIncreaseStatStage?(PBStats::EVASION)
          user.pbIncreaseStatBasic(PBStats::EVASION,1)
          @battle.pbCommonAnimation("StatUp",user,nil)
          @battle.pbDisplay(_INTL("{1}'s Magic Bounce increased its evasion!",user.pbThis,thismove.name))
        end
      end
    end
    userandtarget[0]=user
    userandtarget[1]=target
    return true
  end

  ################################################################################
  # Move PP
  ################################################################################
  def pbSetPP(move,pp)
    move.pp=pp
    #Not effects[PBEffects::Mimic], since Mimic can't copy Mimic
    if move.thismove && move.id==move.thismove.id && !@effects[PBEffects::Transform]
      move.thismove.pp=pp
    end
    pbSyncTributeDracoPP if @tributeDracoBattleMove && move.equal?(@tributeDracoBattleMove)
  end

  def pbReducePP(move)
    if @effects[PBEffects::TwoTurnAttack]>0 ||
      @effects[PBEffects::Outrage]>0 ||
      @effects[PBEffects::Rollout]>0 ||
      @effects[PBEffects::HyperBeam]>0 ||
      @effects[PBEffects::Uproar]>0
      # No need to reduce PP if two-turn attack
      return true
    end
    return true if isbossmon # by SH
    return true if move.pp<0   # No need to reduce PP for special calls of moves
    return true if move.totalpp==0   # Infinite PP, can always be used
    return false if move.pp==0
    if move.pp>0
      pbSetPP(move,move.pp-1)
    end
    return true
  end

  def pbReducePPOther(move)
    pbSetPP(move,move.pp-1) if move.pp>0
  end

  ################################################################################
  # Using a move
  ################################################################################
  def pbObedienceCheck?(choice)
    return true if @battle.isOnline?
    return true if choice[0]!=1
    if (@battle.pbOwnedByPlayer?(@index) && @battle.internalbattle) || (!@battle.pbOwnedByPlayer?(@index) && @index==@battle.battlers[2].index && isConst?(self.species,PBSpecies,:CHARIZARD) && $game_variables[246]==14)
      #### SARDINES - Disobedience - START
      #~ if !$game_switches[1512] ### Azery
        #~ levelLimits = [20, 25, 30, 40, 42, 50, 53, 55, 58, 62, 65, 70, 75, 80, 85, 90, 90, 95, 100]
      #~ else
        #~ levelLimits = [20, 25, 35, 40, 45, 50, 53, 55, 58, 62, 65, 70, 75, 80, 85, 90, 90, 95, 100]
      #~ end
      if $game_switches[1489] == false
       badgelevel = $game_variables[700]
      else
       badgelevel = 100
      end
      #### SARDINES - Disobedience - END
      move=choice[2]
      disobedient=false
      if @level>badgelevel
        a=((@level+badgelevel)*@battle.pbRandom(256)/255).floor
        disobedient|=a<badgelevel
      end
      if self.respond_to?("pbHyperModeObedience")
        disobedient|=!self.pbHyperModeObedience(move)
      end
      if disobedient && !$game_switches[1235]
        @effects[PBEffects::Rage]=false
        if self.status==PBStatuses::SLEEP &&
          (move.function==0x11 || move.function==0xB4) # Snore, Sleep Talk
          @battle.pbDisplay(_INTL("{1} ignored orders while asleep!",pbThis))
          return false
        end
        b=((@level+badgelevel)*@battle.pbRandom(256)/255).floor
        #if b<badgelevel
        #  return false if !@battle.pbCanShowFightMenu?(@index)
        #  othermoves=[]
        #  for i in 0...4
        #    next if i==choice[1]
        #    othermoves[othermoves.length]=i if @battle.pbCanChooseMove?(@index,i,false)
        #  end
        #  if othermoves.length>0
        #    @battle.pbDisplay(_INTL("{1} ignored orders!",pbThis))
        #    newchoice=othermoves[@battle.pbRandom(othermoves.length)]
        #    choice[1]=newchoice
        #    choice[2]=@moves[newchoice]
        #    choice[3]=-1
        #  end
        #  return true
        #elsif self.status!=PBStatuses::SLEEP
        if self.status!=PBStatuses::SLEEP
          c=@level-b
          r=@battle.pbRandom(256)
          if r<c && pbCanSleep?(false,true)
            pbSleepSelf()
            @battle.pbDisplay(_INTL("{1} took a nap!",pbThis))
            return false
          end
          r-=c
          if r<c
            @battle.pbDisplay(_INTL("{1} won't obey!",pbThis))
            @battle.pbDisplay(_INTL("{1} hurt itself!",pbThis)) #pk code
            pbConfusionDamage
          else
            message=@battle.pbRandom(4)
            @battle.pbDisplay(_INTL("{1} ignored orders!",pbThis)) if message==0
            @battle.pbDisplay(_INTL("{1} turned away!",pbThis)) if message==1
            @battle.pbDisplay(_INTL("{1} is loafing around!",pbThis)) if message==2
            @battle.pbDisplay(_INTL("{1} pretended not to notice!",pbThis)) if message==3
          end
          return false
        end
      end
      return true
    else
      return true
    end
  end


  def pbSuccessCheck(thismove,user,target,accuracy=true)
    if target.effects[PBEffects::Commander]
      @battle.pbDisplay(_INTL("{1} avoided the attack!",target.pbThis))
      return false
    end
    if $fefieldeffect == 4
      if thismove.function==0xC4
        if @effects[PBEffects::TwoTurnAttack]>0
          @effects[PBEffects::TwoTurnAttack] = 0
        end
        @battle.pbDisplay(_INTL("But it failed...",target.pbThis))
        return false
      end
    end
    if $fefieldeffect == 5 && user.hasWorkingAbility(:KLUTZ)
      if isConst?(@id,PBMoves,:PSYCHIC) || isConst?(@id,PBMoves,:STRENGTH) ||
        isConst?(@id,PBMoves,:ANCIENTPOWER) || isConst?(@id,PBMoves,:BARRAGE) ||
        isConst?(@id,PBMoves,:ROCKTHROW)
        if @effects[PBEffects::TwoTurnAttack]>0
          @effects[PBEffects::TwoTurnAttack] = 0
        end
        @battle.pbDisplay(_INTL("It was too much of a klutz to move the chess piece.",target.pbThis))
        return false
      end
    end
    if $fefieldeffect == 12
      if thismove.function==0x61
        if @effects[PBEffects::TwoTurnAttack]>0
          @effects[PBEffects::TwoTurnAttack] = 0
        end
        @battle.pbDisplay(_INTL("But it failed...",target.pbThis))
        return false
      end
    end
    if $fefieldeffect == 24
      if thismove.function==0xEB
        if @effects[PBEffects::TwoTurnAttack]>0
          @effects[PBEffects::TwoTurnAttack] = 0
        end
        @battle.pbDisplay(_INTL("But it failed...",target.pbThis))
        return false
      end
    end
    if $fefieldeffect == 43
      if thismove.function==0x95 || thismove.function==0xCA ||
        thismove.function==0x151 || thismove.function==0x76
        if @effects[PBEffects::TwoTurnAttack]>0
          @effects[PBEffects::TwoTurnAttack] = 0
        end
        @battle.pbDisplay(_INTL("But it failed...",target.pbThis))
        return false
      end
    end
    if $fefieldeffect == 44
      if thismove.function==0xED || thismove.function==0xBC #pk code
        if @effects[PBEffects::TwoTurnAttack]>0
          @effects[PBEffects::TwoTurnAttack] = 0
        end
        @battle.pbDisplay(_INTL("But it failed...",target.pbThis))
        return false
      end
    end

    move_priority=@battle.pbMovePriority(user,thismove,target)
    if move_priority>0 && !(thismove.pbIsPhysical?(thismove.type) || thismove.pbIsSpecial?(thismove.type)) &&
      user.hasWorkingAbility(:PRANKSTER)
      if !@battle.pbCheckGlobalAbility(:HEADSTRONG) && target.pbHasType?(:DARK) && $fefieldeffect!=42
        @battle.pbDisplay(_INTL("{1} wasn't affected!",target.pbThis))
        return false
      end
    end
    priorityBlocker=target.priorityBlockingBattlers[0]
    if move_priority>0 && !@battle.pbCheckGlobalAbility(:HEADSTRONG) &&
      ((target.hasWorkingAbility(:DAZZLING) && !target.moldbroken) ||
      (@battle.field.effects[PBEffects::PsychicTerrain]>0 && $fefieldeffect!=37) || # Psychic Terrain overlay only
      $fefieldeffect == 37 || # Psychic Field blocks all priority
      ($fefieldeffect == 34 && target.hasWorkingAbility(:MIRRORARMOR) && !target.moldbroken) ||
      !priorityBlocker.nil?)
      if priorityBlocker
        @battle.pbDisplay(_INTL("{1} activated!",PBAbilities.getName(priorityBlocker.ability)))
      end
      @battle.pbDisplay(_INTL("{1} wasn't affected!",target.pbThis))
      return false
    end
    if !@battle.pbCheckGlobalAbility(:HEADSTRONG) && thismove.pbArmorTailBlocks?(user,target)
      @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!",target.pbThis,
          PBAbilities.getName(target.ability),thismove.name))
      return false
    end
    if user.effects[PBEffects::TwoTurnAttack]>0
      PBDebug.log("[Using two-turn attack]") if $INTERNAL
      self.missed = false
      return true
    end
    # TODO: "Before Protect" applies to Counter/Mirror Coat
    if thismove.function==0xDE && ((target.status!=PBStatuses::SLEEP && (!target.hasWorkingAbility(:COMATOSE) && $fefieldeffect!=1) && (!user.hasWorkingAbility(:WORLDOFNIGHTMARES))) || !(user.effects[PBEffects::HealBlock]==0))  # Dream Eater
      @battle.pbDisplay(_INTL("{1} wasn't affected!",target.pbThis))
      return false
    end
    if (thismove.function==0xDD || thismove.function==0x139 || thismove.function==0x158) && !(user.effects[PBEffects::HealBlock]==0) # Absorbtion Moves
      @battle.pbDisplay(_INTL("{1} wasn't affected!",target.pbThis))
      return false
    end
    #### KUROTSUNE - 025 - START
    if !thismove.zmove # Z-Moves handle protection stuff elsewhere
      $fecounter=3 if $fefieldeffect == 13 && isConst?(thismove.id,PBMoves,:DIVE)
      if target.pbOwnSide.effects[PBEffects::MatBlock] && (isConst?(thismove.id,PBMoves,:PHANTOMFORCE) || isConst?(thismove.id,PBMoves,:SHADOWFORCE) ||
          isConst?(thismove.id,PBMoves,:HYPERSPACEHOLE) || isConst?(thismove.id,PBMoves,:HYPERSPACEFURY))
        @battle.pbDisplay(_INTL("The Mat Block was broken!"))
      end

      if target.pbOwnSide.effects[PBEffects::MatBlock] && (thismove.pbIsPhysical?(thismove.type) || thismove.pbIsSpecial?(thismove.type)) &&
        thismove.canProtectAgainst? && !target.effects[PBEffects::ProtectNegation]
        @battle.pbDisplay(_INTL("{1} protected itself!",target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost if thismove.basedamage>0
        return false
      end
      #### KUROTSUNE - 025 - END
      if target.effects[PBEffects::Protect] && thismove.canProtectAgainst? &&
        !target.effects[PBEffects::ProtectNegation]
        @battle.pbDisplay(_INTL("{1} protected itself!",target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost if thismove.basedamage>0
        return false
      end
      #### KUROTSUNE - 016 - START
      if target.pbOwnSide.effects[PBEffects::CraftyShield] && thismove.basedamage == 0 && !target.effects[PBEffects::ProtectNegation]
        @battle.pbDisplay(_INTL("{1}'s Crafty Shield activated!",target.pbThis))
        user.pbCancelMoves
        @battle.successStates[user.index].protected=true
        return false
      end
      #### KUROTSUNE - 016 - END
      # Wide Guard and Quick Guard halve damage in damage calculation (PokeBattle_Move.rb lines 5121-5126)
      # They don't block moves entirely
      # UPDATE 1/19/2014
      # King's Shield
      if target.effects[PBEffects::KingsShield] && ((thismove.basedamage > 0) || $fefieldeffect == 5 || $fefieldeffect == 31) && (!target.effects[PBEffects::ProtectNegation]) && thismove.hasFlags?('b')
        @battle.pbDisplay(_INTL("{1} protected itself!", target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost if thismove.basedamage>0
        # physical contact
        if thismove.hasFlags?('a') && !user.hasWorkingAbility(:LONGREACH)
          if ($fefieldeffect == 31 || $fefieldeffect == 44 )
            user.pbReduceStat(PBStats::ATTACK, 2, true)
            user.pbReduceStat(PBStats::SPATK, 2, true)
          else
            user.pbReduceStat(PBStats::ATTACK, 2, true)
          end
        end
        return false
      end # end of update
      # Spiky Shield
      if target.effects[PBEffects::SpikyShield] &&
        !target.effects[PBEffects::ProtectNegation] && thismove.canProtectAgainst?
        @battle.pbDisplay(_INTL("{1} protected itself!", target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost if thismove.basedamage>0
        # physical contact
        if thismove.hasFlags?('a') && !user.hasWorkingAbility(:LONGREACH)
          #@scene.pbDamageAnimation(user,0) TODO: Fix animation
          if user.effects[PBEffects::ShieldLife]>0
            spikydamage=user.totalhp/8
            @battle.pbShieldDamage(user,spikydamage)
          else
            if $fefieldeffect == 44
              user.pbReduceHP((user.totalhp/4).floor)
            else
              user.pbReduceHP((user.totalhp/8).floor)
            end
          end
        end
        return false
      end
      # Silk Trap
      if target.effects[PBEffects::SilkTrap] && thismove.basedamage>0 &&
        !target.effects[PBEffects::ProtectNegation] && thismove.canProtectAgainst?
        @battle.pbDisplay(_INTL("{1} protected itself!",target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost
        if thismove.isContactMove? && !user.hasWorkingAbility(:LONGREACH) &&
           !user.hasWorkingItem(:PROTECTIVEPADS) &&
           user.pbCanReduceStatStage?(PBStats::SPEED,false)
          user.pbReduceStat(PBStats::SPEED,1,false,PBMoves::SILKTRAP,target)
        end
        return false
      end
      # Burning Bulwark
      if target.effects[PBEffects::BurningBulwark] && thismove.basedamage>0 &&
        !target.effects[PBEffects::ProtectNegation] && thismove.canProtectAgainst?
        @battle.pbDisplay(_INTL("{1} protected itself!",target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost
        if thismove.isContactMove? && !user.hasWorkingAbility(:LONGREACH) &&
           !user.hasWorkingItem(:PROTECTIVEPADS) && user.pbCanBurn?(false)
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1}'s Burning Bulwark burned {2}!",target.pbThis,user.pbThis(true)))
        end
        return false
      end
      # Obstruct
      if target.effects[PBEffects::Obstruct] && !target.effects[PBEffects::ProtectNegation] && thismove.canProtectAgainst? && ((thismove.basedamage > 0) || $fefieldeffect == 5 || $fefieldeffect == 38)
        @battle.pbDisplay(_INTL("{1} protected itself!", target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost if thismove.basedamage>0
        # physical contact
        if thismove.hasFlags?('a') && !user.hasWorkingAbility(:LONGREACH)# && !(thismove.id==PBMoves::SACREDSWORD && $fefieldeffect==31)
          user.pbReduceStat(PBStats::DEFENSE,2,true)
        end
        return false
      end
      if target.effects[PBEffects::Stormhold] && !target.effects[PBEffects::ProtectNegation] && thismove.canProtectAgainst?
        @battle.pbDisplay(_INTL("{1} protected itself!",target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost if thismove.basedamage>0
        if thismove.isContactMove? && !user.hasWorkingAbility(:LONGREACH) &&
           !user.hasWorkingItem(:PROTECTIVEPADS) && user.pbCanParalyze?(false)
          user.pbParalyze(target)
          @battle.pbDisplay(_INTL("{1}'s Stormhold paralyzed {2}!",target.pbThis,user.pbThis(true)))
        end
        return false
      end
      # Baneful Bunker
      if target.effects[PBEffects::BanefulBunker] &&
        ((thismove.basedamage > 0)) &&
        !target.effects[PBEffects::ProtectNegation] && thismove.canProtectAgainst?
        @battle.pbDisplay(_INTL("{1} protected itself!", target.pbThis))
        @battle.successStates[user.index].protected=true
        user.pbTriggerSteadfastBoost if thismove.basedamage>0
        # physical contact
        if thismove.hasFlags?('a') && user.pbCanPoison?(false) && !user.hasWorkingAbility(:LONGREACH)
          #@scene.pbDamageAnimation(user,0) TODO: Fix animation
          user.pbPoison(target)
          @battle.pbDisplay(_INTL("{1}'s Baneful Bunker poisoned {2}!",target.pbThis,user.pbThis(true)))
        end
        return false
      end
    end
    # TODO: Mind Reader/Lock-On
    # --Sketch/FutureSight/PsychUp work even on Fly/Bounce/Dive/Dig
    if thismove.basedamage==0 && user!=target && !@battle.pbCheckGlobalAbility(:HEADSTRONG)
      type=thismove.pbType(thismove.type,user,target)
      return false if thismove.pbApplyTypeAbsorption(type,user,target) ||
                      thismove.pbApplyCustomMoveImmunity(type,user,target)
    end
    if !thismove.pixie_replaces_effect?(user) && thismove.pbMoveFailed(user,target)
      @battle.pbDisplay(_INTL("But it failed!"))
      return false
    end
    blinded=user.effects[PBEffects::Blinded]>0 && thismove.basedamage>0 #pk code
    if accuracy
      #pk code
      if !blinded && (thismove.lock_on_boost ||
         (target.effects[PBEffects::LockOn]>0 && target.effects[PBEffects::LockOnPos]==user.index))
        self.missed = false
        return true
      end
      invulmiss=false
      if defined?(pbSpookyTributeVanished?) && pbSpookyTributeVanished?(target)
        invulmiss=(thismove.function!=0xCD)
      end
      invulmove=if pbSpookyTributeVanished?(target)
        0
      else
        PBMoveData.new(target.effects[PBEffects::TwoTurnAttack]).function
      end
      case invulmove
      when 0xC9, 0xCC # Fly, Bounce
        (invulmiss=true)                 unless thismove.function==0x08 ||  # Thunder
        thismove.function==0x15 ||  # Hurricane
        thismove.function==0x77 ||  # Gust
        thismove.function==0x78 ||  # Twister
        (thismove.function==0x10D && !user.pbHasType?(:GHOST)) ||  # Curse
        thismove.function==0x11B || # Sky Uppercut
        thismove.function==0x11C || # Smack Down
        thismove.id      ==630   ||
        isConst?(thismove.id,PBMoves,:WHIRLWIND)
      when 0xCA # Dig
        (invulmiss=true)                 unless thismove.function==0x76 || # Earthquake
        thismove.function==0x95 || # Magnitude
        (thismove.function==0x10D && !user.pbHasType?(:GHOST)) # Curse
      when 0xCB,0x23C # Dive, Swan Dive
        (invulmiss=true)                 unless thismove.function==0x75 || # Surf
        thismove.function==0xD0 || # Whirlpool
        (thismove.function==0x10D && !user.pbHasType?(:GHOST)) # Curse
      when 0xCD # Shadow Force
        (invulmiss=true)
      when 0xCE # Sky Drop
        (invulmiss=true)                 unless thismove.function==0x08 ||  # Thunder
        thismove.function==0x15 ||  # Hurricane
        thismove.function==0x77 ||  # Gust
        thismove.function==0x78 ||  # Twister
        (thismove.function==0x10D && !user.pbHasType?(:GHOST)) ||  # Curse
        thismove.function==0x11B || # Sky Uppercut
        thismove.function==0x11C ||   # Smack Down
        thismove.id      ==630
      end
      if target.effects[PBEffects::SkyDrop]
        (invulmiss=true)                 unless thismove.function==0x08 ||  # Thunder
        thismove.function==0x15 ||  # Hurricane
        thismove.function==0x77 ||  # Gust
        thismove.function==0x78 ||  # Twister
        (thismove.function==0x10D && !user.pbHasType?(:GHOST)) ||  # Curse
        thismove.function==0x11B || # Sky Uppercut
        thismove.function==0x11C ||  # Smack Down
        #### KUROTSUNE - 022 - START
        thismove.function==0xCE  ||  # Sky Drop
        #### KUROTSUNE - 022 - END
        thismove.id              == 630
      end
      if invulmiss
        opposingCount=user.opposingBattlers.count { |battler| battler && !battler.isFainted? }
        nonUserCount=opposingCount + user.sameSideBattlers(false).count { |battler| battler && !battler.isFainted? }
        if thismove.target==PBTargets::AllOpposing &&
          opposingCount > 1
          # All opposing PokÃ©mon
          @battle.pbDisplay(_INTL("{1} avoided the attack!",target.pbThis))
        elsif thismove.target==PBTargets::AllNonUsers &&
          nonUserCount > 1
          # All non-users
          @battle.pbDisplay(_INTL("{1} avoided the attack!",target.pbThis))
        elsif thismove.function==0xDC # Leech Seed
          @battle.pbDisplay(_INTL("{1} evaded the attack!",target.pbThis))
        else
          @battle.pbDisplay(_INTL("{1}'s attack missed!",user.pbThis))
        end
        return false
      end
    end
    if thismove.id==83  && thismove.pbTypeModMessages(thismove.type,user,target)==0
      return false
    end
    if thismove.basedamage>0 && thismove.function!=0x02 && # Struggle
      thismove.function!=0x111 # Future Sight
      type=thismove.pbType(thismove.type,user,target)
      typemod=thismove.pbTypeModifier(type,user,target)
      typemod=thismove.FieldTypeChange(user,target,typemod)
      headstrong=@battle.pbCheckGlobalAbility(:HEADSTRONG)
      if !headstrong && isConst?(type,PBTypes,:GROUND)     &&
        target.isAirborne?                 &&
        !target.hasWorkingItem(:RINGTARGET) &&
        $fefieldeffect != 23                &&
        (thismove.id != 664 && thismove.id != 674)
        if target.hasWorkingAbility(:LEVITATE)  &&
          !(target.moldbroken)
          @battle.pbDisplay(_INTL("{1} makes Ground moves miss with Levitate!",target.pbThis))
          return false
        end
        if (target.hasWorkingAbility(:SOLARIDOL) || target.hasWorkingAbility(:LUNARIDOL))  && !(target.moldbroken)
          @battle.pbDisplay(_INTL("{1} makes Ground moves miss with {2}!",target.pbThis,PBAbilities.getName(target.ability)))
          return false
        end
        if target.hasWorkingItem(:AIRBALLOON)
          @battle.pbDisplay(_INTL("{1}'s Air Balloon makes Ground moves miss!",target.pbThis))
          return false
        end
        if target.effects[PBEffects::MagnetRise]>0
          @battle.pbDisplay(_INTL("{1} makes Ground moves miss with Magnet Rise!",target.pbThis))
          return false
        end
        if target.effects[PBEffects::Telekinesis]>0
          @battle.pbDisplay(_INTL("{1} makes Ground moves miss with Telekinesis!",target.pbThis))
          return false
        end
      end
      #### KUROTSUNE - 029 - START
      if !headstrong && target.hasWorkingAbility(:WONDERGUARD) &&
        typemod<=4 &&
        type>=0  &&
        !(target.moldbroken)
        #### KUROTSUNE - 029 - END
        @battle.pbDisplay(_INTL("{1} avoided damage with Wonder Guard!",target.pbThis))
        return false
      end
      if !headstrong && typemod==0 && thismove.function!=0x111 && thismove.id!=PBMoves::OVERCHARGE
        @battle.pbDisplay(_INTL("It doesn't affect\r\n{1}...",target.pbThis(true)))
        return false
      end
    end
    if accuracy && !thismove.pbIsStatus? #pk code
      # Blinded attackers always miss (grazing blow) with damaging moves
      if blinded #pk code
        @battle.pbDisplay(_INTL("{1} can't see through its blindness!",user.pbThis))
        user.missAcc = true
        return false if thismove.pbCrashOnAccuracyMiss?
        @battle.pbDisplay(_INTL("{1}'s attack grazed!",user.pbThis))
        user.grazed = true
        self.missed = false
        return true
      end
      #pk code
      if target.effects[PBEffects::LockOn]>0 && target.effects[PBEffects::LockOnPos]==user.index
        self.missed = false
        return true
      end
      if !thismove.pbAccuracyCheck(user,target) # Includes Counter/Mirror Coat
        # For damaging moves (not OHKO, not status), allow grazing blow with half damage and no secondary effects
        if thismove.basedamage > 0 && thismove.function != 0xDC &&
          !thismove.pbCrashOnAccuracyMiss?
          # Handle Sky Drop release
          if user.effects[PBEffects::SkyDroppee]!=nil
            target.effects[PBEffects::SkyDrop]=false
            @battle.scene.pbUnVanishSprite(target)
            @battle.pbDisplay(_INTL("{1} is freed from the Sky Drop effect!",target.pbThis))
          end
          # Mirror Field reflection check
          if $fefieldeffect == 30 && (thismove.flags&0x01)==0 && thismove.pbIsSpecial?(type) &&
            @battle.pbRandom(10)<5
            @battle.pbDisplay(_INTL("The attack was reflected by the mirror!",user.pbThis))
            $fecounter = 1
            self.missed = false
            return true
          end
          # Grazing blow - half damage, no secondary effects
          @battle.pbDisplay(_INTL("{1}'s attack grazed!",user.pbThis))
          user.missAcc = true
          user.grazed = true
          self.missed = false
          return true
        else
          # Non-damaging moves and OHKO moves still fully miss
          opposingCount=user.opposingBattlers.count { |battler| battler && !battler.isFainted? }
          nonUserCount=opposingCount + user.sameSideBattlers(false).count { |battler| battler && !battler.isFainted? }
          if thismove.target==PBTargets::AllOpposing &&
            opposingCount > 1
            # All opposing PokÃ©mon
            @battle.pbDisplay(_INTL("{1} avoided the attack!",target.pbThis))
          elsif thismove.target==PBTargets::AllNonUsers &&
            nonUserCount > 1
            # All non-users
            @battle.pbDisplay(_INTL("{1} avoided the attack!",target.pbThis))
          elsif thismove.function==0xDC # Leech Seed
            @battle.pbDisplay(_INTL("{1} evaded the attack!",target.pbThis))
          else
            @battle.pbDisplay(_INTL("{1}'s attack missed!",user.pbThis))
            if user.effects[PBEffects::SkyDroppee]!=nil
              target.effects[PBEffects::SkyDrop]=false
              @battle.scene.pbUnVanishSprite(target)
              @battle.pbDisplay(_INTL("{1} is freed from the Sky Drop effect!",target.pbThis))
            end
          end
          user.missAcc = true
          return false
        end
      end
    end
    self.missed = false
    return true
  end

  def pbTryUseMove(choice,thismove,turneffects)
    return true if turneffects[PBEffects::PassedTrying]
    # TODO: Return true if attack has been Mirror Coated once already
    return false if !pbObedienceCheck?(choice)
    return false if self.forcedSwitchEarlier
    tribute_icicle_status = defined?(pbTributeMoveMatches?) &&
      pbTributeMoveMatches?(self,:ICICLETRIBUTE,thismove.id) && thismove.basedamage<=0
    pixie_tribute_attack = thismove.respond_to?(:pixie_tribute_power) &&
      thismove.pixie_tribute_power(self)>0
    # implementing Stance Change
    if isConst?(self.ability, PBAbilities, :STANCECHANGE)
      pbCheckForm(thismove)
    end
    if isConst?(self.species,PBSpecies,:VESPIQUEN) && isConst?(self.item,PBItems,:VESPICREST)
      changed=false
      if thismove.basedamage==0 && (isConst?(thismove.id,PBMoves,:DEFENDORDER) || isConst?(thismove.id,PBMoves,:HEALORDER))
        if @effects[PBEffects::VespiCrest]!=0
          @effects[PBEffects::VespiCrest]  = 0
          changed=true
        end
      elsif thismove.basedamage>0
        if @effects[PBEffects::VespiCrest]!=1
          @effects[PBEffects::VespiCrest]  = 1
          changed=true
        end
      end
      if @effects[PBEffects::VespiCrest]!=-1 && changed==true
        if @effects[PBEffects::VespiCrest]==0
          self.pbReduceStat(PBStats::ATTACK,1,false)
          self.pbReduceStat(PBStats::SPATK,1,false)
          self.pbIncreaseStat(PBStats::DEFENSE,1,false)
          self.pbIncreaseStat(PBStats::SPDEF,1,false)
          @battle.pbDisplay(_INTL("{1} switched to Defense Stance!",pbThis))
        else
          self.pbReduceStat(PBStats::DEFENSE,1,false)
          self.pbReduceStat(PBStats::SPDEF,1,false)
          self.pbIncreaseStat(PBStats::ATTACK,1,false)
          self.pbIncreaseStat(PBStats::SPATK,1,false)
          @battle.pbDisplay(_INTL("{1} switched to Attack Stance!",pbThis))
        end
      end
    end
    # end of update
    # TODO: If being Sky Dropped, return false
    # TODO: Gravity prevents airborne-based moves here
    if !tribute_icicle_status &&
      @effects[PBEffects::Taunt]>0 && thismove.basedamage==0 && !pixie_tribute_attack
      @battle.pbDisplay(_INTL("{1} can't use {2} after the taunt!",
          pbThis,thismove.name))
      return false
    end
    if self.hasWorkingAbility(:ANGERPOINT) && thismove.basedamage==0 && !pixie_tribute_attack
      @battle.pbDisplay(_INTL("{1}'s Anger Point doesn't allow use of status moves!",
          pbThis))
      return false
    end
    if !tribute_icicle_status &&
      @effects[PBEffects::HealBlock]>0 && thismove.isHealingMove? && !pixie_tribute_attack
      @battle.pbDisplay(_INTL("{1} can't use {2} after the Heal Block!",
          pbThis,thismove.name))
      return false
    end
    if !tribute_icicle_status &&
      thismove.isSoundBased? && self.effects[PBEffects::ThroatChop]>0
      @battle.pbDisplay(_INTL("{1} can't use sound-based moves because of its throat damage!",pbThis))
      return false
    end
    if !tribute_icicle_status &&
      @effects[PBEffects::Torment] && thismove.id==@lastMoveUsed &&
      thismove.id!=@battle.struggle.id
      @battle.pbDisplay(_INTL("{1} can't use the same move in a row due to the torment!",
          pbThis))
      return false
    end
    if !@simplemove && !tribute_icicle_status
      opposingBattlers.each do |opposing|
        next if !opposing || !opposing.effects[PBEffects::Imprison]
        if opposing.moves.any? { |move_loop| move_loop && thismove.id==move_loop.id }
          @battle.pbDisplay(_INTL("{1} can't use the sealed {2}!",
              pbThis,thismove.name))
          if $INTERNAL
            move_ids=opposing.moves.map { |move_loop| move_loop ? move_loop.id : -1 }
            PBDebug.log("[#{opposing.pbThis} has: #{move_ids.join(', ')}]")
          end
          return false
        end
      end
    end
    if !tribute_icicle_status &&
      @effects[PBEffects::Disable]>0 && thismove.id==@effects[PBEffects::DisableMove]
      @battle.pbDisplayPaused(_INTL("{1}'s {2} is disabled!",pbThis,thismove.name))
      return false
    end
    if !tribute_icicle_status &&
      @effects[PBEffects::ForewarnDisable]>0 && thismove.id==@effects[PBEffects::ForewarnDisableMove]
      @battle.pbDisplayPaused(_INTL("{1}'s {2} is disabled by Forewarn!",pbThis,thismove.name))
      return false
    end
    if self.hasWorkingAbility(:TRUANT) && @effects[PBEffects::Truant]
      @battle.pbDisplay(_INTL("{1} is loafing around!",pbThis))
      hpgain = pbRecoverHP((self.totalhp/3).floor,true)
      if hpgain > 0
        @battle.pbDisplay(_INTL("{1} restored its health!",pbThis))
      end
      pbTriggerSteadfastBoost
      return false
    end
    if choice[1]==-2 # Battle Palace
      @battle.pbDisplay(_INTL("{1} appears incapable of using its power!",pbThis))
      return false
    end
    if @effects[PBEffects::HyperBeam]>0
      @battle.pbDisplay(_INTL("{1} must recharge!",pbThis))
      pbTriggerSteadfastBoost
      return false
    end
    focused=@effects[PBEffects::FocusEnergyGuard]==@battle.turncount
    if self.status==PBStatuses::SLEEP && !@simplemove
      self.statusCount-=1
      if self.statusCount<=0
        self.pbCureStatus
        # Early Bird - 2x speed the turn after waking up
        if self.hasWorkingAbility(:EARLYBIRD)
          @effects[PBEffects::EarlyBirdBoost] = 2
        end
      else
        self.pbContinueStatus
        if !focused && !thismove.pbCanUseWhileAsleep? # Snore/Sleep Talk
          pbTriggerSteadfastBoost
          return false
        end
      end
    end
    if self.status==PBStatuses::FROZEN
      # Fire moves and certain moves can still thaw the user
      if thismove.canThawUser?
        self.pbCureStatus(false)
        @battle.pbDisplay(_INTL("{1} was defrosted by {2}!",pbThis,thismove.name))
        pbCheckForm
      end
      # Freeze no longer immobilizes - HP sap happens at end of turn instead
    end
    #### AME - 004 - START
    if @effects[PBEffects::Flinch]
      @effects[PBEffects::Flinch]=false
      if focused
        @battle.pbDisplay(_INTL("{1} stayed focused and didn't flinch!",pbThis))
      elsif self.hasWorkingAbility(:INNERFOCUS)
        @battle.pbDisplay(_INTL("{1} won't flinch because of its {2}!",
            self.pbThis,PBAbilities.getName(self.ability)))
      elsif $fefieldeffect == 14  # Rocky Field
        if self.hasWorkingAbility(:STEADFAST)
          pbTriggerSteadfastBoost
        elsif !self.hasWorkingAbility(:STURDY)
          @battle.pbDisplay(_INTL("{1} was knocked into a rock!",pbThis))
          damage=[1,(self.totalhp/16).floor].max
          if damage>0
            @battle.scene.pbDamageAnimation(self,0)
            self.pbReduceHP(damage)
          end
          if self.hp<=0
            user.pbFaint
          else
            @battle.pbDisplay(_INTL("{1} flinched and couldn't move!",self.pbThis))
            pbTriggerSteadfastBoost
            return false
          end
        end
      else
        @battle.pbDisplay(_INTL("{1} flinched and couldn't move!",self.pbThis))
        pbTriggerSteadfastBoost
        return false
      end
    end
    #### AME - 004 - END
    #pk code
    if @effects[PBEffects::Confusion]>0 && !@simplemove && thismove.id!=PBMoves::CALMINGWAKE
      pbContinueConfusion
      @battle.pbDisplay(_INTL("It hurt itself in its confusion!"))
      pbConfusionDamage
      return false if self.isFainted?
      @effects[PBEffects::Confusion]-=1
      pbCureConfusion if @effects[PBEffects::Confusion]==0
    end
    if @effects[PBEffects::Attract]>=0 && !@simplemove
      pbAnnounceAttract(@battle.battlers[@effects[PBEffects::Attract]])
      # Infatuation no longer immobilizes - instead, attacks against infatuated Pokemon always crit
    end
    # Paralysis no longer immobilizes - HP sap happens at end of turn instead
    # UPDATE 2/13/2014
    # implementing Protean / Libero
    protype=thismove.type
    if (thismove.id == 333)
      hp = pbHiddenPower(self.iv)
      protype = hp[0]
    end
    if (isConst?(self.ability,PBAbilities,:PROTEAN) || isConst?(self.ability,PBAbilities,:LIBERO)) && !(self.abilitynulled)
      prot1 = self.type1
      prot2 = self.type2
      if !self.pbHasType?(protype) || (defined?(prot2) && prot1 != prot2)
        self.type1=protype
        self.type2=protype
        typename=PBTypes.getName(protype)
        @battle.pbDisplay(_INTL("{1} had its type changed to {3}!",pbThis,PBAbilities.getName(self.ability),typename))
      end
    end # end of update
    turneffects[PBEffects::PassedTrying]=true
    return true
  end

  def pbConfusionDamage
    self.damagestate.reset
    confmove=PokeBattle_Confusion.new(@battle,nil)
    confmove.pbEffect(self,self)
    pbFaint if self.isFainted?
  end

  def pbUpdateTargetedMove(thismove,user)
    # TODO: Snatch, moves that use other moves
    # TODO: All targeting cases
    # Two-turn attacks, Magic Coat and Future Sight are handled
  end

  def pbCanActivateFocusSash?
    return hasWorkingItem(:FOCUSSASH) &&
      (hp==totalhp || pbConsumableHeldItemRepeat?(:FOCUSSASH))
  end

  def pbPrepareMoveDamageState
    damagestate.reset
    damagestate.focusband=hasWorkingItem(:FOCUSBAND) && @battle.pbRandom(10)==0
    damagestate.rampcrest=isConst?(species,PBSpecies,:RAMPARDOS) && hasWorkingItem(:RAMPCREST) &&
      !effects[PBEffects::RampCrestUsage]
  end

  def pbResolveReverbEchoes
    echoes=@effects[PBEffects::ReverbEcho]
    @effects[PBEffects::ReverbEcho]={}
    return if echoes.empty? || !hasWorkingAbility(:REVERB)
    echoes.each do |move_id,target_indices|
      break if isFainted? || @battle.decision!=0
      move=PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(move_id),self)
      move.reverbEcho=true
      targets=target_indices.filter_map do |index|
        target=@battle.battlers[index]
        target if target && !target.isFainted? && @battle.pbMoveCanTargetInTriple?(self,target,move)
      end
      next if targets.empty?
      target_indices=targets.map(&:index)
      move.spread_target_count=target_indices.length
      @battle.pbDisplay(_INTL("{1}'s {2} echoed back!",pbThis,move.name))
      turneffects=[]
      turneffects[PBEffects::TotalDamage]=0
      targets.each_with_index do |target,index|
        break if isFainted? || @battle.decision!=0
        next if target.isFainted?
        if !@battle.pbCheckGlobalAbility(:HEADSTRONG) && target.hasWorkingAbility(:SOUNDPROOF)
          @battle.pbDisplay(_INTL("{1}'s {2} blocks {3}!",target.pbThis,
            PBAbilities.getName(target.ability),move.name))
          next
        end
        old_move=@battle.lastMoveUsed
        old_user=@battle.lastMoveUser
        begin
          counters=[PBEffects::Metronome,PBEffects::FuryCutter,PBEffects::EchoedVoice,
                    PBEffects::CellSplitter,PBEffects::Tantrum]
          old_counters=counters.map { |effect| @effects[effect] }
          @battle.lastMoveUsed=move_id
          @battle.lastMoveUser=@index
          target.pbPrepareMoveDamageState
          pbProcessMoveAgainstTarget(move,self,target,1,turneffects,false,target_indices,index==0)
        ensure
          counters.zip(old_counters).each { |effect,value| @effects[effect]=value }
          @battle.lastMoveUsed=old_move
          @battle.lastMoveUser=old_user
        end
      end
      move.pbConsumeUsedGem(self)
    end
  end

  def pbProcessMoveAgainstTarget(thismove,user,target,numhits,turneffects,nocheck=false,alltargets=nil,showanimation=true)
    if target
      previously_corroded=target.corroded
      previously_moldbroken=target.moldbroken
      target.moldbroken=user!=target && user.pbBypassesTargetAbility?(thismove)
      target.corroded=user.hasWorkingAbility(:CORROSION) &&
        thismove.pbType(thismove.type,user,target)==PBTypes::POISON
    end
    realnumhits=0
    totaldamage=0
    stalwartDamaged=false
    destinybond=false
    wimpcheck=false
    user.grazed = false  # Reset graze flag for each target
    if $fefieldeffect == 5
      user.effects[PBEffects::SusCrit] = false
      target.effects[PBEffects::SusCrit] = false
    end
    $feshutup=0
    $feshutup2=0
    if target
      aboveHalfHp = target.hp>(target.totalhp/2).floor
      innardsOutHp = target.hp
    end
    for i in 0...numhits
      if user.status==PBStatuses::SLEEP && user.effects[PBEffects::FocusEnergyGuard]!=@battle.turncount &&
         !thismove.pbCanUseWhileAsleep? && !@simplemove && !thismove.reverbEcho
        realnumhits = i
        break
      end
      if !target
        tantrumCheck=@battle.pbWithIcicleTributeMove(user,thismove) do
          thismove.pbEffect(user,target,i,alltargets,showanimation)
        end
        if tantrumCheck == -1
          user.effects[PBEffects::Tantrum]=true
        else
          user.effects[PBEffects::Tantrum]=false
        end
        return
      end
      if target.isbossmon
        bosscheck = bossMoveCheck(thismove,user,target)
        return if bosscheck == 0
      end
      # Check success (accuracy/evasion calculation)
      if !nocheck &&
        !pbSuccessCheck(thismove,user,target,!thismove.reverbEcho && (i==0 || thismove.id==PBMoves::TRIPLEKICK))
        if thismove.id==PBMoves::TRIPLEKICK && realnumhits>0
          break   # Considered a success if Triple Kick hits at least once
        elsif (thismove.pbCrashOnAccuracyMiss? && user.missAcc) ||
              (thismove.function==0x10B && !thismove.pbCrashOnAccuracyMiss?)
          #TODO: Not shown if message is "It doesn't affect XXX..."
          @battle.pbDisplay(_INTL("{1} kept going and crashed!",user.pbThis))
          damage=[1,(user.totalhp/2).floor].max
          damage=user.pbAdjustAbilityRecoilCrashDamage(damage)
          if damage>0
            @battle.scene.pbDamageAnimation(user,0)
            user.pbReduceHP(damage)
          end
          user.pbFaint if user.isFainted?
        elsif thismove.function==0xC9 || thismove.function==0xCA || thismove.function==0xCB ||
          thismove.function==0xCC || thismove.function==0xCD || thismove.function==0xCE #Sprites for two turn moves
          @battle.scene.pbUnVanishSprite(user)
          if thismove.function==0xCE
            @battle.scene.pbUnVanishSprite(target)
          end
          # Rocky Field Crash
        elsif $fefieldeffect == 14  && (thismove.flags&0x01)!=0 &&
          !isConst?(user.ability,PBAbilities,:ROCKHEAD)
          @battle.pbDisplay(_INTL("{1} hit a rock instead!",user.pbThis))
          damage=[1,(user.totalhp/8).floor].max
          if isConst?(user.ability,PBAbilities,:GORILLATACTICS)
            damage=[1,(user.totalhp/4).floor].max
          end
          damage=user.pbAdjustAbilityRecoilCrashDamage(damage)
          if damage>0
            @battle.scene.pbDamageAnimation(user,0)
            user.pbReduceHP(damage)
          end
          user.pbFaint if user.isFainted?
        elsif $fefieldeffect == 30  && (thismove.flags&0x01)!=0
          @battle.pbDisplay(_INTL("{1} hit a mirror instead!",user.pbThis))
          @battle.pbDisplay(_INTL("The mirror shattered!",user.pbThis))
          damage=[1,(user.totalhp/4).floor].max
          damage=user.pbAdjustAbilityRecoilCrashDamage(damage)
          if damage>0
            @battle.scene.pbDamageAnimation(user,0)
            user.pbReduceHP(damage)
          end
          user.pbFaint if user.isFainted?
        end
        user.pbUseBlunderPolicy

        user.effects[PBEffects::Tantrum]=true
        user.effects[PBEffects::Outrage]=0 if thismove.function==0xD2 # Outrage
        user.effects[PBEffects::Rollout]=0 if thismove.function==0xD3 # Rollout
        user.effects[PBEffects::FuryCutter]=0 if thismove.function==0x91 # Fury Cutter
        user.effects[PBEffects::EchoedVoice]+=1 if thismove.function==0x92 # Echoed Voice
        user.effects[PBEffects::EchoedVoice]=0 if thismove.function!=0x92 # Not Echoed Voice
        user.effects[PBEffects::Stockpile]=0 if thismove.function==0x113 # Spit Up
        return 0
      end
      user.pbUseBlunderPolicy if user.grazed
      if thismove.function==0x91 # Fury Cutter
        #### JERICHO - 011 - START
        user.effects[PBEffects::FuryCutter]+=1 if user.effects[PBEffects::FuryCutter]<3
        #### JERICHO - 011 - END
      else
        user.effects[PBEffects::FuryCutter]=0
      end
      if !thismove.reverbEcho && thismove.function==0x92 # Echoed Voice
        user.effects[PBEffects::EchoedVoice]+=1 if user.effects[PBEffects::EchoedVoice]<5
      elsif !thismove.reverbEcho
        user.effects[PBEffects::EchoedVoice]=0
      end
      if thismove.function==0x247 # Cell Splitter
        user.effects[PBEffects::CellSplitter]+=2 if i==0 # Only increment once per turn, not per hit
      end
      if $fefieldeffect == 5
        if thismove.function==0x171 || thismove.id==53 || thismove.id==268
          user.effects[PBEffects::SusCrit] = true
        end
      end
      # This hit will happen; count it
      realnumhits+=1
      # Damage calculation and/or main effect
      previous_hp=target.hp
      revanish=false
      if target.vanished && !((thismove.function==0xC9 || thismove.function==0xCA || thismove.function==0xCB ||
            thismove.function==0xCC || thismove.function==0xCD) && !user.vanished)
        revanish=true
        revanish=false if thismove.function==0xCE
        revanish=false if thismove.function==0x11C
        revanish=false if (thismove.function==0x10D && !user.pbHasType?(:GHOST)) # Curse
        @battle.scene.pbUnVanishSprite(target) unless (thismove.function==0x10D && !user.pbHasType?(:GHOST)) # Curse
      end
      if thismove.respond_to?(:pixie_tribute_power) && thismove.pixie_tribute_power(user)>0
        damage=thismove.pbPixieTributeEffect(user,target,i,alltargets,showanimation)
      else
        damage=@battle.pbWithIcicleTributeMove(user,thismove) do
          thismove.pbEffect(user,target,i,alltargets,showanimation) # Recoil/drain, etc. are applied here
        end
      end
      if $fefieldeffect == 47 && thismove.isSoundBased? && user.effects[PBEffects::ThroatChop]==0
        user.effects[PBEffects::ThroatChop]=3
        @battle.pbDisplay(_INTL("{1} was silenced!",user.pbThis))
      end
      if isConst?(target.species,PBSpecies,:BASTIODON) && target.hasWorkingItem(:BASTCREST,true)
        if target.damagestate.calcdamage>0 && !target.damagestate.substitute &&
          !user.hasWorkingAbility(:ROCKHEAD) && !user.hasWorkingAbility(:MAGICGUARD) &&
          !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          user.pbReduceHP([1,((target.damagestate.hplost)/2).floor].max)
          target.pbRecoverHP([1,((target.damagestate.hplost)/2).floor].max) if !target.isFainted?
          @battle.pbDisplay(_INTL("{1}'s crest causes {2} to take recoil damage and {3} to recover!",
              target.pbThis,user.pbThis(true),target.pbThis))

        end
      end
      # Bloodthirsty - restore HP when using contact moves
      if damage>0 && user.hasWorkingAbility(:BLOODTHIRSTY) && thismove.isContactMove? &&
         user.hp < user.totalhp && user.effects[PBEffects::HealBlock]==0
        hpgain = user.pbRecoverHP((damage/4).floor,true)
        @battle.pbDisplay(_INTL("{1}'s Bloodthirsty restored its HP!",user.pbThis)) if hpgain>0
      end
      if damage == -1
        user.effects[PBEffects::Tantrum]=true
      else
        user.effects[PBEffects::Tantrum]=false
        thismove.pbApplyDreadHeroicEffect(user,target) if thismove.basedamage<=0
      end
      totaldamage += target.damagestate.calcdamage unless damage <0
      if user.isFainted?
        user.pbFaint # no return
      end
      if revanish && !(target.isFainted?)
        @battle.pbCommonAnimation("Fade out",target,nil)
        @battle.scene.pbVanishSprite(target)
      end
      return if numhits>1 && target.damagestate.calcdamage<=0
      @battle.pbJudgeCheckpoint(user,thismove)
      # Additional effect - skip if attack grazed (missed accuracy but dealt partial damage)
      if target.damagestate.calcdamage>0 && !user.grazed &&
        !(user.hasWorkingAbility(:SHEERFORCE) || @battle.SilvallyCheck(user,PBTypes::GROUND)) &&
        ((!target.hasWorkingAbility(:SHIELDDUST) || target.moldbroken) || thismove.hasFlags?("m"))
        addleffect=thismove.addlEffect
        if ![0x0F,0x10,0x12].include?(thismove.function) && $fefieldeffect == 9
          if user.hasWorkingAbility(:SERENEGRACE)
            addleffect*=4
          else
            addleffect*=2
          end
          # Rainbow Field doubles effect chance for everything and stacks with Serene Grace if the move does NOT flinch.
        else
          addleffect*=2 if user.hasWorkingAbility(:SERENEGRACE) || $fefieldeffect == 9 || @battle.field.effects[PBEffects::Rainbow]>0 || ($fefieldeffect == 13 && (thismove.function==0x00E ||
              thismove.function==0x00D || thismove.function==0x00C))
        end
        addleffect=100 if $DEBUG && Input.press?(Input::CTRL)
        addleffect=100 if thismove.id == 522 && $fefieldeffect == 30
        addleffect=40 if thismove.id == 177 && $fefieldeffect == 40
        addleffect=100 if thismove.id == 182 && $fefieldeffect == 40
        addleffect=100 if thismove.id == 784 && $fefieldeffect == 31
        if thismove.respond_to?(:tribute_attack?) &&
           thismove.tribute_attack?(user,:MINDTRIBUTE) &&
           thismove.heroic_tribute?(user,:VICTINI) &&
           thismove.addlEffect>0
          addleffect = 100
        end
        addleffect=0 if (isConst?(user.species,PBSpecies,:LEDIAN) && user.hasWorkingItem(:LEDICREST) && i>1)
        # Lucky Chant prevents secondary effects
        addleffect=0 if target.pbOwnSide.effects[PBEffects::LuckyChant]>0
        # Grazing blow prevents all secondary effects
        addleffect=0 if target.damagestate.partialhit
        thismove.pbApplyAdditionalEffects(user,target,addleffect) if user==target || !target.hasWorkingItem(:COVERTCLOAK)
        # Meloetta
        if isConst?(self.species, PBSpecies, :MELOETTA) && !self.isFainted? && thismove.id == 286
          if self.form==0
            self.form = 1
          elsif self.form==1
            self.form = 0
          end
          transformed = true
          pbUpdate(false)
          @battle.scene.pbChangePokemon(self,@pokemon)
          if self.form==0
            @battle.pbDisplay(_INTL("{1} transformed into Aria Forme!",pbThis))
          elsif self.form==1
            @battle.pbDisplay(_INTL("{1} transformed into Pirouette Forme!",pbThis))
          end
        end
        # Gulp Missile
        if isConst?(self.species, PBSpecies, :CRAMORANT) && self.hasWorkingAbility(:GULPMISSILE) && !self.isFainted? && (thismove.id == 538 || thismove.id == 541) # Surf or Dive
          if self.form==0
            if ($fefieldeffect == 1 || $fefieldeffect == 17 ||
                $fefieldeffect == 18)
              self.form = 2     # Gorging Form
            elsif ($fefieldeffect == 8 || $fefieldeffect == 21 ||
                $fefieldeffect == 22)
              self.form = 1     # Gulping Form
            else
              if self.hp*2.0 > self.totalhp
                self.form = 1   # Gulping Form
              else
                self.form = 2   # Gorging Form
              end
            end
          end
          transformed = true
          pbUpdate(false)
          @battle.scene.pbChangePokemon(self,@pokemon)
          if self.form==1
            @battle.pbDisplay(_INTL("{1} transformed into Gulping Forme!",pbThis))
          elsif self.form==2
            @battle.pbDisplay(_INTL("{1} transformed into Gorging Forme!",pbThis))
          end
        end
      end
      thismove.pbApplyTributeAdditionalEffect(user,target) if thismove.respond_to?(:pbApplyTributeAdditionalEffect) && target.damagestate.calcdamage>0 && !user.grazed
      # Ability effects
      pbEffectsOnDealingDamage(thismove,user,target,damage,innardsOutHp,previous_hp)
      target.pbRestoreTributePigState if target!=user && target.hp<previous_hp && target.effects[PBEffects::TributeSpookyPig]
      stalwartDamaged ||= damage>0 && !target.damagestate.substitute
      # Mana Echoes - Special attacks deal an additional 1/8th of user's max HP damage
      if user.hasWorkingAbility(:MANAECHOES) && damage>0 && !target.isFainted? &&
         !user.grazed &&
         thismove.pbIsSpecial?(thismove.pbType(thismove.type,user,target))
        echoesdamage = (user.totalhp/8).floor
        echoesdamage = [echoesdamage, target.hp].min
        if echoesdamage > 0
          before_echo=target.hp
          target.pbReduceHP(echoesdamage,true)
          target.faintingMove=[user,thismove,before_echo] if target.isFainted?
          @battle.pbDisplay(_INTL("{1}'s Mana Echoes dealt additional damage!",user.pbThis))
        end
      end
      # Abyssal - Attacks crush during intense gravity
      if user.hasWorkingAbility(:ABYSSAL) && damage>0 && !target.isFainted? &&
         !user.grazed &&
         @battle.field.effects[PBEffects::Gravity] > 0
        if target.pbCanCrush?(false)
          target.pbCrush(user)
          @battle.pbDisplay(_INTL("{1} was crushed by the intense gravity!",target.pbThis))
          target.effects[PBEffects::Crushing] = user.index
        end
      end
      # Berserk
      if !target.isFainted? && aboveHalfHp && target.hp<=(target.totalhp/2).floor
        if target.hasWorkingAbility(:BERSERK)
          increment=([32,39].include?($fefieldeffect)) ? 2 : 1
          boosted=false
          @battle.pbWithStatChangeSource([:ability,target.ability]) do
            for stat in [PBStats::ATTACK,PBStats::SPATK]
              next if !target.pbCanIncreaseStatStage?(stat)
              oldStage=target.stages[stat]
              target.pbIncreaseStatBasic(stat,increment)
              boosted||=target.stages[stat]>oldStage
            end
          end
          if boosted
            @battle.pbCommonAnimation("StatUp",target,nil)
            @battle.pbDisplay(_INTL("{1}'s Berserk boosted its offenses!",
                target.pbThis))
          end
        end
      end
      # Emergency Exit
      if !target.isFainted? && aboveHalfHp && target.hp<=(target.totalhp/2).floor
        if target.hasWorkingAbility(:EMERGENCYEXIT) && ((@battle.pbCanChooseNonActive?(target.index) &&
              !@battle.pbAllFainted?(@battle.pbParty(target.index))) || @battle.pbIsWild?)
          if $fefieldeffect == 44
            if !wimpcheck
              if user.pbCanIncreaseStatStage?(PBStats::SPEED)
                user.pbIncreaseStatBasic(PBStats::SPEED,2)
                @battle.pbCommonAnimation("StatUp",user,nil)
                @battle.pbDisplay(_INTL("Emergency Exit raised #{user.pbThis}'s Speed!"))
              end
              wimpcheck=true
            end
          else
            if !target.isbossmon
              if !wimpcheck
                @battle.pbDisplay(_INTL("{1} tactically retreated!",target.pbThis))
                wimpcheck=true
              end
              @battle.pbClearChoices(target.index)
              if @battle.pbIsWild?
                @battle.decision=3 # Set decision to escaped
              else
                target.userSwitch = true
              end
            end
          end
        end
      end
      # Wimp Out
      if !target.isFainted? && aboveHalfHp && target.hp<=(target.totalhp/2).floor
        if target.hasWorkingAbility(:WIMPOUT) && ((@battle.pbCanChooseNonActive?(target.index) &&
              !@battle.pbAllFainted?(@battle.pbParty(target.index))) || @battle.pbIsWild?)
          if !wimpcheck
            @battle.pbDisplay(_INTL("{1} wimped out!",target.pbThis))
            wimpcheck=true
          end
          if !target.isbossmon
            @battle.pbClearChoices(target.index)
            if @battle.pbIsWild?
              @battle.decision=3 # Set decision to escaped
            else
              target.userSwitch = true
            end
          end
        end
      end
      # Grudge
      if !user.isFainted? && target.isFainted?
        if target.effects[PBEffects::Grudge] && target.pbIsOpposing?(user.index)
          pbSetPP(thismove,thismove.pp=0)
          @battle.pbDisplay(_INTL("{1}'s {2} lost all its PP due to the grudge!",
              user.pbThis,thismove.name))
        end
      end
      # gen8 items
      if user.hasWorkingItem(:THROATSPRAY) && thismove.isSoundBased? && user.hp>0
        user.pbUseHitStatItem(:THROATSPRAY,[PBStats::SPATK])
      end
      # Reverb - Sound moves strike again next turn at 0.25x power
      if !thismove.reverbEcho && user.hasWorkingAbility(:REVERB) &&
         thismove.isSoundBased? && thismove.basedamage>0 && damage>0
        echoes=user.effects[PBEffects::ReverbEcho]
        @battle.pbDisplay(_INTL("{1}'s sound echoed!",user.pbThis)) if !echoes.key?(thismove.id)
        echoes[thismove.id] ||= []
        echoes[thismove.id].push(target.index) if !echoes[thismove.id].include?(target.index)
      end
      if target.hasWorkingItem(:EJECTPACK) && target.statLowered
        if !target.isFainted? && @battle.pbCanChooseNonActive?(target.index) &&
          !@battle.pbAllFainted?(@battle.pbParty(target.index))
          @battle.pbDisplay(_INTL("#{target.pbThis}'s Eject Pack activates!"))
          target.pbUseConsumableHeldItem
          @battle.pbClearChoices(target.index)
          target.userSwitch = true
        end
      end
      if target.isFainted?
        destinybond=destinybond || target.effects[PBEffects::DestinyBond]
        #        target.pbFaint # no return
      end
      user.pbFaint if user.isFainted? # no return
      break if user.isFainted?
      break if target.isFainted?
      # Make the target flinch
      if target.damagestate.calcdamage>0 && !target.damagestate.substitute && !target.hasWorkingItem(:COVERTCLOAK)
        if !isConst?(target.ability,PBAbilities,:SHIELDDUST) || target.moldbroken || thismove.hasFlags?("m")
          if user.hasWorkingItem(:RAZORFANG) &&
            thismove.canKingsRock? && target.status!=PBStatuses::SLEEP #pk code
            if @battle.pbRandom(10)==0
              target.effects[PBEffects::Flinch]=true
            end
          end
        end
      end
      if target.damagestate.calcdamage>0 && !target.isFainted?
        # Defrost
        if isConst?(thismove.pbType(thismove.type,user,target),PBTypes,:FIRE) &&
          target.status==PBStatuses::FROZEN
          target.pbCureStatus
        elsif thismove.name=="Scald" && target.status==PBStatuses::FROZEN
          target.pbCureStatus
        end
        if user.hasWorkingAbility(:HYPERCUTTER) && target.hp>0 &&
           target.effects[PBEffects::Wounded]==0 && !target.damagestate.substitute &&
           target.pbApplyGrievousWounds(3)
          @battle.pbDisplay(_INTL("{1} was wounded!",target.pbThis))
        end
        # Fever Pitch
        if target.effects[PBEffects::Rage] && target.pbIsOpposing?(user.index)
          [PBStats::ATTACK,PBStats::SPATK].each do |stat|
            target.pbIncreaseStat(stat,1,false,PBMoves::RAGE,target) if target.pbCanIncreaseStatStage?(stat,false)
          end
        end
      end
      #      target.pbFaint if target.isFainted? # no return
      user.pbFaint if user.isFainted? # no return
      break if user.isFainted?
      break if target.isFainted?
      # Berry check (maybe just called by ability effect, since only necessary Berries are checked)
      for j in 0...4
        @battle.battlers[j].pbBerryCureCheck
      end
      target.pbUpdateTargetedMove(thismove,user)
      break if target.damagestate.calcdamage<=0
    end
    recklessfunctions = [0xFA,0xFB,0xFC,0xFD,0xFE,0x10B,0x130,0x3CD,0xBB9,0xBBA]
    if user.grazed && recklessfunctions.include?(thismove.function)
      @battle.pbDisplay(_INTL("{1} kept going and crashed!",user.pbThis))
      damage=[1,(user.totalhp/2).floor].max
      damage=user.pbAdjustAbilityRecoilCrashDamage(damage)
      if damage>0
        @battle.scene.pbDamageAnimation(user,0)
        user.pbReduceHP(damage)
      end
      user.pbFaint if user.isFainted?
    end
    if totaldamage>0
      turneffects[PBEffects::TotalDamage]+=totaldamage
    end
    # Battle Arena only - attack is successful
    @battle.successStates[user.index].useState=2
    @battle.successStates[user.index].typemod=target.damagestate.typemod
    # Type effectiveness
    if numhits>1
      if target.damagestate.typemod>4
        @battle.pbDisplay(_INTL("It's super effective!"))
      elsif target.damagestate.typemod>=1 && target.damagestate.typemod<4
        @battle.pbDisplay(_INTL("It's not very effective..."))
      end
      if realnumhits==1
        @battle.pbDisplay(_INTL("Hit {1} time!",realnumhits))
      else
        @battle.pbDisplay(_INTL("Hit {1} times!",realnumhits))
      end
    end
    if ($fefieldeffect == 24 && target.isFainted? && thismove.function==0xC2)
      @effects[PBEffects::HyperBeam] = 0
    end
    if ($fefieldeffect == 34 && thismove.id==788)
      @effects[PBEffects::HyperBeam] = 0
    end
    if stalwartDamaged && target.hasWorkingAbility(:STALWART) && !target.moldbroken
      if target.effects[PBEffects::StalwartMove]==thismove.id
        target.effects[PBEffects::StalwartStacks]+=1
      else
        target.effects[PBEffects::StalwartMove]=thismove.id
        target.effects[PBEffects::StalwartStacks]=1
      end
    end
    # Faint if 0 HP
    target.pbFaint if target.isFainted?
    user.pbFaint if user.isFainted? # no return
    # TODO: If Poison Point, etc. triggered above, user's Synchronize somehow triggers
    #       here even if condition is removed before now [true except for Triple Kick]
    # Destiny Bond
    if !user.isFainted? && target.isFainted?
      if destinybond && target.pbIsOpposing?(user.index)
        @battle.pbDisplay(_INTL("{1} took its attacker down with it!",target.pbThis))
        user.pbReduceHP(user.hp)
        user.pbFaint # no return
        @battle.pbJudgeCheckpoint(user)
      end
    end
    # Berry check
    @battle.eachActiveBattlerIndex do |index|
      @battle.battlers[index].pbBerryCureCheck
    end
    target.pbUpdateTargetedMove(thismove,user)
    if realnumhits != numhits && (thismove.name=="Thunder Raid")
      @battle.pbCommonAnimation("Failsafe",self,nil)
      @battle.scene.pbUnVanishSprite(self)
    end
    return damage
  ensure
    if target
      target.corroded=previously_corroded
      target.moldbroken=previously_moldbroken
    end
  end

  def pbTriggerSteadfastBoost
    return if !self.hasWorkingAbility(:STEADFAST)
    contributors=@effects[PBEffects::StatCapContributors]
    next_source=(0...3).map { |occurrence| [:ability,ability,occurrence] }.find do |source|
      !contributors.key?(source)
    end
    @battle.pbWithStatChangeSource(next_source || [:ability,ability,0]) do
      if pbIncreaseStat(PBStats::SPEED,1,false,nil,nil,true,false,false)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!",pbThis,PBAbilities.getName(ability)))
      end
    end
  end

  def pbTakeLiquidOozeDamage(amount)
    amount*=2 if [19,26,41].include?($fefieldeffect)
    pbReduceHP(amount,true)
    @battle.pbDisplay(_INTL("{1} sucked up the liquid ooze!",pbThis))
    if @effects[PBEffects::Wounded]==0 && pbApplyGrievousWounds(3)
      @battle.pbDisplay(_INTL("{1} was wounded!",pbThis))
    end
  end

  def pbClearMultiTurn
    binding_word=@effects[PBEffects::MultiTurnAttack]==PBMoves::BINDINGWORD
    gas_suppressed=binding_word && @ability==PBAbilities::NEUTRALIZINGGAS &&
      !@battle.pbCheckGlobalAbility(:NEUTRALIZINGGAS)
    @effects[PBEffects::MultiTurn]=0
    @effects[PBEffects::MultiTurnAttack]=0
    @effects[PBEffects::MultiTurnUser]=-1
    @effects[PBEffects::MultiTurnBindingBand]=false
    return unless binding_word
    stat_changes=@effects[PBEffects::StatChangeHolder]
    [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,PBStats::SPATK,PBStats::SPDEF,
      PBStats::ACCURACY,PBStats::EVASION].each do |stat|
      @stages[stat]=stat_changes[stat]
      stat_changes[stat]=0
    end
    @battle.pbNeutralizingGasStarted if gas_suppressed && hasWorkingAbility(:NEUTRALIZINGGAS)
  end

  def pbClearPropellerTailEffects
    changed=false
    if @effects[PBEffects::MultiTurn]>0
      pbClearMultiTurn
      changed=true
    end
    for effect in [PBEffects::MeanLook,PBEffects::LeechSeed]
      next if @effects[effect]<0
      @effects[effect]=-1
      changed=true
    end
    if @effects[PBEffects::JawLock]
      source=@battle.battlers[@effects[PBEffects::JawLockUser]] if @effects[PBEffects::JawLockUser]>=0
      if source && source.effects[PBEffects::JawLockUser]==@index
        source.effects[PBEffects::JawLock]=false
        source.effects[PBEffects::JawLockUser]=-1
      end
      @effects[PBEffects::JawLock]=false
      @effects[PBEffects::JawLockUser]=-1
      changed=true
    end
    for effect in [PBEffects::StealthRock,PBEffects::StickyWeb]
      next if !pbOwnSide.effects[effect]
      pbOwnSide.effects[effect]=false
      changed=true
    end
    for effect in [PBEffects::Spikes,PBEffects::ToxicSpikes,PBEffects::Caltrops]
      next if pbOwnSide.effects[effect]<=0
      pbOwnSide.effects[effect]=0
      changed=true
    end
    if changed
      @battle.pbDisplay(_INTL("{1}'s Propeller Tail cleared hazards and traps!",pbThis))
    end
  end

  def pbUseMoveSimple(moveid,index=-1,target=-1,danced=false)
    choice=[]
    choice[0]=1       # "Use move"
    choice[1]=index   # Index of move to be used in user's moveset
    choice[2]=PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(moveid),self) # PokeBattle_Move object of the move
    choice[2].pp=-1
    choice[3]=target  # Target (-1 means no target yet)
    @simplemove=true
    if index>=0
      @battle.choices[@index][1]=index
    end
    @usingsubmove=true
    side=(@battle.pbIsOpposing?(self.index)) ? 1 : 0
    owner=@battle.pbGetOwnerIndex(self.index)
    if @battle.zMove[side][owner]==self.index
      crystal = pbZCrystalFromType(choice[2].type)
      PokeBattle_ZMoves.new(@battle,self,choice[2],crystal,choice)
    else
      pbUseMove(choice,true,danced,moveid)
    end
    @usingsubmove=false
    @simplemove=false
    return
  end

  def pbDancerMoveCheck(id)
    dancemoves = [17,63,138,170,192,418,420,483,721]
    if $fefieldeffect == 6 # Big Top
      if self.hasWorkingAbility(:DANCER)
        for i in dancemoves
          if id == i
            boost=false
            if !pbTooHigh?(PBStats::SPATK)
              pbIncreaseStatBasic(PBStats::SPATK,1)
              @battle.pbCommonAnimation("StatUp",self,nil) if !boost
              boost=true
            end
            if !pbTooHigh?(PBStats::SPEED)
              pbIncreaseStatBasic(PBStats::SPEED,1)
              @battle.pbCommonAnimation("StatUp",self,nil) if !boost
              boost=true
            end
            if boost
              @battle.pbDisplay(_INTL("{1}'s Dancer boosted its Special Attack and Speed!",
                  pbThis))
            end
          end
        end
      end
    end
    for i in @battle.battlers
      next if i == self
      for j in dancemoves
        if id == j
          if i.hasWorkingAbility(:DANCER)
            @battle.pbDisplay(_INTL("{1} joined in with the dance!",i.pbThis))
            i.pbUseMoveSimple(id,-1,-1,true)
            i.effects[PBEffects::Outrage]=0
          end
        end
      end
    end
  end

  def pbUseMove(choice,specialusage=false,danced=false,moveid=choice[2].id)
    previous_icicle_bypass=@battle.icicleTributeBypass
    @battle.icicleTributeBypass=false
    @effects[PBEffects::LiminalAttackThisMove]=false
    @liminal_status_this_move=false
    # TODO: lastMoveUsed is not to be updated on nested calls
    turneffects=[]
    turneffects[PBEffects::SpecialUsage]=specialusage
    turneffects[PBEffects::PassedTrying]=false
    turneffects[PBEffects::TotalDamage]=0
    # Start using the move
    pbBeginTurn(choice)
    spooky_release=pbSpookyTributeVanished?(self)
    # Force the use of certain moves if they're already being used
    if @effects[PBEffects::TwoTurnAttack]>0 ||
      @effects[PBEffects::HyperBeam]>0 ||
      @effects[PBEffects::Outrage]>0 ||
      @effects[PBEffects::Rollout]>0 ||
      (@effects[PBEffects::SkyDroppee] && @effects[PBEffects::SkyDroppee] != -1) ||
      @effects[PBEffects::Uproar]>0
      PBDebug.log("[Continuing move]") if $INTERNAL
      continued=@moves[0] if spooky_release || @tributeDracoActive
      continued=nil if continued && continued.id!=@currentMove
      choice[2]=continued || (PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(@currentMove),self) rescue nil)
      if spooky_release && @spookyTributeLane
        choice[3]=@spookyTributeLane
      end
      moveid=choice[2].id if continued
      turneffects[PBEffects::SpecialUsage]=true
      self.lastRoundMoved=@battle.turncount
    elsif @effects[PBEffects::Encore]>0
      if @battle.pbCanShowCommands?(@index) &&
        @battle.pbCanChooseMove?(@index,@effects[PBEffects::EncoreIndex],false)
        PBDebug.log("[Using Encore move]") if $INTERNAL
        if choice[1]!=@effects[PBEffects::EncoreIndex] # Was Encored mid-round
          choice[1]=@effects[PBEffects::EncoreIndex]
          choice[2]=@moves[@effects[PBEffects::EncoreIndex]]
          choice[3]=-1 # No target chosen
        end
        self.lastRoundMoved=@battle.turncount
      end
    end
    thismove=choice[2]
    return if !thismove || thismove.id==0 # if move was not chosen
    if @tributeDracoActive && thismove.equal?(@tributeDracoBattleMove) && !hasWorkingItem(:DRACOTRIBUTE)
      @battle.pbDisplay(_INTL("{1}'s Draco Tribute can't be used!",pbThis))
      self.lastRoundMoved=@battle.turncount
      pbCancelMoves
      pbEndTurn(choice)
      return
    end
    if !turneffects[PBEffects::SpecialUsage] && thismove.tribute_attack?(self,:STONETRIBUTE) &&
       thismove.heroic_tribute?(self,:RAMPARDOS) && !@battle.pbTributeOnceUsed?(@pokemon,:stone_priority)
      tribute_rampardos=@pokemon
    end
    if !turneffects[PBEffects::SpecialUsage]
      # TODO: Quick Claw message
    end
    # TODO: Record that self has moved this round (for Payback, etc.)
    # Stance Change goes here
    # Try to use the move
    #return false if self.effects[PBEffects::SkyDrop]
    if !pbTryUseMove(choice,thismove,turneffects)
      if self.vanished
        @battle.scene.pbUnVanishSprite(self)
        droprelease = self.effects[PBEffects::SkyDroppee]
        if droprelease!=nil && droprelease!=-1
          oppmon = @battle.battlers[droprelease]
          if oppmon
            oppmon.effects[PBEffects::SkyDrop]=false
            @battle.scene.pbUnVanishSprite(oppmon)
            @battle.pbDisplay(_INTL("{1} is freed from the Sky Drop effect!",oppmon.pbThis))
          end
        end
      end
      self.lastMoveUsed=-1
      if !turneffects[PBEffects::SpecialUsage]
        self.lastMoveUsedSketch=-1 if self.effects[PBEffects::TwoTurnAttack]==0
        self.lastRegularMoveUsed=-1
        self.lastRoundMoved=@battle.turncount
      end
      pbCancelMoves
      @battle.pbGainEXP
      pbEndTurn(choice)
      @battle.pbJudgeSwitch
      return
    end
    if !turneffects[PBEffects::SpecialUsage]
      if !pbReducePP(thismove)
        @battle.pbDisplay(_INTL("{1} used\r\n{2}!",pbThis,thismove.name))
        @battle.pbDisplay(_INTL("But there was no PP left for the move!"))
        self.lastMoveUsed=-1
        if !turneffects[PBEffects::SpecialUsage]
          self.lastMoveUsedSketch=-1 if self.effects[PBEffects::TwoTurnAttack]==0
          self.lastRegularMoveUsed=-1
          self.lastRoundMoved=@battle.turncount
        end
        pbEndTurn(choice)
        @battle.pbJudgeSwitch
        return
      end
    end
    @effects[PBEffects::UsedAttackThisTurn]=true if thismove.basedamage>0
    if self.hasWorkingAbility(:LIMINAL)
      if thismove.basedamage==0 && thismove.pixie_tribute_power(self)<=0
        @liminal_status_this_move=true
        @effects[PBEffects::LiminalAttackBoost]=true
      else
        @effects[PBEffects::LiminalAttackThisMove]=@effects[PBEffects::LiminalAttackBoost]
        @effects[PBEffects::LiminalAttackBoost]=false
        @effects[PBEffects::LiminalStatusPriority]=true
      end
    end
    if thismove.function!=0x92 # Echoed Voice
      self.effects[PBEffects::EchoedVoice]=0
    end
    if thismove.function!=0x91 # Fury Cutter
      self.effects[PBEffects::FuryCutter]=0
    end
    #### KUROTSUNE - 023 - START
    if @effects[PBEffects::Powder] && isConst?(thismove.type,PBTypes,:FIRE)
      @battle.pbDisplay(_INTL("The powder around {1} exploded!",pbThis))
      pbReduceHP((@totalhp/4).floor)
      pbFaint if @hp<1
      return false if @hp<1
    end
    #### KUROTSUNE - 023 - END
    # Remember that user chose a two-turn move
    native_charge=thismove.pbTwoTurnAttack(self) unless spooky_release
    spooky_charge=!spooky_release && thismove.spooky_tribute_active?(self)
    if spooky_release
      @effects[PBEffects::SpookyTribute]=3
      @spookyTributeLane=nil
      @battle.scene.pbUnVanishSprite(self) if vanished && thismove.function!=0xCE
    elsif spooky_charge
      @effects[PBEffects::SpookyTribute]=2
    end
    if spooky_charge || native_charge
      # Beginning use of two-turn attack
      @effects[PBEffects::TwoTurnAttack]=thismove.id
      @currentMove=thismove.id
      if self.hasWorkingAbility(:EARLYBIRD)
        @effects[PBEffects::EarlyBirdBoost]=2
      end
    else
      @effects[PBEffects::TwoTurnAttack]=0 # Cancel use of two-turn attack
      @effects[PBEffects::SkyDroppee] = nil
    end
    # "X used Y!" message
    if !spooky_charge && thismove.pbDisplayUseMessage(self)==-1 # Focus Punch lost its focus
      self.lastMoveUsed=thismove.id
      if !turneffects[PBEffects::SpecialUsage]
        self.lastMoveUsedSketch=thismove.id if self.effects[PBEffects::TwoTurnAttack]==0
        self.lastRegularMoveUsed=thismove.id
        self.movesUsed.push(thismove.id)   # For Last Resort
        self.lastRoundMoved=@battle.turncount
      end
      @battle.lastMoveUsed=thismove.id
      @battle.lastMoveUser=self.index
      @battle.successStates[self.index].useState=2 # somehow treated as a success
      @battle.successStates[self.index].typemod=4
      pbEndTurn(choice) if @tributeDracoActive
      return
    end
    # Find the user and target(s)
    targets=[]
    user=pbFindUser(choice,targets,moveid)
    tribute_hit_targets=[]
    tribute_pre_stages = user ? user.stages.clone : nil
    tribute_status_context=thismove.pbTributeStatusContext(user)
    # Battle Arena only - assume failure
    @battle.successStates[user.index].useState=1
    @battle.successStates[user.index].typemod=4
    # Check whether Selfdestruct works
    selffaint=(thismove.function==0xE0) # Selfdestruct
    thismove.azureInquisitionBoost=false
    if !thismove.pixie_replaces_effect?(user) && (!spooky_charge || native_charge) && !thismove.pbOnStartUse(user)
      user.lastMoveUsed=thismove.id
      if !turneffects[PBEffects::SpecialUsage]
        user.lastMoveUsedSketch=thismove.id if user.effects[PBEffects::TwoTurnAttack]==0
        user.lastRegularMoveUsed=thismove.id
        user.movesUsed.push(thismove.id)   # For Last Resort
        user.lastRoundMoved=@battle.turncount
      end
      @battle.lastMoveUsed=thismove.id
      @battle.lastMoveUser=user.index
      if spooky_charge || spooky_release || @tributeDracoActive
        pbCancelMoves
        pbEndTurn(choice)
      end
      # Might pbEndTurn need to be called here?
      return
    end
    if spooky_charge
      @spookyTributeLane=targets.first&.index
      self.lastMoveUsed=thismove.id
      self.lastRegularMoveUsed=thismove.id
      self.movesUsed.push(thismove.id)
      self.lastRoundMoved=@battle.turncount
      @battle.lastMoveUsed=thismove.id
      @battle.lastMoveUser=@index
      thismove.pbApplyTributeSelectionEffect(self,targets)
      thismove.pbEffect(self,targets.first,0,targets.map(&:index)) if native_charge && targets.first
      if @effects[PBEffects::TwoTurnAttack]>0
        thismove.pbHandleSpookyTributeCharge(self)
      else
        pbCancelMoves
      end
      pbEndTurn(choice)
      @battle.pbJudgeSwitch
      return
    end
    if !turneffects[PBEffects::SpecialUsage]
      move_type=targets.empty? ? thismove.type : thismove.pbType(thismove.type,user,targets.first)
      user.moveHistory.push([@battle.turncount,thismove.id,move_type])
      user.moveHistory.shift if user.moveHistory.length>PBMoves.maxValue
    end
    thismove.natural_order_boost=false
    thismove.fertilize_boost=false
    if thismove.basedamage>0 && !targets.empty?
      thismove.natural_order_boost=user.effects[PBEffects::NaturalOrder]>0
      user.effects[PBEffects::NaturalOrder]=0
      if user.effects[PBEffects::Fertilize] &&
         targets.any? { |target| thismove.pbType(thismove.type,user,target)==PBTypes::GRASS }
        thismove.fertilize_boost=true
        user.effects[PBEffects::Fertilize]=false
      end
    end
    thismove.gem_item_used=nil
    thismove.defense_curl_boost=false
    thismove.battle_cry_boost=false
    if thismove.basedamage>0 && user.effects[PBEffects::TwoTurnAttack]==0 &&
       user.pbOwnSide.effects[PBEffects::BattleCry]>0
      thismove.battle_cry_boost=true
      user.pbOwnSide.effects[PBEffects::BattleCry]=0
    end
    if thismove.function!=0x247
      user.effects[PBEffects::CellSplitter]=0
    end
    thismove.lock_on_boost=user.effects[PBEffects::LockOnMove]
    user.effects[PBEffects::LockOnMove]=false
    if thismove.basedamage>0 && PBStuff::MOMENTUMMOVE.include?(thismove.id) && user.effects[PBEffects::DefenseCurl]
      thismove.defense_curl_boost=true
      user.effects[PBEffects::DefenseCurl]=false
    end
    if user.hasWorkingAbility(:PROPELLERTAIL) && PBStuff::MOMENTUMMOVE.include?(thismove.id)
      user.pbClearPropellerTailEffects
    end
    if selffaint
      user.hp=0
      user.pbFaint # no return
    end
    # Advance the repeat counter once per move, including spread and multihit moves.
    user.effects[PBEffects::Metronome]=user.pbNextRepeatCount(thismove.id)
    # Record move as having been used
    thismove.azureAbilityCharge=false
    if user.effects[PBEffects::AbilityCharge] && thismove.basedamage>0 && user.effects[PBEffects::TwoTurnAttack]==0
      charge_target=targets.first || user
      charge_type=thismove.pbType(thismove.type,user,charge_target)
      if charge_type==PBTypes::ELECTRIC
        thismove.azureAbilityCharge=true
        user.effects[PBEffects::AbilityCharge]=false
        user.effects[PBEffects::Charge]=false
      end
    end
    if @battle.pbOwnedByPlayer?(user.index)
      $game_variables[530] += 1
    end
    user.lastMoveUsed=thismove.id
    if thismove.basedamage>0 && thismove.isContactMove? && user.effects[PBEffects::Inquisition]
      thismove.azureInquisitionBoost=true
      user.effects[PBEffects::Inquisition]=false
    end
    if !turneffects[PBEffects::SpecialUsage]
      user.lastMoveUsedSketch=thismove.id
      user.lastRegularMoveUsed=thismove.id
      user.movesUsed.push(thismove.id)   # For Last Resort
      user.lastRoundMoved=@battle.turncount
    end
    @battle.lastMoveUsed=thismove.id
    @battle.lastMoveUser=user.index
    thismove.pbBeginTributeAttack(user)
    thismove.pbApplyTributeSelectionEffect(user,targets)
    # Try to use move against user if there aren't any targets
    if targets.length==0 && !(@effects[PBEffects::TwoTurnAttack]>0)
      user=pbChangeUser(thismove,user)
      tribute_move_resolved=false
      if thismove.id==PBMoves::MINIMIZE || thismove.target==PBTargets::SingleNonUser ||
        thismove.target==PBTargets::RandomOpposing ||
        thismove.target==PBTargets::AllOpposing ||
        thismove.target==PBTargets::AllNonUsers ||
        thismove.target==PBTargets::Partner ||
        thismove.target==PBTargets::UserOrPartner ||
        thismove.target==PBTargets::SingleOpposing ||
        thismove.target==PBTargets::OppositeOpposing
        @battle.pbDisplay(_INTL("But there was no target..."))
        if thismove.function==0xC9 || thismove.function==0xCA || thismove.function==0xCB ||
          thismove.function==0xCC || thismove.function==0xCD || thismove.function==0xCE #Sprites for two turn moves
          @battle.scene.pbUnVanishSprite(user)
        end
      else
        PBDebug.logonerr{
          @battle.pbWithIcicleTributeMove(user,thismove) { thismove.pbEffect(user,nil) }
          tribute_move_resolved=true
        }
      end
      flashed=false
      # Misc Field Effects 1
      case $fefieldeffect
      when 33 # Flower Garden Stages
        tempcounter = $fecounter
        if (thismove.id == PBMoves::GROWTH ||
            thismove.id == PBMoves::FLOWERSHIELD ||
            thismove.id == PBMoves::RAINDANCE ||
            thismove.id == PBMoves::SUNNYDAY ||
            thismove.id == PBMoves::ROTOTILLER ||
            thismove.id == PBMoves::INGRAIN)
          $fecounter+=1 if $fecounter < 4
          if user.hasWorkingAbility(:RIPEN)
            $fecounter+=1 if $fecounter < 4
          end
        end
      end
      # FIELD TRANSFORMATIONS 1
      case $fefieldeffect
      when 3 # Misty Field
        if (thismove.id == PBMoves::TAILWIND)
          if $fefieldeffect == $febackup
            $fefieldeffect = 0
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mist was blown away!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
      when 4 # Dark Crystal Cavern
        if (thismove.id == PBMoves::SUNNYDAY)
          $fefieldeffect = 25
          @effects[PBEffects::Terrain] = @battle.weatherduration
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The sun lit up the crystal cavern!"))
          @battle.seedCheck
        end
      when 11 # Corrosive Mist Field
        if (thismove.id == PBMoves::TAILWIND)
          if $fefieldeffect == $febackup
            $fefieldeffect = 0
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mist was blown away!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::GRAVITY)
          $fefieldeffect = 10
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The toxic mist collected on the ground!"))
          @battle.seedCheck
        end
      when 21 # Water Surface
        if (thismove.id == PBMoves::GRAVITY)
          $fefieldeffect = 22
          $febackup = 22
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle sank into the depths!"))
          @battle.seedCheck
        end
      when 29 # Holy
        if (thismove.id == PBMoves::CURSE && (isConst?(user.type1,PBTypes,:GHOST) || isConst?(user.type2,PBTypes,:GHOST))  || thismove.id == PBMoves::TRICKORTREAT)
          $febackup = 40
          $fefieldeffect = 40
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("Evil spirits gathered!"))
          @battle.seedCheck
        end
      when 33 # Flower Garden Field
        if tempcounter < $fecounter
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The garden grew a little bit!"))
        end
      when 35 # New World
        if (thismove.id == PBMoves::GRAVITY)
          $fefieldeffect = 34
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The world's matter reformed!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::GEOMANCY)
          $fefieldeffect = 34
          $febackup = 34
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The world was regenerated!"))
          @battle.seedCheck
        end
      when 40 # Haunted
        if (thismove.id == PBMoves::PURIFY)
          if $fefieldeffect == $febackup
            $fefieldeffect = 29
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The evil spirits have been exorcised!"))
          @battle.seedCheck
        end
      when 41 # Corrupted cave
        if thismove.id == PBMoves::PURIFY
          if $fefieldeffect == $febackup
            $fefieldeffect = 23
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The cave was purified!"))
          @battle.seedCheck
        end
      when 42 # Bewitched woods
        if (thismove.id == PBMoves::PURIFY)
          if $fefieldeffect == $febackup
            $fefieldeffect = 15
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The evil spirits have been exorcised!"))
          @battle.seedCheck
        end
      when 43 # Sky Field
        if (thismove.id == PBMoves::GRAVITY || thismove.id == PBMoves::INGRAIN)
          $fefieldeffect = 27
          $febackup = 27
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle has been brought down to the mountains!"))
          @battle.seedCheck
        end
      when 45 # Infernal Field
        if thismove.id == PBMoves::PURIFY
          $fefieldeffect = 7
          $febackup = 7
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The hellish flames were purified!"))
          @battle.seedCheck
        end
      end
      #End Field Transformations
      if tribute_move_resolved
        thismove.pbApplyTributeAfterMove(user,targets,turneffects[PBEffects::TotalDamage],tribute_pre_stages,tribute_status_context,
          hit_targets: tribute_hit_targets)
      end
      unless !thismove
        pbDancerMoveCheck(thismove.id) unless danced
      end
    else
      # We have targets
      showanimation=true
      alltargets=[]
      if @effects[PBEffects::TwoTurnAttack]>0 && targets.length==0
        numhits=thismove.pbNumHits(user)
        pbProcessMoveAgainstTarget(thismove,user,nil,numhits,turneffects,false,alltargets,showanimation)
      end
      for i in 0...targets.length
        alltargets.push(targets[i].index)
      end
      thismove.spread_target_count=alltargets.length
      # For each target in turn
      i=0; loop do break if i>=targets.length
        # Get next target
        userandtarget=[user,targets[i]]
        success=pbChangeTarget(thismove,userandtarget,targets)
        user=userandtarget[0]
        target=userandtarget[1]
        # If couldn't get the next target
        if !success
          i+=1
          next
        end
        numhits=thismove.pbNumHits(user)
        if (thismove.flags&0x04)==0 && numhits<2
          if user.isbossmon && @battle.pbIsOpposing?(user.index)
            numhits = [$game_variables[699],1].max
          end
          if isConst?(user.species,PBSpecies,:LEDIAN) && user.hasWorkingItem(:LEDICREST) &&
            thismove.isPunchingMove?
            numhits = 4
          end
          if isConst?(user.species,PBSpecies,:CINCCINO) && user.hasWorkingItem(:CINCCREST) &&
            !thismove.pbIsMultiHit
            hitchances=[2,2,3,3,4,5]
            ret=hitchances[@battle.pbRandom(hitchances.length)]
            ret=5 if user.ability == PBAbilities::SKILLLINK
            numhits = ret
          end
        end
        #### KUROTSUNE - 004 - START
        if numhits == 1 && user.hasWorkingAbility(:PARENTALBOND)
          counter1=0
          counter2=0
          for k in @battle.battlers
            next if k.isFainted?
            counter1+=1
          end
          for j in @battle.battlers
            next unless user.pbIsOpposing?(j.index)
            next if j.isFainted?
            counter2+=1
          end
          user.effects[PBEffects::ParentalBond] = true unless ((thismove.target == PBTargets::AllNonUsers && !(counter1==2)) || (thismove.target == PBTargets::AllOpposing && !(counter2==1)))
          numhits = 2  unless ((thismove.target == PBTargets::AllNonUsers && !(counter1==2)) || (thismove.target == PBTargets::AllOpposing && !(counter2==1)))
        else
          user.effects[PBEffects::ParentalBond] = false
        end
        #### KUROTSUNE - 004 - END
        if numhits == 1 && thismove.isContactMove? &&
          isConst?(user.species,PBSpecies,:TYPHLOSION) && user.hasWorkingItem(:TYPHCREST)
          counter1=0
          counter2=0
          for k in @battle.battlers
            next if k.isFainted?
            counter1+=1
          end
          for j in @battle.battlers
            next unless user.pbIsOpposing?(j.index)
            next if j.isFainted?
            counter2+=1
          end
          user.effects[PBEffects::TyphBond] = true unless ((thismove.target == PBTargets::AllNonUsers && !(counter1==2)) || (thismove.target == PBTargets::AllOpposing && !(counter2==1)))
          numhits = 2  unless ((thismove.target == PBTargets::AllNonUsers && !(counter1==2)) || (thismove.target == PBTargets::AllOpposing && !(counter2==1)))
        else
          user.effects[PBEffects::TyphBond] = false
        end
        target.pbPrepareMoveDamageState
        target_hp=target.hp

        # Use move against the current target
        hitcheck=user.pbWithDracoTributeSelfDrops(thismove,target) do
          if thismove.id==PBMoves::PYROCLASM
            @battle.field.effects[PBEffects::PyroPreTarget]=i>0 ? targets[i-1].index : user.index
            begin
              thismove.pbDisplayUseMessage(user,target)
              pbProcessMoveAgainstTarget(thismove,user,target,1,turneffects,!user.pbIsOpposing?(target.index),alltargets,true)
            ensure
              @battle.field.effects[PBEffects::PyroPreTarget]=-1
            end
          else
            pbProcessMoveAgainstTarget(thismove,user,target,numhits,turneffects,false,alltargets,showanimation)
          end
        end
        tribute_hit_targets.push(target) if target.hp<target_hp && !tribute_hit_targets.include?(target)
        break if user.isFainted? && !selffaint
        showanimation=false unless (hitcheck==0 && (thismove.pbIsSpecial?(thismove.type) || thismove.pbIsPhysical?(thismove.type)))
        if thismove.function==0x15E && hitcheck>0
          @battle.pbDisplay(_INTL("{1} was burnt out!",self.pbThis))
        end
       # Probopass Crest
        if isConst?(user.species,PBSpecies,:PROBOPASS) && user.hasWorkingItem(:PROBOCREST)
          if thismove.basedamage > 0 && thismove.id != PBMoves::PROBOPOG
            move=getConst(PBMoves,:PROBOPOG) || 0
            movename=PBMoves.getName(move)
            @battle.pbDisplay(_INTL("{1}'s mini noses followed up on the attack!",user.pbThis))
            if thismove.target==PBTargets::AllOpposing || thismove.target==PBTargets::AllNonUsers
              movetarget=user.pbOppositeOpposing
            else
              movetarget=target
            end
            user.pbUseMoveSimple(move,-1,movetarget)
          end
        end
        i+=1
      end
      thismove.spread_target_count=nil
      # Misc Field Effects 2
      case $fefieldeffect
      when 11 # Corrosive Mist Combustion
        if (thismove.id == PBMoves::HEATWAVE ||
            thismove.id == PBMoves::LAVAPLUME ||
            thismove.id == PBMoves::FLAMEBURST ||
            thismove.id == PBMoves::SEARINGSHOT ||
            thismove.id == PBMoves::SELFDESTRUCT ||
            thismove.id == PBMoves::EXPLOSION ||
            thismove.id == PBMoves::ERUPTION ||
            thismove.id == PBMoves::FIREPLEDGE)
          dampcheck=0
          @battle.eachActiveBattlerIndex do |i|
            battler = @battle.battlers[i]
            next if !battler
            dampcheck = 1 if (!battler.abilitynulled && battler.ability == PBAbilities::DAMP)
          end
          if dampcheck == 0
            @battle.eachActiveBattlerIndex do |i|
              battler = @battle.battlers[i]
              next if !battler
              combust = battler.hp
              next if combust==0
              invulcheck=PBMoveData.new(battler.effects[PBEffects::TwoTurnAttack]).function
              case invulcheck
              when 0xC9, 0xCC, 0xCA, 0xCB, 0xCD, 0xCE
                combust = 0
              end
              combust =0 if battler.effects[PBEffects::SkyDrop]
              combust-=1 if battler.hasWorkingAbility(:STURDY)
              combust =0 if battler.hasWorkingAbility(:FLASHFIRE)
              if battler.isbossmon && @battle.shieldCount>0
                combust =0
              end
              combust =0 if battler.effects[PBEffects::Protect] == true
              combust =0 if battler.pbOwnSide.effects[PBEffects::WideGuard] > 0
              combust-=1 if battler.effects[PBEffects::Endure] == true
              combust =0 if battler.effects[PBEffects::KingsShield] == true
              combust =0 if battler.effects[PBEffects::SpikyShield] == true
              combust =0 if battler.effects[PBEffects::MatBlock] == true
              battler.pbReduceHP(combust) if combust != 0
              battler.pbFaint if battler.isFainted?
            end
          else
            @battle.pbDisplay(_INTL("A Pokémon's Damp ability prevented a complete explosion!"))
          end
        end
      when 16 # Superheated Steam
        if (thismove.id == PBMoves::SURF || thismove.id == PBMoves::MUDDYWATER ||
            thismove.id == PBMoves::WATERPLEDGE || thismove.id == PBMoves::WATERSPOUT ||
            thismove.id == PBMoves::SPARKLINGARIA || thismove.id == PBMoves::HYDROPUMP)
          @battle.pbDisplay(_INTL("Steam shot up from the field!"))
          for i in 0...4
            canthit = 0
            invulcheck=PBMoveData.new(@battle.battlers[i].effects[PBEffects::TwoTurnAttack]).function
            case invulcheck
            when 0xC9, 0xCC, 0xCA, 0xCB, 0xCD, 0xCE
              canthit = 1
            end
            canthit =1 if @battle.battlers[i].effects[PBEffects::SkyDrop]
            if canthit = 0 && @battle.battlers[i].pbCanReduceStatStage?(PBStats::ACCURACY)
              @battle.battlers[i].pbReduceStatBasic(PBStats::ACCURACY,1)
              @battle.pbCommonAnimation("StatDown",@battle.battlers[i],nil)
              @battle.pbDisplay(_INTL("{1}'s accuracy fell!",@battle.battlers[i].pbThis))
            end
          end
        end
      when 20 # Ashen Beach Ash
        if (isConst?(thismove.type,PBTypes,:FLYING) && thismove.pbIsSpecial?(thismove.type)) ||
          (thismove.id == PBMoves::LEAFTORNADO || thismove.id == PBMoves::FIRESPIN ||
            thismove.id == PBMoves::TWISTER || thismove.id == PBMoves::RAZORWIND ||
            thismove.id == PBMoves::WHIRLPOOL)
          @battle.pbDisplay(_INTL("The attack stirred up the ash on the ground!"))
          for i in 0...4
            canthit = 0
            invulcheck=PBMoveData.new(@battle.battlers[i].effects[PBEffects::TwoTurnAttack]).function
            case invulcheck
            when 0xC9, 0xCC, 0xCA, 0xCB, 0xCD, 0xCE
              canthit = 1
            end
            canthit =1 if @battle.battlers[i].effects[PBEffects::SkyDrop]
            if canthit = 0 && @battle.battlers[i].pbCanReduceStatStage?(PBStats::ACCURACY)
              @battle.battlers[i].pbReduceStatBasic(PBStats::ACCURACY,1)
              @battle.pbCommonAnimation("StatDown",@battle.battlers[i],nil)
              @battle.pbDisplay(_INTL("{1}'s accuracy fell!",@battle.battlers[i].pbThis))
            end
          end
        end
      when 23 # Cave Collapse
        if (thismove.id == PBMoves::EARTHQUAKE || thismove.id == PBMoves::MAGNITUDE ||
            thismove.id == PBMoves::BULLDOZE)
          $fecounter += 1
          case $fecounter
          when 1
            @battle.pbDisplay(_INTL("Bits of rock fell from the crumbling ceiling!"))
          when 2
            @battle.pbDisplay(_INTL("The quake collapsed the ceiling!"))
            # Set Stealth Rocks for both sides
            for side in 0...2
              next if @battle.sides[side].effects[PBEffects::StealthRock]
              @battle.sides[side].effects[PBEffects::StealthRock]=true
            end
            @battle.pbDisplay(_INTL("Pointed stones float in the air!"))

            # Activate Stealth Rocks immediately - deal damage to all Pokemon
            for i in 0...4
              battler = @battle.battlers[i]
              next if battler.hp==0
              if battler.pbOwnSide.effects[PBEffects::StealthRock]
                if !battler.hasWorkingAbility(:MAGICGUARD) && !(battler.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44) && !battler.hasWorkingItem(:HEAVYDUTYBOOTS) && !battler.hasWorkingAbility(:LIMBER)
                  atype=getConst(PBTypes,:ROCK) || 0
                  eff=PBTypes.getCombinedEffectiveness(atype,battler.type1,battler.type2)
                  if eff>0
                    # Double damage on Cave Field
                    eff = eff*2
                    @battle.scene.pbDamageAnimation(battler,0)
                    battler.pbReduceHP([(battler.totalhp*eff/32).floor,1].max)
                    @battle.pbDisplay(_INTL("{1} was hurt by stealth rocks!",battler.pbThis))
                  end
                end
              end
              battler.pbFaint if battler.isFainted?
            end

            # Apply crushing status to all Pokemon
            for i in 0...4
              battler = @battle.battlers[i]
              next if battler.hp==0

              # Check invulnerability
              invulcheck=PBMoveData.new(battler.effects[PBEffects::TwoTurnAttack]).function
              case invulcheck
              when 0xC9, 0xCC, 0xCA, 0xCB, 0xCD, 0xCE # Fly, Bounce, Dig, Dive, Phantom Force, Shadow Force
                next
              end
              next if battler.effects[PBEffects::SkyDrop]
              next if battler.isbossmon

              # Check immunities
              if battler.hasWorkingAbility(:BATTLEARMOR) || battler.hasWorkingAbility(:SHELLARMOR) ||
                 battler.hasWorkingAbility(:SOLIDROCK) || battler.hasWorkingAbility(:PRISMARMOR) ||
                 battler.hasWorkingAbility(:BULLETPROOF) || battler.hasWorkingAbility(:ROCKHEAD) ||
                 @battle.SilvallyCheck(battler,PBTypes::ROCK)
                next
              end

              # Check protection
              if battler.effects[PBEffects::Protect] || battler.effects[PBEffects::WideGuard] ||
                 battler.effects[PBEffects::KingsShield] || battler.effects[PBEffects::SpikyShield] ||
                 battler.effects[PBEffects::MatBlock] || battler.pbOwnSide.effects[PBEffects::DuneDefense]>0
                next
              end

              # Endure, Miracle, Sturdy - survive at 1 HP instead of being crushed
              if battler.hasWorkingAbility(:STURDY) || battler.effects[PBEffects::Endure] ||
                 battler.hasWorkingAbility(:MIRACLE)
                if battler.hp > 1
                  @battle.scene.pbDamageAnimation(battler,0)
                  battler.pbReduceHP(battler.hp - 1)
                  @battle.pbDisplay(_INTL("{1} endured the cave-in!",battler.pbThis))
                end
                next
              end

              # Apply crushing status
              if battler.pbCanCrush?(false)
                battler.pbCrush(self)
                @battle.pbDisplay(_INTL("{1} was crushed by the falling rocks!",battler.pbThis))
              end
            end
            $fecounter = 0
          end
        end
      when 30 # Mirror Shatter
        if (thismove.id == PBMoves::EARTHQUAKE || thismove.id == PBMoves::BULLDOZE ||  thismove.id == PBMoves::MAGNITUDE ||
            thismove.id == PBMoves::BOOMBURST || thismove.id == PBMoves::HYPERVOICE)
          @battle.pbDisplay(_INTL("The mirror arena shattered!"))
          for i in 0...4
            shatter = @battle.battlers[i].totalhp
            next if shatter==0
            shatter/=2
            invulcheck=PBMoveData.new(@battle.battlers[i].effects[PBEffects::TwoTurnAttack]).function
            case invulcheck
            when 0xC9, 0xCC, 0xCA, 0xCB, 0xCD, 0xCE
              shatter = 0
            end
            shatter =0 if @battle.battlers[i].effects[PBEffects::SkyDrop]
            shatter =0 if @battle.battlers[i].hasWorkingAbility(:SHELLARMOR)
            shatter =0 if @battle.battlers[i].hasWorkingAbility(:BATTLEARMOR)
            shatter =0 if @battle.battlers[i].effects[PBEffects::Protect] == true
            shatter =0 if @battle.battlers[i].pbOwnSide.effects[PBEffects::WideGuard] > 0
            shatter =0 if @battle.battlers[i].effects[PBEffects::KingsShield] == true
            shatter =0 if @battle.battlers[i].effects[PBEffects::SpikyShield] == true
            shatter =0 if @battle.battlers[i].effects[PBEffects::MatBlock] == true
            @battle.battlers[i].pbReduceHP(shatter) if shatter != 0
            @battle.battlers[i].pbFaint if @battle.battlers[i].isFainted?
          end
        end
      when 33 # Flower Garden Stages
        tempcounter = $fecounter
        if (thismove.id == PBMoves::CUT)
          $fecounter-=1 if $fecounter > 0
        end
      when 38 # Dimensional
        combust = user.totalhp
        if combust!=0
          if (thismove.id == PBMoves::DIG || thismove.id == PBMoves::DIVE ||
              thismove.id == PBMoves::FLY || thismove.id == PBMoves::BOUNCE) &&
            user.effects[PBEffects::TwoTurnAttack] > 0
            combust-=1 if user.hasWorkingAbility(:STURDY)
            combust =0 if user.pbOwnSide.effects[PBEffects::WideGuard] > 0
            combust =0 if user.effects[PBEffects::MatBlock] == true
            @battle.pbDisplay(_INTL("The corrupted field damaged {1}!",user.pbThis)) if combust != 0
            user.pbReduceHP(combust) if combust != 0
            user.pbFaint if user.isFainted?
          end
        end
      when 41 # Corrupted Cave damage
        if (thismove.id == PBMoves::HEATWAVE ||
            thismove.id == PBMoves::BLASTBURN ||
            thismove.id == PBMoves::ERUPTION ||
            thismove.id == PBMoves::LAVAPLUME)
          dampcheck=0
          for i in 0...4
            dampcheck = 1 if (!@battle.battlers[i].abilitynulled && @battle.battlers[i].ability == PBAbilities::DAMP)
          end
          if dampcheck == 0
            for i in 0...4
              combust = (@battle.battlers[i].totalhp)/2
              next if combust==0
              invulcheck=PBMoveData.new(@battle.battlers[i].effects[PBEffects::TwoTurnAttack]).function
              case invulcheck
              when 0xC9, 0xCC, 0xCA, 0xCB, 0xCD, 0xCE
                combust = 0
              end
              combust =0 if @battle.battlers[i].effects[PBEffects::SkyDrop]
              #combust-=1 if @battle.battlers[i].hasWorkingAbility(:STURDY)
              combust =0 if @battle.battlers[i].hasWorkingAbility(:FLASHFIRE)
              if (@battle.battlers[i].isbossmon && @battle.shieldCount>0)
                combust =0
              elsif (@battle.battlers[i].isbossmon && @battle.shieldCount==0)
                combust = 0.5
              end
              combust =0 if @battle.battlers[i].effects[PBEffects::Protect] == true
              combust =0 if @battle.battlers[i].pbOwnSide.effects[PBEffects::WideGuard] > 0
              #combust-=1 if @battle.battlers[i].effects[PBEffects::Endure] == true
              combust =0 if @battle.battlers[i].effects[PBEffects::KingsShield] == true
              combust =0 if @battle.battlers[i].effects[PBEffects::SpikyShield] == true
              combust =0 if @battle.battlers[i].effects[PBEffects::MatBlock] == true
              @battle.battlers[i].pbReduceHP(combust) if combust != 0
              @battle.battlers[i].pbFaint if @battle.battlers[i].isFainted?
            end
          else
            @battle.pbDisplay(_INTL("A Pokémon's Damp ability prevented a complete explosion!"))
          end
        end
      end
      # FIELD TRANSFORMATIONS 2
      case $fefieldeffect
      when 2 # Grassy Field
        # Sludge Wave field transformation removed
      when 3 # Misty Field
        if (thismove.id == PBMoves::WHIRLWIND || thismove.id == PBMoves::GUST ||
            thismove.id == PBMoves::RAZORWIND || thismove.id == PBMoves::HURRICANE ||
            thismove.id == PBMoves::DEFOG || thismove.id == PBMoves::TWISTER ||
            thismove.id == PBMoves::TAILWIND)
          if $fefieldeffect == $febackup
            $fefieldeffect = 0
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mist was blown away!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
      when 4 # Dark Crystal Cavern
        if (thismove.id == PBMoves::EARTHQUAKE || thismove.id == PBMoves::BULLDOZE ||
            thismove.id == PBMoves::MAGNITUDE || thismove.id == PBMoves::TECTONICRAGE)
          $fecounter += 1
          case $fecounter
          when 1
            @battle.pbDisplay(_INTL("The crystals began to crack..."))
          when 2
            $fefieldeffect = 23
            $febackup = 23
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The crystals shattered!"))
            $fecounter = 0
            @battle.seedCheck
          end
        end
      when 7 # Burning Field
        if (thismove.id == PBMoves::WHIRLWIND || thismove.id == PBMoves::GUST ||
            thismove.id == PBMoves::RAZORWIND || thismove.id == PBMoves::DEFOG ||
            thismove.id == PBMoves::HURRICANE || thismove.id == PBMoves::TAILWIND)
          $fefieldeffect = 23
          $febackup = 23
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The wind snuffed out the flame!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::SURF || thismove.id == PBMoves::MUDDYWATER ||
            thismove.id == PBMoves::WATERSPOUT || thismove.id == PBMoves::WATERPLEDGE ||
            thismove.id == PBMoves::SPARKLINGARIA)
          if $fefieldeffect == $febackup
            $fefieldeffect = 23
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The water snuffed out the flame!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::SANDTOMB)
          if $fefieldeffect == $febackup
            $fefieldeffect = 23
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The sand snuffed out the flame!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::BLIZZARD)
          $fefieldeffect = 23
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The intense cold choked out the flames!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
      when 10 # Corrosive Field
        if (thismove.id == PBMoves::SEEDFLARE || thismove.id == PBMoves::PURIFY)
          $fefieldeffect = 2
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The polluted field was purified!"))
          @battle.seedCheck
        end
      when 11 # Corrosive Mist Field
        if (thismove.id == PBMoves::HEATWAVE || thismove.id == PBMoves::ERUPTION ||
            thismove.id == PBMoves::SEARINGSHOT || thismove.id == PBMoves::FLAMEBURST ||
            thismove.id == PBMoves::LAVAPLUME || thismove.id == PBMoves::FIREPLEDGE ||
            thismove.id == PBMoves::EXPLOSION || thismove.id == PBMoves::SELFDESTRUCT)
          if $fefieldeffect == $febackup
            $fefieldeffect = 0
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The toxic mist combusted!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::GUST || thismove.id == PBMoves::HURRICANE ||
            thismove.id == PBMoves::RAZORWIND || thismove.id == PBMoves::WHIRLWIND ||
            thismove.id == PBMoves::DEFOG || thismove.id == PBMoves::TWISTER ||
            thismove.id == PBMoves::TAILWIND)
          if $fefieldeffect == $febackup
            $fefieldeffect = 0
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mist was blown away!"))
          @battle.field.effects[PBEffects::Terrain]=0
          @battle.seedCheck
        end
      when 13 # Icy Field
        if (thismove.id == PBMoves::HEATWAVE || thismove.id == PBMoves::INCINERATE || thismove.id == PBMoves::ERUPTION ||
            thismove.id == PBMoves::SEARINGSHOT || thismove.id == PBMoves::FLAMEBURST ||
            thismove.id == PBMoves::LAVAPLUME || thismove.id == PBMoves::FIREPLEDGE ||
            thismove.id == PBMoves::LAVASURF)
            if $game_switches[1409] = true
                hazardsExist = false
                if user.pbOwnSide.effects[PBEffects::Spikes]>0 || user.pbOpposingSide.effects[PBEffects::Spikes]>0
                  user.pbOwnSide.effects[PBEffects::Spikes] = 0
                  user.pbOpposingSide.effects[PBEffects::Spikes] = 0
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::ToxicSpikes]>0 || user.pbOpposingSide.effects[PBEffects::ToxicSpikes]>0
                  user.pbOwnSide.effects[PBEffects::ToxicSpikes] = 0
                  user.pbOpposingSide.effects[PBEffects::ToxicSpikes] = 0
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::StealthRock] || user.pbOpposingSide.effects[PBEffects::StealthRock]
                  user.pbOwnSide.effects[PBEffects::StealthRock] = false
                  user.pbOpposingSide.effects[PBEffects::StealthRock] = false
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::StickyWeb] || user.pbOpposingSide.effects[PBEffects::StickyWeb]
                  user.pbOwnSide.effects[PBEffects::StickyWeb] = false
                  user.pbOpposingSide.effects[PBEffects::StickyWeb] = false
                  hazardsExist = true
                end
                if hazardsExist
                  @battle.pbDisplay(_INTL("Removed all hazards from the field!"))
                end
              $fefieldeffect = 21
              @battle.pbChangeBGSprite
              @battle.pbDisplay(_INTL("The ice melted away!"))
          elsif ($fefieldeffect == $febackup)
            $fecounter+=1
            if $fecounter==2
              $fefieldeffect = 23
              @battle.pbChangeBGSprite
              @battle.pbDisplay(_INTL("The ice melted away!"))
            end
          else
            if $febackup==21
              $fefieldeffect = 21
            elsif $febackup==26
              $fefieldeffect = 26
            else
              $fefieldeffect = 23
            end
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The ice melted away!"))
          end
          if $febackup==21 || $febackup==26
            hazardsExist = false
            if user.pbOwnSide.effects[PBEffects::Spikes]>0 || user.pbOpposingSide.effects[PBEffects::Spikes]>0
              user.pbOwnSide.effects[PBEffects::Spikes] = 0
              user.pbOpposingSide.effects[PBEffects::Spikes] = 0
              hazardsExist = true
            end
            if user.pbOwnSide.effects[PBEffects::ToxicSpikes]>0 || user.pbOpposingSide.effects[PBEffects::ToxicSpikes]>0
              user.pbOwnSide.effects[PBEffects::ToxicSpikes] = 0
              user.pbOpposingSide.effects[PBEffects::ToxicSpikes] = 0
              hazardsExist = true
            end
            if user.pbOwnSide.effects[PBEffects::StealthRock] || user.pbOpposingSide.effects[PBEffects::StealthRock]
              user.pbOwnSide.effects[PBEffects::StealthRock] = false
              user.pbOpposingSide.effects[PBEffects::StealthRock] = false
              hazardsExist = true
            end
            if user.pbOwnSide.effects[PBEffects::StickyWeb] || user.pbOpposingSide.effects[PBEffects::StickyWeb]
              user.pbOwnSide.effects[PBEffects::StickyWeb] = false
              user.pbOpposingSide.effects[PBEffects::StickyWeb] = false
              hazardsExist = true
            end
            if hazardsExist
              @battle.pbDisplay(_INTL("Removed all hazards from the field!"))
            end
          end
          @battle.seedCheck
        elsif (thismove.id == PBMoves::DIVE)
          if ($fefieldeffect != $febackup) && ($febackup==21 || $febackup==22 || $febackup==26)
            if $fecounter==3
              if $febackup==22
                $fefieldeffect = 21
              else
                $fefieldeffect = $febackup
              end
              @battle.pbRestoreFieldBack
              @battle.pbDisplay(_INTL("The ice was broken from underneath!"))
              @battle.seedCheck
              $fecounter=0
            end
          end
        end
        if (thismove.id == PBMoves::EARTHQUAKE || thismove.id == PBMoves::MAGNITUDE ||
            thismove.id == PBMoves::BULLDOZE)
            if $game_switches[1409] = true
                hazardsExist = false
                if user.pbOwnSide.effects[PBEffects::Spikes]>0 || user.pbOpposingSide.effects[PBEffects::Spikes]>0
                  user.pbOwnSide.effects[PBEffects::Spikes] = 0
                  user.pbOpposingSide.effects[PBEffects::Spikes] = 0
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::ToxicSpikes]>0 || user.pbOpposingSide.effects[PBEffects::ToxicSpikes]>0
                  user.pbOwnSide.effects[PBEffects::ToxicSpikes] = 0
                  user.pbOpposingSide.effects[PBEffects::ToxicSpikes] = 0
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::StealthRock] || user.pbOpposingSide.effects[PBEffects::StealthRock]
                  user.pbOwnSide.effects[PBEffects::StealthRock] = false
                  user.pbOpposingSide.effects[PBEffects::StealthRock] = false
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::StickyWeb] || user.pbOpposingSide.effects[PBEffects::StickyWeb]
                  user.pbOwnSide.effects[PBEffects::StickyWeb] = false
                  user.pbOpposingSide.effects[PBEffects::StickyWeb] = false
                  hazardsExist = true
                end
                if hazardsExist
                  @battle.pbDisplay(_INTL("Removed all hazards from the field!"))
                end
              $fefieldeffect = 21
              @battle.pbChangeBGSprite
            elsif $fefieldeffect == $febackup
              $fecounter+=1
              if $fecounter==2
                $fefieldeffect = 23
                @battle.pbChangeBGSprite
              end
            else #here
              if $febackup==21 || $febackup==26
                hazardsExist = false
                if user.pbOwnSide.effects[PBEffects::Spikes]>0 || user.pbOpposingSide.effects[PBEffects::Spikes]>0
                  user.pbOwnSide.effects[PBEffects::Spikes] = 0
                  user.pbOpposingSide.effects[PBEffects::Spikes] = 0
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::ToxicSpikes]>0 || user.pbOpposingSide.effects[PBEffects::ToxicSpikes]>0
                  user.pbOwnSide.effects[PBEffects::ToxicSpikes] = 0
                  user.pbOpposingSide.effects[PBEffects::ToxicSpikes] = 0
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::StealthRock] || user.pbOpposingSide.effects[PBEffects::StealthRock]
                  user.pbOwnSide.effects[PBEffects::StealthRock] = false
                  user.pbOpposingSide.effects[PBEffects::StealthRock] = false
                  hazardsExist = true
                end
                if user.pbOwnSide.effects[PBEffects::StickyWeb] || user.pbOpposingSide.effects[PBEffects::StickyWeb]
                  user.pbOwnSide.effects[PBEffects::StickyWeb] = false
                  user.pbOpposingSide.effects[PBEffects::StickyWeb] = false
                  hazardsExist = true
                end
                if hazardsExist
                  @battle.pbDisplay(_INTL("Removed all hazards from the field!"))
                end
                $fefieldeffect = $febackup
                @battle.pbChangeBGSprite
              else
                $fefieldeffect=23
                @battle.pbChangeBGSprite
              end
            end
            @battle.pbDisplay(_INTL("The quake broke up the ice!"))
            @battle.seedCheck
        end
      when 16 # Volcanic Top Field
        if (thismove.id == PBMoves::FLY || thismove.id == PBMoves::BOUNCE ||
            thismove.id == PBMoves::HEAVENLYWING)
          $fefieldeffect = 43
          $febackup = 43
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle was taken to the skies!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::BLIZZARD || thismove.id == PBMoves::GLACIATE)
          $fefieldeffect = 27
          $febackup = 27
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The fire on the field was put out!"))
          @battle.seedCheck
        end
        # eruption check
        if (thismove.id == PBMoves::BULLDOZE || thismove.id == PBMoves::EARTHQUAKE ||
            thismove.id == PBMoves::MAGNITUDE || thismove.id == PBMoves::ERUPTION ||
            thismove.id == PBMoves::PRECIPICEBLADES || thismove.id == PBMoves::LAVAPLUME ||
            thismove.id == PBMoves::LAVASURF || thismove.id == PBMoves::EARTHPOWER)
          @battle.eruption = true
          @battle.pbDisplay(_INTL("The volcano top erupted!"))
        elsif thismove.id == PBMoves::HOTTEMPO
          @battle.eruption = true
          @battle.pbDisplay(_INTL("The tremors from the attack caused the volcano top to erupt!"))
        end
      when 17 # Factory Field
        if (thismove.id == PBMoves::DISCHARGE  || thismove.id == PBMoves::IONDELUGE ||
            thismove.id == PBMoves::OVERDRIVE || thismove.id == PBMoves::AURAWHEEL)
          @battle.pbDisplay(_INTL("SYSTEM ONLINE."))
        end
        if (thismove.id == PBMoves::EXPLOSION || thismove.id == PBMoves::SELFDESTRUCT ||
            thismove.id == PBMoves::MAGNITUDE || thismove.id == PBMoves::EARTHQUAKE ||
            thismove.id == PBMoves::FISSURE || thismove.id == PBMoves::BULLDOZE)
          $febackup = 18
          $fefieldeffect = 18
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The field was broken!"))
          @battle.seedCheck
        end
      when 18 # Shortcircuit Field
        if (thismove.id == PBMoves::PARABOLICCHARGE || thismove.id == PBMoves::WILDCHARGE ||
            thismove.id == PBMoves::CHARGEBEAM)
          $febackup = 17
          $fefieldeffect = 17
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("SYSTEM ONLINE."))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::DISCHARGE || thismove.id == PBMoves::IONDELUGE ||
            thismove.id == PBMoves::OVERDRIVE || thismove.id == PBMoves::AURAWHEEL)
          @battle.pbDisplay(_INTL("The field shorted out!"))
        end
      when 21 # Water Surface
        if (thismove.id == PBMoves::DIVE || thismove.id == PBMoves::GRAVITY ||
            thismove.id == PBMoves::ANCHORSHOT || thismove.id == PBMoves::GRAVAPPLE)
          $fefieldeffect = 22
          $febackup = 22
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle was pulled underwater!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::BLIZZARD || thismove.id == PBMoves::GLACIATE)
          $febackup = 21
          $fefieldeffect = 13
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The water froze over!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::SLUDGEWAVE)
          $fecounter += 1
          case $fecounter
          when 1
            @battle.pbDisplay(_INTL("Poison spread through the water!"))
          when 2
            $fefieldeffect = 26
            $febackup = 26
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The water was polluted!"))
            $fecounter = 0
            @battle.seedCheck
          end
        end
      when 22 # Underwater
        if (thismove.id == PBMoves::DIVE || thismove.id == PBMoves::SKYDROP ||
            thismove.id == PBMoves::FLY || thismove.id == PBMoves::BOUNCE ||
            thismove.id == PBMoves::SHOREUP)
          $fefieldeffect = 21
          $febackup = 21
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle resurfaced!"))
          hazardsExist = false
          if user.pbOwnSide.effects[PBEffects::Spikes]>0 || user.pbOpposingSide.effects[PBEffects::Spikes]>0
            user.pbOwnSide.effects[PBEffects::Spikes] = 0
            user.pbOpposingSide.effects[PBEffects::Spikes] = 0
            hazardsExist = true
          end
          if user.pbOwnSide.effects[PBEffects::ToxicSpikes]>0 || user.pbOpposingSide.effects[PBEffects::ToxicSpikes]>0
            user.pbOwnSide.effects[PBEffects::ToxicSpikes] = 0
            user.pbOpposingSide.effects[PBEffects::ToxicSpikes] = 0
            hazardsExist = true
          end
          if user.pbOwnSide.effects[PBEffects::StealthRock] || user.pbOpposingSide.effects[PBEffects::StealthRock]
            user.pbOwnSide.effects[PBEffects::StealthRock] = false
            user.pbOpposingSide.effects[PBEffects::StealthRock] = false
            hazardsExist = true
          end
          if user.pbOwnSide.effects[PBEffects::StickyWeb] || user.pbOpposingSide.effects[PBEffects::StickyWeb]
            user.pbOwnSide.effects[PBEffects::StickyWeb] = false
            user.pbOpposingSide.effects[PBEffects::StickyWeb] = false
            hazardsExist = true
          end
          if hazardsExist
            @battle.pbDisplay(_INTL("Removed all hazards from field!"))
          end
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::SLUDGEWAVE)
          $fecounter += 1
          case $fecounter
          when 1
            @battle.pbDisplay(_INTL("Poison spread through the water!"))
          when 2
            $fefieldeffect = 26
            $febackup = 26
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The water was polluted!"))
            @battle.pbDisplay(_INTL("The grime sank beneath the battlers!"))
            $fecounter = 0
            @battle.seedCheck
          end
        end
      when 23 # Cave
        # Field transformations removed - Cave Field is now stable
      when 25 # Crystal Cavern
        if (thismove.id == PBMoves::DARKPULSE || thismove.id == PBMoves::DARKVOID ||
            thismove.id == PBMoves::NIGHTDAZE)
          $fefieldeffect = 4
          $febackup = 4
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The crystal's light was warped by the darkness!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::BULLDOZE || thismove.id == PBMoves::EARTHQUAKE ||
            thismove.id == PBMoves::MAGNITUDE)
          $fecounter += 1
          case $fecounter
          when 1
            @battle.pbDisplay(_INTL("The crystals are cracking..."))
          when 2
            $fefieldeffect = 23
            $febackup = 23
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The crystals were broken up!"))
            $fecounter = 0
            @battle.seedCheck
          end
        end
      when 26 # Murkwater Surface
        if (thismove.id == PBMoves::WHIRLPOOL)
          $fefieldeffect = 21
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The maelstrom flushed out the poison!"))
          hazardsExist = false
          if user.pbOwnSide.effects[PBEffects::Spikes]>0 || user.pbOpposingSide.effects[PBEffects::Spikes]>0
            user.pbOwnSide.effects[PBEffects::Spikes] = 0
            user.pbOpposingSide.effects[PBEffects::Spikes] = 0
            hazardsExist = true
          end
          if user.pbOwnSide.effects[PBEffects::ToxicSpikes]>0 || user.pbOpposingSide.effects[PBEffects::ToxicSpikes]>0
            user.pbOwnSide.effects[PBEffects::ToxicSpikes] = 0
            user.pbOpposingSide.effects[PBEffects::ToxicSpikes] = 0
            hazardsExist = true
          end
          if user.pbOwnSide.effects[PBEffects::StealthRock] || user.pbOpposingSide.effects[PBEffects::StealthRock]
            user.pbOwnSide.effects[PBEffects::StealthRock] = false
            user.pbOpposingSide.effects[PBEffects::StealthRock] = false
            hazardsExist = true
          end
          if user.pbOwnSide.effects[PBEffects::StickyWeb] || user.pbOpposingSide.effects[PBEffects::StickyWeb]
            user.pbOwnSide.effects[PBEffects::StickyWeb] = false
            user.pbOpposingSide.effects[PBEffects::StickyWeb] = false
            hazardsExist = true
          end
          if hazardsExist
            @battle.pbDisplay(_INTL("Removed all hazards from field!"))
          end

          @battle.seedCheck
        end
        if (thismove.id == PBMoves::PURIFY)
          $febackup = 21
          $fefieldeffect = 21
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The attack cleared the waters!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::BLIZZARD || thismove.id == PBMoves::GLACIATE)
          $febackup = 26
          $fefieldeffect = 13
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The toxic water froze over!"))
          @battle.seedCheck
        end
      when 27 # Mountain
        if (thismove.id == PBMoves::FLY || thismove.id == PBMoves::BOUNCE ||
            thismove.id == PBMoves::HEAVENLYWING)
          $fefieldeffect = 43
          $febackup = 43
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle was taken to the skies!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::BLIZZARD)
          $fefieldeffect = 28
          $febackup = 28
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mountain was covered in snow!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::LAVAPLUME || thismove.id == PBMoves::LAVASURF ||
            thismove.id == PBMoves::ERUPTION)
          $fefieldeffect = 16
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mountain erupted!"))
          @battle.seedCheck
        end
      when 28 # Snowy Mountain
        if (thismove.id == PBMoves::FLY || thismove.id == PBMoves::BOUNCE ||
            thismove.id == PBMoves::HEAVENLYWING)
          $fefieldeffect = 43
          $febackup = 43
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle was taken to the skies!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::HEATWAVE || thismove.id == PBMoves::FLAMEBURST ||
            thismove.id == PBMoves::LAVAPLUME || thismove.id == PBMoves::SEARINGSHOT ||
            thismove.id == PBMoves::FIREPLEDGE)
          $fefieldeffect = 27
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The snow melted away!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::ERUPTION || thismove.id == PBMoves::LAVASURF)
          $fefieldeffect = 16
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mountain erupted!"))
          @battle.seedCheck
        end
      when 29 # Holy
        if (thismove.id == PBMoves::PHANTOMFORCE || thismove.id == PBMoves::SHADOWFORCE)
          if $fefieldeffect == $febackup
            $fefieldeffect = 40
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("Evil spirits gathered!"))
        end
        if ((thismove.id == PBMoves::CURSE && (isConst?(user.type1,PBTypes,:GHOST) || isConst?(user.type2,PBTypes,:GHOST))) || thismove.id == PBMoves::OMINOUSWIND)
          $fecounter += 1
          case $fecounter
          when 1
            @battle.pbDisplay(_INTL("Dark energy seeps in..."))
          when 2
            if $fefieldeffect == $febackup
              $fefieldeffect = 40
            else
              $fefieldeffect = $febackup
            end
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("Evil spirits gathered!"))
          end
        end
      when 30 # Mirror
        if (thismove.id == PBMoves::EARTHQUAKE || thismove.id == PBMoves::BOOMBURST ||
            thismove.id == PBMoves::BULLDOZE || thismove.id == PBMoves::HYPERVOICE ||
            thismove.id == PBMoves::MAGNITUDE)
          $fefieldeffect = 0
          $febackup = 0
          @battle.pbChangeBGSprite
          @battle.seedCheck
        end
      when 32 # Dragon's Den
        if (thismove.id == PBMoves::MISTBALL)
          @battle.basefield = 0
          $fefieldeffect = 31
          $febackup = 31
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The mist-ical energy altered the surroundings!"))
          @battle.seedCheck
        end
      when 33 # Flower Garden Field
        if $fecounter >1
          if (thismove.id == PBMoves::HEATWAVE || thismove.id == PBMoves::ERUPTION ||
              thismove.id == PBMoves::SEARINGSHOT || thismove.id == PBMoves::FLAMEBURST ||
              thismove.id == PBMoves::LAVAPLUME || thismove.id == PBMoves::FIREPLEDGE) &&
            @battle.pbWeather != PBWeather::RAINDANCE
            $fecounter-=2
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The garden caught fire!"))
            @battle.seedCheck
          end
        end
        if tempcounter > $fecounter
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The garden was cut down a bit!"))
        end
      when 38 # Dimensional Rift
        if (thismove.id == PBMoves::BLIZZARD || thismove.id == PBMoves::COLDTRUTH ||
            thismove.id == PBMoves::ICEBURN || thismove.id == PBMoves::FREEZESHOCK ||
            thismove.id == PBMoves::GLACIATE || thismove.id == PBMoves::SHEERCOLD)
          $febackup = 39
          $fefieldeffect = 39
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The dimension froze up!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::SEEDFLARE || thismove.id == PBMoves::PURIFY) &&
          @battle.pbWeather != PBWeather::SHADOWSKY
          $febackup = 0
          $fefieldeffect = 0
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The dimension was purified!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::PRECIPICEBLADES)
          $fefieldeffect = 45
          $febackup = 45
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The field went up in flames!"))
          @battle.seedCheck
        end
      when 39 # Angie
        if (thismove.id == PBMoves::HEATWAVE || thismove.id == PBMoves::ERUPTION ||
            thismove.id == PBMoves::INFERNO || thismove.id == PBMoves::FLAMEBURST ||
            thismove.id == PBMoves::LAVAPLUME || thismove.id == PBMoves::BLASTBURN ||
            thismove.id == PBMoves::BURNUP || thismove.id == PBMoves::INFERNOOVERDRIVE)
          $febackup = 38
          $fefieldeffect = 38
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The dimension thawed away!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::PURIFY)
          $febackup = 13
          $fefieldeffect = 13
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The dimension cleared was purified!"))
          @battle.seedCheck
        end
      when 40 # Haunted
        if (thismove.id == PBMoves::JUDGMENT || thismove.id == PBMoves::SACREDFIRE ||
            thismove.id == PBMoves::ORIGINPULSE)
          if $fefieldeffect == $febackup
            $fefieldeffect = 29
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The evil spirits have been exorcised!"))
          @battle.seedCheck
        elsif (thismove.id == PBMoves::DAZZLINGGLEAM || thismove.id == PBMoves::FLASH || thismove.id == PBMoves::PURIFY)
          if $game_map.map_id!=111
            if $fefieldeffect == $febackup
              $fefieldeffect = 0
            else
              $fefieldeffect = $febackup
            end
            @battle.field.effects[PBEffects::Terrain]=3
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The evil spirits have been forced back!"))
            @battle.seedCheck
          end
        end
      when 41 # Corrupted cave
        if (thismove.id == PBMoves::SEEDFLARE || thismove.id == PBMoves::SOLARBEAM ||
            thismove.id == PBMoves::SOLARBLADE || thismove.id == PBMoves::PURIFY)
          if $fefieldeffect == $febackup
            $fefieldeffect = 23
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The cave was purified!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::HEATWAVE || thismove.id == PBMoves::BLASTBURN ||
            thismove.id == PBMoves::ERUPTION || thismove.id == PBMoves::LAVAPLUME ||
            thismove.id == PBMoves::INFERNOOVERDRIVE)
          if $fefieldeffect == $febackup
            $fefieldeffect = 7
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The cave's corruption combusted!"))
          @battle.seedCheck
        end
      when 42 # Bewitched Woods
        if (thismove.id == PBMoves::PURIFY)
          if $fefieldeffect == $febackup
            $fefieldeffect = 15
          else
            $fefieldeffect = $febackup
          end
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The evil spirits have been exorcised!"))
          @battle.seedCheck
        end
      when 43 # Sky Field
        if (thismove.id == PBMoves::GRAVITY || thismove.id == PBMoves::INGRAIN ||
            thismove.id == PBMoves::THOUSANDARROWS)
          $fefieldeffect = 27
          $febackup = 27
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The battle has been brought down to the mountains!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::SMACKDOWN || thismove.id == PBMoves::GRAVAPPLE)
          $fecounter += 1
          case $fecounter
          when 1
            @battle.pbDisplay(_INTL("Altitude is being lost!"))
          when 2
            $fefieldeffect = 27
            $febackup = 27
            @battle.pbChangeBGSprite
            @battle.pbDisplay(_INTL("The battle has been brought down to the mountains!"))
            $fecounter = 0
            @battle.seedCheck
          end
        end
      when 45 # Infernal Field
        if (thismove.id == PBMoves::JUDGMENT || thismove.id == PBMoves::ORIGINPULSE)
          $fefieldeffect = 7
          $febackup = 7
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The hellish landscape was purified!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::GLACIATE)
          $fefieldeffect = 39
          $febackup = 39
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The hellish landscape was doused of its fire!"))
          @battle.seedCheck
        end
      when 46 # Beach Field
        if (thismove.id == PBMoves::LAVAPLUME || thismove.id == PBMoves::ERUPTION)
          $fefieldeffect = 20
          $febackup = 20
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("Ash rains down on the beach!"))
          @battle.seedCheck
        end
        if (thismove.id == PBMoves::ORIGINPULSE || thismove.id == PBMoves::HYDROVORTEX)
          $fefieldeffect = 21
          $febackup = 21
          @battle.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The beach flooded!"))
          @battle.seedCheck
        end
      end
      #End Field Transformations
      # TODO: Sheer Force should prevent effects of items/abilities/moves that
      #       trigger here - which ones?
      if !((user.hasWorkingAbility(:SHEERFORCE) || @battle.SilvallyCheck(user,PBTypes::GROUND)) && thismove.addlEffect>0)
        # Shell Bell
        if user.hasWorkingItem(:SHELLBELL) && turneffects[PBEffects::TotalDamage]>0 && @effects[PBEffects::HealBlock]==0
          hpgain=user.pbRecoverHP([(turneffects[PBEffects::TotalDamage]/8).floor,1].max,true)
          if hpgain>0
            @battle.pbDisplay(_INTL("{1} restored a little HP using its Shell Bell!",user.pbThis))
          end
        end
        # Life Orb
        if user.hasWorkingItem(:LIFEORB) && turneffects[PBEffects::TotalDamage]>0 &&
          !user.hasWorkingAbility(:MAGICGUARD) && !(user.hasWorkingAbility(:WONDERGUARD) && $fefieldeffect == 44)
          lifeorbdamage=user.pbAdjustAbilityRecoilCrashDamage([(user.totalhp/10).floor,1].max)
          if user.effects[PBEffects::ShieldLife]>0
            hploss=lifeorbdamage
            @battle.pbShieldDamage(user,lifeorbdamage)
          else
            hploss=user.pbReduceHP(lifeorbdamage,true)
          end
          if hploss>0
            @battle.pbDisplay(_INTL("{1} lost some of its HP!",user.pbThis))
          end
        end
        # Counterweight - raises speed when using momentum moves
        if user.hasWorkingItem(:COUNTERWEIGHT) && PBStuff::MOMENTUMMOVE.include?(thismove.id)
          if user.pbCanIncreaseStatStage?(PBStats::SPEED,false)
            user.pbIncreaseStat(PBStats::SPEED,1,true)
			@battle.pbDisplay(_INTL("{1} gained speed with its Counterweight!",user.pbThis))
          end
        end
        user.pbFaint if user.isFainted? # no return
      end
      unless !thismove
        pbDancerMoveCheck(thismove.id) unless danced
      end
      thismove.pbApplyTributeAfterMove(user,targets,turneffects[PBEffects::TotalDamage],tribute_pre_stages,tribute_status_context,
        hit_targets: tribute_hit_targets) if thismove.respond_to?(:pbApplyTributeAfterMove)
      thismove.pbConsumeUsedGem(user)
      # Switch moves
      for i in @battle.battlers
        if i.userSwitch == true
          i.userSwitch = false
          shed_hp=i.effects[PBEffects::TributeOrthwormShedHP]
          i.effects[PBEffects::TributeOrthwormShedHP]=0
          if !(@battle.pbIsWild? && !@battle.pbOwnedByPlayer?(i.index))
            @battle.pbDisplay(_INTL("{1} went back to {2}!",i.pbThis,@battle.pbGetOwner(i.index).name))
          end
          newpoke=0
          newpoke=@battle.pbSwitchInBetween(i.index,true,false)
          @battle.pbMessagesOnReplace(i.index,newpoke)
          i.vanished=false
          i.pbResetForm
          @battle.pbReplace(i.index,newpoke,false)
          @battle.pbOnActiveOne(i)
          i.pbAbilitiesOnSwitchIn(true)
          if shed_hp>0 && !i.isFainted? && i.effects[PBEffects::Substitute]==0
            i.effects[PBEffects::Substitute]=shed_hp
            @battle.scene.pbSubstituteSprite(i,i.pbIsOpposing?(1)) if @battle.scene.respond_to?(:pbSubstituteSprite)
            @battle.pbDisplay(_INTL("{1} inherited a shed tail substitute!",i.pbThis))
          end
          if @battle.field.effects[PBEffects::WonderRoom] > 0
            if !(i.isFainted?)
              if i.wonderroom==false
                i.pbSwapDefenses
              end
            end
          end
        end
        if i.forcedSwitch == true
          i.forcedSwitch = false
          party=@battle.pbParty(i.index)
          active_indices=[]
          @battle.eachSameSideBattler(i.index) do |ally|
            active_indices.push(ally.pokemonIndex) if !ally.isFainted?
          end
          j=-1
          until j!=-1
            j=@battle.pbRandom(party.length)
            if !(party[j] && !party[j].isEgg? && party[j].hp>0 && !active_indices.include?(j))
              j=-1
            end
            if !@battle.pbCanSwitchLax?(i.index,j,false)
              j=-1
            end
          end
          newpoke=j#@battle.pbParty(i.index)[j]
          # newpoke=@battle.choices[@battle.pbRandom(@battle.choices.length)]
          i.vanished=false
          i.pbResetForm
          @battle.pbReplace(i.index,newpoke,false)
          @battle.pbOnActiveOne(i)
          i.pbAbilitiesOnSwitchIn(true)
          if @battle.field.effects[PBEffects::WonderRoom] > 0
            if !(i.isFainted?)
              if i.wonderroom==false
                i.pbSwapDefenses
              end
            end
          end
          @battle.pbDisplay(_INTL("{1} was dragged out!",i.pbThis))
          i.forcedSwitchEarlier = true
        end
      end
    end
    thismove.defense_curl_boost=false
    thismove.pbEndTributeAttack
    thismove.lock_on_boost=false
    thismove.fertilize_boost=false
    thismove.natural_order_boost=false
    thismove.pbFinishRedSunZenith(user) if thismove.respond_to?(:pbFinishRedSunZenith)
    if PokeBattle_Move_093::MAXIMIZED_FUNCTIONS.include?(thismove.function)
      user.effects[PBEffects::FeverPitchBoost]=false
    end
    if user.effects[PBEffects::LaserFocus]>0
      user.effects[PBEffects::LaserFocus]-=1
    end
    @battle.pbGainEXP
    # Battle Arena only - update skills
    for i in 0...4
      @battle.successStates[i].updateSkill
    end
    # Swalot Crest
    if isConst?(user.species,PBSpecies,:SWALOT) && user.hasWorkingItem(:SWACREST)
      if thismove.id == PBMoves::BELCH
        move=getConst(PBMoves,:SPITUP) || 0
        movename=PBMoves.getName(move)
        @battle.pbDisplay(_INTL("{1} used {2}!",user.pbThis,movename))
        user.pbUseMoveSimple(move)
      end
      if(thismove.id!=PBMoves::STOCKPILE && thismove.id!=PBMoves::SPITUP &&
          thismove.id!=PBMoves::SWALLOW) && user.effects[PBEffects::Stockpile] < 3
        user.effects[PBEffects::Stockpile]+=1
        @battle.pbDisplay(_INTL("{1} stockpiled {2}!",user.pbThis,
            user.effects[PBEffects::Stockpile]))
        showanim=true
        if user.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
          user.pbIncreaseStat(PBStats::DEFENSE,1,false,showanim)
          user.effects[PBEffects::StockpileDef]+=1
          showanim=false
        end
        if user.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
          user.pbIncreaseStat(PBStats::SPDEF,1,false,showanim)
          user.effects[PBEffects::StockpileSpDef]+=1
          showanim=false
        end
      end
    end
    # End of move usage
    thismove.azureAbilityCharge=false
    pbEndTurn(choice)
    @battle.pbJudgeSwitch
    return
  ensure
    @battle.icicleTributeBypass=previous_icicle_bypass
    @battle.pbMarkTributeOnceUsed(tribute_rampardos,:stone_priority) if tribute_rampardos
  end

  def pbCancelMoves
    # If failed pbTryUseMove or have already used Pursuit to chase a switching foe
    # Cancel multi-turn attacks (note: Hyper Beam effect is not canceled here)
    @effects[PBEffects::TwoTurnAttack]=0 if @effects[PBEffects::TwoTurnAttack]>0
    if @effects[PBEffects::SpookyTribute]!=0
      @battle.scene.pbUnVanishSprite(self) if vanished
      @effects[PBEffects::SpookyTribute]=0
      @spookyTributeLane=nil
    end
    @effects[PBEffects::Outrage]=0
    @effects[PBEffects::Rollout]=0
    @effects[PBEffects::Uproar]=0
    @currentMove=0
    # Reset counters for moves which increase them when used in succession
    @effects[PBEffects::FuryCutter]=0
    @effects[PBEffects::EchoedVoice]=0
  end

  ################################################################################
  # Turn processing
  ################################################################################
  def pbBeginTurn(choice)
    # Cancel some lingering effects which only apply until the user next moves
    @effects[PBEffects::DestinyBond]=false
    @effects[PBEffects::Grudge]=false
    # Encore's effect ends if the encored move is no longer available
    if @effects[PBEffects::Encore]>0 &&
      @moves[@effects[PBEffects::EncoreIndex]].id!=@effects[PBEffects::EncoreMove]
      PBDebug.log("[Resetting Encore effect]") if $INTERNAL
      @effects[PBEffects::Encore]=0
      @effects[PBEffects::EncoreIndex]=0
      @effects[PBEffects::EncoreMove]=0
    end
    # Wake up in an uproar
    if self.status==PBStatuses::SLEEP && !self.hasWorkingAbility(:SOUNDPROOF)
      for i in 0...4
        if @battle.battlers[i].effects[PBEffects::Uproar]>0 || @battle.battlers[i].effects[PBEffects::FeverPitch]==true
          pbCureStatus(false)
          @battle.pbDisplay(_INTL("{1} woke up in the uproar!",pbThis))
        end
      end
    end
  end

  def pbEndTurn(choice)
    @effects[PBEffects::Blinded]-=1 if @effects[PBEffects::Blinded]>0 #pk code
    @battle.pbResolveMirrorHerbs
    @effects[PBEffects::LiminalAttackThisMove]=false
    if @liminal_status_this_move
      @effects[PBEffects::LiminalStatusPriority]=false
      @liminal_status_this_move=false
    end
    @effects[PBEffects::SpookyTribute]=0 if @effects[PBEffects::SpookyTribute]==3
    pbDisableTributeDraco if @tributeDracoActive && @effects[PBEffects::TwoTurnAttack]==0
    # True end(?)
    if @effects[PBEffects::ChoiceBand]<0 && @lastMoveUsed>=0 && !self.isFainted? &&
      (self.hasWorkingItem(:CHOICEBAND) ||
        self.hasWorkingItem(:CHOICESPECS) ||
        self.hasWorkingItem(:CHOICESCARF) ||
        self.hasWorkingAbility(:GORILLATACTICS))
      @effects[PBEffects::ChoiceBand]=@lastMoveUsed
    end
    @battle.synchronize[0]=-1
    @battle.synchronize[1]=-1
    @battle.synchronize[2]=0
    @battle.eachActiveBattlerIndex do |i|
      battler=@battle.battlers[i]
      next if !battler
      battler.pbAbilityCureCheck
      battler.pbBerryCureCheck
      battler.pbAbilitiesOnSwitchIn(false)
      battler.pbCheckForm
    end
    @effects[PBEffects::ThunderRaidHit]=0
    self.missed = true
    self.missAcc = false
    self.grazed = false
    self.statLowered = false
  end

  def pbProcessTurn(choice)
    # Can't use a move if fainted
    return if self.isFainted?
    # Wild roaming PokÃ©mon always flee if possible
    if !@battle.opponent && @battle.pbIsOpposing?(self.index) &&
      @battle.rules["alwaysflee"] && @battle.pbCanRun?(self.index)
      pbBeginTurn(choice)
      @battle.pbDisplay(_INTL("{1} fled!",self.pbThis))
      @battle.decision=3
      pbEndTurn(choice)
      return
    end
    # If this battler's action for this round wasn't "use a move"
    if choice[0]!=1
      # Clean up effects that end at battler's turn
      pbBeginTurn(choice)
      pbEndTurn(choice)
      return
    end
	if choice[2].nil?
	  pbBeginTurn(choice)
	  pbEndTurn(choice)
	  return
	end
    # Turn is skipped if Pursuit was used during switch
    if @effects[PBEffects::Pursuit]
      @effects[PBEffects::Pursuit]=false
      pbCancelMoves
      pbEndTurn(choice)
      @battle.pbJudgeSwitch
      return
    end
    # Use the move
    if choice[2].zmove && !@effects[PBEffects::Flinch] && @status!=PBStatuses::SLEEP #pk code
      choice[2].zmove=false
      @battle.pbUseZMove(self.index,choice[2],self.item,choice[1])
    else
      choice[2].zmove=false if choice[2].zmove # For flinches
      #    @battle.pbDisplayPaused("Before: [#{@lastMoveUsedSketch},#{@lastMoveUsed}]")
      @battle.previousMove = @battle.lastMoveUsed
      @previousMove = @lastMoveUsed
      PBDebug.logonerr{
        pbUseMove(choice,choice[2]==@battle.struggle)
      }
    end
    #   @battle.pbDisplayPaused("After: [#{@lastMoveUsedSketch},#{@lastMoveUsed}]")
  end
  #### KUROTSUNE - 014 - START
  def pbSwapDefenses
    aux = @spdef
    @spdef = defense
    @defense = aux
    if @wonderroom
      @wonderroom = false
    else
      @wonderroom = true
    end
  end
  #### KUROTSUNE - 014 - END

  #### TGuilerrr - Boss Implementation

  def pbInitBoss(pkmn,index)
    bossdata = $bosscache
    boss = bossdata[pkmn.bossId]
    if boss.immunities
      @immunities = {
        :moves => [],
        :fieldEffectDamage => [],
      }
      immunitiesarray = []
      if boss.immunities[:moves]
        for i in boss.immunities[:moves]
          immunitiesarray.push(i)
        end
      end
      @immunities[:moves] = immunitiesarray
      immunitiesarray = []
      if boss.immunities[:fieldEffectDamage]
        for i in boss.immunities[:fieldEffectDamage]
          immunitiesarray.push(i)
        end
      end
      @immunities[:fieldEffectDamage] = immunitiesarray
    else
      @immunities = {
        :moves => [],
        :fieldEffectDamage => [],
      }
    end
    @onBreakEffects = boss.onBreakEffects
    @onEntryEffects = boss.onEntryEffects
    @barGraphic    = boss.barGraphic
    @entryText    = boss.entryText ? boss.entryText : nil
    if boss.chargeAttack
      @chargeAttack  = {}
      boss.chargeAttack.each do |key,value|
        @chargeAttack[key] = value
      end
    else
      @chargeAttack = nil
    end
    if boss.sosDetails
      @sosDetails = {}
      boss.sosDetails.each do |key,value|
        @sosDetails[key] = value
      end
    else
      @sosDetails = nil
    end
    if boss.randomSetChanges
      @randomSetChanges = {}
      boss.randomSetChanges.each do |key,value|
        @randomSetChanges[key] = value
      end
    else
      @randomSetChanges = nil
    end
    @name = boss.name unless boss.name == ""
    @shieldCount = pkmn.shieldCount
    @shieldsBroken = Array.new(pkmn.shieldCount,false)
    @shieldsBrokenThisTurn = [0,0,0,0]
    @currentSOS = 0
    @battle.typesequence = 0
    @capturable = boss.capturable ? boss.capturable : false
    @canrun = boss.canrun ? boss.canrun : false
    @battle.cantescape=true if !@canrun
  end

  #pk code
  attr_accessor :azureGlaiveRush
  attr_accessor :azureStatsRaisedThisRound
  attr_accessor :azureJetstream

  def azureHitsTaken
    counts=@battle.instance_variable_get(:@azure_hits_taken) || {}
    return counts[@pokemon.object_id] || 0
  end

  unless method_defined?(:azure_move_compat_pbInitialize)
    alias azure_move_compat_pbInitialize pbInitialize
    def pbInitialize(pkmn,index,batonpass)
      azureReleaseCommander
      @battle.azureReleaseJetstream(self) if @azureJetstream && !@fakebattler
      azure_move_compat_pbInitialize(pkmn,index,batonpass)
      @azureGlaiveRush=false
      @azureStatsRaisedThisRound=false
      @azureJetstream=nil
    end
  end

  def azureReleaseCommander(dondozo=@effects[PBEffects::Commander],tatsugiri=@effects[PBEffects::Commandee])
    if tatsugiri && tatsugiri.effects[PBEffects::Commander]==self
      tatsugiri.effects[PBEffects::Commander]=false
      tatsugiri.vanished=false
      @battle.scene.pbUnVanishSprite(tatsugiri) if !tatsugiri.isFainted?
    elsif dondozo && dondozo.effects[PBEffects::Commandee]==self
      dondozo.effects[PBEffects::Commandee]=false
    end
    @effects[PBEffects::Commander]=false
    @effects[PBEffects::Commandee]=false
  end

  def azureCommanderCheck
    return if isFainted? || !@battle.doublebattle
    return if @effects[PBEffects::Commander] || @effects[PBEffects::Commandee]
    return if @effects[PBEffects::TwoTurnAttack]>0
    if isConst?(species,PBSpecies,:TATSUGIRI)
      return if !hasWorkingAbility(:COMMANDER)
      partner_species=PBSpecies::DONDOZO
    elsif isConst?(species,PBSpecies,:DONDOZO)
      partner_species=PBSpecies::TATSUGIRI
    else
      return
    end
    partner=@battle.allSameSideBattlers(index).find do |other|
      other.species==partner_species && !other.isFainted? &&
        @battle.nearBattlers?(index,other.index) &&
        @battle.pbGetOwnerIndex(index)==@battle.pbGetOwnerIndex(other.index) &&
        !other.effects[PBEffects::Commander] && !other.effects[PBEffects::Commandee] &&
        other.effects[PBEffects::TwoTurnAttack]==0 &&
        (partner_species==PBSpecies::DONDOZO || other.hasWorkingAbility(:COMMANDER))
    end
    return if !partner
    if partner_species==PBSpecies::DONDOZO
      tatsugiri=self; dondozo=partner
    else
      tatsugiri=partner; dondozo=self
    end
    if tatsugiri.effects[PBEffects::Substitute]>0
      tatsugiri.effects[PBEffects::Substitute]=0
      @battle.scene.pbUnSubstituteSprite(tatsugiri,tatsugiri.pbIsOpposing?(1))
    end
    @battle.scene.pbVanishSprite(tatsugiri)
    tatsugiri.vanished=true
    @battle.pbDisplay(_INTL("{1} was swallowed by {2} and became its commander!",
      tatsugiri.pbThis,dondozo.pbThis(true)))
    choice=@battle.choices[tatsugiri.index]
    choice[2].zmove=false if choice[0]==1 && choice[2]
    @battle.choices[tatsugiri.index]=[0,0,nil,-1]
    tatsugiri.pbCancelMoves
    tatsugiri.effects[PBEffects::Commander]=dondozo
    dondozo.effects[PBEffects::Commandee]=tatsugiri
    @battle.pbWithStatChangeSource([:ability,PBAbilities::COMMANDER]) do
      [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,PBStats::SPATK,PBStats::SPDEF].each do |stat|
        dondozo.pbIncreaseStat(stat,2,false,:ABILITY,dondozo)
      end
    end
  end

  unless method_defined?(:azure_move_compat_pbAbilitiesOnSwitchIn)
    alias azure_move_compat_pbAbilitiesOnSwitchIn pbAbilitiesOnSwitchIn
    def pbAbilitiesOnSwitchIn(onactive,megad=false,gas_ended=false)
      ret=azure_move_compat_pbAbilitiesOnSwitchIn(onactive,megad,gas_ended)
      azureCommanderCheck
      return ret
    end
  end

  unless method_defined?(:azure_move_compat_pbFaint)
    alias azure_move_compat_pbFaint pbFaint
    def pbFaint(showMessage=true)
      dondozo=@effects[PBEffects::Commander]
      tatsugiri=@effects[PBEffects::Commandee]
      ret=azure_move_compat_pbFaint(showMessage)
      azureReleaseCommander(dondozo,tatsugiri) if ret && isFainted? && (dondozo || tatsugiri)
      return ret
    end
  end

  unless method_defined?(:azure_move_compat_pbBeginTurn)
    alias azure_move_compat_pbBeginTurn pbBeginTurn
    def pbBeginTurn(choice)
      @azureGlaiveRush=false
      azure_move_compat_pbBeginTurn(choice)
    end
  end

  unless method_defined?(:azure_move_compat_pbReducePP)
    alias azure_move_compat_pbReducePP pbReducePP
    def pbReducePP(move)
      beforepp=move.pp
      ret=azure_move_compat_pbReducePP(move)
      if ret && beforepp>0 && move.pp==beforepp-1 && move.pp>0 &&
         pbOwnSide.effects[PBEffects::PressurePlate]>0
        pbSetPP(move,move.pp-1)
      end
      return ret
    end
  end

  def azureConsumeNeedle
    return false if @effects[PBEffects::Needles]<=0 || isFainted?
    @effects[PBEffects::Needles]-=1
    @battle.scene.pbDamageAnimation(self,0)
    if !hasWorkingAbility(:MAGICGUARD) &&
       !(hasWorkingAbility(:WONDERGUARD) && $fefieldeffect==44)
      pbReduceHP([(@totalhp/8).floor,1].max)
    end
    @battle.pbDisplay(_INTL("A needle tore into {1}!",pbThis(true)))
    return true
  end
end
