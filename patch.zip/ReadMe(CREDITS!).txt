#########CREDITS##############

If your name is missing, PLEASE contact me and I will update this list immediately.

Special thanks to Pokemon Rejuvenation and the Calamity League, this wouldn't be possible without their support, and go check them out!

--------Developers--------
Lead Developer: pkchu, darius, vincenzonova, treeckoz, liridium, ace
Artists: cheselth, sparkie, pixelrosas, chase, rat, anting
Composers: daforlynx, Rust
Writers: Fe = Iron
Mappers: riru, mice, bluemoon
Scripting: tguiller
Balancing: pingu, clue
Wiki: lexa

--------Former Developers--------
badman, cervys, candii, onion, dada

--------Playtesters--------
Zervixen
TridentGreen
SleepyBoi
Shinyrio
ShinyGolem
Ryouyashi
ReintendoO
Pingu
Orion89
R--
Martenaizor
Liridium
kaleidoscope
LEmonetteee_
Julius Caesar
Deeffect
couchchurro
chxxo
Badman
Pyuku
AceTrainerDevin
A11
DemICE
Moto
Azery
SG
Mizz
Commander
Glow
BIGFriv

--------Pok�mon--------
Gamefreak/Nintendo
The Pok�mon Company
--------Tiles--------
Amethyst and the Reborn Team
Janichroma and the Rejuvenation Team
Juno & Ice and the Floral Tempus Team
Magiscarf
KingTapir
IcyCatElf
Alucus
PeekyChew
Kyle Dove
Dewitty
CNC
Zetavares852
Lark125
ThatsSoWitty
xAlien95
UltimoSpriter
Heavy-Metal-Lover
WesleyFG
XDinky
Newtiteuf
Erma96
Hydrargirium
Poison-Master
Thedeadheroalistair
Shutwig
Asdsimone
Xxdevil
Steinnaples
Hek-el-grande
sylver1984
NikNak93
TeaAddiction
Cuddlesthefatcat
Gigatom
The-Red-eX
ChaoticCherryCake
rayd12smitty
GlitchxCity
Zeak6464
TapuFini
SpartaLazor
leparagon
Bulbapedia
Serebii
M3rein
BlackOutG5
Rune
Rigbycwts
Rot8ter_ConeX
James Davy
Luka-SJ
THECubberx
Akizakura16
Carmaniac
Jan
CNickC
The Musical Ghost
WolfPP
mybusiness
Leparagon
N-Kin
Conyjams
Smogon
SelenaArmorclaw
FishbowlSoul90
Princess-Pheonix
Drawn-Mario
WilsonScarloxy
LaPampa-Fr
Zeo254
Mewmore
Kalalokki
RadicalCharizard
NoelleMBrooks
Anarlaurendil
Kingofthe-x-roads
Smogon
Smash 27
BIGFriv
--------Graphics--------
Pokemon Desolation Team
Janichroma
Maruno&Pkmn Essentials Team
Amethyst
Juno& Ice
No.XII
Senpai Diego
Alistair
Clara-WaH
Pyrolusite
StargazerSammie
Ekat
SacredDragonair
ChaoticCherryCake
PrincessPhoenix
ranko
Sorrow-Divine (https://twitter.com/sorrowdivine)
AerunFE (https://twitter.com/aerunfe)
hut (https://twitter.com/huttaburger)
Crimson (https://twitter.com/crimcrimart)
Dewdneym (https://twitter.com/Dewndeym)
AnonAlpaca
Lichen
Alexandre
-------Animations--------
Reborn Animation Team:
Smeargletail
Robin
Amethyst
Mde
Cass
Vulpes
-------Shiny Sprites-------
Alex
Bluedodobob
Dypatome
Might Gai
Njab
Atticus
Korvpizza
Hycrox
Guzam
Kiteruguma/Bibs
Cyanna Cyril
Siragon
Jan
EliteFlyingTaco
MakaTorracat
Zumi
Azery
Bazaro
rentalrafflesia
Arkiel
Desaya
Kmk
Trevore
BIGJRA
Anti_Hero
ycoder321
DreamblitzX
Tartar
Felcatty
foznkr
Cool Girl
Phi-Bi
jmanultrax1
WSGreen
Amine elhedili/Another Retired Shipper
DeathBoo
luis
Sceptilespy
Candy
MOLVEGQ
--------Maps--------
Juno & Ice and the Floral Tempus Team (Meadow Temple)
--------Music--------
GlitchXCity
NickOleksiak
Solkrieg
The Ophidians
xxxshadowgiratinaxxx
TheGuitahHeroe
Pianoman91894
LightUmbreon
KunningFox
Zumi
Anthos
Glaf Glorf
Kamex
vanilluxePavilion
insanetherainmusic
--------Scripting--------
Pokemon Rejuvenation Team
Maruno(Pkmn Essentials)
Amethyst(PBS files/Field Effect concept)
Kurotsune(Backup save system)
Sardines
DemICE(In-battle info script)
Cassie Rose
Calamity League (Field Effects)
--------Generation 8 Addition--------
ActionReplayer
Pokemon Trainer Jackey
www.pokecommunity.com
Project: Generation 6 for Pok�mon Essentials (Pok�mon sprites and PBS files)
See the discussion at Pok�Community!
www.pokecommunity.com
Noscium
Quanyails
Zermonious
GeoIsEvil
Kyle Dove
dDialgaDiamondb
N-kin
Misterreno
Kevfin
Xtreme1992
Vale98PM
Branflakes325
Dreadwing93
Amethyst
Jan
Zumi
Bazaro
Koyo
Smeargletail
Noscium
Lepagon
N-kin
fishbowlsoul90
princess-phoenix
SageDeoxys
Kyle-Dove
DatLopunnyTho
Conyjams
kaji atsu
The cynical poet
LuigiPlayer
Falgaia of the Smogon S/M sprite project
Pikafan2000
Lord-Myre
Lepargon
Amethyst
conyjams
KingOfThe-X-Roads
Crocovyle
Cynda
InvoluntaryTwitch
zlolxd
mjco
G.E.Z.
--Mega Sprites:
Julian
Amethyst
Gardrow
FlameJow
The Cynical Poet
Minhnerd
Branflakes325
--------Tutorials------
Thundaga
-FL-
HelioAu
Playerin
Amethyst
--------Scripting Help--------
Cass
Jan
DemICE
Moto
Falirion
Azery
Commander
BIGFriv
--------Pok�mon Essentials-----------
Poccil
Flameguru
Maruno
FL.
P-Sign
